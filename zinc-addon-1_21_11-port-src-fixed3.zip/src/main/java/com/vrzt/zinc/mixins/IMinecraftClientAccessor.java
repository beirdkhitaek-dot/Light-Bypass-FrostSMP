package com.vrzt.zinc.mixins;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.session.ProfileKeys;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MinecraftClient.class})
public interface IMinecraftClientAccessor {
   @Accessor("attackCooldown")
   void setAttackCooldown(int var1);

   @Accessor("itemUseCooldown")
   void setItemUseCooldown(int var1);

   @Mutable
   @Accessor("profileKeys")
   void setProfileKeys(ProfileKeys var1);

   @Accessor("mouse")
   Mouse getMouse();

   @Invoker("doAttack")
   boolean invokeDoAttack();

   @Invoker("doItemUse")
   void invokeDoItemUse();
}
