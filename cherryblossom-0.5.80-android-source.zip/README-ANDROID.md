# Cherry Blossom 0.5.80-android

Changes on top of 0.5.80:

1. **Device key storage (non-Windows).** `DeviceIdentity` no longer throws "requires Windows". On Android/Linux/macOS the
   device key is kept in an owner-only file (`~/.cherryblossom/device/device-key-v1.json`) instead of DPAPI. The license
   check itself is unchanged: the client still contacts the license server, and the server decides whether this device is
   bound/allowed. A new Android device is a new device to the server, so you may need staff to bind or reset it.
2. **Spotify HUD on non-Windows via the Spotify Web API** (`SpotifyApiSource`).
   - Create an app at developer.spotify.com, add redirect URI `http://127.0.0.1:8888/callback`.
   - Put the Client ID in `config/cherryblossom/spotify/spotify-api.json`: `{"client_id":"..."}`
   - Enable the Spotify HUD. A login link is copied to the clipboard and posted in chat; open it in your phone browser
     and approve. The refresh token is saved in the same file.
   - Prev/play-pause/next need Spotify Premium.
   - Windows behavior is unchanged (media-session helper).

Status: not built or run on a device. `SpotifyNowPlaying`/`SpotifyHudRenderer` edits were not compiled (need Minecraft libs).

Build note: the workflow builds the `source/` module only. The merged client jar needs the base Cherry GUI jar and the
Windows `build.ps1`, which are not part of this source.

## Last.fm source (no login)
Instead of Spotify login you can use Last.fm now-playing. Get a free API key at last.fm/api/account/create and put in
`config/cherryblossom/spotify/spotify-api.json`:
`{"client_id":"","lastfm_api_key":"YOUR_KEY","lastfm_user":"YOUR_USERNAME"}`
Shows title, artist and cover art. Last.fm cannot control playback, so the HUD buttons do nothing in this mode.
(Your Spotify/other player must scrobble to Last.fm for it to show up.)
