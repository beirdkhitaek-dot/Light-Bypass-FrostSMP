package dev.cherryblossom.client.render;

import cherryblossom.integration.ToggleNotifications;
import dev.cherryblossom.client.ui.Theme;
import net.minecraft.class_310;
import net.minecraft.class_408;
import org.joml.Matrix4f;

/** Compact Anubis bar layout using Cherry's existing font atlas, canvas and theme. */
public final class ToggleToastRenderer {
    public static void render(){
        var mc=class_310.method_1551();var toasts=ToggleNotifications.snapshot();
        if(toasts.isEmpty()||!UiResources.ready()||mc.field_1690.field_1842)return;
        var window=mc.method_22683();int width=window.method_4489(),height=window.method_4506();
        float scale=Math.max(.55f,Math.min(1.3f,height/1080f));float bottom=height-(mc.field_1755 instanceof class_408?14*window.method_4495()+6*scale:10*scale);
        Theme.beginFrame();var fonts=UiResources.atlas();long now=System.nanoTime();
        try(UiCanvas canvas=new UiCanvas()){
            canvas.begin(ScreenSurface.INSTANCE);
            for(int i=toasts.size()-1;i>=0;i--){
                var toast=toasts.get(i);float elapsed=(now-toast.since())/1_000_000_000f;
                float progress=Math.max(0,Math.min(1,elapsed/.16f));if(elapsed>2.16f)progress=Math.max(0,1-(elapsed-2.16f)/.18f);
                float h=28*scale,w=fonts.medium.width(toast.name(),17*scale)+fonts.regular.width("off",14*scale)+45*scale,y=bottom-h*progress,x=10*scale-(1-progress)*(w+12*scale);
                int alpha=Math.round(235*progress);canvas.roundRect(x,y,w,h,6*scale,(alpha<<24)|0x231C24);
                canvas.roundRectStroke(x,y,w,h,6*scale,scale,Theme.alpha(Theme.accentBright(),.22f*progress));
                canvas.textMiddle(fonts.medium,toast.name(),x+12*scale,y+h/2,17*scale,Theme.alpha(0xFFF6EFF3,progress));
                canvas.roundRect(x+w-43*scale,y+8*scale,scale,12*scale,0,Theme.alpha(0xFFAE9BA7,.35f*progress));
                canvas.textRight(fonts.regular,toast.enabled()?"on":"off",x+w-12*scale,y+h/2,14*scale,Theme.alpha(toast.enabled()?Theme.accentBright():0xFFBFAFBA,progress));
                bottom-=h*progress+6*scale;
            }
            canvas.flush(mc.method_1522().method_71639(),new Matrix4f(),CherryBlossomGpu.get().screenProjection.method_71092((float)width,(float)height),0,1);
        }
    }
    private ToggleToastRenderer(){}
}
