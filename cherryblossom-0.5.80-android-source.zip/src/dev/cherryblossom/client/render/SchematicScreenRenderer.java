package dev.cherryblossom.client.render;

import cherryblossom.feature.AutoSchematicBuilderModule;
import cherryblossom.schematic.SchematicSetupScreen;
import dev.cherryblossom.client.render.text.FontAtlas;
import dev.cherryblossom.client.ui.Theme;
import dev.cherryblossom.client.sound.CherryBlossomSounds;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.List;

/** A compact schematic setup page rendered with the client's existing SDF fonts and glass theme. */
public final class SchematicScreenRenderer {
    private static final float W=840,H=480;
    private static State state;
    private record Request(Object page,AutoSchematicBuilderModule module,int width,int height,int mx,int my,boolean preview){}
    private static Request request;
    private record Hit(float x,float y,float w,float h,Runnable action){boolean inside(float px,float py){return px>=x&&py>=y&&px<x+w&&py<y+h;}}
    private static final class State{
        Object page;AutoSchematicBuilderModule module;List<String> files;List<Hit> hits=new ArrayList<>();
        float left,top,scale,sx,sy,mx,my,scroll;
        State(Object page,AutoSchematicBuilderModule module){this.page=page;this.module=module;files=AutoSchematicBuilderModule.files();}
        float x(double scaled){return ((float)scaled*sx-left)/scale;}
        float y(double scaled){return ((float)scaled*sy-top)/scale;}
    }
    public static boolean render(Object page,AutoSchematicBuilderModule module,int scaledW,int scaledH,int mx,int my){
        request=new Request(page,module,scaledW,scaledH,mx,my,false);return UiResources.ready();
    }
    public static boolean preview(Object page,AutoSchematicBuilderModule module,int scaledW,int scaledH,int mx,int my){request=new Request(page,module,scaledW,scaledH,mx,my,true);return UiResources.ready();}
    public static void renderLate(){
        Request r=request;if(r!=null&&class_310.method_1551().field_1755==r.page)drawPage(r.page,r.module,r.width,r.height,r.mx,r.my,r.preview);
    }
    private static boolean drawPage(Object page,AutoSchematicBuilderModule module,int scaledW,int scaledH,int mx,int my,boolean preview){
        if(!UiResources.ready())return false;
        if(state==null||state.page!=page)state=new State(page,module);State s=state;
        var mc=class_310.method_1551();var window=mc.method_22683();int width=window.method_4489(),height=window.method_4506();
        float fit=Math.min(width/(W+70),height/(H+70));
        float preference=(float)(cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue()/100);
        s.scale=fit*Math.min(1,Math.max(.6f,preference));s.left=(width-W*s.scale)/2;s.top=(height-H*s.scale)/2;
        s.sx=width/(float)Math.max(1,scaledW);s.sy=height/(float)Math.max(1,scaledH);s.mx=s.x(mx);s.my=s.y(my);s.hits.clear();
        Theme.beginFrame();FontAtlas f=UiResources.atlas();
        try(UiCanvas c=new UiCanvas()){
            c.begin(ScreenSurface.INSTANCE);if(!preview)c.roundRect(0,0,width,height,0,0x550B0710);c.push();c.translate(s.left,s.top);c.scale(s.scale,0,0);
            if(preview)drawPreview(c,f,s);else draw(c,f,s);
            c.pop();c.flush(mc.method_1522().method_71639(),new Matrix4f(),CherryBlossomGpu.get().screenProjection.method_71092((float)width,(float)height),0,1);
        }
        return true;
    }
    private static void drawPreview(UiCanvas c,FontAtlas f,State s){
        int accent=Theme.accentBright(),muted=0xFFCCB9C7;var module=s.module;String[] info=module.loadedInfo();
        float top=-s.top/s.scale+18,bottom=(class_310.method_1551().method_22683().method_4506()-s.top)/s.scale-58;
        c.roundRect(0,top,440,90,14,Theme.tint(0xE62C1B28));c.roundRectStroke(0,top,440,90,14,1,Theme.alpha(accent,.25f));
        c.icon("cube",false,25,top+25,19,accent);c.textFit(f.semibold,module.selectedFile(),45,top+25,16,375,-1);
        c.textMiddle(f.regular,info==null?"Schematic preview":info[1]+"  ·  "+module.placedCount()+" / "+module.targetCount()+" placed",18,top+50,11,muted);
        int[] offset=module.offset();c.textMiddle(f.medium,"Rotation "+module.rotationDegrees()+"°   ·   Offset "+offset[0]+" / "+offset[1]+" / "+offset[2],18,top+72,10,muted);
        c.roundRect(0,bottom,W,40,12,Theme.tint(0xED2C1B28));c.roundRectStroke(0,bottom,W,40,12,1,Theme.alpha(accent,.25f));
        c.textMiddle(f.medium,"Drag to orbit  ·  Scroll to zoom",16,bottom+20,10.5f,0xFFE9DCE5);
        c.textCentered(f.medium,"R  Rotate    Arrows / PgUp / PgDn  Move",W/2,bottom+20,10,muted);
        c.textRight(f.semibold,"Enter  Build    Esc  Close",W-16,bottom+20,10.5f,accent);
    }
    private static void draw(UiCanvas c,FontAtlas f,State s){
        var module=s.module;int accent=Theme.accentBright(),muted=0xFFBFAEBC;
        c.shadow(0,0,W,H,20,26,0x77000000);
        c.roundRectGradient(0,0,W,H,20,Theme.tint(0xF0442839),Theme.tint(0xF0251821));
        c.roundRectStroke(0,0,W,H,20,1,Theme.alpha(accent,.28f));
        c.roundRect(22,21,40,40,12,Theme.alpha(accent,.16f));c.icon("cube",false,42,41,22,accent);
        c.textMiddle(f.semibold,"Auto SchematicBuilder",76,32,19,-1);
        c.textMiddle(f.regular,"Pick a schematic, position it, then build.",76,53,11,muted);
        button(c,f,s,780,24,36,32,"x","",false,()->((SchematicSetupScreen)s.page).method_25419());
        c.roundRect(22,77,796,1,0,0x17FFFFFF);
        c.textMiddle(f.semibold,"Schematics",26,103,13,-1);
        c.textRight(f.medium,Integer.toString(s.files.size()),300,103,11,muted);
        c.roundRect(22,122,286,250,12,0x28000000);
        float max=Math.max(0,s.files.size()*42-240);s.scroll=Math.max(0,Math.min(max,s.scroll));
        c.pushClip(27,127,276,240);
        for(int i=0;i<s.files.size();i++){
            String file=s.files.get(i);float y=128+i*42-s.scroll;if(y+39<127||y>367)continue;
            boolean selected=file.equals(module.selectedFile()),hover=s.mx>=28&&s.mx<302&&s.my>=Math.max(y,127)&&s.my<Math.min(y+38,367);
            if(selected||hover)c.roundRect(28,y,274,38,8,selected?Theme.alpha(accent,.21f):0x10FFFFFF);
            c.icon(selected?"check":"file",false,45,y+19,14,selected?accent:muted);
            c.textFit(f.medium,file.replaceFirst("(?i)\\.(schem|litematic)$",""),60,y+14,11.5f,225,selected?-1:0xFFDFCFDA);
            c.textMiddle(f.regular,file.toLowerCase().endsWith(".litematic")?"Litematica":"Sponge schematic",60,y+28,8.5f,muted);
            float top=Math.max(y,127),bottom=Math.min(y+38,367);
            s.hits.add(new Hit(28,top,274,bottom-top,()->module.selectFile(file)));
        }
        if(s.files.isEmpty()){
            c.icon("folder",false,165,207,30,Theme.alpha(accent,.75f));
            c.textCentered(f.medium,"No schematics yet",165,245,13,-1);
            c.textCentered(f.regular,"Add .schem or .litematic files",165,268,10,muted);
            c.textCentered(f.regular,"using Open folder below.",165,284,10,muted);
        }
        c.popClip();
        button(c,f,s,22,383,137,32,"folder","Open folder",false,()->((SchematicSetupScreen)s.page).openFolder());
        button(c,f,s,169,383,139,32,"arrow-clockwise","Refresh",false,()->s.files=AutoSchematicBuilderModule.files());
        c.roundRect(328,94,1,321,0,0x12FFFFFF);
        String[] info=module.loadedInfo();
        c.textMiddle(f.semibold,"Build options",350,103,13,-1);
        c.textFit(f.semibold,module.selectedFile().isEmpty()?"Choose a schematic":module.selectedFile(),350,135,16,440,-1);
        c.textMiddle(f.regular,!module.preparationStatus().isEmpty()?module.preparationStatus():info==null?"Choose a file, anchor it, then start.":info[1]+"  ·  "+info[2]+"  ·  "+(module.layerByLayer.get()?"bottom to top":"adaptive"),350,159,11,muted);
        String anchor=module.anchor()==null?"Not anchored":module.anchor().method_10263()+"  /  "+module.anchor().method_10264()+"  /  "+module.anchor().method_10260();
        c.roundRect(350,180,456,56,11,0x1A000000);
        c.textMiddle(f.medium,"Anchor",365,197,10,muted);c.textMiddle(f.medium,anchor,365,218,12,-1);
        button(c,f,s,648,190,146,36,"map-pin","Place at feet",false,module::placeAtFeet);
        c.textMiddle(f.medium,"Rotation",350,260,11,muted);
        for(int i=0;i<4;i++){
            int angle=i*90;boolean chosen=module.rotationDegrees()==angle;
            button(c,f,s,443+i*92,244,86,32,"",angle+"°",chosen,()->{for(int n=0;n<4&&module.rotationDegrees()!=angle;n++)module.rotateQuarter();});
        }
        c.textMiddle(f.medium,"Offset",350,299,11,muted);
        int[] offsets=module.offset();String[] labels={"X","Y","Z"};
        for(int i=0;i<3;i++){
            int axis=i;float x=350+i*155;
            c.roundRect(x,316,146,36,10,0x22000000);
            c.textMiddle(f.medium,labels[i]+"  "+(offsets[i]>0?"+":"")+offsets[i],x+44,334,12,-1);
            button(c,f,s,x+3,320,30,28,"","−",false,()->nudge(module,axis,-1));
            button(c,f,s,x+113,320,30,28,"","+",false,()->nudge(module,axis,1));
        }
        button(c,f,s,350,372,145,39,"",module.human.get()?"Natural: On":"Natural: Off",module.human.get(),()->module.setNaturalMovement(!module.human.get()));
        button(c,f,s,503,372,155,39,"",module.layerByLayer.get()?"Layers: On":"Layers: Off",module.layerByLayer.get(),()->module.setLayerByLayer(!module.layerByLayer.get()));
        button(c,f,s,666,372,140,39,"eye","3D preview",false,()->{if(module.readyToBuild())module.openPreviewScreen();});
        c.roundRect(22,429,796,1,0,0x17FFFFFF);
        c.textMiddle(f.regular,"J  Anchor     K  Start / pause     O  Preview",26,452,10,muted);
        String status=!module.preparationStatus().isEmpty()?module.preparationStatus():module.readyToBuild()?(module.layerByLayer.get()?"Bottom to top":"Adaptive build"):module.creativeMode()?"Creative inventory":module.needs().size()+" material types";
        c.textRight(f.regular,status,595,452,10,muted);
        boolean ready=module.readyToBuild();
        button(c,f,s,616,439,190,30,module.isBuilding()?"pause":"play",module.isBuilding()?"Pause building":"Start building",ready,()->{
            if(module.loadedInfo()!=null){boolean start=!module.isBuilding();module.setBuildingFromScreen(start);if(start)((SchematicSetupScreen)s.page).start();}
        });
    }
    private static void nudge(AutoSchematicBuilderModule module,int axis,int delta){module.nudge(axis==0?delta:0,axis==1?delta:0,axis==2?delta:0);}
    private static void button(UiCanvas c,FontAtlas f,State s,float x,float y,float w,float h,String icon,String label,boolean primary,Runnable action){
        boolean hover=s.mx>=x&&s.mx<x+w&&s.my>=y&&s.my<y+h;
        int accent=Theme.accentBright();c.roundRect(x,y,w,h,9,primary?Theme.alpha(accent,hover?.95f:.8f):hover?0x22FFFFFF:0x0BFFFFFF);
        c.roundRectStroke(x,y,w,h,9,1,primary?Theme.alpha(accent,.5f):0x14FFFFFF);
        int text=primary?Theme.tint(0xFF38202D):0xFFEADDE6;
        if(!icon.isEmpty())c.icon(icon,false,x+(label.isEmpty()?w/2:19),y+h/2,14,text);
        if(!label.isEmpty())c.textCentered(f.medium,label,x+w/2+(icon.isEmpty()?0:8),y+h/2,11,text);
        s.hits.add(new Hit(x,y,w,h,action));
    }
    public static boolean click(Object page,double x,double y){
        if(state==null||state.page!=page)return false;State s=state;float mx=s.x(x),my=s.y(y);
        for(Hit hit:List.copyOf(s.hits))if(hit.inside(mx,my)){CherryBlossomSounds.play(CherryBlossomSounds.CLICK,.7f);hit.action.run();return true;}return false;
    }
    public static boolean scroll(Object page,double x,double y,double amount){
        if(state==null||state.page!=page)return false;State s=state;float mx=s.x(x),my=s.y(y);
        if(mx>=22&&mx<=308&&my>=122&&my<=372){s.scroll-=amount*42;return true;}return false;
    }
    public static void closed(Object page){if(state!=null&&state.page==page)state=null;if(request!=null&&request.page==page)request=null;}
}
