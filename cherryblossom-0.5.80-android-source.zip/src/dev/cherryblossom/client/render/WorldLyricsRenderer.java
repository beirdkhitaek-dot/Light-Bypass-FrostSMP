package dev.cherryblossom.client.render;

import cherryblossom.feature.WorldLyricsModule;
import dev.cherryblossom.client.ui.Theme;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.*;
import net.minecraft.class_1011;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Camera-facing world surface, with cached Unicode-capable lyric typography. */
public final class WorldLyricsRenderer {
    private static final PanelSurface SURFACE=new PanelSurface(900,220);
    private static final Map<String,UiTexture> TEXT=new LinkedHashMap<>(16,.75f,true);
    private static Font font;
    private WorldLyricsRenderer(){}
    public static void render(WorldLyricsModule module,Matrix4f view,Matrix4f projection,Vector3f forward,Vector3f right,Vector3f up){
        if(!UiResources.ready())return;var d=module.display();if(d.title().isBlank()||module.hidePaused()&&!d.playing())return;
        String line=d.line();if(line.isBlank()&&!d.status().equals("ready")){if(!module.statusMessages())return;line=d.status();}
        if(line.isBlank()&&d.next().isBlank())return;
        var mc=class_310.method_1551();Theme.beginFrame();
        SURFACE.radius=0;SURFACE.pixelSize=.002f*module.textScale();SURFACE.right.set(right);SURFACE.up.set(up);SURFACE.forward.set(forward).negate();
        SURFACE.center.set(forward).mul((float)module.distance()).fma((float)module.height(),up).fma((float)module.horizontal(),right);
        try(var c=new UiCanvas()){
            c.begin(SURFACE);c.pushAlpha(module.opacity());
            if(module.background()){c.shadow(0,0,900,210,28,20,0x33000000);c.roundRect(0,0,900,210,28,Theme.alpha(0xFF211923,.78f));c.roundRectStroke(0,0,900,210,28,1,Theme.alpha(Theme.accentBright(),.24f));}
            if(module.songDetails())drawText(c,d.title()+"  ·  "+d.artist(),450,20,18,780,Theme.alpha(0xFFF4E9F1,.55f));
            drawText(c,line,450,70,45,820,0xFFF9F2F7);
            if(module.nextLine()&&!d.next().isBlank())drawText(c,d.next(),450,140,28,780,Theme.alpha(Theme.accentBright(),.6f));
            c.popAlpha();
            c.flush(mc.method_1522().method_71639(),module.throughWalls()?null:mc.method_1522().method_71640(),view,CherryBlossomGpu.get().worldProjection.method_71123(projection),(float)(System.nanoTime()/1e9),.92f,true);
        }
    }
    private static UiTexture texture(String text){
        UiTexture cached=TEXT.get(text);if(cached!=null)return cached;
        try{
            if(font==null)try(InputStream in=WorldLyricsRenderer.class.getResourceAsStream("/assets/cherryblossom/fonts/Montserrat-Medium.ttf")){font=Font.createFont(Font.TRUETYPE_FONT,in).deriveFont(64f);}
            Font use=font.canDisplayUpTo(text)<0?font:new Font(Font.DIALOG,Font.PLAIN,64);
            BufferedImage probe=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);Graphics2D pg=probe.createGraphics();pg.setFont(use);int width=Math.max(4,Math.min(4096,pg.getFontMetrics().stringWidth(text)+16));pg.dispose();
            BufferedImage image=new BufferedImage(width,96,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();
            try{g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,RenderingHints.VALUE_FRACTIONALMETRICS_ON);g.setFont(use);g.setColor(Color.WHITE);g.drawString(text,8,72);}finally{g.dispose();}
            try(class_1011 pixels=new class_1011(width,96,false)){
                for(int y=0;y<96;y++)for(int x=0;x<width;x++)pixels.method_61941(x,y,image.getRGB(x,y));
                cached=UiTexture.upload("world lyrics",pixels,false,RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
            }
            TEXT.put(text,cached);while(TEXT.size()>12){var it=TEXT.entrySet().iterator();var entry=it.next();entry.getValue().close();it.remove();}return cached;
        }catch(Exception error){return null;}
    }
    private static void drawText(UiCanvas c,String text,float center,float y,float size,float maxWidth,int color){
        if(text==null||text.isBlank())return;var t=texture(text);if(t==null)return;
        float height=size*1.5f,width=height*t.width()/t.height();if(width>maxWidth){height*=maxWidth/width;width=maxWidth;}
        c.image(t.view(),t.sampler(),center-width/2,y,width,height,0,color);
    }
    public static void release(){for(var texture:TEXT.values())texture.close();TEXT.clear();}
}
