package dev.cherryblossom.client.donut;

import dev.cherryblossom.client.module.Category;
import dev.cherryblossom.client.module.Module;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

/** Compatibility for preserved GUI calls; the removed module loads no model or audio. */
public final class DrDonutt extends Module {
    public static final String ID="drdonutt";
    private static final DrDonutt INSTANCE=new DrDonutt();
    public DrDonutt(){super(ID,"DrDonutt","","disco-ball",Category.RENDER);}
    public static DrDonutt get(){return INSTANCE;}
    public void summon(){}
    public double danceTime(double time){return 0;}
    public String animation(){return "Idle";}
    public boolean following(){return false;}
    public class_243 feet(){return null;}
    public double radius(){return 0;}
    public DonutRenderer renderer(){return null;}
    public void tick(class_310 client){}
    public void pointedAt(boolean value){}
    public double pick(class_243 origin,class_243 direction){return -1;}
    public boolean beginDrag(class_746 player,float tick){return false;}
    public boolean drag(class_746 player,float tick){return false;}
    public void push(float amount){}
    public void endDrag(){}
    public class_243 grabPoint(){return null;}
    public void renderWorld(){}
}
