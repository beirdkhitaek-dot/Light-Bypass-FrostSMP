package dev.cherryblossom.client.ui;

import dev.cherryblossom.client.render.UiCanvas;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import cherryblossom.feature.UiPalette;

/** One colour source shared by the Cherry interface, tree and native HUD. */
public final class Theme {
    public static final int SIDEBAR=-16116700, CONTENT=-15853269, CARD=-15655115, CARD_HOVER=-15061687,
        CARD_PRESSED=-15919063, SHEET=-15655891, FIELD=-15128515, CONTROL_OFF=-13549224,
        ONLINE=-9574335, DOCK=-233499369, DOCK_HOVER=-14013393, TEXT=-1,
        TEXT_SECONDARY=-5196872,TEXT_MUTED=-7697007,DIVIDER=0x1FFFFFFF,SHADOW=-1728053248,DANGER=-42390;
    public static final float PANEL_RADIUS=22,CARD_RADIUS=16;
    private static final Map<Integer,Integer> TINTS=new HashMap<>();
    private static int palette=0xFFFF8FBD;
    private Theme(){}
    public static void beginFrame(){int color=accentBright();if(color!=palette){palette=color;TINTS.clear();}}
    public static int accentBright(){return UiPalette.accent(1);}
    public static int accent(){return mix(accentBright(),0xFF000000,.38f);}
    public static int cursor(){return mix(accentBright(),-1,.35f);}
    public static int alpha(int color,float alpha){return color&0xFFFFFF|Math.round((color>>>24)*Math.max(0,Math.min(1,alpha)))<<24;}
    public static int mix(int a,int b,float t){return UiCanvas.lerpColor(a,b,t);}
    public static int tint(int original){return TINTS.computeIfAbsent(original,Theme::recolor);}
    private static int recolor(int color){
        int r=(color>>16)&255,g=(color>>8)&255,b=color&255;
        if(!(r>g+4&&b>g+3&&r>=b*.87f))return color;
        if((palette&0xFFFFFF)==0xFF8FBD)return color;
        float[] old=Color.RGBtoHSB(r,g,b,null),target=Color.RGBtoHSB((palette>>16)&255,(palette>>8)&255,palette&255,null);
        float hue=(target[0]+old[0]-.93006f+1)%1;
        float saturation=Math.min(.95f,old[1]*(target[1]/.43922f));
        return color&0xFF000000|Color.HSBtoRGB(hue,saturation,old[2])&0xFFFFFF;
    }
}
