/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3532
 */
package dev.cherryblossom.client.ui;

import dev.cherryblossom.client.CherryBlossomController;
import dev.cherryblossom.client.module.Category;
import dev.cherryblossom.client.module.Module;
import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.render.UiCanvas;
import dev.cherryblossom.client.render.text.FontAtlas;
import dev.cherryblossom.client.setting.BoolSetting;
import dev.cherryblossom.client.setting.CherryBlossomSettings;
import dev.cherryblossom.client.setting.ColorSetting;
import dev.cherryblossom.client.setting.KeySetting;
import dev.cherryblossom.client.setting.ModeSetting;
import dev.cherryblossom.client.setting.Setting;
import dev.cherryblossom.client.setting.SettingsStore;
import dev.cherryblossom.client.setting.SliderSetting;
import dev.cherryblossom.client.setting.TextSetting;
import dev.cherryblossom.client.setting.TotemPickerSetting;
import dev.cherryblossom.client.setting.ModuleResetSetting;
import dev.cherryblossom.client.setting.BlockPickerSetting;
import dev.cherryblossom.client.sound.CherryBlossomSounds;
import dev.cherryblossom.client.ui.CherryBlossomMark;
import dev.cherryblossom.client.ui.Ease;
import dev.cherryblossom.client.ui.MainPanel;
import dev.cherryblossom.client.ui.Spring;
import dev.cherryblossom.client.ui.TextField;
import dev.cherryblossom.client.ui.Theme;
import dev.cherryblossom.client.ui.UiAnimations;
import dev.cherryblossom.client.ui.UiInput;
import dev.cherryblossom.client.ui.Widgets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_3532;

final class ClickGui {
    private final MainPanel panel;
    private final ConfigPanel configs = new ConfigPanel();
    private final UiAnimations anim = new UiAnimations();
    private final DropdownLayout dropdown = new DropdownLayout(this,this.anim);
    private final Spring open = new Spring(0.0f, 15.0f);
    private final Set<String> expanded = new HashSet<String>();
    private final Map<String, Float> expandFrame = new HashMap<String, Float>();
    private float scroll;
    private float scrollTarget;
    private final TextField search = new TextField(48);
    private final TextField textEditor = new TextField(4096);
    private TextSetting editingText;
    private boolean textJustOpened;
    private List<Category> wheelCategories;
    private String wheelPageTitle;
    private String wheelPageIcon;
    private final TextField wheelSearch = new TextField(48);
    private int wheelFocus;
    private boolean wheelKeyboardNavigation;
    private boolean wheelInteracted;
    private float wheelScroll;
    private float wheelScrollTarget;
    private static final int WHEEL_HIGHLIGHT = -34633;
    private static final int WHEEL_ROSE = -14372;
    private static final int WHEEL_TEXT_MUTED = -1917232;
    private static final float[] TREE_TRUNK = new float[]{0.0f, 292.0f, 34.0f, -2.0f, 253.0f, 31.0f, -4.0f, 213.0f, 27.0f, -1.0f, 174.0f, 23.0f, 2.0f, 135.0f, 19.0f, 0.0f, 94.0f, 15.0f, 0.0f, 52.0f, 12.0f, 0.0f, 10.0f, 10.0f, 0.0f, -38.0f, 8.0f, 0.0f, -83.0f, 6.0f, 0.0f, -123.0f, 5.0f};
    private static final float[] TREE_LEFT = new float[]{0.0f, -8.0f, 13.0f, -35.0f, -24.0f, 12.0f, -76.0f, -51.0f, 10.0f, -122.0f, -72.0f, 8.0f, -170.0f, -85.0f, 5.0f};
    private static final float[] TREE_RIGHT = new float[]{0.0f, -8.0f, 13.0f, 36.0f, -24.0f, 12.0f, 78.0f, -51.0f, 10.0f, 124.0f, -72.0f, 8.0f, 170.0f, -85.0f, 5.0f};
    private static final float[] TREE_LEFT_FORK = new float[]{-89.0f, -56.0f, 9.0f, -111.0f, -81.0f, 7.0f, -133.0f, -117.0f, 5.0f, -159.0f, -142.0f, 3.0f};
    private static final float[] TREE_RIGHT_FORK = new float[]{91.0f, -56.0f, 9.0f, 113.0f, -81.0f, 7.0f, 135.0f, -117.0f, 5.0f, 161.0f, -142.0f, 3.0f};
    private static final float[] TREE_LOW_LEFT = new float[]{0.0f, 111.0f, 18.0f, -42.0f, 108.0f, 15.0f, -82.0f, 91.0f, 11.0f, -112.0f, 75.0f, 8.0f, -144.0f, 72.0f, 5.0f};
    private static final float[] TREE_LOW_RIGHT = new float[]{0.0f, 111.0f, 18.0f, 42.0f, 108.0f, 15.0f, 82.0f, 91.0f, 11.0f, 112.0f, 75.0f, 8.0f, 144.0f, 72.0f, 5.0f};
    private static final float[][] TREE_CANOPY = new float[][]{{-171.0f, -64.0f, 47.0f}, {-143.0f, -113.0f, 55.0f}, {-99.0f, -156.0f, 58.0f}, {-52.0f, -184.0f, 55.0f}, {0.0f, -194.0f, 60.0f}, {52.0f, -184.0f, 55.0f}, {99.0f, -156.0f, 58.0f}, {143.0f, -113.0f, 55.0f}, {171.0f, -64.0f, 47.0f}, {-162.0f, -16.0f, 45.0f}, {-119.0f, -28.0f, 60.0f}, {-64.0f, -49.0f, 66.0f}, {0.0f, -52.0f, 83.0f}, {64.0f, -49.0f, 66.0f}, {119.0f, -28.0f, 60.0f}, {162.0f, -16.0f, 45.0f}};
    private static final float[][] TREE_BLOSSOMS = new float[][]{{-215.0f, -72.0f, 0.7f}, {-181.0f, -119.0f, 0.58f}, {-145.0f, -58.0f, 0.72f}, {-108.0f, -111.0f, 0.62f}, {-62.0f, -91.0f, 0.66f}, {-18.0f, -144.0f, 0.55f}, {39.0f, -104.0f, 0.7f}, {88.0f, -140.0f, 0.55f}, {136.0f, -72.0f, 0.68f}, {184.0f, -119.0f, 0.6f}, {216.0f, -55.0f, 0.67f}, {-128.0f, -143.0f, 0.5f}, {-77.0f, -166.0f, 0.52f}, {-29.0f, -72.0f, 0.52f}, {23.0f, -168.0f, 0.48f}, {79.0f, -76.0f, 0.54f}, {127.0f, -133.0f, 0.48f}, {-153.0f, -15.0f, 0.48f}, {-86.0f, -25.0f, 0.48f}, {78.0f, -18.0f, 0.5f}, {151.0f, -26.0f, 0.46f}};
    private static final float[][] WHEEL_NODE_OFFSETS = new float[][]{{-170.0f, -85.0f}, {0.0f, -123.0f}, {170.0f, -85.0f}, {-144.0f, 72.0f}, {144.0f, 72.0f}, {0.0f, 164.0f}};

    ClickGui(MainPanel panel) {
        this.panel = panel;
    }

    void resumeLayout(){
        closeTextEditor();configs.close();TotemPickerPanel.close();backToWheel();
    }

    boolean positionLocked() {
        return CherryBlossomSettings.PANEL_POSITION_LOCKED.on();
    }

    void positionLocked(boolean locked) {
        CherryBlossomSettings.PANEL_POSITION_LOCKED.set(locked);
    }

    void wheelMode(boolean enabled) {
        CherryBlossomSettings.CLICK_GUI_LAYOUT.set(enabled ? "Wheel" : "Dropdown");
        closeTextEditor();configs.close();TotemPickerPanel.close();CherryBlossomController.get().unfocusText(wheelSearch);
        SettingsStore.saveNow();
        this.wheelCategories = null;
        this.wheelPageTitle = null;
        this.wheelPageIcon = null;
        this.wheelSearch.clear();
        this.wheelScroll = 0.0f;
        this.wheelScrollTarget = 0.0f;
    }

    private boolean wheelMode() {
        return CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Wheel");
    }

    boolean onWheelKey(int key, int action) {
        if(editingText!=null){if(action==1&&key==256){closeTextEditor();return true;}return false;}
        if(configs.isOpen()){if(action==1&&key==256)configs.close();return true;}
        if(TotemPickerPanel.key(key,action))return true;
        if (!this.wheelMode() || action != 1) {
            return false;
        }
        if (key == 256 && this.wheelCategories != null) {
            this.backToWheel();
            return true;
        }
        if (this.wheelCategories != null) {
            return false;
        }
        int count = this.wheelEntries().size();
        if (key == 263 || key == 265) {
            this.wheelFocus = (this.wheelFocus + count - 1) % count;
            this.wheelKeyboardNavigation = true;
            return true;
        }
        if (key == 262 || key == 264) {
            this.wheelFocus = (this.wheelFocus + 1) % count;
            this.wheelKeyboardNavigation = true;
            return true;
        }
        if (key == 257 || key == 335 || key == 32) {
            this.openWheelEntry(this.wheelEntries().get(this.wheelFocus));
            return true;
        }
        return false;
    }

    boolean onWheelEscape() {
        if(editingText!=null){closeTextEditor();return true;}
        if(configs.isOpen()){configs.close();return true;}
        if(TotemPickerPanel.isOpen()){TotemPickerPanel.close();return true;}
        if (!this.wheelMode()) {
            return false;
        }
        if (this.wheelCategories != null) {
            this.backToWheel();
            return true;
        }
        return false;
    }

    private void backToWheel() {
        this.wheelCategories = null;
        this.wheelPageTitle = null;
        this.wheelPageIcon = null;
        this.wheelSearch.clear();
        CherryBlossomController.get().unfocusText(this.wheelSearch);
        this.wheelScroll = 0.0f;
        this.wheelScrollTarget = 0.0f;
    }

    private void openWheelEntry(WheelEntry entry) {
        this.wheelInteracted = true;
        this.wheelCategories = entry.categories();
        this.wheelPageTitle = entry.title();
        this.wheelPageIcon = entry.icon();
        this.wheelSearch.clear();
        this.wheelScroll = 0.0f;
        this.wheelScrollTarget = 0.0f;
        CherryBlossomSounds.play(CherryBlossomSounds.TAB, 0.7f);
    }

    void render(UiCanvas c, UiInput in, FontAtlas f, float time) {
        Theme.beginFrame();
        if(cherryblossom.module.modules.client.CherryBlossom.animationMode.getModeIndex()==2)time=0;
        UiInput originalInput=in;
        if(TotemPickerPanel.isOpen()||editingText!=null)in=UiInput.INERT;
        float motion = CherryBlossomSettings.CLICK_GUI_MOTION.floatValue();
        float dt = Math.min(0.05f, CherryBlossomController.get().frameDelta() * motion);
        this.anim.beginFrame(dt);
        float reveal = Ease.outCubic(this.open.target(1.0f).update(dt));
        for (Category category : Category.values()) {
            for (Module module : ModuleManager.of(category)) {
                String id = module.id();
                this.expandFrame.put(id, Float.valueOf(this.anim.get("clickgui." + id + ".expand", this.expanded.contains(id), 8.0f * motion)));
            }
        }
        c.pushAlpha(reveal);
        if(this.wheelMode()){
            if(configs.isOpen()){
                this.drawWheelScene(c,in,f,time,320,276,.88f,false);
                configs.render(c,in,f);
            }else if(this.wheelCategories==null)this.drawWheel(c,in,f,time);
            else this.drawWheelModules(c,in,f,dt,time);
            this.drawConfigButton(c,in,f);
            this.drawWheelFooter(c,in,f);
        }else{
            dropdown.render(c,configs.isOpen()?UiInput.INERT:in,f,time);
            this.drawConfigButton(c,configs.isOpen()?UiInput.INERT:in,f);
            if(configs.isOpen()){
                c.roundRect(0,0,1240,580,22,0x77000000);
                configs.renderAt(c,in,f,339,65,"Back");
            }
        }
        TotemPickerPanel.render(c,originalInput,f);
        if(editingText!=null)drawTextEditor(c,originalInput,f);
        c.popAlpha();
    }
    private void openTextEditor(TextSetting setting){
        editingText=setting;textEditor.setText(setting.get());textEditor.selectAll();textJustOpened=true;
        textEditor.onSubmit(value->saveTextEditor());CherryBlossomController.get().focusText(textEditor);
    }
    private void closeTextEditor(){
        CherryBlossomController.get().unfocusText(textEditor);editingText=null;textJustOpened=false;
    }
    private void saveTextEditor(){
        if(editingText!=null){editingText.set(textEditor.text());SettingsStore.markDirty();SettingsStore.saveNow();}
        closeTextEditor();
    }
    private void drawTextEditor(UiCanvas c,UiInput input,FontAtlas f){
        UiInput in=textJustOpened?UiInput.INERT:input;textJustOpened=false;
        c.roundRect(0,0,1240,580,22,0x88000000);
        c.shadow(300,185,640,210,18,22,0x77000000);
        c.roundRectGradient(300,185,640,210,18,Theme.tint(0xF0442839),Theme.tint(0xF0251821));
        c.roundRectStroke(300,185,640,210,18,1,Theme.alpha(Theme.accentBright(),.4f));
        c.textMiddle(f.semibold,editingText.name(),322,216,17,-1);
        c.textMiddle(f.regular,"Enter a value, then save. Esc cancels.",322,240,10.5f,0xFFCDB5C5);
        c.roundRect(322,263,596,42,10,0x33000000);
        c.roundRectStroke(322,263,596,42,10,1,Theme.alpha(Theme.accentBright(),.55f));
        String shown=Widgets.tail(f.regular,textEditor.text(),12,560);
        if(textEditor.allSelected())c.roundRect(334,274,Math.min(566,f.regular.width(shown,12)+5),20,3,Theme.alpha(Theme.accentBright(),.25f));
        float end=c.textMiddle(f.regular,shown,335,284,12,-1);
        if(textEditor.caretVisible()&&!textEditor.allSelected())c.rect(end+1,276,1,16,Theme.accentBright());
        in.hover("textedit.field",322,263,596,42);if(in.clicked("textedit.field"))CherryBlossomController.get().focusText(textEditor);
        if(ConfigPanel.button(c,in,f,"textedit.cancel","Cancel",696,334,104,35,true))closeTextEditor();
        else if(ConfigPanel.button(c,in,f,"textedit.save","Save",812,334,106,35,true))saveTextEditor();
    }
    String dropdownQuery(){return wheelSearch.text();}
    float dropdownExpansion(Module module){return Math.max(0,Math.min(1,expandFrame.getOrDefault(module.id(),0f)));}
    boolean dropdownExpanded(Module module){return expanded.contains(module.id());}
    void dropdownExpand(Module module){if(!expanded.add(module.id()))expanded.remove(module.id());CherryBlossomSounds.play(CherryBlossomSounds.CLICK,.65f);}
    void dropdownSearchBlur(UiInput in){if(in.pressed&&CherryBlossomController.get().isFocused(wheelSearch)&&!"wheel.search".equals(in.hovered()))CherryBlossomController.get().unfocusText(wheelSearch);}
    private void drawBackground(UiCanvas c, float time) {
        String background;
        if (this.wheelMode()) {
            return;
        }
        c.roundRect(0.0f, 0.0f, 1240.0f, 580.0f, 22.0f, Theme.tint(-267906012));
        int palette = switch (background = (String)CherryBlossomSettings.CLICK_GUI_BACKGROUND.get()) {
            case "Nebula" -> 2;
            case "Ocean" -> 0;
            case "Midnight" -> 7;
            case "Sunset" -> 5;
            case "Forest" -> 4;
            case "Synthwave" -> 1;
            case "Monochrome" -> 6;
            default -> 3;
        };
        float strength = CherryBlossomSettings.CLICK_GUI_OPACITY.floatValue();
        c.pushAlpha(strength * 0.68f);
        c.aurora(0.0f, 0.0f, 1240.0f, 580.0f, 22.0f, 0.73f, palette, -1);
        c.popAlpha();
        if (background.equals("Nebula") || background.equals("Midnight") || background.equals("Synthwave")) {
            c.pushAlpha(strength * 0.72f);
            for (int i = 0; i < 42; ++i) {
                float x = 26.0f + ClickGui.fract((float)i * 0.618034f + 0.17f) * 1188.0f;
                float y = 24.0f + ClickGui.fract((float)i * 0.754878f + 0.41f) * 532.0f;
                float pulse = 0.28f + 0.22f * (float)Math.sin(time * 1.5f + (float)i * 0.71f);
                c.circle(x, y, 0.8f + (float)(i % 4) * 0.22f, Theme.alpha(Theme.tint(-2233857), pulse));
            }
            c.popAlpha();
        }
        c.roundRect(0.0f, 0.0f, 1240.0f, 580.0f, 22.0f, 1845956895);
        c.roundRectGradient(0.0f, 0.0f, 1240.0f, 70.0f, 22.0f, 890445620, 1253172);
        if (CherryBlossomSettings.CLICK_GUI_GLOW.on()) {
            c.roundRectStroke(1.0f, 1.0f, 1238.0f, 578.0f, 21.0f, 1.2f, Theme.alpha(Theme.accentBright(), 0.36f));
        }
    }

    private void drawTree(UiCanvas c, float cx, float cy, float scale, float time) {
        int i;
        this.drawCanopy(c, cx, cy, scale);
        this.drawTreePath(c, cx, cy, TREE_TRUNK, scale, 1.0f);
        this.drawTreePath(c, cx, cy, TREE_LEFT, scale, 1.0f);
        this.drawTreePath(c, cx, cy, TREE_RIGHT, scale, 1.0f);
        this.drawTreePath(c, cx, cy, TREE_LEFT_FORK, scale, 0.88f);
        this.drawTreePath(c, cx, cy, TREE_RIGHT_FORK, scale, 0.88f);
        this.drawTreePath(c, cx, cy, TREE_LOW_LEFT, scale, 0.94f);
        this.drawTreePath(c, cx, cy, TREE_LOW_RIGHT, scale, 0.94f);
        for (i = 0; i < TREE_BLOSSOMS.length; ++i) {
            float[] blossom = TREE_BLOSSOMS[i];
            float drift = (float)Math.sin(time * 0.28f + (float)i * 1.7f) * 1.3f;
            this.drawBlossom(c, cx + blossom[0] * scale, cy + (blossom[1] + drift) * scale, blossom[2] * scale);
        }
        for (i = 0; i < 48; ++i) {
            float seedX = ClickGui.fract((float)i * 0.618034f + 0.13f);
            float seedY = ClickGui.fract((float)i * 0.754878f + 0.37f);
            float speed = 0.01f + (float)(i % 5) * 0.0017f;
            float phase = ClickGui.fract(seedY + time * speed);
            float sway = (float)Math.sin(time * (0.16f + (float)(i % 4) * 0.018f) + (float)i * 2.31f) * (7.0f + (float)(i % 5) * 2.0f);
            float x = 16.0f + seedX * 1208.0f + sway;
            float y = -10.0f + phase * 600.0f;
            float leaf = (2.5f + (float)(i % 4) * 0.48f) * scale;
            float angle = 0.2f + (float)Math.sin(time * 0.27f + (float)i * 1.91f) * 0.55f;
            float alpha = 0.3f + (float)(i % 4) * 0.045f;
            c.petal(x, y, leaf, leaf * 1.55f, angle, Theme.alpha(Theme.tint(-14372), alpha), Theme.alpha(Theme.tint(-34633), alpha * 0.48f));
        }
    }

    private void drawCanopy(UiCanvas c, float cx, float cy, float scale) {
        c.circle(cx, cy - 64.0f * scale, 132.0f * scale, Theme.tint(-23094));
        c.circle(cx, cy - 20.0f * scale, 88.0f * scale, Theme.tint(-23094));
        c.circle(cx - 65.0f * scale, cy - 49.0f * scale, 78.0f * scale, Theme.tint(-23607));
        c.circle(cx + 65.0f * scale, cy - 49.0f * scale, 78.0f * scale, Theme.tint(-23607));
        c.circle(cx, cy - 127.0f * scale, 70.0f * scale, Theme.tint(-20016));
        for (float[] lobe : TREE_CANOPY) {
            float x = cx + lobe[0] * scale;
            float y = cy + (lobe[1] + 27.0f) * scale;
            float r = lobe[2] * scale;
            c.circle(x, y + 5.0f * scale, r + 2.0f * scale, Theme.tint(-1606999));
        }
        for (int i = 0; i < TREE_CANOPY.length; ++i) {
            float[] lobe = TREE_CANOPY[i];
            float x = cx + lobe[0] * scale;
            float y = cy + (lobe[1] + 27.0f) * scale;
            float r = (lobe[2] - 2.0f) * scale;
            int fill = i % 4 == 0 ? Theme.tint(-18476) : (i % 3 == 0 ? Theme.tint(-21552) : Theme.tint(-23862));
            c.circle(x, y -= 3.0f * scale, r, fill);
            c.circle(x - r * 0.22f, y - r * 0.27f, r * 0.43f, 419428090);
        }
    }

    private void drawBlossom(UiCanvas c, float cx, float cy, float scale) {
        float radius = 8.0f * scale;
        for (int i = 0; i < 5; ++i) {
            float angle = (float)(-1.5707963267948966 + (double)i * Math.PI * 0.4);
            float px = cx + (float)Math.cos(angle) * radius * 0.52f;
            float py = cy + (float)Math.sin(angle) * radius * 0.52f;
            c.petal(px, py, 7.5f * scale, 10.0f * scale, angle, Theme.alpha(Theme.tint(-14372), 0.62f), Theme.alpha(Theme.tint(-34633), 0.32f));
        }
        c.circle(cx, cy, 1.5f * scale, Theme.alpha(Theme.tint(-14372), 0.78f));
    }

    private void drawTreePath(UiCanvas c, float cx, float cy, float[] points, float scale, float alpha) {
        int count = points.length / 3;
        for (int i = 0; i < count - 1; ++i) {
            float[] a = i == 0 ? ClickGui.point(points, 0) : ClickGui.point(points, i - 1);
            float[] b = ClickGui.point(points, i);
            float[] d = ClickGui.point(points, i + 1);
            float[] e = ClickGui.point(points, Math.min(count - 1, i + 2));
            for (int step = 0; step < 8; ++step) {
                float t0 = (float)step / 8.0f;
                float t1 = (float)(step + 1) / 8.0f;
                float[] p0 = ClickGui.catmull(a, b, d, e, t0);
                float[] p1 = ClickGui.catmull(a, b, d, e, t1);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float length = Math.max(0.001f, (float)Math.sqrt(dx * dx + dy * dy));
                float overlap = 0.45f;
                float x1 = cx + (p0[0] - dx / length * overlap) * scale;
                float y1 = cy + (p0[1] - dy / length * overlap) * scale;
                float x2 = cx + (p1[0] + dx / length * overlap) * scale;
                float y2 = cy + (p1[1] + dy / length * overlap) * scale;
                float w0 = Math.max(1.2f, p0[2] * scale);
                float w1 = Math.max(1.0f, p1[2] * scale);
                c.taperedBranch(x1, y1, x2, y2, w0, w1, Theme.alpha(Theme.tint(-4619631), alpha));
            }
        }
    }

    private static float[] point(float[] points, int index) {
        int offset = index * 3;
        return new float[]{points[offset], points[offset + 1], points[offset + 2]};
    }

    private static float[] catmull(float[] a, float[] b, float[] c, float[] d, float t) {
        float t2 = t * t;
        float t3 = t2 * t;
        float[] out = new float[3];
        for (int i = 0; i < 3; ++i) {
            out[i] = 0.5f * (2.0f * b[i] + (-a[i] + c[i]) * t + (2.0f * a[i] - 5.0f * b[i] + 4.0f * c[i] - d[i]) * t2 + (-a[i] + 3.0f * b[i] - 3.0f * c[i] + d[i]) * t3);
        }
        return out;
    }

    private void drawBlossomTab(UiCanvas c, FontAtlas f, WheelEntry entry, float cx, float cy, float hover, float pulse, float scale) {
        c.push();
        c.scale(scale, cx, cy);
        float radius = 30.0f;
        int iconColor = ClickGui.wheelNodeColor(entry.id());
        float glow = 0.06f + hover * 0.24f + pulse * 0.018f;
        c.shadow(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, radius, 15.0f + hover * 7.0f, Theme.alpha(Theme.tint(-34633), glow));
        c.circle(cx, cy, radius, Theme.tint(-8895393));
        c.icon(entry.icon(), false, cx, cy, 20.0f, Theme.mix(iconColor, -2053, hover * 0.6f));
        float total = entry.categories().stream().mapToInt(cat -> ModuleManager.of(cat).size()).sum();
        String count = "0/" + (int)total;
        float titleW = f.semibold.width(entry.title(), 10.0f);
        float countW = f.medium.width(count, 9.0f);
        float badgeW = Math.max(94.0f, titleW + countW + 28.0f);
        float badgeY = cy + 37.0f;
        c.roundRect(badgeW * -0.5f + cx, badgeY, badgeW, 21.0f, 7.0f, Theme.tint(-228970422));
        c.roundRectStroke(cx - badgeW * 0.5f, badgeY, badgeW, 21.0f, 7.0f, 0.8f, 956295410);
        c.roundRect(cx - badgeW * 0.5f + 8.0f, badgeY + 7.0f, 5.0f, 6.0f, 1.5f, iconColor);
        float labelX = cx - badgeW * 0.5f + 19.0f;
        c.textMiddle(f.semibold, entry.title(), labelX, badgeY + 10.5f, 10.0f, -2053);
        c.textRight(f.medium, count, cx + badgeW * 0.5f - 8.0f, badgeY + 10.5f, 9.0f, iconColor);
        c.pop();
    }

    private static int wheelNodeColor(String id) {
        return switch (id) {
            case "donut" -> Theme.tint(-16170);
            case "misc" -> Theme.tint(-22574);
            case "visual" -> Theme.tint(-1660726);
            default -> Theme.tint(-34633);
        };
    }

    private void drawHeader(UiCanvas c, UiInput in, FontAtlas f) {
        CherryBlossomMark.draw(c, 34.0f, 31.0f, 25.0f, Theme.accentBright());
        c.textMiddle(f.bold, "CherryBlossom Client", 57.0f, 25.0f, 20.0f, -1);
        c.textMiddle(f.regular, "Click to toggle \u00b7 right-click to expand settings", 58.0f, 48.0f, 12.0f, Theme.tint(-5196872));
        float glowX = 940.0f;
        boolean glowHover = in.hover("clickgui.glow", glowX, 17.0f, 50.0f, 32.0f);
        float glowA = this.anim.get("clickgui.glow.h", glowHover, 18.0f);
        int glowFill = CherryBlossomSettings.CLICK_GUI_GLOW.on() ? Theme.alpha(Theme.accentBright(), 0.32f) : Theme.mix(Theme.tint(-988141248), Theme.tint(-383042216), glowA);
        c.roundRect(glowX, 17.0f, 50.0f, 32.0f, 16.0f, glowFill);
        c.icon("sparkle", false, glowX + 12.0f, 33.0f, 13.0f, CherryBlossomSettings.CLICK_GUI_GLOW.on() ? -1 : Theme.tint(-7697007));
        c.textMiddle(f.medium, "Glow", glowX + 23.0f, 33.0f, 10.0f, -1);
        if (in.clicked("clickgui.glow")) {
            CherryBlossomSettings.CLICK_GUI_GLOW.toggle();
            CherryBlossomSounds.play(CherryBlossomSounds.TOGGLE_ON, 0.65f);
        }
        float themeX = 1004.0f;
        boolean themeHover = in.hover("clickgui.theme", themeX, 17.0f, 108.0f, 32.0f);
        float themeA = this.anim.get("clickgui.theme.h", themeHover, 18.0f);
        c.roundRect(themeX, 17.0f, 108.0f, 32.0f, 16.0f, Theme.mix(Theme.tint(-988141248), Theme.tint(-383042216), themeA));
        c.icon("palette", false, themeX + 15.0f, 33.0f, 14.0f, Theme.accentBright());
        c.textMiddle(f.medium, (String)CherryBlossomSettings.CLICK_GUI_BACKGROUND.get(), themeX + 27.0f, 33.0f, 11.0f, -1);
        if (in.clicked("clickgui.theme")) {
            CherryBlossomSettings.CLICK_GUI_BACKGROUND.cycle(1);
            CherryBlossomSounds.play(CherryBlossomSounds.TAB, 0.65f);
        }
        float lockX = 1128.0f;
        boolean lockHover = in.hover("clickgui.lock", lockX, 17.0f, 64.0f, 32.0f);
        float lockA = this.anim.get("clickgui.lock.h", lockHover, 18.0f);
        boolean locked = this.positionLocked();
        c.roundRect(lockX, 17.0f, 64.0f, 32.0f, 16.0f, locked ? Theme.alpha(Theme.accentBright(), 0.34f) : Theme.mix(Theme.tint(-988141248), Theme.tint(-383042216), lockA));
        c.icon(locked ? "lock" : "lock-simple", false, lockX + 16.0f, 33.0f, 13.0f, locked ? -1 : Theme.tint(-7697007));
        c.textMiddle(f.medium, "Lock", lockX + 28.0f, 33.0f, 10.0f, -1);
        if (in.clicked("clickgui.lock")) {
            this.panel.clickGuiPositionLocked(!locked);
            CherryBlossomSounds.play(!locked ? CherryBlossomSounds.TOGGLE_ON : CherryBlossomSounds.TOGGLE_OFF, 0.7f);
        }
    }

    private List<WheelEntry> wheelEntries() {
        return List.of(new WheelEntry("combat", "Combat", "sword", List.of(Category.COMBAT)), new WheelEntry("misc", "Misc", "squares-four", List.of(Category.MISC)), new WheelEntry("macros", "Macros", "keyboard", List.of(Category.MACROS)), new WheelEntry("donut", "Donut", "donut", List.of(Category.DONUT)), new WheelEntry("render", "Render", "eye", List.of(Category.RENDER)), new WheelEntry("client", "Client", "user", List.of(Category.CLIENT)));
    }

    private void drawWheel(UiCanvas c, UiInput in, FontAtlas f, float time) {
        float progress = Math.max(0,Math.min(1,this.anim.get("wheel.panel.progress", 0.0f, 10.5f)));
        float cx = 620.0f - 300.0f * progress;
        float cy = 250.0f + 26.0f * progress;
        float scale = .88f;
        this.drawWheelScene(c, in, f, time, cx, cy, scale, true);
    }

    private void drawWheelScene(UiCanvas c, UiInput in, FontAtlas f, float time, float cx, float cy, float scale, boolean interactive) {
        this.drawTree(c, cx, cy, scale, time);
        WheelEntry[] entries = (WheelEntry[])this.wheelEntries().toArray(WheelEntry[]::new);
        WheelEntry hoveredEntry = null;
        float hoveredX = 0.0f;
        float hoveredY = 0.0f;
        for (int i = 0; i < entries.length; ++i) {
            WheelEntry entry = entries[i];
            float px = cx + WHEEL_NODE_OFFSETS[i][0] * scale;
            float py = cy + WHEEL_NODE_OFFSETS[i][1] * scale;
            String id = "wheel.category." + entry.id();
            float radius = 29.0f * scale;
            boolean inside = interactive && in.hover(id, px - 59.0f * scale, py - 34.0f * scale, 118.0f * scale, 65.0f * scale);
            float dx = (in.x - px) / (radius + 5.0f * scale);
            float dy = (in.y - py) / (radius + 5.0f * scale);
            boolean hovered = inside && dx * dx + dy * dy <= 1.0f;
            boolean focused = interactive && this.wheelKeyboardNavigation && i == this.wheelFocus;
            float hover = this.anim.get(id + ".hover", hovered || focused, 9.5f);
            float pulse = 0.5f + 0.5f * (float)Math.sin(time * 0.72f + (float)i * 0.83f);
            float press = this.anim.get(id + ".press", in.held(id), 14.0f);
            this.drawBlossomTab(c, f, entry, px, py, hover, pulse, scale);
            if (focused) {
                c.circleStroke(px, py, radius + 7.0f * scale, 1.5f * scale, Theme.alpha(Theme.tint(-14372), 0.8f));
            }
            if (hovered && interactive) {
                hoveredEntry = entry;
                hoveredX = px;
                hoveredY = py;
            }
            if (!hovered || !in.clicked(id)) continue;
            this.wheelKeyboardNavigation = false;
            this.openWheelEntry(entry);
        }
        float hubRadius = 42.0f * scale;
        float hubDx=in.x-cx,hubDy=in.y-cy;
        boolean hubHover=hubDx*hubDx+hubDy*hubDy<=hubRadius*hubRadius&&in.hover("wheel.layout",cx-hubRadius,cy-hubRadius,hubRadius*2,hubRadius*2);
        if(hubHover&&in.clicked("wheel.layout")){
            this.wheelMode(false);CherryBlossomSounds.play(CherryBlossomSounds.TAB,.7f);
        }
        c.shadow(cx - hubRadius, cy - hubRadius, hubRadius * 2.0f, hubRadius * 2.0f, hubRadius, 22.0f * scale, 1352809328);
        c.circle(cx, cy, hubRadius + 3.0f * scale, Theme.tint(-1542745));
        c.circle(cx, cy, hubRadius, Theme.tint(-9420708));
        c.circleStroke(cx, cy, hubRadius - 1.0f * scale, 1.2f * scale, Theme.alpha(Theme.tint(-34633), 0.92f));
        CherryBlossomMark.draw(c, cx, cy, 39.0f * scale, Theme.tint(-14372));
        if(hubHover)c.circleStroke(cx,cy,hubRadius+5*scale,1.5f*scale,Theme.accentBright());
        float pillW = 194.0f * scale;
        float pillY = cy + 53.0f * scale;
        c.roundRect(cx - pillW * 0.5f, pillY, pillW, 40.0f * scale, 8.0f * scale, Theme.tint(-228970422));
        c.roundRectStroke(cx - pillW * 0.5f, pillY, pillW, 40.0f * scale, 8.0f * scale, 0.9f * scale, 1258282987);
        c.textCentered(f.semibold, "CherryBlossom Client", cx, pillY + 13.0f * scale, 12.0f * scale, Theme.tint(-34633));
        c.textCentered(f.medium, hubHover?"CLICK FOR DROPDOWN":"CHOOSE A BRANCH", cx, pillY + 28.0f * scale, 7.5f * scale, Theme.tint(-1917232));
        if (hoveredEntry != null) {
            float tipW = 148.0f * scale;
            float tipH = 37.0f * scale;
            float tipX = hoveredX < cx ? hoveredX + 78.0f * scale : hoveredX - tipW - 26.0f * scale;
            float tipY = hoveredY - 18.0f * scale;
            tipX = class_3532.method_15363((float)tipX, (float)(8.0f * scale), (float)(1240.0f - tipW - 8.0f * scale));
            tipY = class_3532.method_15363((float)tipY, (float)(8.0f * scale), (float)(580.0f - tipH - 8.0f * scale));
            c.shadow(tipX, tipY, tipW, tipH, 7.0f * scale, 10.0f * scale, 1697649705);
            c.roundRect(tipX, tipY, tipW, tipH, 7.0f * scale, Theme.tint(-229889469));
            c.roundRectStroke(tipX, tipY, tipW, tipH, 7.0f * scale, 0.8f * scale, 1442835186);
            c.textMiddle(f.semibold, hoveredEntry.title() + " modules", tipX + 9.0f * scale, tipY + 12.0f * scale, 9.0f * scale, -2053);
            c.textMiddle(f.regular, "No modules available", tipX + 9.0f * scale, tipY + 26.0f * scale, 8.0f * scale, Theme.tint(-1917232));
        }
    }

    private void drawWheelModules(UiCanvas c, UiInput in, FontAtlas f, float dt, float time) {
        float panelProgress = Math.max(0,Math.min(1,this.anim.get("wheel.panel.progress", 1.0f, 10.5f)));
        float treeCx = 620.0f - 300.0f * panelProgress;
        this.drawWheelScene(c, in, f, time, treeCx, 250+26*panelProgress, .88f, false);
        float slide = (1.0f - panelProgress) * 560.0f;
        c.push();
        c.translate(slide, 0.0f);
        c.pushAlpha(panelProgress);
        this.drawWheelModulePanel(c, in, f, dt);
        c.popAlpha();
        c.pop();
    }

    private void drawWheelModulePanel(UiCanvas c, UiInput in, FontAtlas f, float dt) {
        float x = 638.0f;
        float y = 77.0f;
        float w = 562.0f;
        float h = 454.0f;
        c.shadow(x, y, w, h, 22.0f, 21.0f, 0x60000000);
        c.roundRectGradient(x, y, w, h, 22.0f, Theme.tint(-396741298), Theme.tint(-398842312));
        c.roundRectStroke(x, y, w, h, 22.0f, 1.0f, 1124068082);
        c.roundRectGradient(x + 1.0f, y + 1.0f, w - 2.0f, 58.0f, 21.0f, 0x18FFFFFF, 0xFFFFFF);
        boolean backHover = in.hover("wheel.back", x + 20.0f, y + 20.0f, 88.0f, 32.0f);
        c.roundRectGradient(x + 20.0f, y + 20.0f, 88.0f, 32.0f, 16.0f, Theme.tint(-646427800), Theme.tint(-983943857));
        c.roundRectStroke(x + 20.0f, y + 20.0f, 88.0f, 32.0f, 16.0f, 0.9f, Theme.alpha(Theme.tint(-14372), 0.12f + (backHover ? 0.28f : 0.0f)));
        c.icon("caret-left", false, x + 38.0f, y + 36.0f, 15.0f, Theme.tint(-14372));
        c.textMiddle(f.medium, "Tree", x + 52.0f, y + 36.0f, 11.0f, Theme.tint(-461832));
        if (backHover && in.clicked("wheel.back")) {
            this.backToWheel();
            CherryBlossomSounds.play(CherryBlossomSounds.TAB, 0.65f);
            return;
        }
        c.icon(this.wheelPageIcon == null ? "tree" : this.wheelPageIcon, false, x + 140.0f, y + 38.0f, 22.0f, Theme.tint(-14372));
        c.textMiddle(f.semibold, this.wheelPageTitle == null ? "Modules" : this.wheelPageTitle, x + 160.0f, y + 30.0f, 18.0f, -1796);
        c.textMiddle(f.regular, "Category overview", x + 160.0f, y + 49.0f, 10.0f, Theme.tint(-1917232));
        List<Module> allModules = this.wheelCategories.stream().flatMap(category -> ModuleManager.of(category).stream()).toList();
        int enabled = (int)allModules.stream().filter(Module::enabled).count();
        String count = enabled + " / " + allModules.size();
        float countW = f.medium.width(count, 10.0f) + 20.0f;
        c.roundRect(x + w - countW - 22.0f, y + 27.0f, countW, 23.0f, 11.5f, Theme.tint(-864730273));
        c.textCentered(f.medium, count, x + w - countW * 0.5f - 22.0f, y + 38.5f, 10.0f, Theme.tint(-14372));
        this.drawWheelSearch(c, in, f, x + 22.0f, y + 72.0f, w - 44.0f, 35.0f);
        String query = this.wheelSearch.text().trim().toLowerCase(Locale.ROOT);
        List<Module> modules = allModules.stream().filter(module -> query.isEmpty() || module.name().toLowerCase(Locale.ROOT).contains(query) || module.id().toLowerCase(Locale.ROOT).contains(query) || module.description().toLowerCase(Locale.ROOT).contains(query)).toList();
        float listX = x + 22.0f;
        float listY = y + 123.0f;
        float listW = w - 44.0f;
        float listH = h - 144.0f;
        float rowH = 48.0f;
        float contentHeight = 0.0f;
        for (Module module2 : modules) {
            float expanded = class_3532.method_15363((float)this.expandFrame.getOrDefault(module2.id(), Float.valueOf(0.0f)).floatValue(), (float)0.0f, (float)1.0f);
            contentHeight += rowH + this.expandedHeight(module2) * expanded;
        }
        float maxScroll = Math.max(0.0f, contentHeight - listH);
        if (in.inside(listX, listY, listW, listH) && in.scroll != 0.0f) {
            this.wheelScrollTarget = class_3532.method_15363((float)(this.wheelScrollTarget - in.scroll * rowH * 1.4f), (float)0.0f, (float)maxScroll);
        }
        this.wheelScrollTarget = class_3532.method_15363((float)this.wheelScrollTarget, (float)0.0f, (float)maxScroll);
        float amount = cherryblossom.module.modules.client.CherryBlossom.animationMode.getModeIndex()==2 ? 1.0f : 1.0f - (float)Math.exp(-dt * 11.0f);
        this.wheelScroll += (this.wheelScrollTarget - this.wheelScroll) * amount;
        this.wheelScroll = class_3532.method_15363(this.wheelScroll, 0.0f, maxScroll);
        c.pushClip(listX, listY, listW, listH);
        if (modules.isEmpty()) {
            String message = query.isEmpty() ? "No modules in this branch" : "No modules match your search";
            c.circle(x + w * 0.5f, listY + 70.0f, 25.0f, 1680810805);
            c.icon(query.isEmpty() ? "sparkle" : "magnifying-glass", false, x + w * 0.5f, listY + 70.0f, 19.0f, Theme.tint(-14372));
            c.textCentered(f.medium, message, x + w * 0.5f, listY + 113.0f, 12.0f, Theme.tint(-1778457));
        } else {
            float rowY = listY - this.wheelScroll;
            for (int i = 0; i < modules.size(); ++i) {
                float reveal;
                Module module3 = modules.get(i);
                float expanded = class_3532.method_15363((float)this.expandFrame.getOrDefault(module3.id(), Float.valueOf(0.0f)).floatValue(), (float)0.0f, (float)1.0f);
                float settingsHeight = this.expandedHeight(module3);
                if (rowY + rowH + settingsHeight * expanded < listY || rowY > listY + listH) {
                    rowY += rowH + settingsHeight * expanded;
                    continue;
                }
                String id = "wheel.module." + module3.id();
                String toggleId = id + ".toggle";
                String settingsId = id + ".settings";
                boolean rowHover = in.hover(id, listX, rowY + 2.0f, listW - 82.0f, rowH - 4.0f);
                boolean switchHover = in.hover(toggleId, listX + listW - 82.0f, rowY + 2.0f, 54.0f, rowH - 4.0f);
                boolean settingsHover = in.hover(settingsId, listX + listW - 28.0f, rowY + 2.0f, 28.0f, rowH - 4.0f);
                boolean hovered = rowHover || switchHover || settingsHover;
                float hover = this.anim.get(id + ".hover", hovered, 13.0f);
                float active = this.anim.get(id + ".active", module3.enabled(), 12.0f);
                float press = this.anim.get(id + ".press", in.held(id) || in.held(toggleId), 20.0f);
                c.push();
                c.scale(1.0f + hover * 0.004f - press * 0.006f, listX + listW * 0.5f, rowY + rowH * 0.5f);
                int top = Theme.mix(Theme.tint(-782617268), Theme.tint(-528988315), hover * 0.38f + active * 0.22f);
                int bottom = Theme.mix(Theme.tint(-783733439), Theme.tint(-496551081), active * 0.28f);
                c.roundRectGradient(listX, rowY + 2.0f, listW, rowH - 4.0f, 13.0f, top, bottom);
                c.roundRectStroke(listX, rowY + 2.0f, listW, rowH - 4.0f, 13.0f, 0.9f, Theme.alpha(Theme.tint(-14372), 0.06f + hover * 0.22f + active * 0.15f));
                c.textMiddle(module3.enabled() ? f.semibold : f.medium, module3.name(), listX + 16.0f, rowY + 17.0f, 12.0f, Theme.mix(Theme.tint(-1521192), -1796, Math.max(active, hover * 0.7f)));
                c.textFit(f.regular, module3.description(), listX + 16.0f, rowY + 33.0f, 9.5f, listW - 128.0f, Theme.tint(-2508342));
                this.drawWheelSwitch(c, listX + listW - 74.0f, rowY + 13.5f, active);
                c.icon(expanded > 0.5f ? "caret-down" : "caret-right", false, listX + listW - 15.0f, rowY + rowH * 0.5f, 11.0f, Theme.alpha(Theme.tint(-1917232), 0.58f + hover * 0.35f));
                c.pop();
                if (rowHover && in.clicked(id) || switchHover && in.clicked(toggleId)) {
                    module3.toggle();
                    CherryBlossomSounds.play(module3.enabled() ? CherryBlossomSounds.TOGGLE_ON : CherryBlossomSounds.TOGGLE_OFF, 0.75f);
                }
                if ((settingsHover && in.clicked(settingsId) || hovered && in.secondaryClicked(listX, rowY + 2.0f, listW, rowH - 4.0f)) && !module3.settings().isEmpty()) {
                    if (!this.expanded.add(module3.id())) {
                        this.expanded.remove(module3.id());
                    }
                    CherryBlossomSounds.play(CherryBlossomSounds.CLICK, 0.65f);
                }
                if ((reveal = settingsHeight * expanded) > 0.5f) {
                    this.drawWheelExpandedSettings(c, in, f, module3, listX + 5.0f, rowY + rowH, listW - 10.0f, settingsHeight, expanded, listY, listY + listH);
                }
                rowY += rowH + reveal;
            }
        }
        c.popClip();
        if (in.pressed && CherryBlossomController.get().isFocused(this.wheelSearch) && !"wheel.search".equals(in.hovered())) {
            CherryBlossomController.get().unfocusText(this.wheelSearch);
        }
    }

    void drawWheelSearch(UiCanvas c, UiInput in, FontAtlas f, float x, float y, float w, float h) {
        CherryBlossomController controller = CherryBlossomController.get();
        boolean focused = controller.isFocused(this.wheelSearch);
        boolean hovered = in.hover("wheel.search", x, y, w, h);
        float hover = this.anim.get("wheel.search.hover", hovered, 15.0f);
        float focus = this.anim.get("wheel.search.focus", focused, 14.0f);
        float cy = y + h * 0.5f;
        c.roundRectGradient(x, y, w, h, h * 0.5f, Theme.mix(Theme.tint(-396741299), Theme.tint(-260552603), hover * 0.5f), Theme.tint(-397725885));
        c.roundRectStroke(x, y, w, h, h * 0.5f, focused ? 1.2f : 0.8f, Theme.alpha(Theme.tint(-14372), 0.08f + hover * 0.14f + focus * 0.56f));
        c.icon("magnifying-glass", false, x + 19.0f, cy, 14.0f, Theme.mix(Theme.tint(-1917232), Theme.tint(-14372), Math.max(hover, focus)));
        float textX = x + 35.0f;
        float maxWidth = w - 55.0f;
        if (this.wheelSearch.isEmpty()) {
            c.textFit(f.regular, focused ? "Type to filter modules" : "Search modules", textX, cy, 11.0f, maxWidth, Theme.tint(-1917232));
        } else {
            String shown = Widgets.tail(f.regular, this.wheelSearch.text(), 11.0f, maxWidth - 4.0f);
            float end = c.textMiddle(f.regular, shown, textX, cy, 11.0f, Theme.tint(-461832));
            if (focused && !this.wheelSearch.allSelected() && this.wheelSearch.caretVisible()) {
                c.rect(end + 1.0f, cy - 7.0f, 1.0f, 14.0f, Theme.tint(-14372));
            }
        }
        if (in.clicked("wheel.search") && !focused) {
            controller.focusText(this.wheelSearch);
            CherryBlossomSounds.play(CherryBlossomSounds.CLICK, 0.6f);
        }
    }

    private void drawConfigButton(UiCanvas c,UiInput in,FontAtlas f) {
        float x=598,y=ConfigPanel.buttonY();
        if(ConfigPanel.button(c,in,f,"configs.open","",x,y,44,44,true)) {
            this.backToWheel();configs.open();TotemPickerPanel.close();
        }
        c.icon("gear",false,x+22,y+22,20,Theme.accentBright());
        c.textMiddle(f.medium,"Configs",x+54,y+22,11,Theme.tint(-461832));
    }
    private void drawWheelFooter(UiCanvas c, UiInput in, FontAtlas f) {
        float y = 537.0f;
        if (this.wheelCategories != null && this.wheelCategories.stream().allMatch(category -> ModuleManager.of(category).isEmpty())) {
            c.textRight(f.regular, "No modules in this category", 1212.0f, y + 15.0f, 10.0f, Theme.tint(-1917232));
        }
    }

    private void drawWheelSwitch(UiCanvas c, float x, float y, float enabled) {
        float w = 43.0f;
        float h = 23.0f;
        int off = Theme.tint(-7576710);
        int on = Theme.tint(-743744);
        c.roundRect(x, y, w, h, h * 0.5f, Theme.mix(off, on, enabled));
        float knob = 17.0f;
        float kx = x + 3.0f + (w - knob - 6.0f) * enabled;
        c.shadow(kx, y + 3.0f, knob, knob, knob * 0.5f, 4.0f, 0x50000000);
        c.circle(kx + knob * 0.5f, y + h * 0.5f, knob * 0.5f, -1796);
    }

    private void drawWheelExpandedSettings(UiCanvas c, UiInput in, FontAtlas f, Module module, float x, float y, float width, float totalHeight, float progress, float clipTop, float clipBottom) {
        float reveal = totalHeight * progress;
        float top = y + 1.0f;
        c.pushAlpha(progress);
        c.roundRect(x + 2.0f, top, width - 4.0f, reveal, 9.0f, Theme.tint(-1573050823));
        c.pushClip(x + 3.0f, top, width - 6.0f, reveal);
        float rowY = top + 5.0f;
        for (Setting<?> setting : module.settings()) {
            if (!setting.isVisible()) continue;
            float height = ClickGui.settingHeight(setting);
            boolean interactive = rowY + height <= top + reveal - 1.0f && rowY >= clipTop && rowY + height <= clipBottom;
            UiInput rowInput = interactive ? in : UiInput.INERT;
            String id = "wheel.setting." + module.id() + "." + setting.id();
            if (setting instanceof BoolSetting) {
                BoolSetting bool = (BoolSetting)setting;
                c.textFit(f.medium, setting.name(), x + 8.0f, rowY + height * 0.5f, 10.5f, width - 66.0f, Theme.tint(-1452833));
                float active = this.anim.get(id + ".active", bool.on(), 12.0f);
                this.drawWheelSwitch(c, x + width - 53.0f, rowY + (height - 23.0f) * 0.5f, active);
                rowInput.hover(id, x + width - 57.0f, rowY, 54.0f, height);
                if (interactive && rowInput.clicked(id)) {
                    bool.toggle();
                }
            } else if (setting instanceof BlockPickerSetting picker) {
                drawSetting(c,rowInput,f,module,setting,x+8,rowY,width-16,height);
            } else if (setting instanceof TotemPickerSetting picker) {
                TotemPickerPanel.row(c,rowInput,f,id,picker,x+8,rowY,width-16,height);
            } else if (setting instanceof SliderSetting) {
                SliderSetting slider = (SliderSetting)setting;
                c.textFit(f.medium, setting.name(), x + 8.0f, rowY + 7.0f, 10.5f, width - 16.0f, Theme.tint(-1452833));
                float valueWidth = Math.min(42.0f, Math.max(30.0f, f.medium.width(slider.format(), 11.5f) + 8.0f));
                float trackWidth = Math.max(24.0f, width - valueWidth - 28.0f);
                Widgets.slider(c, rowInput, this.anim, f, id, slider, x + 8.0f, rowY + height - 9.0f, trackWidth, x + width - 8.0f);
            } else if (setting instanceof ModeSetting) {
                ModeSetting mode = (ModeSetting)setting;
                c.textFit(f.medium, setting.name(), x + 8.0f, rowY + height * 0.5f, 10.5f, width - 120.0f, Theme.tint(-1452833));
                float pillWidth = Math.min(108.0f, width * 0.56f);
                float pillX = x + width - pillWidth - 7.0f;
                boolean hovered = rowInput.hover(id, pillX, rowY + 3.0f, pillWidth, height - 6.0f);
                float hover = this.anim.get(id + ".hover", hovered, 13.0f);
                c.roundRectGradient(pillX, rowY + 3.0f, pillWidth, height - 6.0f, (height - 6.0f) * 0.5f, Theme.mix(Theme.tint(-9419940), Theme.tint(-7253650), hover), Theme.tint(-10930614));
                c.textCentered(f.medium, f.medium.ellipsize((String)mode.get(), 10.5f, pillWidth - 14.0f), pillX + pillWidth * 0.5f, rowY + height * 0.5f, 10.5f, -2566);
                if (rowInput.clicked(id)) {
                    mode.cycle(1);
                    CherryBlossomSounds.play(CherryBlossomSounds.TAB, 0.6f);
                }
            } else {
                this.drawSetting(c, rowInput, f, module, setting, x + 8.0f, rowY, width - 16.0f, height);
            }
            rowY += height;
        }
        c.popClip();
        c.popAlpha();
    }

    private List<Card> layoutCards(float margin, float gap, float contentY, float colW, int columns) {
        float[] heights = new float[columns];
        ArrayList<Card> cards = new ArrayList<Card>();
        String query = this.search.text().trim().toLowerCase(Locale.ROOT);
        for (Category category : Category.values()) {
            List<Module> modules = ModuleManager.of(category).stream().filter(module -> query.isEmpty() || module.name().toLowerCase(Locale.ROOT).contains(query) || module.id().toLowerCase(Locale.ROOT).contains(query) || module.description().toLowerCase(Locale.ROOT).contains(query)).toList();
            int column = 0;
            for (int i = 1; i < columns; ++i) {
                if (!(heights[i] < heights[column])) continue;
                column = i;
            }
            float cardH = 39.0f + (float)modules.size() * 27.0f;
            for (Module module2 : modules) {
                cardH += this.expandedHeight(module2) * class_3532.method_15363((float)this.expandFrame.getOrDefault(module2.id(), Float.valueOf(0.0f)).floatValue(), (float)0.0f, (float)1.0f);
            }
            float cardX = margin + (float)column * (colW + gap);
            float cardY = contentY + heights[column];
            cards.add(new Card(category, modules, cardX, cardY, colW, cardH, false));
            int n = column;
            heights[n] = heights[n] + (cardH + 9.0f);
        }
        int searchColumn = 0;
        for (int i = 1; i < columns; ++i) {
            if (!(heights[i] < heights[searchColumn])) continue;
            searchColumn = i;
        }
        float searchY = contentY + heights[searchColumn];
        cards.add(new Card(null, List.of(), margin + (float)searchColumn * (colW + gap), searchY, colW, 78.0f, true));
        return cards;
    }

    private void drawSearchCard(UiCanvas c, UiInput in, FontAtlas f, Card card) {
        if (card.y() > 538.0f || card.y() + card.height() < 70.0f) {
            return;
        }
        c.roundRect(card.x(), card.y(), card.width(), card.height(), 12.0f, Theme.tint(-401530826));
        c.icon("magnifying-glass", false, card.x() + 18.0f, card.y() + 17.0f, 15.0f, Theme.tint(-8140289));
        c.textMiddle(f.semibold, "Search modules", card.x() + 33.0f, card.y() + 17.0f, 13.0f, -1);
        float sx = card.x() + 9.0f;
        float sy = card.y() + 34.0f;
        float sw = card.width() - 18.0f;
        Widgets.searchPill(c, in, this.anim, f, "clickgui.search", this.search, sx, sy, sw, 34.0f, "Search modules", "magnifying-glass", 11.0f, Theme.tint(-8140289));
        if (!this.search.isEmpty() && Widgets.iconButton(c, in, this.anim, "clickgui.search.clear", "x", sx + sw - 17.0f, sy + 17.0f, 9.0f, 0)) {
            this.search.clear();
            CherryBlossomController.get().unfocusText(this.search);
        }
    }

    private void drawCard(UiCanvas c, UiInput in, FontAtlas f, Card card) {
        if (card.y() > 538.0f || card.y() + card.height() < 70.0f) {
            return;
        }
        c.roundRect(card.x(), card.y(), card.width(), card.height(), 12.0f, Theme.tint(-401530826));
        c.roundRect(card.x(), card.y(), card.width(), 31.0f, 12.0f, Theme.tint(-384095421));
        c.rect(card.x(), card.y() + 19.0f, card.width(), 12.0f, Theme.tint(-384095421));
        c.icon(card.category().icon(), false, card.x() + 17.0f, card.y() + 15.0f, 15.0f, card.category().color());
        c.textMiddle(f.semibold, card.category().displayName(), card.x() + 31.0f, card.y() + 15.0f, 13.0f, -1);
        int enabled = 0;
        for (Module module : card.modules()) {
            if (!module.enabled()) continue;
            ++enabled;
        }
        String count = Integer.toString(enabled);
        float countW = f.semibold.width(count, 11.0f) + 12.0f;
        c.roundRect(card.x() + card.width() - countW - 8.0f, card.y() + 7.0f, countW, 17.0f, 9.0f, Theme.alpha(Theme.accentBright(), 0.28f));
        c.textCentered(f.semibold, count, card.x() + card.width() - countW * 0.5f - 8.0f, card.y() + 15.5f, 11.0f, -1);
        if (CherryBlossomSettings.CLICK_GUI_GLOW.on()) {
            c.roundRectStroke(card.x(), card.y(), card.width(), card.height(), 12.0f, 1.0f, Theme.alpha(card.category().color(), 0.23f));
        }
        float rowY = card.y() + 34.0f;
        for (Module module : card.modules()) {
            boolean switchHover;
            float y = rowY;
            String base = "clickgui." + module.id();
            boolean visible = y >= 70.0f && y + 27.0f <= 538.0f;
            float rowX = card.x() + 5.0f;
            float rowW = card.width() - 10.0f;
            boolean rowHover = visible && in.hover(base + ".row", rowX, y - 1.0f, rowW, 25.0f);
            float hover = this.anim.get(base + ".h", rowHover, 18.0f);
            float expanded = class_3532.method_15363((float)this.expandFrame.getOrDefault(module.id(), Float.valueOf(0.0f)).floatValue(), (float)0.0f, (float)1.0f);
            if (hover > 0.01f || expanded > 0.01f) {
                int rowFill = module.enabled() ? Theme.alpha(Theme.accent(), 0.17f + expanded * 0.1f) : Theme.alpha(Theme.tint(-9337696), 0.1f + hover * 0.1f);
                c.roundRect(rowX, y - 1.0f, rowW, 25.0f, 7.0f, rowFill);
            }
            float switchX = card.x() + card.width() - 50.0f;
            float settingsX = switchX - 12.0f;
            float labelMax = Math.max(28.0f, card.width() - 99.0f);
            c.textMiddle(module.enabled() ? f.semibold : f.medium, ClickGui.ellipsize(f, module.name(), labelMax), card.x() + 13.0f, y + 11.5f, 12.0f, module.enabled() ? -1 : Theme.tint(-5196872));
            boolean settingsHover = visible && in.hover(base + ".settings", settingsX - 9.0f, y + 1.0f, 18.0f, 22.0f);
            float settingA = this.anim.get(base + ".settings.h", settingsHover, 18.0f);
            c.circle(settingsX, y + 11.0f, 8.5f, Theme.alpha(-1, settingA * 0.13f));
            c.icon("sliders-horizontal", false, settingsX, y + 11.0f, 11.0f, Theme.mix(Theme.tint(-7697007), -1, settingA));
            if (visible && in.clicked(base + ".settings")) {
                this.panel.openSettings(module);
                CherryBlossomSounds.play(CherryBlossomSounds.MENU_OPEN, 0.7f);
            }
            Widgets.drawSwitch(c, this.anim, base + ".switch", switchX, y + 1.0f, module.enabled(), 0.0f, 0.0f);
            boolean bl = switchHover = visible && in.hover(base + ".switch", switchX - 4.0f, y, 50.0f, 25.0f);
            if (switchHover) {
                this.anim.get(base + ".switch.h", true, 18.0f);
            }
            if (visible && (in.clicked(base + ".row") || in.clicked(base + ".switch"))) {
                module.toggle();
                CherryBlossomSounds.play(module.enabled() ? CherryBlossomSounds.TOGGLE_ON : CherryBlossomSounds.TOGGLE_OFF, 0.8f);
            }
            if (visible && in.secondaryClicked(rowX, y - 1.0f, rowW, 25.0f)) {
                if (!module.settings().isEmpty()) {
                    if (!this.expanded.add(module.id())) {
                        this.expanded.remove(module.id());
                    }
                    CherryBlossomSounds.play(CherryBlossomSounds.CLICK, 0.7f);
                } else {
                    this.panel.openSettings(module);
                    CherryBlossomSounds.play(CherryBlossomSounds.MENU_OPEN, 0.7f);
                }
            }
            rowY += 27.0f;
            float settingsHeight = this.expandedHeight(module);
            float reveal = settingsHeight * expanded;
            if (reveal > 0.5f) {
                this.drawExpandedSettings(c, in, f, module, card.x() + 5.0f, rowY, card.width() - 10.0f, settingsHeight, expanded);
            }
            rowY += reveal;
        }
    }

    private void drawExpandedSettings(UiCanvas c, UiInput in, FontAtlas f, Module module, float x, float y, float width, float totalHeight, float progress) {
        float reveal = totalHeight * progress;
        float top = y + 1.0f;
        c.pushAlpha(progress);
        c.roundRect(x + 3.0f, top, width - 6.0f, reveal, 8.0f, Theme.tint(-1542843358));
        c.pushClip(x + 4.0f, top, width - 8.0f, reveal);
        float rowY = top + 5.0f;
        for (Setting<?> setting : module.settings()) {
            if (!setting.isVisible()) continue;
            float rowHeight = ClickGui.settingHeight(setting);
            boolean fullyRevealed = rowY + rowHeight <= top + reveal - 1.0f && rowY >= 76.0f && rowY + rowHeight <= 538.0f;
            UiInput rowInput = fullyRevealed ? in : UiInput.INERT;
            this.drawSetting(c, rowInput, f, module, setting, x + 9.0f, rowY, width - 18.0f, rowHeight);
            rowY += rowHeight;
        }
        c.popClip();
        c.popAlpha();
    }

    void drawSetting(UiCanvas c, UiInput in, FontAtlas f, Module module, Setting<?> setting, float x, float y, float width, float height) {
        String id = "clickgui.setting." + module.id() + "." + setting.id();
        if(setting instanceof BlockPickerSetting picker){
            if(ConfigPanel.button(c,in,f,id,"Choose Blocks · "+picker.selectedCount()+" selected",x,y+3,width,height-6,cherryblossom.integration.TrialAccess.allowed()))picker.open();
            return;
        }
        if (setting instanceof ModuleResetSetting reset) {
            float gap=6,buttonWidth=(width-gap)/2;
            boolean allowed=cherryblossom.integration.TrialAccess.allowed();
            if(ConfigPanel.button(c,in,f,id+".keybind","Reset keybind",x,y+3,buttonWidth,height-6,allowed)) {
                reset.resetKeybind();CherryBlossomSounds.play(CherryBlossomSounds.CLICK,.65f);
            }
            if(ConfigPanel.button(c,in,f,id+".options","Reset settings",x+buttonWidth+gap,y+3,buttonWidth,height-6,allowed)) {
                reset.resetOptions();CherryBlossomSounds.play(CherryBlossomSounds.CLICK,.65f);
            }
            return;
        }
        if (setting instanceof BoolSetting) {
            BoolSetting bool = (BoolSetting)setting;
            c.textFit(f.medium, setting.name(), x, y + height * 0.5f, 10.5f, width - 54.0f, Theme.tint(-5196872));
            if (Widgets.toggle(c, in, this.anim, id, x + width - 42.0f, y + (height - 24.0f) * 0.5f, bool.on())) {
                bool.toggle();
            }
            return;
        }
        if (setting instanceof SliderSetting) {
            SliderSetting slider = (SliderSetting)setting;
            c.textFit(f.medium, setting.name(), x, y + 7.0f, 10.5f, width - 10.0f, Theme.tint(-5196872));
            float valueWidth = Math.min(42.0f, Math.max(30.0f, f.medium.width(slider.format(), 11.5f) + 8.0f));
            float trackWidth = Math.max(24.0f, width - valueWidth - 18.0f);
            Widgets.slider(c, in, this.anim, f, id, slider, x + 4.0f, y + height - 9.0f, trackWidth, x + width - 5.0f);
            return;
        }
        if (setting instanceof ModeSetting) {
            ModeSetting mode = (ModeSetting)setting;
            c.textFit(f.medium, setting.name(), x, y + height * 0.5f, 10.5f, width - 100.0f, Theme.tint(-5196872));
            float pillW = Math.min(98.0f, width * 0.55f);
            float pillX = x + width - pillW;
            boolean hovered = in.hover(id, pillX, y + 3.0f, pillW, height - 6.0f);
            float hover = this.anim.get(id + ".h", hovered, 18.0f);
            c.roundRect(pillX, y + 3.0f, pillW, height - 6.0f, (height - 6.0f) * 0.5f, Theme.mix(Theme.tint(-14931394), Theme.tint(-13549221), hover));
            c.textCentered(f.medium, f.medium.ellipsize((String)mode.get(), 10.5f, pillW - 14.0f), pillX + pillW * 0.5f, y + height * 0.5f, 10.5f, -1);
            if (in.clicked(id)) {
                mode.cycle(1);
                CherryBlossomSounds.play(CherryBlossomSounds.TAB, 0.6f);
            }
            return;
        }
        if (setting instanceof ColorSetting) {
            ColorSetting color = (ColorSetting)setting;
            c.textFit(f.medium, setting.name(), x, y + 7.0f, 10.5f, width - 10.0f, Theme.tint(-5196872));
            int[] palette = color.palette();
            float radius = 6.0f;
            float step = Math.min(20.0f, (width - 14.0f) / (float)Math.max(1, palette.length));
            float start = x + 8.0f + radius;
            for (int i = 0; i < palette.length; ++i) {
                float cx = start + (float)i * step;
                String swatch = id + "." + i;
                boolean hovered = in.hover(swatch, cx - 8.0f, y + height - 18.0f, 16.0f, 16.0f);
                boolean selected = color.argb() == palette[i];
                float hover = this.anim.get(swatch + ".h", hovered, 18.0f);
                if (selected) {
                    c.circleStroke(cx, y + height - 10.0f, radius + 2.2f, 1.4f, -1);
                }
                c.circle(cx, y + height - 10.0f, radius + hover * 0.7f, palette[i]);
                if (!in.clicked(swatch)) continue;
                color.set(palette[i]);
            }
            return;
        }
        if (setting instanceof TextSetting) {
            TextSetting text = (TextSetting)setting;
            c.textFit(f.medium, setting.name(), x, y + 7.0f, 10.5f, width - 10.0f, Theme.tint(-5196872));
            float valueY = y + height - 9.0f;
            boolean hovered = in.hover(id, x, y + 14.0f, width, height - 14.0f);
            c.textFit(f.regular, ((String)text.get()).isEmpty() ? "Click to edit" : (String)text.get(), x, valueY, 10.5f, width - 10.0f, hovered ? -1 : Theme.tint(-7697007));
            if (in.clicked(id)) {
                this.openTextEditor(text);
            }
            return;
        }
        if (setting instanceof KeySetting) {
            KeySetting key = (KeySetting)setting;
            c.textFit(f.medium, setting.name(), x, y + height * 0.5f, 10.5f, width - 92.0f, Theme.tint(-5196872));
            CherryBlossomController controller = CherryBlossomController.get();
            float time = (float)System.nanoTime() / 1.0E9f;
            if (Widgets.keyButton(c, in, this.anim, f, id, key, x + width, y + height * 0.5f, controller.isCapturing(key), time)) {
                controller.startKeyCapture(key);
            }
            return;
        }
        c.textMiddle(f.medium, setting.name(), x, y + height * 0.5f, 10.5f, Theme.tint(-5196872));
    }

    private float expandedHeight(Module module) {
        float height = 10.0f;
        boolean hasSettings = false;
        for (Setting<?> setting : module.settings()) {
            if (!setting.isVisible()) continue;
            height += ClickGui.settingHeight(setting);
            hasSettings = true;
        }
        return hasSettings ? height : 0.0f;
    }

    static float settingHeight(Setting<?> setting) {
        if(setting instanceof BlockPickerSetting)return 39;
        if(setting instanceof TotemPickerSetting)return 39;
        if (setting instanceof SliderSetting) {
            return 42.0f;
        }
        if (setting instanceof ModeSetting) {
            return 31.0f;
        }
        if (setting instanceof ColorSetting) {
            return 36.0f;
        }
        if (setting instanceof TextSetting) {
            return 34.0f;
        }
        if (setting instanceof KeySetting) {
            return 32.0f;
        }
        return 27.0f;
    }

    private static float fract(float value) {
        return value - (float)Math.floor(value);
    }

    private static String ellipsize(FontAtlas f, String value, float maxWidth) {
        if (f.medium.width(value, 12.0f) <= maxWidth) {
            return value;
        }
        String clipped = value;
        while (clipped.length() > 3 && f.medium.width(clipped + "\u2026", 12.0f) > maxWidth) {
            clipped = clipped.substring(0, clipped.length() - 1);
        }
        return clipped + "\u2026";
    }

    private record WheelEntry(String id, String title, String icon, List<Category> categories) {
    }

    private record Card(Category category, List<Module> modules, float x, float y, float width, float height, boolean search) {
    }
}

