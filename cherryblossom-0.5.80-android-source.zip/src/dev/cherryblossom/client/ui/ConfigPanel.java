package dev.cherryblossom.client.ui;

import cherryblossom.CherryBlossom;
import cherryblossom.manager.ConfigLibrary;
import cherryblossom.integration.TrialAccess;
import dev.cherryblossom.client.render.UiCanvas;
import dev.cherryblossom.client.render.text.FontAtlas;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/** Four persistent slots, with clipboard sharing through the validated config format. */
public final class ConfigPanel {
    private ConfigLibrary library;
    private boolean opened;
    private int selected;
    private String status="Select a slot to save or paste a config.";
    private boolean error;
    public static float buttonY(){
        var controller=dev.cherryblossom.client.CherryBlossomController.get();
        return (class_310.method_1551().method_22683().method_4506()-controller.clickGuiScreenTop()-16)/controller.clickGuiScreenScale()-44;
    }
    public boolean isOpen(){return opened;}
    public void open(){opened=true;}
    public void close(){opened=false;}
    public ConfigLibrary library(){
        if(library==null){
            var settings=CherryBlossom.INSTANCE.getSettingsManager();
            library=new ConfigLibrary(FabricLoader.getInstance().getConfigDir().resolve("cherryblossom-slots.json"),
                settings::capture,settings::apply,settings::validate,settings::resetAll);
        }
        return library;
    }
    public void action(String action,int slot){
        try {
            if(!TrialAccess.allowed())throw new IllegalStateException("This trial has expired.");
            ConfigLibrary lib=library();String id=ConfigLibrary.slotId(slot);
            switch(action){
                case "save" -> {lib.saveSlot(slot);status="Saved current modules and settings to slot "+(slot+1)+".";}
                case "load" -> {lib.loadConfig(id);CherryBlossom.INSTANCE.getSettingsManager().saveNow();cherryblossom.integration.CherryGui.saveSettings();status="Loaded slot "+(slot+1)+".";}
                case "copy" -> {class_310.method_1551().field_1774.method_1455(lib.copyCode(id));status="Config copied. Share it or paste it into another slot.";}
                case "delete" -> {lib.delete(id);status="Deleted saved config from slot "+(slot+1)+".";}
                case "paste" -> {lib.pasteSlot(slot,class_310.method_1551().field_1774.method_1460());status="Pasted into slot "+(slot+1)+". Press Load to use it.";}
                default -> throw new IllegalArgumentException("Unknown config action.");
            }
            error=false;
        }catch(Exception failure){error=true;status=failure.getMessage()==null?"Could not complete config action.":failure.getMessage();}
    }
    public void render(UiCanvas c,UiInput in,FontAtlas f){
        renderAt(c,in,f,638,77,"Tree");
    }
    public void renderAt(UiCanvas c,UiInput in,FontAtlas f,float x,float y,String backLabel){
        float w=562,h=454;
        c.shadow(x,y,w,h,22,21,0x60000000);
        c.roundRectGradient(x,y,w,h,22,Theme.tint(0xED442839),Theme.tint(0xED251821));
        c.roundRectStroke(x,y,w,h,22,1,Theme.alpha(Theme.accentBright(),.35f));
        if(button(c,in,f,"configs.back",backLabel,x+20,y+20,78,32,true)){close();return;}
        c.textMiddle(f.semibold,"Configs",x+120,y+32,19,-1);
        c.textMiddle(f.regular,"Four slots for your modules and settings",x+22,y+76,11,0xFFD4BBCB);
        try {
            ConfigLibrary lib=library();
            for(int i=0;i<4;i++){
                float sx=x+22+(i%2)*264,sy=y+100+(i/2)*94;
                var profile=lib.slot(i);boolean hover=in.hover("configs.slot."+i,sx,sy,254,82);
                c.roundRect(sx,sy,254,82,12,Theme.alpha(Theme.accentBright(),selected==i?.23f:hover?.12f:.05f));
                c.roundRectStroke(sx,sy,254,82,12,1,Theme.alpha(Theme.accentBright(),selected==i?.85f:.22f));
                c.textMiddle(f.semibold,"Slot "+(i+1),sx+15,sy+22,14,-1);
                c.textMiddle(f.regular,profile==null?"Empty":profile.enabledCount()+" modules enabled",sx+15,sy+44,10.5f,0xFFD4BBCB);
                if(profile!=null)c.textMiddle(f.regular,DateTimeFormatter.ofPattern("dd MMM, HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(profile.updated())),sx+15,sy+63,9,0xFFB9A4B1);
                if(in.clicked("configs.slot."+i))selected=i;
            }
            boolean occupied=lib.slot(selected)!=null;
            String[] actions={"save","load","copy","paste","delete"},labels={"Save config","Load config","Copy config","Paste config","Delete config"};
            for(int i=0;i<5;i++)if(button(c,in,f,"configs."+actions[i],labels[i],x+22+i*105,y+302,98,37,i==0||i==3||occupied))action(actions[i],selected);
        }catch(Exception failure){status=failure.getMessage();error=true;}
        c.textFit(f.medium,status,x+22,y+367,10.5f,w-44,error?0xFFFFA9B9:0xFFE4CDDC);
        c.textMiddle(f.regular,"Save and Paste replace the selected slot.",x+22,y+397,10,0xFFBEA8B6);
        c.textMiddle(f.regular,"Copy shares a saved slot. Load applies it to the client.",x+22,y+417,10,0xFFBEA8B6);
    }
    static boolean button(UiCanvas c,UiInput in,FontAtlas f,String id,String text,float x,float y,float w,float h,boolean enabled){
        boolean hover=enabled&&in.hover(id,x,y,w,h);
        c.roundRect(x,y,w,h,10,Theme.alpha(Theme.accentBright(),enabled?(hover?.34f:.19f):.06f));
        c.roundRectStroke(x,y,w,h,10,1,Theme.alpha(Theme.accentBright(),enabled?.35f:.1f));
        c.textCentered(f.medium,text,x+w/2,y+h/2,10.5f,enabled?-1:0xFF8C7C87);
        return enabled&&in.clicked(id);
    }
}
