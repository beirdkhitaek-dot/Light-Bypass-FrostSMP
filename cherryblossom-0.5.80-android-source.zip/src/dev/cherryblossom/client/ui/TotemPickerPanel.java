package dev.cherryblossom.client.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import dev.cherryblossom.client.render.*;
import dev.cherryblossom.client.render.text.FontAtlas;
import dev.cherryblossom.client.setting.TotemPickerSetting;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import cherryblossom.itemfx.*;
import cherryblossom.itemfx.mesh.*;
import net.minecraft.class_1011;

/** A scrollable thumbnail dropdown; it captures input while open. */
public final class TotemPickerPanel {
    private static final Map<Integer,CompletableFuture<BufferedImage>> IMAGES=new HashMap<>();
    private static final Map<Integer,UiTexture> TEXTURES=new HashMap<>();
    private static TotemPickerSetting setting;
    private static float scroll;
    private static int focus;
    private static boolean justOpened;
    private static long importedRevision=-1;
    private static final float X=636,Y=64,W=540,H=464,LIST_Y=121,LIST_H=350,ROW_H=49;
    private TotemPickerPanel(){}
    public static boolean isOpen(){return setting!=null;}
    public static void open(TotemPickerSetting value){setting=value;scroll=0;focus=0;justOpened=true;}
    public static void close(){setting=null;}
    private static List<Integer> order(){ArrayList<Integer> list=new ArrayList<>();for(int i=5;i<setting.modes().size();i++)list.add(i);for(int i=0;i<5;i++)list.add(i);return list;}
    public static boolean available(int index){return index<5||TotemAssets.entries().get(index-5).available();}
    public static boolean select(int index){if(setting==null||!available(index))return false;setting.set(setting.modes().get(index));close();return true;}
    public static boolean key(int key,int action){
        if(!isOpen())return false;if(action!=1)return true;
        if(key==256){close();return true;}
        List<Integer> list=order();
        if(key==265||key==264){int direction=key==265?-1:1;do{focus=Math.floorMod(focus+direction,list.size());}while(!available(list.get(focus)));scroll=Math.max(0,Math.min(Math.max(0,list.size()*ROW_H-LIST_H),focus*ROW_H-130));}
        else if(key==257||key==335)select(list.get(focus));return true;
    }
    public static void row(UiCanvas c,UiInput in,FontAtlas f,String id,TotemPickerSetting value,float x,float y,float width,float height){
        c.textFit(f.medium,"Totem",x,y+height/2,10.5f,65,-1452833);
        float bx=x+72,bw=width-72;boolean hover=in.hover(id,bx,y+2,bw,height-4);
        c.roundRect(bx,y+2,bw,height-4,10,Theme.tint(hover?0xFF865568:0xFF643C50));thumbnail(c,value.index(),bx+6,y+4,28);
        c.textFit(f.medium,value.get(),bx+42,y+height/2,10.5f,bw-66,-1);c.icon("caret-down",false,bx+bw-14,y+height/2,12,Theme.accentBright());
        if(in.clicked(id))open(value);
    }
    public static void render(UiCanvas c,UiInput in,FontAtlas f){
        if(!isOpen())return;boolean consume=justOpened;justOpened=false;
        c.roundRect(0,0,1240,580,22,0x77000000);c.shadow(X,Y,W,H,18,25,0x77000000);
        c.roundRectGradient(X,Y,W,H,18,Theme.tint(0xFF442839),Theme.tint(0xFF251821));c.roundRectStroke(X,Y,W,H,18,1,Theme.alpha(Theme.accentBright(),.6f));
        c.textMiddle(f.semibold,"Choose a totem",X+20,Y+27,17,-1);in.hover("totem.close",X+W-42,Y+12,28,28);c.icon("x",false,X+W-28,Y+26,14,-1);
        if(!consume&&in.clicked("totem.close")){close();return;}if(!consume&&in.pressed&&!in.inside(X,Y,W,H)){close();return;}
        List<Integer> list=order();if(in.inside(X+10,LIST_Y,W-20,LIST_H)&&in.scroll!=0)scroll-=in.scroll*ROW_H;
        scroll=Math.max(0,Math.min(scroll,Math.max(0,list.size()*ROW_H-LIST_H)));
        c.pushClip(X+10,LIST_Y,W-20,LIST_H);
        for(int i=0;i<list.size();i++) {
            int index=list.get(i);float y=LIST_Y+i*ROW_H-scroll;if(y+ROW_H<LIST_Y||y>LIST_Y+LIST_H)continue;
            boolean enabled=available(index),hover=in.inside(X+12,LIST_Y,W-26,LIST_H)&&in.hover("totem.option."+index,X+14,y,W-32,ROW_H-3);if(hover)focus=i;
            boolean selected=setting.index()==index;
            c.roundRect(X+14,y+1,W-32,ROW_H-4,10,selected?Theme.alpha(Theme.accentBright(),.27f):hover?0x22FFFFFF:0x08000000);thumbnail(c,index,X+21,y+5,36);
            c.textFit(f.medium,setting.modes().get(index),X+69,y+17,12,W-116,enabled?-1:0xFFA09AA0);
            String detail=index<5?(index==4?"Your PNG":"Built-in design"):!enabled?"Needs Refined Buckets + Punchy":detail(index-5);
            c.textFit(f.regular,detail,X+69,y+33,9.5f,W-116,enabled?0xFFB8ACB4:0xFFFFB8CC);
            if(selected)c.icon("check",false,X+W-38,y+22,14,Theme.accentBright());
            if(!consume&&enabled&&in.clicked("totem.option."+index)){select(index);break;}
        }
        c.popClip();c.textMiddle(f.regular,"Scroll to browse · click a totem to choose it",X+20,Y+H-24,10,0xFFCEC2CB);
        float content=list.size()*ROW_H;if(content>LIST_H){float thumb=LIST_H*LIST_H/content;float sy=LIST_Y+scroll/(content-LIST_H)*(LIST_H-thumb);c.roundRect(X+W-13,sy,3,thumb,1.5f,Theme.alpha(Theme.accentBright(),.75f));}
    }
    private static String detail(int index){CompletableFuture<BufferedImage> ready=IMAGES.get(index+5);if(ready==null||!ready.isDone()||ready.isCompletedExceptionally())return "Loading preview…";var pack=TotemAssets.pack(index);return (pack.model3d()?"3D model":"Pixel artwork")+(pack.frameCount()>1?" · Animated":"");}
    public static void thumbnail(UiCanvas c,int index,float x,float y,float size){
        if(index==4&&importedRevision!=ImportedTotem.revision()) {
            importedRevision=ImportedTotem.revision();IMAGES.remove(4);
            UiTexture previous=TEXTURES.remove(4);if(previous!=null)previous.close();
        }
        UiTexture texture=TEXTURES.get(index);
        if(texture==null){
            CompletableFuture<BufferedImage> future=IMAGES.computeIfAbsent(index,i->CompletableFuture.supplyAsync(()->{
                if(i>=5)return TotemAssets.pack(i-5).preview();
                return switch(i){case 0->TotemAssets.previewMesh(SpriteModels.build(1).mesh);case 1->TotemAssets.previewMesh(SpriteModels.build(2).mesh);case 2->TotemAssets.previewMesh(SpookyModel.build());case 3->TotemAssets.previewMesh(ChromeModel.build());default->TotemAssets.previewMesh(ImportedTotem.mesh());};
            }));
            if(future.isDone()&&!future.isCompletedExceptionally()){
                BufferedImage source=future.join();try(class_1011 image=new class_1011(source.getWidth(),source.getHeight(),false)){
                    for(int py=0;py<source.getHeight();py++)for(int px=0;px<source.getWidth();px++)image.method_61941(px,py,source.getRGB(px,py));
                    texture=UiTexture.upload("totem preview "+index,image,false,RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST));TEXTURES.put(index,texture);
                }
            }
        }
        c.roundRect(x,y,size,size,6,0x33000000);if(texture==null){c.icon("image",false,x+size/2,y+size/2,size*.5f,Theme.alpha(Theme.accentBright(),.6f));return;}
        float scale=Math.min(size/texture.width(),size/texture.height()),w=texture.width()*scale,h=texture.height()*scale;c.image(texture.view(),texture.sampler(),x+(size-w)/2,y+(size-h)/2,w,h,0,-1);
    }
    public static void release(){for(UiTexture texture:TEXTURES.values())texture.close();TEXTURES.clear();}
}
