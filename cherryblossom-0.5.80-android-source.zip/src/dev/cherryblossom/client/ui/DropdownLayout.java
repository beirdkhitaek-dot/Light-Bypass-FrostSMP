package dev.cherryblossom.client.ui;

import dev.cherryblossom.client.module.Category;
import dev.cherryblossom.client.module.Module;
import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.render.UiCanvas;
import dev.cherryblossom.client.render.text.FontAtlas;
import dev.cherryblossom.client.setting.Setting;
import dev.cherryblossom.client.setting.ModeSetting;
import dev.cherryblossom.client.setting.TotemPickerSetting;
import dev.cherryblossom.client.sound.CherryBlossomSounds;
import java.util.*;

/** Six glass branch dropdowns, sharing the tree's module/setting instances. */
final class DropdownLayout {
    private final ClickGui owner;
    private final UiAnimations anim;
    private final Set<Category> collapsed=EnumSet.noneOf(Category.class);
    private final Map<Category,Float> scroll=new EnumMap<>(Category.class);
    private String lastQuery="",hint;
    static final float X=16,Y=114,GAP=12,COLUMN=(1208-5*GAP)/6,HEADER=42,VIEW=366,ROW=34;
    DropdownLayout(ClickGui owner,UiAnimations anim){this.owner=owner;this.anim=anim;}
    private List<Module> modules(Category category,String query){return ModuleManager.of(category).stream().filter(m->query.isEmpty()||m.name().toLowerCase(Locale.ROOT).contains(query)||m.description().toLowerCase(Locale.ROOT).contains(query)).toList();}
    void render(UiCanvas c,UiInput in,FontAtlas f,float time){
        String query=owner.dropdownQuery().strip().toLowerCase(Locale.ROOT);if(!lastQuery.equals(query)){scroll.clear();lastQuery=query;}
        hint="Scroll each branch  ·  click to toggle  ·  right-click or use the arrow for settings";
        c.roundRect(0,0,1240,580,22,0x220A050D);
        c.shadow(16,18,1208,72,16,20,0x55000000);
        glass(c,16,18,1208,72,16);
        boolean markHover=in.hover("dropdown.tree.mark",29,29,46,46);
        c.roundRect(29,29,46,46,12,Theme.alpha(Theme.accentBright(),markHover?.29f:.16f));
        CherryBlossomMark.draw(c,52,52,29,Theme.accentBright());
        if(in.clicked("dropdown.tree.mark"))tree();
        c.textMiddle(f.semibold,"CherryBlossom",89,42,20,-1);
        c.textMiddle(f.regular,"Dropdown  ·  "+ModuleManager.all().size()+" modules",90,65,10.5f,0xFFCEBCCA);
        owner.drawWheelSearch(c,in,f,385,37,640,34);
        boolean back=in.hover("dropdown.tree",1044,35,164,38);
        c.roundRect(1044,35,164,38,11,Theme.alpha(Theme.accentBright(),back?.28f:.12f));
        c.icon("tree",false,1064,54,16,Theme.accentBright());c.textMiddle(f.medium,"Tree layout",1081,54,12,0xFFEEDFE9);
        if(in.clicked("dropdown.tree"))tree();
        Category[] categories=Category.values();
        for(int i=0;i<categories.length;i++)column(c,in,f,categories[i],X+i*(COLUMN+GAP),query);
        owner.dropdownSearchBlur(in);
        c.textFit(f.regular,hint,22,554,10.5f,1196,0xFFC7B0C0);
    }
    private void tree(){owner.wheelMode(true);CherryBlossomSounds.play(CherryBlossomSounds.TAB,.7f);}
    private static void glass(UiCanvas c,float x,float y,float w,float h,float r){
        c.roundRectGradient(x,y,w,h,r,Theme.tint(0xF0442839),Theme.tint(0xF0251821));
        c.roundRectStroke(x,y,w,h,r,1,Theme.alpha(Theme.accentBright(),.23f));
    }
    private void column(UiCanvas c,UiInput in,FontAtlas f,Category category,float x,String query){
        List<Module> modules=modules(category,query);String base="dropdown.category."+category.name();
        boolean open=!query.isEmpty()||!collapsed.contains(category);
        float progress=Math.max(0,Math.min(1,anim.get(base+".open",open,13)));
        float content=8;for(Module module:modules)content+=ROW+expandedHeight(module)*owner.dropdownExpansion(module);
        if(modules.isEmpty())content=58;
        float full=Math.min(VIEW,content),visible=full*progress;
        c.shadow(x,Y,COLUMN,HEADER+visible+4,13,14,0x44000000);glass(c,x,Y,COLUMN,HEADER+visible+4,13);
        boolean hover=in.hover(base,x,Y,COLUMN,HEADER);
        if(hover)c.roundRect(x+1,Y+1,COLUMN-2,HEADER-2,12,Theme.alpha(Theme.accentBright(),.1f));
        c.icon(category.icon(),false,x+19,Y+21,16,Theme.accentBright());
        c.textMiddle(f.semibold,category.displayName(),x+35,Y+21,12.5f,-1);
        long enabled=ModuleManager.of(category).stream().filter(Module::enabled).count();
        c.textRight(f.medium,enabled+" / "+ModuleManager.of(category).size(),x+COLUMN-27,Y+21,8.5f,0xFFCEB7C8);
        c.icon(open?"caret-down":"caret-right",false,x+COLUMN-15,Y+21,10,Theme.accentBright());
        if(in.clicked(base)){if(!collapsed.add(category))collapsed.remove(category);CherryBlossomSounds.play(CherryBlossomSounds.TAB,.6f);}
        float listY=Y+HEADER,clipBottom=listY+visible;
        float maximum=Math.max(0,content-full),offset=Math.max(0,Math.min(maximum,scroll.getOrDefault(category,0f)));
        if(open&&in.inside(x,listY,COLUMN,visible)&&in.scroll!=0)offset=Math.max(0,Math.min(maximum,offset-in.scroll*32));
        scroll.put(category,offset);
        if(visible<=1)return;
        c.roundRect(x+10,listY-1,COLUMN-20,1,0,0x16FFFFFF);
        c.pushClip(x+3,listY,COLUMN-6,visible);
        if(modules.isEmpty())c.textCentered(f.regular,"No matches",x+COLUMN/2,listY+28,10,0xFFB9A3B3);
        float rowY=listY+4-offset;
        for(Module module:modules){
            float expansion=owner.dropdownExpansion(module),settings=expandedHeight(module),reveal=settings*expansion;
            boolean fully=rowY>=listY&&rowY+ROW<=clipBottom;
            UiInput rowInput=fully?in:UiInput.INERT;String id="dropdown.module."+module.id();
            if(rowY+ROW>=listY&&rowY<=clipBottom){
                boolean row=rowInput.hover(id,x+7,rowY,COLUMN-38,ROW-2),arrow=rowInput.hover(id+".settings",x+COLUMN-31,rowY,24,ROW-2);
                float active=anim.get(id+".active",module.enabled(),12),h=anim.get(id+".hover",row||arrow,14);
                c.roundRect(x+6,rowY+1,COLUMN-12,ROW-3,8,Theme.alpha(Theme.accentBright(),.14f*active+.09f*h));
                if(active>.01)c.roundRect(x+8,rowY+9,2,14,1,Theme.alpha(Theme.accentBright(),active));
                c.textFit(module.enabled()?f.semibold:f.medium,module.name(),x+16,rowY+ROW/2,12,COLUMN-52,module.enabled()?-1:0xFFDDCBD8);
                c.icon(owner.dropdownExpanded(module)?"caret-down":"caret-right",false,x+COLUMN-19,rowY+ROW/2,10,Theme.alpha(Theme.accentBright(),.6f+.4f*h));
                if(row||arrow)hint=module.name()+"  ·  "+module.description();
                if(rowInput.clicked(id)){module.toggle();CherryBlossomSounds.play(module.enabled()?CherryBlossomSounds.TOGGLE_ON:CherryBlossomSounds.TOGGLE_OFF,.75f);}
                if(rowInput.clicked(id+".settings")||rowInput.secondaryClicked(x+6,rowY,COLUMN-12,ROW-2))owner.dropdownExpand(module);
            }
            if(reveal>.5f&&rowY+ROW+reveal>=listY&&rowY+ROW<clipBottom)settings(c,in,f,module,x+7,rowY+ROW,COLUMN-14,settings,expansion,listY,clipBottom);
            rowY+=ROW+reveal;
        }
        c.popClip();
        if(maximum>0&&open&&progress>.95f){float thumb=Math.max(22,full*full/content),sy=listY+(full-thumb)*offset/maximum;c.roundRect(x+COLUMN-5,sy,2,Math.min(thumb,visible),1,Theme.alpha(Theme.accentBright(),.5f));}
    }
    static float height(Setting<?> setting){return setting instanceof ModeSetting?53:ClickGui.settingHeight(setting);}
    static float expandedHeight(Module module){float h=10;for(var s:module.settings())if(s.isVisible())h+=height(s);return h;}
    private void settings(UiCanvas c,UiInput in,FontAtlas f,Module module,float x,float y,float w,float total,float progress,float clipTop,float clipBottom){
        float reveal=total*progress;c.pushAlpha(progress);c.roundRect(x,y,w,reveal,8,0x24000000);c.pushClip(x+1,y,w-2,reveal);
        float row=y+5;
        for(Setting<?> setting:module.settings()){
            if(!setting.isVisible())continue;float h=height(setting);
            boolean interactive=row>=clipTop&&row+h<=clipBottom&&row+h<=y+reveal;
            UiInput input=interactive?in:UiInput.INERT;
            if(setting instanceof ModeSetting mode){
                String id="dropdown.setting."+module.id()+"."+setting.id();
                c.textFit(f.medium,setting.name(),x+7,row+9,10,w-14,0xFFE4D1DF);
                boolean hover=input.hover(id,x+5,row+20,w-10,28);
                c.roundRect(x+5,row+20,w-10,28,8,Theme.alpha(Theme.accentBright(),hover?.24f:.12f));
                float labelX=x+13,labelW=w-36;
                if(mode instanceof TotemPickerSetting picker){TotemPickerPanel.thumbnail(c,picker.index(),x+8,row+23,22);labelX=x+36;labelW=w-58;}
                c.textFit(f.medium,mode.get(),labelX,row+34,10,labelW,0xFFF1DFEB);c.icon("caret-down",false,x+w-15,row+34,9,Theme.accentBright());
                if(input.clicked(id)){if(mode instanceof TotemPickerSetting picker)TotemPickerPanel.open(picker);else mode.cycle(1);CherryBlossomSounds.play(CherryBlossomSounds.TAB,.6f);}
            }else owner.drawSetting(c,input,f,module,setting,x+7,row,w-14,h);
            row+=h;
        }
        c.popClip();c.popAlpha();
    }
}
