/*
 * Decompiled with CFR 0.152.
 */
package dev.cherryblossom.client.ui;

public final class Spring {
    private float value;
    private float velocity;
    private float target;
    private final float stiffness;

    public Spring(float initial, float stiffness) {
        this.value = initial;
        this.target = initial;
        this.stiffness = stiffness;
    }

    public Spring target(float target) {
        this.target = target;
        return this;
    }

    public void snap(float value) {
        this.value = value;
        this.target = value;
        this.velocity = 0.0f;
    }

    public float update(float dt) {
        int mode=cherryblossom.module.modules.client.CherryBlossom.animationMode.getModeIndex();
        if(mode==2){snap(this.target);return this.value;}
        dt = Math.max(0,Math.min(dt, 0.05f));
        if(mode==1){
            float omega=Math.max(.001f,this.stiffness), damping=.65f, wd=omega*(float)Math.sqrt(1-damping*damping);
            float x=this.value-this.target,b=(this.velocity+damping*omega*x)/wd;
            float decay=(float)Math.exp(-damping*omega*dt),cos=(float)Math.cos(wd*dt),sin=(float)Math.sin(wd*dt);
            this.value=this.target+decay*(x*cos+b*sin);
            this.velocity=decay*(-damping*omega*(x*cos+b*sin)+wd*(-x*sin+b*cos));
            return this.value;
        }
        float omega = this.stiffness;
        float x = this.value - this.target;
        float exp = (float)Math.exp(-omega * dt);
        float newX = (x + (this.velocity + omega * x) * dt) * exp;
        this.velocity = (this.velocity - omega * (this.velocity + omega * x) * dt) * exp;
        this.value = this.target + newX;
        return this.value;
    }

    public float value() {
        return this.value;
    }

    public float target() {
        return this.target;
    }
}

