package dev.cherryblossom.client.discord;

import com.google.gson.*;
import com.sun.jna.platform.win32.*;
import com.sun.jna.ptr.IntByReference;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Discord's local IPC protocol. Each write is one complete little-endian frame. */
public final class DiscordIpc {
    public interface Connection extends Closeable {
        InputStream input();
        OutputStream output();
    }
    @FunctionalInterface public interface Connector {Connection open() throws IOException;}
    public record Frame(int opcode,byte[] payload){
        public JsonObject json()throws IOException{
            try{return JsonParser.parseString(new String(payload,StandardCharsets.UTF_8)).getAsJsonObject();}
            catch(RuntimeException e){throw new IOException("Invalid Discord IPC response",e);}
        }
    }
    private DiscordIpc(){}
    public static byte[] packet(int opcode,byte[] payload){
        return ByteBuffer.allocate(8+payload.length).order(ByteOrder.LITTLE_ENDIAN).putInt(opcode).putInt(payload.length).put(payload).array();
    }
    public static Frame read(InputStream input)throws IOException {
        byte[] header=input.readNBytes(8);if(header.length!=8)throw new EOFException("Discord disconnected");
        ByteBuffer buffer=ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
        int opcode=buffer.getInt(),length=buffer.getInt();
        if(opcode<0||opcode>4||length<0||length>1_048_576)throw new IOException("Invalid Discord IPC frame");
        byte[] body=input.readNBytes(length);if(body.length!=length)throw new EOFException("Truncated Discord IPC response");
        return new Frame(opcode,body);
    }
    public static Connection openLocal()throws IOException {
        if(System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")){
            for(int i=0;i<10;i++)try{return new WindowsConnection("\\\\.\\pipe\\discord-ipc-"+i);}catch(IOException ignored){}
        }else{
            Set<Path> roots=new LinkedHashSet<>();
            for(String key:List.of("XDG_RUNTIME_DIR","TMPDIR","TMP","TEMP")){
                String value=System.getenv(key);if(value!=null&&!value.isBlank())roots.add(Path.of(value));
            }
            roots.add(Path.of("/tmp"));
            for(Path root:roots)for(int i=0;i<10;i++){
                SocketChannel channel=null;
                try{
                    channel=SocketChannel.open(StandardProtocolFamily.UNIX);
                    channel.connect(UnixDomainSocketAddress.of(root.resolve("discord-ipc-"+i)));
                    SocketChannel socket=channel;
                    // Direct channel I/O permits one reader and one writer concurrently.
                    InputStream input=new InputStream(){
                        public int read()throws IOException{byte[] b=new byte[1];return read(b,0,1)<0?-1:b[0]&255;}
                        public int read(byte[] b,int off,int len)throws IOException{return socket.read(ByteBuffer.wrap(b,off,len));}
                    };
                    OutputStream output=new OutputStream(){
                        public void write(int b)throws IOException{write(new byte[]{(byte)b},0,1);}
                        public void write(byte[] b,int off,int len)throws IOException{ByteBuffer bytes=ByteBuffer.wrap(b,off,len);while(bytes.hasRemaining())socket.write(bytes);}
                    };
                    return new Connection(){public InputStream input(){return input;}public OutputStream output(){return output;}public void close()throws IOException{socket.close();}};
                }catch(IOException|UnsupportedOperationException ignored){if(channel!=null)try{channel.close();}catch(IOException ignoredClose){}}
            }
        }
        throw new IOException("Discord desktop is not running");
    }

    /** Poll before reading: synchronous Windows pipe reads otherwise block writes. */
    private static final class WindowsConnection implements Connection {
        private final WinNT.HANDLE handle;
        private final Object io=new Object();
        private volatile boolean closed;
        WindowsConnection(String path)throws IOException {
            handle=Kernel32.INSTANCE.CreateFile(path,WinNT.GENERIC_READ|WinNT.GENERIC_WRITE,0,null,WinNT.OPEN_EXISTING,0,null);
            if(handle==null||WinBase.INVALID_HANDLE_VALUE.equals(handle))throw new IOException("Discord pipe unavailable");
        }
        private IOException error(){return new IOException("Discord pipe error "+Kernel32.INSTANCE.GetLastError());}
        private final InputStream input=new InputStream(){
            public int read()throws IOException{byte[] b=new byte[1];return read(b,0,1)<0?-1:b[0]&255;}
            public int read(byte[] b,int off,int len)throws IOException{
                Objects.checkFromIndexSize(off,len,b.length);if(len==0)return 0;
                while(!closed){
                    synchronized(io){
                        if(closed)break;
                        IntByReference available=new IntByReference();
                        if(!Kernel32.INSTANCE.PeekNamedPipe(handle,null,0,null,available,null))throw error();
                        int count=Math.min(len,available.getValue());
                        if(count>0){
                            byte[] data=new byte[count];IntByReference read=new IntByReference();
                            if(!Kernel32.INSTANCE.ReadFile(handle,data,count,read,null))throw error();
                            if(read.getValue()==0)throw new EOFException("Discord pipe closed");
                            System.arraycopy(data,0,b,off,read.getValue());return read.getValue();
                        }
                    }
                    try{Thread.sleep(10);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException("Discord reader interrupted",e);}
                }
                throw new EOFException("Discord pipe closed");
            }
        };
        private final OutputStream output=new OutputStream(){
            public void write(int b)throws IOException{write(new byte[]{(byte)b},0,1);}
            public void write(byte[] b,int off,int len)throws IOException{
                Objects.checkFromIndexSize(off,len,b.length);byte[] data=off==0&&len==b.length?b:Arrays.copyOfRange(b,off,off+len);
                synchronized(io){
                    if(closed)throw new EOFException("Discord pipe closed");
                    IntByReference written=new IntByReference();
                    if(!Kernel32.INSTANCE.WriteFile(handle,data,len,written,null))throw error();
                    if(written.getValue()!=len)throw new IOException("Incomplete Discord pipe write");
                }
            }
        };
        public InputStream input(){return input;}public OutputStream output(){return output;}
        public void close(){synchronized(io){if(!closed){closed=true;Kernel32.INSTANCE.CloseHandle(handle);}}}
    }
}
