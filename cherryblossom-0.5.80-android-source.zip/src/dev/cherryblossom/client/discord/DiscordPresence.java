package dev.cherryblossom.client.discord;

import com.google.gson.*;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/** Background-only presence publisher. Missing Discord never blocks Minecraft. */
public final class DiscordPresence implements AutoCloseable {
    public record Config(boolean enabled,String applicationId,String invite,boolean playing) {
        public Config {applicationId=Objects.requireNonNullElse(applicationId,"").trim();invite=normalizeInvite(invite);}
    }
    private static final long HANDSHAKE_TIMEOUT=8_000,ACK_TIMEOUT=15_000;
    private final DiscordIpc.Connector connector;
    private final long retryDelay;
    private final ScheduledExecutorService worker;
    private final long started=Instant.now().getEpochSecond();
    private volatile Config desired=new Config(false,"","",false);
    private volatile Session session;
    private volatile boolean closed;
    private volatile String status="Disabled";
    private long nextAttempt;
    private Config sent;

    public DiscordPresence(){this(DiscordIpc::openLocal,15_000);}
    public DiscordPresence(DiscordIpc.Connector connector,long retryDelay){
        this.connector=connector;this.retryDelay=retryDelay;
        worker=Executors.newSingleThreadScheduledExecutor(task->{Thread t=new Thread(task,"CherryBlossom Discord RPC");t.setDaemon(true);return t;});
    }
    public void start(){worker.scheduleWithFixedDelay(this::pulse,0,250,TimeUnit.MILLISECONDS);}
    public void configure(Config config){desired=Objects.requireNonNull(config);}
    public String status(){return status;}
    public static boolean validId(String id){return id!=null&&id.matches("[1-9][0-9]{16,19}");}
    public static String normalizeInvite(String value){
        if(value==null||value.isBlank())return "";
        try{
            String text=value.trim();if(text.startsWith("discord.gg/")||text.startsWith("discord.com/invite/"))text="https://"+text;
            URI uri=URI.create(text);String host=uri.getHost(),path=uri.getPath();
            boolean allowed="discord.gg".equalsIgnoreCase(host)?path!=null&&path.matches("/[A-Za-z0-9_-]+")
                    :"discord.com".equalsIgnoreCase(host)&&path!=null&&path.matches("/invite/[A-Za-z0-9_-]+");
            return allowed&&"https".equalsIgnoreCase(uri.getScheme())&&uri.getUserInfo()==null&&uri.getPort()==-1&&uri.getQuery()==null&&uri.getFragment()==null?uri.toASCIIString():"";
        }catch(IllegalArgumentException e){return "";}
    }
    public static JsonObject activity(Config config,long started){
        JsonObject activity=new JsonObject();activity.addProperty("type",0);
        activity.addProperty("details","Using CherryBlossomClient");
        activity.addProperty("state",config.playing()?"Playing Minecraft":"In the menus");
        JsonObject timestamps=new JsonObject();timestamps.addProperty("start",started);activity.add("timestamps",timestamps);
        if(!config.invite().isEmpty()){
            JsonObject button=new JsonObject();button.addProperty("label","Discord");button.addProperty("url",config.invite());
            JsonArray buttons=new JsonArray();buttons.add(button);activity.add("buttons",buttons);
        }
        return activity;
    }
    private void pulse(){
        if(closed)return;
        try{
            Config config=desired;long now=System.currentTimeMillis();
            if(!config.enabled()||!validId(config.applicationId())){
                disconnect(true);nextAttempt=0;status=config.enabled()?"Set Discord Application ID":"Disabled";return;
            }
            Session current=session;
            if(current!=null&&!current.id.equals(config.applicationId())){disconnect(true);current=null;nextAttempt=0;}
            if(current!=null&&(current.failed||(!current.ready&&now-current.opened>HANDSHAKE_TIMEOUT)
                    ||(current.pending!=null&&now-current.requested>ACK_TIMEOUT))){disconnect(false);current=null;status="Waiting to reconnect to Discord";nextAttempt=now+retryDelay;}
            if(current==null){
                if(now<nextAttempt)return;nextAttempt=now+retryDelay;status="Connecting to Discord";
                try{
                    current=new Session(connector.open(),config.applicationId());session=current;
                    JsonObject hello=new JsonObject();hello.addProperty("v",1);hello.addProperty("client_id",config.applicationId());
                    current.send(0,hello);current.listen();
                }catch(IOException e){disconnect(false);status="Waiting for Discord desktop";return;}
            }
            if(current.ready&&current.pending==null&&!config.equals(sent)){
                current.publish(activity(config,started));sent=config;
            }
        }catch(Throwable error){disconnect(false);status="Waiting to reconnect to Discord";nextAttempt=System.currentTimeMillis()+retryDelay;}
    }
    private void disconnect(boolean clear){
        Session old=session;session=null;sent=null;
        if(old!=null){
            try{
                if(clear&&old.ready&&!old.failed){
                    old.publish(null);
                    // Await the clear ACK briefly on this worker, never on Minecraft's thread.
                    long until=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(750);
                    while(old.pending!=null&&!old.failed&&System.nanoTime()<until)Thread.sleep(10);
                }
            }catch(IOException ignored){}catch(InterruptedException interrupted){Thread.currentThread().interrupt();}
            old.retired=true;
            try{old.connection.close();}catch(IOException ignored){}
        }
    }
    @Override public synchronized void close(){
        if(closed)return;closed=true;
        worker.execute(()->{disconnect(true);status="Disabled";worker.shutdown();});
    }
    private final class Session {
        final DiscordIpc.Connection connection;
        final String id;
        final long opened=System.currentTimeMillis();
        volatile boolean ready,failed,retired;
        volatile String pending;
        volatile long requested;
        Session(DiscordIpc.Connection connection,String id){this.connection=connection;this.id=id;}
        synchronized void send(int opcode,byte[] bytes)throws IOException {connection.output().write(DiscordIpc.packet(opcode,bytes));connection.output().flush();}
        void send(int opcode,JsonObject json)throws IOException {send(opcode,json.toString().getBytes(StandardCharsets.UTF_8));}
        void publish(JsonObject activity)throws IOException {
            JsonObject args=new JsonObject();args.addProperty("pid",ProcessHandle.current().pid());args.add("activity",activity==null?JsonNull.INSTANCE:activity);
            JsonObject request=new JsonObject();request.addProperty("cmd","SET_ACTIVITY");request.add("args",args);
            String nonce=UUID.randomUUID().toString();pending=nonce;requested=System.currentTimeMillis();request.addProperty("nonce",nonce);send(1,request);
        }
        void listen(){
            Thread reader=new Thread(()->{
                try{
                    while(!retired){
                        DiscordIpc.Frame frame=DiscordIpc.read(connection.input());
                        if(frame.opcode()==2)throw new EOFException("Discord closed RPC");
                        if(frame.opcode()==3){send(4,frame.payload());continue;}
                        if(frame.opcode()!=1)continue;
                        JsonObject json=frame.json();
                        String event=json.has("evt")&&!json.get("evt").isJsonNull()?json.get("evt").getAsString():"";
                        if("ERROR".equals(event)){status="Discord rejected the application or activity";throw new IOException("Discord RPC error");}
                        if("READY".equals(event)){ready=true;status="Connected to Discord";}
                        if(json.has("nonce")&&!json.get("nonce").isJsonNull()&&json.get("nonce").getAsString().equals(pending)){pending=null;status="Showing CherryBlossomClient on Discord";}
                    }
                }catch(Exception e){failed=true;}
            },"CherryBlossom Discord IPC reader");reader.setDaemon(true);reader.start();
        }
    }
}
