/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1109
 *  net.minecraft.class_1113
 *  net.minecraft.class_1140$class_11518
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3414
 */
package dev.cherryblossom.client.sound;

import dev.cherryblossom.client.CherryBlossomClient;
import dev.cherryblossom.client.setting.CherryBlossomSettings;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;

public final class CherryBlossomSounds {
    public static final class_3414 HOVER = CherryBlossomSounds.event("ui.hover");
    public static final class_3414 CLICK = CherryBlossomSounds.event("ui.click");
    public static final class_3414 TAB = CherryBlossomSounds.event("ui.tab");
    public static final class_3414 TOGGLE_ON = CherryBlossomSounds.event("ui.toggle_on");
    public static final class_3414 TOGGLE_OFF = CherryBlossomSounds.event("ui.toggle_off");
    public static final class_3414 PANEL_OPEN = CherryBlossomSounds.event("ui.panel_open");
    public static final class_3414 PANEL_CLOSE = CherryBlossomSounds.event("ui.panel_close");
    public static final class_3414 MENU_OPEN = CherryBlossomSounds.event("ui.menu_open");
    public static final class_3414 MENU_CLOSE = CherryBlossomSounds.event("ui.menu_close");
    public static final class_3414 SLIDER = CherryBlossomSounds.event("ui.slider");
    public static final class_3414 KEYBIND = CherryBlossomSounds.event("ui.keybind");
    public static final class_3414 NOTIFY = CherryBlossomSounds.event("ui.notify");
    public static final class_3414 RECENTER = CherryBlossomSounds.event("ui.recenter");
    public static final class_3414 DENY = CherryBlossomSounds.event("ui.deny");
    public static final class_3414 EQUIP = CherryBlossomSounds.event("headset.equip");
    public static final class_3414 REMOVE = CherryBlossomSounds.event("headset.remove");
    public static final class_3414 BOOT = CherryBlossomSounds.event("headset.boot");
    private static final Set<class_3414> WARNED = new HashSet<class_3414>();

    private CherryBlossomSounds() {
    }

    private static class_3414 event(String name) {
        return class_3414.method_47908((class_2960)CherryBlossomClient.id(name));
    }

    public static float effectiveVolume(float requested) {
        if(!cherryblossom.module.modules.client.CherryBlossom.uiSounds.getValue())return 0;
        return Math.min(.3f, Math.max(0,requested)*(float)(cherryblossom.module.modules.client.CherryBlossom.uiVolume.getValue()/100.0)*.3f);
    }
    public static void play(class_3414 sound, float volume) {
        CherryBlossomSounds.play(sound, volume, 1.0f);
    }

    public static void play(class_3414 sound, float volume, float pitch) {
        boolean openingCue = sound.comp_3319().method_12832().endsWith("menu_open");
        float scaled = effectiveVolume(volume) * (openingCue ? 0.52f : 1.0f);
        if (scaled <= 0.001f) {
            return;
        }
        float gentlePitch = Math.max(0.5f, Math.min(2.0f, openingCue ? Math.min(pitch, 1.0f) : pitch));
        class_1140.class_11518 result = class_310.method_1551().method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)sound, (float)gentlePitch, (float)Math.min(0.3f, scaled)));
        if (result == class_1140.class_11518.field_60956 && WARNED.add(sound)) {
            CherryBlossomClient.LOGGER.warn("Sound {} was not started by the sound engine (is the Interface volume at 0?)", (Object)sound.comp_3319());
        }
    }
}

