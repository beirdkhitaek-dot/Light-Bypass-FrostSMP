package dev.cherryblossom.client.module;

import com.google.gson.JsonObject;
import dev.cherryblossom.client.setting.SettingsStore;
import java.util.*;
import net.minecraft.class_310;

/** Only imported modules are registered. CherryBlossom owns feature events and key presses. */
public final class ModuleManager {
    private static final Map<String, Module> MODULES = new LinkedHashMap<>();
    public static void init() {
        if (!MODULES.isEmpty()) return;
        if (cherryblossom.CherryBlossom.INSTANCE == null || cherryblossom.CherryBlossom.INSTANCE.getModuleManager() == null)
            throw new IllegalStateException("CherryBlossom runtime did not initialize");
        for (cherryblossom.module.Module module : cherryblossom.CherryBlossom.INSTANCE.getModuleManager().c()) {
            CherryBlossomModule wrapper=new CherryBlossomModule(module);
            if (MODULES.putIfAbsent(wrapper.id(), wrapper)!=null) throw new IllegalStateException("Duplicate module: "+wrapper.id());
        }
        // Register for the normal Cherry save cadence, using CherryBlossom's native serialization.
        SettingsStore.register("cherryblossom-modules.json", ModuleManager::write, ModuleManager::read);
    }
    public static List<Module> all() { return List.copyOf(MODULES.values()); }
    public static List<Module> of(Category category) { return MODULES.values().stream().filter(m->m.category()==category).toList(); }
    public static Module get(String id) { return MODULES.get(id); }
    public static int enabledCount() { return (int)MODULES.values().stream().filter(Module::enabled).count(); }
    public static int enabledCount(Category category) { return (int)of(category).stream().filter(Module::enabled).count(); }
    public static void tickKeybinds(class_310 client, boolean captured) {
        for (Module module:MODULES.values()) ((CherryBlossomModule)module).pull();
    }
    private static JsonObject write() { return cherryblossom.CherryBlossom.INSTANCE.getSettingsManager().capture(); }
    private static void read(JsonObject root) {
        cherryblossom.CherryBlossom.INSTANCE.getSettingsManager().apply(root);
        for (Module module:MODULES.values()) ((CherryBlossomModule)module).pull();
    }
}
