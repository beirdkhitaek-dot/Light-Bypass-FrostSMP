package dev.cherryblossom.client.module;

/** The imported client's complete tab order. */
public enum Category {
    COMBAT("Combat", "sword", 0xFFFF8FBD),
    MISC("Misc", "squares-four", 0xFFFFA7CC),
    MACROS("Macros", "keyboard", 0xFFFFBBCE),
    DONUT("Donut", "donut", 0xFFFFC0D6),
    RENDER("Render", "eye", 0xFFE6B8FF),
    CLIENT("Client", "user", 0xFFFFD1E3);

    private final String displayName, icon;
    private final int color;
    Category(String name, String icon, int color) { this.displayName=name; this.icon=icon; this.color=color; }
    public String displayName() { return displayName; }
    public String icon() { return icon; }
    public String description() { return displayName + " modules from CherryBlossom"; }
    public int color() { return color; }

    // Binary aliases for Cherry presentation classes; these are not enum values or tabs.
    public static final Category MOVEMENT=MISC, PLAYER=MISC, WORLD=DONUT,
        VISUAL=RENDER, LEGIT=MISC, AC_OFF=MISC, DONUT_SMP=DONUT;
}
