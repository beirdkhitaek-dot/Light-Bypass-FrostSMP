package dev.cherryblossom.client.module;

import dev.cherryblossom.client.setting.*;
import java.util.*;
import java.util.function.*;
import cherryblossom.integration.CherryGui;
import cherryblossom.module.setting.*;

/** Every visible control writes through to the original feature instance. */
public final class CherryBlossomModule extends Module {
    private static final java.lang.reflect.Field VALUE;
    static {
        try {VALUE=dev.cherryblossom.client.setting.Setting.class.getDeclaredField("value");VALUE.setAccessible(true);}
        catch(ReflectiveOperationException e){throw new ExceptionInInitializerError(e);}
    }
    private final cherryblossom.module.Module nativeModule;
    private final List<Runnable> refresh = new ArrayList<>();
    private boolean pulling;
    private int sequence;

    public CherryBlossomModule(cherryblossom.module.Module module) {
        super("cherryblossom_"+module.getClass().getName().replace('.', '_'),
            module instanceof cherryblossom.module.modules.client.CherryBlossom ? "CherryBlossom+" : module.getName().toString(),
            Objects.toString(module.getDescription(), ""), Category.valueOf(module.getCategory().name()).icon(),
            Category.valueOf(module.getCategory().name()));
        nativeModule=module;
        bind(keybind(), module::getKeybind, v->{
            module.setKeybind(v);
            for (cherryblossom.module.setting.Setting setting:module.getSettings())
                if (setting instanceof BindSetting b && b.isModuleKey()) b.setValue(v);
        });
        List<dev.cherryblossom.client.setting.Setting<?>> controls=new ArrayList<>();
        controls.add(keybind());
        controls.add(new ModuleResetSetting(()->resetModule(true),()->resetModule(false)));
        for (cherryblossom.module.setting.Setting setting:module.getSettings()) add(setting,controls);
        group("Settings", controls.toArray(dev.cherryblossom.client.setting.Setting<?>[]::new));
    }
    public cherryblossom.module.Module nativeModule() { return nativeModule; }
    private void resetModule(boolean keybindOnly) {
        dev.cherryblossom.client.CherryBlossomController.get().stopKeyboardCapture();
        cherryblossom.CherryBlossom.INSTANCE.getSettingsManager().resetModule(nativeModule,keybindOnly);
        pull();SettingsStore.markDirty();
    }
    @Override public boolean enabled() { return nativeModule.isEnabled(); }
    @Override public void setEnabled(boolean enabled) {
        nativeModule.toggle(enabled);
        SettingsStore.markDirty();
    }
    @Override public void toggle() { setEnabled(!enabled()); }
    @Override void loadEnabled(boolean enabled) { setEnabled(enabled); }
    public void pull() { pulling=true; try { for (Runnable r:refresh) r.run(); } finally { pulling=false; } }
    private <T> void bind(dev.cherryblossom.client.setting.Setting<T> control, Supplier<T> get, Consumer<T> set) {
        display(control,get.get());
        Object[] last={get.get()};
        control.onChange(()->{ if(!pulling) { set.accept(control.get()); last[0]=get.get(); SettingsStore.markDirty(); } });
        refresh.add(()->{
            T value=get.get();
            if(!Objects.equals(value,last[0])) { display(control,value); last[0]=value; }
        });
    }
    private static void display(dev.cherryblossom.client.setting.Setting<?> control,Object value) {
        try {VALUE.set(control,value);}catch(IllegalAccessException e){throw new IllegalStateException(e);}
    }
    private String nextId() { return "option_"+(sequence++); }
    private void add(cherryblossom.module.setting.Setting source, List<dev.cherryblossom.client.setting.Setting<?>> out) {
        if(source instanceof BindSetting b && b.isModuleKey()) return;
        String id=nextId(), name=source.getName().toString(), desc=Objects.toString(source.getDescription(), "");
        int begin=out.size();
        if(source instanceof BooleanSetting b) {
            var c=new BoolSetting(id,name,desc,b.getDefaultValue()); bind(c,b::getValue,b::setValue); out.add(c);
        } else if(source instanceof NumberSetting n) {
            var c=new SliderSetting(id,name,desc,n.getDefaultValue(),n.getMin(),n.getMax(),n.getFormat(),"");
            bind(c,n::getValue,v->{n.getValue(v);display(c,n.getValue());}); out.add(c);
        } else if(source instanceof cherryblossom.module.setting.ModeSetting<?> m) {
            List<? extends Enum<?>> values=m.getPossibleValues();
            String[] names=values.stream().map(Enum::toString).toArray(String[]::new);
            var c=nativeModule instanceof cherryblossom.feature.CustomTotemModule && source==cherryblossom.feature.CustomTotemModule.design
                ? new TotemPickerSetting(id,name,desc,names[m.getOriginalValue()],names)
                : new dev.cherryblossom.client.setting.ModeSetting(id,name,desc,names[m.getOriginalValue()],names);
            bind(c,()->names[m.getModeIndex()],v->m.setModeIndex(Arrays.asList(names).indexOf(v))); out.add(c);
        } else if(source instanceof ChoiceSetting m) {
            var c=new dev.cherryblossom.client.setting.ModeSetting(id,name,desc,m.getDefaultMode(),m.getModes().toArray(String[]::new));
            c.liveModes(m::getModes);
            bind(c,m::getMode,m::setMode); out.add(c);
        } else if(source instanceof StringSetting s) {
            var c=new TextSetting(id,name,desc,s.getValue(),4096); bind(c,s::getValue,s::setValue); out.add(c);
        } else if(source instanceof BindSetting b) {
            var c=new KeySetting(id,name,desc,b.getDefaultValue()); bind(c,b::getValue,b::setValue); out.add(c);
        } else if(source instanceof RgbSetting rgb) {
            // RGB sliders preserve the entire native colour range using Cherry's own controls.
            addColor(id,name,desc,rgb::getArgb,rgb::setArgb,out);
        } else if(source instanceof MinMaxSetting range) {
            var lo=new SliderSetting(id+"_min",name+" minimum",desc,range.getDefaultMin(),range.getMinValue(),range.getMaxValue(),range.getStep(),"");
            var hi=new SliderSetting(id+"_max",name+" maximum",desc,range.getDefaultMax(),range.getMinValue(),range.getMaxValue(),range.getStep(),"");
            bind(lo,range::getCurrentMin,v->{range.setCurrentMin(v);if(v>range.getCurrentMax())range.setCurrentMax(v);});
            bind(hi,range::getCurrentMax,v->{range.setCurrentMax(v);if(v<range.getCurrentMin())range.setCurrentMin(v);});
            out.add(lo); out.add(hi);
        } else if(source instanceof ItemSetting item) {
            var c=new TextSetting(id,name,desc+" (Minecraft item ID)",CherryGui.itemId(item),256);
            bind(c,()->CherryGui.itemId(item),v->CherryGui.setItem(item,v)); out.add(c);
        } else if(source instanceof StorageBlocksSetting blocks) {
            if(nativeModule instanceof cherryblossom.anubis.module.impl.render.BlockEspModule){
                var picker=new BlockPickerSetting(id+"_picker",blocks);picker.visibleWhen(()->SettingVisibility.visible(source));out.add(picker);
                for(var entry:blocks.entries()){
                    int first=out.size();String label=name+" / "+entry.displayName();
                    addColor(id+"_"+entry.id(),label,desc,()->entry.color().getRGB(),v->entry.setColor(new java.awt.Color(v,true)),out);
                    var tracer=new BoolSetting(id+"_"+entry.id()+"_tracer",label+" / Tracers",desc,entry.tracerEnabled());bind(tracer,entry::tracerEnabled,entry::setTracerEnabled);out.add(tracer);
                    addColor(id+"_"+entry.id()+"_tracer_color",label+" / Tracer color",desc,()->entry.tracerColor().getRGB(),v->entry.setTracerColor(new java.awt.Color(v,true)),out);
                    for(int i=first;i<out.size();i++)out.get(i).visibleWhen(()->SettingVisibility.visible(source)&&entry.enabled());
                }
                return;
            }
            final TextSetting search=blocks.hasTracerControls()?new TextSetting(id+"_search","Search Blocks","Find a Minecraft block by name or ID","",160):null;
            final BoolSetting selectedOnly=blocks.hasTracerControls()?new BoolSetting(id+"_selected","Selected Blocks Only","Show selected blocks; searching also shows matching unselected blocks",true):null;
            if(search!=null){search.onChange(SettingsStore::markDirty);selectedOnly.onChange(SettingsStore::markDirty);out.add(search);out.add(selectedOnly);}
            for(var entry:blocks.entries()) {
                int first=out.size();String label=name+" / "+entry.displayName();
                dev.cherryblossom.client.setting.Setting<?> selection=null;
                if(!blocks.isColorOnly()) {
                    var c=new BoolSetting(id+"_"+entry.id(),label,desc,entry.enabled());
                    bind(c,entry::enabled,entry::setEnabled);out.add(c);selection=c;
                }
                if(!blocks.isPickerOnly())addColor(id+"_"+entry.id(),label,desc,()->entry.color().getRGB(),v->entry.setColor(new java.awt.Color(v,true)),out);
                if(blocks.hasTracerControls()){
                    var tracer=new BoolSetting(id+"_"+entry.id()+"_tracer",label+" / Tracers",desc,entry.tracerEnabled());bind(tracer,entry::tracerEnabled,entry::setTracerEnabled);out.add(tracer);
                    addColor(id+"_"+entry.id()+"_tracer_color",label+" / Tracer color",desc,()->entry.tracerColor().getRGB(),v->entry.setTracerColor(new java.awt.Color(v,true)),out);
                }
                for(int i=first;i<out.size();i++){
                    boolean selector=out.get(i)==selection;
                    out.get(i).visibleWhen(()->{
                        if(!SettingVisibility.visible(source))return false;
                        if(search==null)return true;
                        String query=search.get().trim().toLowerCase(Locale.ROOT);
                        return (query.isEmpty()||entry.displayName().toLowerCase(Locale.ROOT).contains(query)||entry.id().toLowerCase(Locale.ROOT).contains(query))
                            &&(!selectedOnly.on()||!query.isEmpty()||entry.enabled())&&(selector||entry.enabled());
                    });
                }
            }
            if(search!=null){search.visibleWhen(()->SettingVisibility.visible(source));selectedOnly.visibleWhen(()->SettingVisibility.visible(source));}
            return;
        } else if(source instanceof ButtonSetting button) {
            var c=new BoolSetting(id,name,desc,false);
            c.onChange(()->{if(!pulling && c.on()){button.run();pulling=true;try{c.set(false);}finally{pulling=false;} SettingsStore.markDirty();}});
            out.add(c);
        } else throw new IllegalStateException("Unsupported setting "+source.getClass().getName()+" in "+name());
        for(int i=begin;i<out.size();i++) out.get(i).visibleWhen(()->SettingVisibility.visible(source));
    }
    private void addColor(String id,String name,String desc,Supplier<Integer> get,Consumer<Integer> set,List<dev.cherryblossom.client.setting.Setting<?>> out) {
        String[] labels={"Red","Green","Blue","Alpha"};
        for(int i=0;i<4;i++) {
            int shift=i==3?24:16-i*8, mask=255<<shift;
            var c=new SliderSetting(id+"_"+labels[i],name+" "+labels[i],desc,(get.get()>>>shift)&255,0,255,1,"");
            bind(c,()->(double)((get.get()>>>shift)&255),v->set.accept((get.get()&~mask)|(v.intValue()<<shift)));
            out.add(c);
        }
    }
}
