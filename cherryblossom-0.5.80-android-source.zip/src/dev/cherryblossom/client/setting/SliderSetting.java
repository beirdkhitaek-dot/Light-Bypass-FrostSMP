/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 */
package dev.cherryblossom.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.cherryblossom.client.setting.Setting;
import java.util.Locale;

public final class SliderSetting
extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;
    private final String unit;
    private final double displayScale;

    public SliderSetting(String id, String name, String description, double defaultValue, double min, double max, double step, String unit) {
        this(id, name, description, defaultValue, min, max, step, unit, 1.0);
    }

    public SliderSetting(String id, String name, String description, double defaultValue, double min, double max, double step, String unit, double displayScale) {
        super(id, name, description, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
        this.unit = unit;
        this.displayScale = displayScale;
    }

    public double min() {
        return this.min;
    }

    public double max() {
        return this.max;
    }

    public double step() {
        return this.step;
    }

    public float floatValue() {
        return ((Double)this.value).floatValue();
    }

    public float fraction() {
        return (float)(((Double)this.value - this.min) / (this.max - this.min));
    }

    public void setFraction(double fraction) {
        this.set(Double.isFinite(fraction) ? this.min + Math.max(0.0, Math.min(1.0, fraction)) * (this.max - this.min) : (Double)this.defaultValue());
    }

    @Override
    protected Double sanitize(Double value) {
        if (java.util.Objects.equals(value, defaultValue())) return value;
        if (value == null || !Double.isFinite(value)) {
            value = (Double)this.defaultValue();
        }
        double clamped = Math.max(this.min, Math.min(this.max, value));
        if (this.step > 0.0) {
            clamped = this.min + (double)Math.round((clamped - this.min) / this.step) * this.step;
        }
        return (double)Math.round(clamped * 1000000.0) / 1000000.0;
    }

    public String format() {
        double shown = (Double)this.value * this.displayScale;
        double shownStep = this.step * this.displayScale;
        String number = shownStep >= 1.0 || shownStep == 0.0 ? Long.toString(Math.round(shown)) : String.format(Locale.ROOT, shownStep >= 0.1 ? "%.1f" : "%.2f", shown);
        return number + this.unit;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive((Number)this.value);
    }

    @Override
    public void fromJson(JsonElement json) {
        if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isNumber()) {
            this.value = this.sanitize(json.getAsDouble());
        }
    }
}

