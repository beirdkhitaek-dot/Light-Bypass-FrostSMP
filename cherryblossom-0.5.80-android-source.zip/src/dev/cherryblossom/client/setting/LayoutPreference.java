package dev.cherryblossom.client.setting;

import java.util.List;

/** Install both layouts before the original settings store validates saved values. */
public final class LayoutPreference {
    private LayoutPreference(){}
    public static ModeSetting install(ModeSetting setting){return setting.liveModes(()->List.of("Wheel","Dropdown"));}
    public static float screenScale(float treeScale){
        if(!CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Dropdown"))return treeScale;
        var window=net.minecraft.class_310.method_1551().method_22683();
        float fit=Math.min(window.method_4489()/1272f,window.method_4506()/612f);
        return Math.min(fit,treeScale*1.23f);
    }
}
