package dev.cherryblossom.client.setting;
/** Marks the totem design selector for a thumbnail dropdown. */
public final class TotemPickerSetting extends ModeSetting {
    public TotemPickerSetting(String id,String name,String description,String value,String... values){super(id,name,description,value,values);}
}
