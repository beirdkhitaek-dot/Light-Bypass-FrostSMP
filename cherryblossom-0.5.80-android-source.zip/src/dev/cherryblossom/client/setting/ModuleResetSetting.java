package dev.cherryblossom.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

/** Two actions, never a saved value or a toggle. */
public final class ModuleResetSetting extends Setting<Boolean> {
    private final Runnable keybind,options;
    public ModuleResetSetting(Runnable keybind,Runnable options){
        super("module_resets","Reset","Clear this module's keybind or restore its default settings",false);
        this.keybind=keybind;this.options=options;
    }
    public void resetKeybind(){keybind.run();}
    public void resetOptions(){options.run();}
    @Override public JsonElement toJson(){return JsonNull.INSTANCE;}
    @Override public void fromJson(JsonElement ignored){}
}
