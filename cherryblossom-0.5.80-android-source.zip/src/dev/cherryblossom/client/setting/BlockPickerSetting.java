package dev.cherryblossom.client.setting;

import cherryblossom.module.setting.StorageBlocksSetting;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

/** Opens the block icon gallery; selections live in the native ESP palette. */
public final class BlockPickerSetting extends Setting<Boolean> {
    private final StorageBlocksSetting blocks;
    public BlockPickerSetting(String id,StorageBlocksSetting blocks){super(id,"Choose Blocks","Open the searchable block icon picker",false);this.blocks=blocks;}
    public int selectedCount(){return blocks.selectedCount();}
    public void open(){cherryblossom.feature.BlockPickerScreen.open(blocks);}
    @Override public JsonElement toJson(){return JsonNull.INSTANCE;}
    @Override public void fromJson(JsonElement ignored){}
}
