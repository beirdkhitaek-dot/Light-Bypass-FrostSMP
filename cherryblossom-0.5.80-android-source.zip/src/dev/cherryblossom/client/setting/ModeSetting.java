package dev.cherryblossom.client.setting;
import com.google.gson.*;
import java.util.*;
import java.util.function.Supplier;

/** Cherry's selector, with optional live choices for imported model lists. */
public class ModeSetting extends Setting<String> {
    private final List<String> modes;
    private Supplier<List<String>> live;
    public ModeSetting(String id,String name,String description,String defaultValue,String... modes) {
        super(id,name,description,defaultValue);this.modes=List.of(modes);
        if(!this.modes.contains(defaultValue))throw new IllegalArgumentException("Unknown default mode: "+defaultValue);
    }
    public ModeSetting liveModes(Supplier<List<String>> supplier) {live=supplier;return this;}
    public List<String> modes() {List<String> current=live==null?modes:live.get();return current.isEmpty()?modes:current;}
    public int index() {return Math.max(0,modes().indexOf(value));}
    public boolean is(String mode) {return value.equals(mode);}
    public void cycle(int direction) {List<String> current=modes();set(current.get(Math.floorMod(index()+direction,current.size())));}
    @Override protected String sanitize(String value) {return modes().contains(value)?value:defaultValue();}
    @Override public JsonElement toJson(){return new JsonPrimitive(value);}
    @Override public void fromJson(JsonElement json){if(json.isJsonPrimitive())value=sanitize(json.getAsString());}
}
