package dev.cherryblossom.client;

import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.render.CherryBlossomPipelines;
import dev.cherryblossom.client.render.UiResources;
import dev.cherryblossom.client.setting.CherryBlossomSettings;
import dev.cherryblossom.client.setting.SettingsStore;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Cherry presentation initialization; feature initialization belongs to cherryblossom.Main. */
public final class CherryBlossomClient implements ClientModInitializer {
    public static final String MOD_ID="cherryblossom";
    public static final Logger LOGGER=LoggerFactory.getLogger("CherryBlossom");
    private static dev.cherryblossom.client.discord.DiscordPresence DISCORD=new dev.cherryblossom.client.discord.DiscordPresence();
    private static boolean trialNotified,trialExpiredNotified,trialStopped,deviceNotified,presenceStarted;
    public static class_2960 id(String path) { return class_2960.method_60655(MOD_ID,path); }
    @Override public void onInitializeClient() {
        CherryBlossomPipelines.init();
        CherryBlossomSettings.init();
        if(cherryblossom.module.modules.client.CherryBlossom.discordApplicationId.getValue().isBlank())
            cherryblossom.module.modules.client.CherryBlossom.discordApplicationId.setValue(cherryblossom.integration.DiscordDefaults.get("application_id"));
        ModuleManager.init();
        cherryblossom.integration.DeviceAccess.tick();
        ResourceLoader.get(class_3264.field_14188).registerReloader(id("ui_resources"),(class_3302)((class_4013)UiResources::reload));
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            cherryblossom.integration.TrialAccess.tick();
            cherryblossom.integration.DeviceNoticeScreen.pollActivationKey();
            if(!cherryblossom.integration.TrialAccess.allowed()){
                CherryBlossomController.get().forceOff();
                if(!trialStopped){
                    trialStopped=true;if(presenceStarted){DISCORD.close();presenceStarted=false;}
                    for(var module:cherryblossom.CherryBlossom.INSTANCE.getModuleManager().c())try{module.toggle(false);}catch(Throwable e){LOGGER.warn("Trial expiry cleanup failed: {}",module.getName(),e);}
                    dev.cherryblossom.client.ui.TotemPickerPanel.release();
                }
                if(!cherryblossom.integration.DeviceAccess.allowed()){
                    if(!deviceNotified&&client.method_18506()==null){deviceNotified=true;client.method_1507(new cherryblossom.integration.DeviceNoticeScreen(client.field_1755));}
                    return;
                }
                if(!trialExpiredNotified&&client.method_18506()==null){
                    trialExpiredNotified=true;trialNotified=true;
                    if(!(client.field_1755 instanceof cherryblossom.integration.TrialNoticeScreen))client.method_1507(new cherryblossom.integration.TrialNoticeScreen(client.field_1755));
                }
                return;
            }
            trialStopped=false;
            if(!presenceStarted&&!Boolean.getBoolean("cherryblossom.rpc.disabled")){DISCORD=new dev.cherryblossom.client.discord.DiscordPresence();DISCORD.start();presenceStarted=true;}
            if(cherryblossom.integration.TrialAccess.isTrial()&&!trialNotified&&client.method_18506()==null){
                trialNotified=true;client.method_1507(new cherryblossom.integration.TrialNoticeScreen(client.field_1755));
            }
            ModuleManager.tickKeybinds(client,CherryBlossomController.get().capturesKeyboard());SettingsStore.tick();
            DISCORD.configure(new dev.cherryblossom.client.discord.DiscordPresence.Config(
                cherryblossom.module.modules.client.CherryBlossom.discordRpc.getValue(),cherryblossom.module.modules.client.CherryBlossom.discordApplicationId.getValue(),
                cherryblossom.module.modules.client.CherryBlossom.discordInvite.getValue(),client.field_1687!=null));
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client->{
            cherryblossom.integration.TrialAccess.save();
            DISCORD.close();
            for(var module:ModuleManager.all())if(((dev.cherryblossom.client.module.CherryBlossomModule)module).nativeModule() instanceof cherryblossom.feature.SpotifyHudModule spotify)spotify.shutdown();
            if(cherryblossom.integration.DeviceAccess.allowed())SettingsStore.saveNow();dev.cherryblossom.client.ui.TotemPickerPanel.release();
        });
        LOGGER.info("CherryBlossom GUI initialized with {} modules in {} tabs",ModuleManager.all().size(),dev.cherryblossom.client.module.Category.values().length);
    }
}
