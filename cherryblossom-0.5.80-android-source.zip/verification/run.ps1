param([string]$ClientJar = (Join-Path $PSScriptRoot '..\dist\cherryblossom-client-0.5.80.jar'),[switch]$NativeBaseline,[switch]$WorldTest,[switch]$SkyTest,[switch]$SodiumParticlesOff,[switch]$SpotifyTest,[switch]$TrialTest,[switch]$TrialExpired,[switch]$TrialWorld,[switch]$StaffTest,[switch]$AntiVanishTest,[switch]$JumpTest,[switch]$SchematicTest,[switch]$BoatTest,[switch]$CharacterTest,[switch]$DeviceTest,[switch]$AnubisTest,[switch]$KnifeTest,[switch]$BlockPickerTest,[switch]$ChunkFinderTest,[switch]$FovTest,[switch]$RenderDistanceTest,[switch]$HandPositionTest,[switch]$GlintTest,[switch]$MediaTest)
$ErrorActionPreference='Stop'
if($MediaTest){$WorldTest=$true}
if($GlintTest){$WorldTest=$true}
if($HandPositionTest){$WorldTest=$true}
if($RenderDistanceTest){$WorldTest=$true}
if($FovTest){$WorldTest=$true}
if($ChunkFinderTest){$WorldTest=$true}
if($BlockPickerTest){$WorldTest=$true}
if($KnifeTest){$WorldTest=$true}
if($AnubisTest){$WorldTest=$true}
if($CharacterTest){$WorldTest=$true}
if($SkyTest){$WorldTest=$true}
if($BoatTest){$WorldTest=$true}
if($SpotifyTest){$WorldTest=$true}
if($StaffTest){$WorldTest=$true}
if($SchematicTest){$WorldTest=$true}
if($JumpTest){$WorldTest=$true}
if($AntiVanishTest){$WorldTest=$true}
if($TrialExpired){$TrialTest=$true}
if($TrialWorld){$TrialTest=$true;$WorldTest=$true}
$project=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$deps=(Resolve-Path -LiteralPath (Join-Path $project 'build\deps')).Path
$mappingFile=[IO.Path]::GetFullPath($ClientJar)+'.mapping.json'
$compileClient=$ClientJar
if(Test-Path -LiteralPath $mappingFile){$nameMapping=Get-Content -LiteralPath $mappingFile -Raw | ConvertFrom-Json;$compileClient=$nameMapping.sourceJar}
$loader=Join-Path $env:APPDATA '.minecraft\libraries\net\fabricmc\fabric-loader\0.19.5\fabric-loader-0.19.5.jar'
$official=Join-Path $env:APPDATA '.minecraft\versions\1.21.11\1.21.11.jar'
$assets=Join-Path $env:APPDATA 'ModrinthApp\meta\assets'
$api=@(Get-ChildItem -LiteralPath (Join-Path $env:APPDATA 'ModrinthApp\profiles') -Recurse -Filter 'fabric-api-0.141.6+1.21.11.jar' | Select-Object -First 1 -ExpandProperty FullName)[0]
$build=Join-Path $project 'build\verification'
$game=Join-Path $build ('game-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6))
$output=Join-Path $game 'verification'
$trialHome=Join-Path $game 'trial-home'
if($TrialExpired){
    $trialDir=Join-Path $trialHome '.cherryblossom\trials'
    New-Item -ItemType Directory -Force -Path $trialDir | Out-Null
    $trialNow=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $trialStart=$trialNow-73L*60*60*1000
    @{started=$trialStart;expires=$trialStart+72L*60*60*1000;lastSeen=$trialNow;expired=$false} | ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $trialDir 'trial72h-v1.json') -Encoding ASCII
}
$classes=Join-Path $game 'verifier-classes'
$apiDeps=Join-Path $game 'api'
New-Item -ItemType Directory -Force -Path $classes,$apiDeps,$output,(Join-Path $game 'mods') | Out-Null
Set-Content -LiteralPath (Join-Path $game 'options.txt') -Encoding ASCII -Value 'menuBackgroundBlurriness:0'
if($WorldTest){Add-Content -LiteralPath (Join-Path $game 'options.txt') -Encoding ASCII -Value @('pauseOnLostFocus:false','renderDistance:2','simulationDistance:5','maxFps:60')}
$legacyConfig=Join-Path $game 'config\cherryblossom'
New-Item -ItemType Directory -Force -Path $legacyConfig | Out-Null
Set-Content -LiteralPath (Join-Path $legacyConfig 'modules.json') -Encoding UTF8 -Value '{"config_version":6,"fly":{"enabled":true},"fullbright":{"enabled":true},"show_hud":{"enabled":true}}'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::OpenRead($api)
try {
    foreach($entry in $zip.Entries) {
        if($entry.FullName -like 'META-INF/jars/*.jar') {
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,(Join-Path $apiDeps ([IO.Path]::GetFileName($entry.FullName))),$true)
        }
    }
} finally { $zip.Dispose() }
if($WorldTest){
Copy-Item -LiteralPath (Join-Path $project 'verification-world\build\libs\cherry-world-verifier-1.0.0.jar') -Destination (Join-Path $game 'mods\cherry-world-verifier.jar')
}else{
$compileCp=$compileClient+';'+$loader+';'+$deps+'\*;'+$apiDeps+'\*'
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'java') -Filter '*.java' -Recurse | Select-Object -ExpandProperty FullName)
$sources+=@(Get-ChildItem -LiteralPath (Join-Path $project 'verification-shared') -Filter '*.java' -Recurse | Select-Object -ExpandProperty FullName)
& javac --release 21 -proc:none -encoding UTF-8 -cp $compileCp -d $classes @sources
if($LASTEXITCODE -ne 0) {throw 'Verifier compilation failed.'}
& jar --create --file (Join-Path $game 'mods\cherry-cherryblossom-verifier.jar') -C $classes . -C (Join-Path $PSScriptRoot 'resources') .
if($LASTEXITCODE -ne 0) {throw 'Verifier packaging failed.'}
}
if(Test-Path -LiteralPath $mappingFile){
    $verifierJar=Join-Path $game $(if($WorldTest){'mods\cherry-world-verifier.jar'}else{'mods\cherry-cherryblossom-verifier.jar'})
    & java -cp ((Join-Path $project 'build\tools')+';'+$deps+'\*') PrepareVerifier $verifierJar ($verifierJar+'.stage') $mappingFile
    if($LASTEXITCODE -ne 0){throw 'Verifier remapping failed'}
    Move-Item -LiteralPath ($verifierJar+'.stage') -Destination $verifierJar -Force
}
Copy-Item -LiteralPath $ClientJar -Destination (Join-Path $game 'mods\cherry-cherryblossom-client.jar')
if($SodiumParticlesOff){
    $profileMods=Join-Path $env:APPDATA 'ModrinthApp\profiles\nigey\mods'
    foreach($name in @('sodium-fabric-0.8.14+mc1.21.11.jar','sodium-extra-fabric-0.9.4+mc1.21.11.jar')) {
        Copy-Item -LiteralPath (Join-Path $profileMods $name) -Destination (Join-Path $game 'mods')
    }
    Set-Content -LiteralPath (Join-Path $game 'config\sodium-extra-options.json') -Encoding ASCII -Value '{"particle_settings":{"particles":false}}'
}
if($NativeBaseline) {Copy-Item -LiteralPath 'C:\Users\aadan\Downloads\cherryblossom-client-0.5.23.jar' -Destination (Join-Path $game 'mods\original-cherry.jar')}
Copy-Item -LiteralPath $api -Destination (Join-Path $game 'mods\fabric-api.jar')
$libs=@(Get-ChildItem -LiteralPath $deps -Filter '*.jar' | Where-Object {$_.Name -notmatch '^minecraft-|^fabric-|^mixinextras-|^sponge-mixin-|^asm-'} | Select-Object -ExpandProperty FullName)
$newLibraries=@(Get-ChildItem -LiteralPath (Join-Path $env:APPDATA 'ModrinthApp\meta\libraries\org\ow2\asm') -Recurse -Filter '*9.10.1.jar' | Select-Object -ExpandProperty FullName)
$newLibraries+=Join-Path $env:APPDATA 'ModrinthApp\meta\libraries\net\fabricmc\sponge-mixin\0.17.4+mixin.0.8.7\sponge-mixin-0.17.4+mixin.0.8.7.jar'
$runCp=(@($loader)+$newLibraries+$libs+@($official)) -join ';'
$runArgs=@('-Xmx2G','-Dcherryblossom.rpc.disabled=true','-Dcherryblossom.spotify.disabled=true',('-Dcherryblossom.verification.output='+$output),('-Dcherryblossom.verification.gameDir='+$game),'-Dfabric.log.disableAnsi=true','-cp',$runCp,'net.fabricmc.loader.impl.launch.knot.KnotClient','--username','CherryVerify','--uuid','c7000000000000000000000000000002','--accessToken','0','--version','CherryBlossomVerification','--gameDir',$game,'--assetsDir',$assets,'--assetIndex','29','--width','1240','--height','720')
if($MediaTest){$runArgs=@('-Dcherry.verification.media=true',('-Duser.home='+$trialHome))+$runArgs}
if($GlintTest){$runArgs=@('-Dcherry.verification.glint=true',('-Duser.home='+$trialHome))+$runArgs}
if($HandPositionTest){$runArgs=@('-Dcherry.verification.handposition=true',('-Duser.home='+$trialHome))+$runArgs}
if($RenderDistanceTest){$runArgs=@('-Dcherry.verification.renderdistance=true',('-Duser.home='+$trialHome))+$runArgs}
if($FovTest){$runArgs=@('-Dcherry.verification.fov=true',('-Duser.home='+$trialHome))+$runArgs}
if($ChunkFinderTest){$runArgs=@('-Dcherry.verification.chunkfinders=true',('-Duser.home='+$trialHome))+$runArgs}
if($BlockPickerTest){$runArgs=@('-Dcherry.verification.blockpicker=true',('-Duser.home='+$trialHome))+$runArgs}
if($KnifeTest){$runArgs=@('-Dcherry.verification.knifes=true',('-Duser.home='+$trialHome))+$runArgs}
if($AnubisTest){$runArgs=@('-Dcherry.verification.anubis=true',('-Duser.home='+$trialHome))+$runArgs}
if($SchematicTest){$runArgs=@('-Dcherry.verification.schematic=true')+$runArgs}
if($CharacterTest){$runArgs=@('-Dcherry.verification.character=true')+$runArgs}
if($BoatTest){$runArgs=@('-Dcherry.verification.boat=true')+$runArgs}
if($JumpTest){$runArgs=@('-Dcherry.verification.jump=true')+$runArgs}
if($SkyTest){$runArgs=@('-Dcherry.verification.sky=true')+$runArgs}
if($StaffTest){$runArgs=@('-Dcherry.verification.staff=true')+$runArgs}
if($AntiVanishTest){$runArgs=@('-Dcherry.verification.antiVanish=true')+$runArgs}
if($DeviceTest){$runArgs=@('-Dcherry.verification.device=true',('-Duser.home='+$trialHome))+$runArgs}
if($TrialTest){$runArgs=@('-Dcherry.verification.trial=true',('-Duser.home='+$trialHome))+$runArgs}
if($TrialExpired){$runArgs=@('-Dcherry.verification.trialExpired=true')+$runArgs}
if($TrialWorld){$runArgs=@('-Dcherry.verification.trialWorld=true')+$runArgs}
if($SpotifyTest){$runArgs=@('-Dcherry.verification.spotify=true')+@($runArgs | Where-Object {$_ -ne '-Dcherryblossom.spotify.disabled=true'})}
$argFile=Join-Path $game 'run.args'
if($NativeBaseline) {$runArgs=@('-Dcherry.verification.nativeBaseline=true')+$runArgs}
[IO.File]::WriteAllLines($argFile,@($runArgs | ForEach-Object {'"'+$_.Replace('\','/')+'"'}),[Text.UTF8Encoding]::new($false))
Write-Output ('Verification directory: '+$game)
$process=Start-Process -FilePath (Get-Command java).Source -ArgumentList ('@"'+$argFile+'"') -WorkingDirectory $game -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $game 'stdout.log') -RedirectStandardError (Join-Path $game 'stderr.log')
$watch=[Diagnostics.Stopwatch]::StartNew()
while(-not $process.WaitForExit(1000)) {
    if($watch.Elapsed.TotalSeconds -gt $(if($SchematicTest){360}else{180})) { $process.Kill(); throw ('Verification timed out: '+$game) }
}
Get-Content -LiteralPath (Join-Path $game 'stdout.log') -Tail 30
Get-Content -LiteralPath (Join-Path $game 'stderr.log') -Tail 30
if($WorldTest){
    $errors=Select-String -LiteralPath (Join-Path $game 'stdout.log') -Pattern 'Error dispatching event|custom item rendering disabled|HUD element failed|CherryBlossom: .* failed handling'
    if($errors){[IO.File]::WriteAllLines((Join-Path $output 'runtime-failure.txt'),@($errors | ForEach-Object {$_.Line}))}
}
if($null -ne $process.ExitCode -and $process.ExitCode -ne 0) { throw ('Runtime failed, exit '+$process.ExitCode+': '+$game) }
if(Test-Path -LiteralPath (Join-Path $output 'runtime-failure.txt')) {Get-Content -LiteralPath (Join-Path $output 'runtime-failure.txt'); throw 'Runtime assertions failed.'}
if(-not (Test-Path -LiteralPath (Join-Path $output 'runtime-results.txt'))) {throw ('Runtime exited before checks completed: '+$game)}
Copy-Item -LiteralPath (Join-Path $output 'runtime-results.txt'),(Join-Path $output 'runtime-module-inventory.json') -Destination $PSScriptRoot -Force
if(Test-Path -LiteralPath (Join-Path $output 'classic-ui.png')) {Copy-Item -LiteralPath (Join-Path $output 'classic-ui.png') -Destination $PSScriptRoot -Force}
if(Test-Path -LiteralPath (Join-Path $output 'sidebar-ui.png')) {Copy-Item -LiteralPath (Join-Path $output 'sidebar-ui.png') -Destination $PSScriptRoot -Force}
if(Test-Path -LiteralPath (Join-Path $output 'tree-ui.png')) {Copy-Item -LiteralPath (Join-Path $output 'tree-ui.png') -Destination $PSScriptRoot -Force}
Get-Content -LiteralPath (Join-Path $output 'runtime-results.txt')

