package integration.verification;
import cherryblossom.integration.TrialClock;
import java.nio.file.*;
import java.util.concurrent.atomic.AtomicLong;

public final class TrialClockChecks {
    private static int checks;
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
    public static void main(String[] args)throws Exception{
        Path root=Files.createTempDirectory(Path.of(args[0]),"clock-checks-");
        long start=1_800_000_000_000L;AtomicLong wall=new AtomicLong(start),nano=new AtomicLong(0);
        Path file=root.resolve("trial.json");TrialClock clock=new TrialClock(file,wall::get,nano::get);
        check(clock.allowed()&&clock.remainingMillis()==TrialClock.DURATION,"Fresh trial lasts exactly 72 hours");
        check(Files.isRegularFile(file),"First launch persists deadline");
        wall.addAndGet(60_000);nano.addAndGet(60_000_000_000L);clock.update(true);
        TrialClock restart=new TrialClock(file,wall::get,nano::get);
        check(restart.expiresAt()==start+TrialClock.DURATION,"Restart preserves original deadline");
        wall.set(start+TrialClock.DURATION-1);nano.set(0);TrialClock boundary=new TrialClock(file,wall::get,nano::get);
        check(boundary.allowed()&&boundary.remainingMillis()==1,"One millisecond before deadline is active");
        wall.incrementAndGet();boundary.update(false);check(!boundary.allowed(),"Exactly 72 hours expires");
        check(!new TrialClock(file,wall::get,nano::get).allowed(),"Expiry survives restart");
        Path back=root.resolve("rollback.json");wall.set(start);nano.set(0);TrialClock rollback=new TrialClock(back,wall::get,nano::get);
        wall.addAndGet(3_600_000);nano.addAndGet(3_600_000_000_000L);rollback.update(true);
        wall.set(start);check(!rollback.allowed(),"Large clock rollback blocks access immediately");rollback.update(false);
        wall.set(start+3_600_000);check(!new TrialClock(back,wall::get,nano::get).allowed(),"Clock rollback remains expired after restart");
        Path monotonic=root.resolve("monotonic.json");wall.set(start);nano.set(0);TrialClock monotonicClock=new TrialClock(monotonic,wall::get,nano::get);
        nano.set(TrialClock.DURATION*1_000_000);check(!monotonicClock.allowed(),"Monotonic elapsed time expires a frozen wall clock");
        Path corrupt=root.resolve("corrupt.json");Files.writeString(corrupt,"broken");check(!new TrialClock(corrupt,wall::get,nano::get).allowed(),"Corrupt state blocks access");
        Path blocked=root.resolve("not-a-directory");Files.writeString(blocked,"file");check(!new TrialClock(blocked.resolve("trial.json"),wall::get,nano::get).allowed(),"Unwritable state blocks access");
        Files.writeString(corrupt,"{\"started\":"+start+",\"expires\":"+(start+1)+",\"lastSeen\":"+start+",\"expired\":false}");check(!new TrialClock(corrupt,wall::get,nano::get).allowed(),"Invalid duration blocks access");
        System.out.println("PASS: "+checks+" trial deadline, restart, rollback, monotonic time and invalid-state checks.");
    }
}
