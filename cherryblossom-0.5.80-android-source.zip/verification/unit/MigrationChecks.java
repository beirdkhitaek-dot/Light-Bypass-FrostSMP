package integration.verification;
import cherryblossom.integration.LegacyConfigMigration;
import com.google.gson.*;
import java.nio.file.*;

public final class MigrationChecks {
    private static int checks;
    private static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);checks++;}
    public static void main(String[] args)throws Exception{
        Path config=Files.createTempDirectory(Path.of(args[0]),"migration-checks-");Files.createDirectory(config.resolve("cherryblossom"));
        JsonObject before=JsonParser.parseString("{\"HUD\":{\"Watermark\":true},\"Custom Totem\":{},\"Auto Totem\":{},\"Earlier Client+\":{\"GUI Size\":115,\"Animations\":2,\"Theme\":3}}").getAsJsonObject();
        String data=before.toString();Files.writeString(config.resolve("earlier-profile.json"),data);Files.writeString(config.resolve("cherryblossom/earlier-modules.json"),data);
        Files.writeString(config.resolve("unrelated.json"),"{\"value\":true}");
        var library=new JsonObject();library.addProperty("version",1);var list=new JsonArray();var item=new JsonObject();item.add("data",before);item.addProperty("name","My config");list.add(item);library.add("configs",list);Files.writeString(config.resolve("earlier-library.json"),library.toString());
        LegacyConfigMigration.migrate(config);
        check(Files.exists(config.resolve("cherryblossom.json")),"Native profile migrates");
        check(Files.exists(config.resolve("cherryblossom/cherryblossom-modules.json")),"GUI profile migrates");
        JsonObject after=JsonParser.parseString(Files.readString(config.resolve("cherryblossom.json"))).getAsJsonObject();
        check(after.has("CherryBlossom+")&&!after.has("Earlier Client+"),"Client key normalized");
        check(after.getAsJsonObject("CherryBlossom+").get("GUI Size").getAsInt()==115,"Client preference preserved");
        check(Files.readString(config.resolve("earlier-profile.json")).equals(data),"Original profile preserved");
        JsonObject savedLibrary=JsonParser.parseString(Files.readString(config.resolve("cherryblossom-configs.json"))).getAsJsonObject();
        check(savedLibrary.getAsJsonArray("configs").get(0).getAsJsonObject().getAsJsonObject("data").has("CherryBlossom+"),"Saved library settings migrate");
        Files.writeString(config.resolve("cherryblossom.json"),"{\"keep\":true}");LegacyConfigMigration.migrate(config);
        check(Files.readString(config.resolve("cherryblossom.json")).equals("{\"keep\":true}"),"Existing new profile is not overwritten");
        check(Files.readString(config.resolve("unrelated.json")).equals("{\"value\":true}"),"Other mod configuration is untouched");
        System.out.println("PASS: "+checks+" profile migration and preservation checks.");
    }
}
