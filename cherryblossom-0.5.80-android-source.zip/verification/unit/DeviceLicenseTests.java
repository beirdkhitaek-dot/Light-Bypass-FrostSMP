import cherryblossom.integration.DeviceIdentity;
import cherryblossom.integration.DeviceLease;
import com.google.gson.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

public final class DeviceLicenseTests {
    private static int checks;
    private static void check(boolean yes,String message){if(!yes)throw new AssertionError(message);checks++;System.out.println("DEVICE JAVA PASS: "+message);}
    interface Attempt{void run()throws Exception;}
    private static void denied(Attempt attempt,String message)throws Exception{boolean failed=false;try{attempt.run();}catch(Exception expected){failed=true;}check(failed,message);}
    private static long verify(JsonObject fixture,String token,String fingerprint,String edition,String challenge,long time)throws Exception{
        return DeviceLease.verify(token,fixture.get("public_key").getAsString(),fixture.get("issuer").getAsString(),fingerprint,edition,challenge,time);
    }
    public static void main(String[] args)throws Exception{
        JsonObject fixture=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject();String lease=fixture.get("lease").getAsString(),fingerprint=fixture.get("fingerprint").getAsString(),edition=fixture.get("edition").getAsString(),challenge=fixture.get("challenge").getAsString();long now=fixture.get("server_time").getAsLong();
        check(verify(fixture,lease,fingerprint,edition,challenge,now)==300000,"Java verifies the actual website-signed P-256 lease");
        denied(()->verify(fixture,lease,"other-device",edition,challenge,now),"Lease cannot authorize another computer");
        denied(()->verify(fixture,lease,fingerprint,"trial",challenge,now),"Lease cannot authorize another edition");
        denied(()->verify(fixture,lease,fingerprint,edition,"replayed-challenge",now),"Old lease cannot answer a fresh authentication challenge");
        denied(()->verify(fixture,lease,fingerprint,edition,challenge,now+300001),"Expired lease is rejected");
        String[] segments=lease.split("\\.");byte[] payload=Base64.getUrlDecoder().decode(segments[1]);payload[payload.length/2]^=1;String changed=segments[0]+"."+Base64.getUrlEncoder().withoutPadding().encodeToString(payload)+"."+segments[2];
        denied(()->verify(fixture,changed,fingerprint,edition,challenge,now),"Tampered license data fails the pinned signature check");
        denied(()->verify(fixture,"unsigned.payload.",fingerprint,edition,challenge,now),"Unsigned responses are rejected");
        denied(()->DeviceLease.verify(lease,fixture.get("public_key").getAsString(),"https://wrong.example",fingerprint,edition,challenge,now),"Wrong issuer is rejected");
        Path folder=Path.of(args[1]);Files.createDirectories(folder);Path file=folder.resolve("device-key-v1.json");
        DeviceIdentity identity=DeviceIdentity.loadOrCreate(file);String original=Files.readString(file);
        check(original.contains("protected_private_key")&&!original.contains("PRIVATE KEY"),"Only Windows-protected private key material is persisted");
        DeviceIdentity loaded=DeviceIdentity.loadOrCreate(file);
        check(loaded.publicKey().equals(identity.publicKey())&&loaded.fingerprint().equals(identity.fingerprint()),"Restart reloads the same Windows-protected device identity");
        Signature signature=Signature.getInstance("SHA256withECDSAinP1363Format");signature.initVerify(KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.getUrlDecoder().decode(identity.publicKey()))));byte[] message="CherryBlossom/device/v1\ninteroperability".getBytes(StandardCharsets.UTF_8);signature.update(message);
        check(signature.verify(loaded.sign(message)),"Reloaded device key signs standard P-256 possession proofs");
        String bootstrap="a".repeat(64);var descriptor=new JsonObject();descriptor.addProperty("version",1);descriptor.addProperty("token",bootstrap);descriptor.addProperty("edition","normal");
        var activation=cherryblossom.integration.ClientActivation.parse(descriptor.toString().getBytes(StandardCharsets.UTF_8),"normal");
        activation.bind(loaded,(path,body)->{
            check(path.equals("/api/client/device/auto"),"Personal download uses the automatic binding endpoint");
            check(body.get("token").getAsString().equals(bootstrap)&&body.get("edition").getAsString().equals("normal"),"Automatic proof retains its authenticated download credential and edition");
            var proof=Signature.getInstance("SHA256withECDSAinP1363Format");proof.initVerify(KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.getUrlDecoder().decode(body.get("public_key").getAsString()))));proof.update(("CherryBlossom/auto-bind/v1\n"+bootstrap+"\n"+loaded.publicKey()+"\nnormal").getBytes(StandardCharsets.UTF_8));
            check(proof.verify(Base64.getUrlDecoder().decode(body.get("signature").getAsString())),"Java automatic binding proof interoperates with the server's P-256 namespace");
            var response=new JsonObject();response.addProperty("http_status",200);response.addProperty("status","bound");return response;
        });
        for(String error:new String[]{"device_locked","personal_download_required","access_inactive","unexpected"})denied(()->activation.bind(loaded,(path,body)->{var response=new JsonObject();response.addProperty("http_status",403);response.addProperty("error",error);return response;}),"Binding fails closed for "+error);
        denied(()->cherryblossom.integration.ClientActivation.parse(descriptor.toString().getBytes(StandardCharsets.UTF_8),"trial"),"Personal activation credential cannot cross editions");
        denied(()->cherryblossom.integration.ClientActivation.parse(new byte[4097],"normal"),"Oversized activation resources fail closed");
        denied(()->cherryblossom.integration.ClientActivation.parse("{}".getBytes(StandardCharsets.UTF_8),"normal"),"Incomplete activation resources fail closed");
        DeviceIdentity other=DeviceIdentity.loadOrCreate(folder.resolve("second-device.json"));check(!other.fingerprint().equals(identity.fingerprint()),"A new installation receives a distinct device key");
        JsonObject corrupt=JsonParser.parseString(original).getAsJsonObject();corrupt.addProperty("protected_private_key",Base64.getEncoder().encodeToString(new byte[]{1,2,3}));Files.writeString(file,corrupt.toString());String damaged=Files.readString(file);
        denied(()->DeviceIdentity.loadOrCreate(file),"Unreadable protected keys fail closed");check(Files.readString(file).equals(damaged),"A damaged key is never silently overwritten with a new identity");Files.writeString(file,original);
        check(DeviceIdentity.loadOrCreate(file).fingerprint().equals(identity.fingerprint()),"Restoring the encrypted record restores the same identity");
        check(!cherryblossom.integration.DeviceAccess.allowed(),"Client starts locked without a validated signed lease");
        System.out.println("PASS: "+checks+" Java license, replay, signature and real Windows DPAPI checks.");
    }
}
