package integration.verification;
import cherryblossom.feature.*;

public final class AntiVanishRuleChecks {
    private static int checks;
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
    private static boolean role(String text)throws Exception{return (Boolean)StaffClassifier.class.getMethod("hasRole",String.class).invoke(null,text);}
    public static void main(String[] args)throws Exception{
        check(!VanishAlertRules.DONUT_STAFF.isEmpty(),"Bundled candidate list initializes");
        check(VanishAlertRules.isStaffName("FluffyMaster07"),"Candidate lookup initializes after its list");
        check(VanishAlertRules.isStaffName("fluffymaster07"),"Case-insensitive candidate lookup");
        check(VanishAlertRules.isStaffName("DrDonutt"),"Owner recognized");
        check(!VanishAlertRules.isStaffName("OrdinaryFixture"),"Ordinary player not a bundled candidate");
        check(role("[STAFF]"),"Visible staff role recognized");
        check(role("\u00a7c[\ua731\u1d1b\u1d00\ua730\ua730]"),"Small-cap formatted staff role recognized");
        check(!role("\u2605 Donut+++"),"Decorative stars and paid rank do not establish staff role");
        check(VanishChatParser.looksLikeLeaveMessage("RankedFixture left the game","RankedFixture"),"Leave message recognized");
        check(!VanishChatParser.looksLikeLeaveMessage("RankedFixture: I left my base","RankedFixture"),"Ordinary chat is not a logout");
        System.out.println("PASS: "+checks+" Anti Vanish initialization, rank and leave-parser checks.");
    }
}
