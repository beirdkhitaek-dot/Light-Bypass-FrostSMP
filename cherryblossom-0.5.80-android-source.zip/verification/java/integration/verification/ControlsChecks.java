package integration.verification;

import dev.cherryblossom.client.CherryBlossomController;
import dev.cherryblossom.client.module.*;
import dev.cherryblossom.client.sound.CherryBlossomSounds;
import dev.cherryblossom.client.ui.Spring;
import cherryblossom.module.modules.client.CherryBlossom;
import net.minecraft.class_310;

public final class ControlsChecks {
    public static boolean capture;
    public static int submissions;
    public static float lastVolume;
    public static void record(net.minecraft.class_1113 sound){
        try{var field=net.minecraft.class_1102.class.getDeclaredField("field_5442");field.setAccessible(true);lastVolume=field.getFloat(sound);submissions++;}
        catch(ReflectiveOperationException e){throw new AssertionError(e);}
    }
    private static int checks;
    private static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);checks++;System.out.println("CONTROL PASS: "+text);}
    public static int run(class_310 mc){
        double size=CherryBlossom.guiSize.getValue(),volume=CherryBlossom.uiVolume.getValue();
        boolean sounds=CherryBlossom.uiSounds.getValue();int animations=CherryBlossom.animationMode.getModeIndex();
        try {
            var module=ModuleManager.all().stream().filter(m->m.name().equals("CherryBlossom+")).findFirst().orElseThrow();
            var source=((CherryBlossomModule)module).nativeModule();
            check(source.getSettings().stream().noneMatch(s->s.getName().toString().contains("Halloween")||s.getName().toString().contains("Beat Shake")),"Removed music, volume and beat-shake controls");
            var controller=CherryBlossomController.get();float small=0;
            for(int percent:new int[]{70,100,140}) {
                CherryBlossom.guiSize.getValue(percent);float scale=controller.clickGuiScreenScale();
                if(percent==70)small=scale;
                check(controller.clickGuiScreenLeft()>=0&&controller.clickGuiScreenTop()>=0,"GUI remains on screen at "+percent+"%");
                float x=controller.clickGuiScreenLeft()+830*scale,y=controller.clickGuiScreenTop()+290*scale;
                check(Math.abs((x-controller.clickGuiScreenLeft())/scale-830)<.001&&Math.abs((y-controller.clickGuiScreenTop())/scale-290)<.001,"Pointer inverse matches render scale at "+percent+"%");
                if(percent==140)check(Math.abs(scale/small-2)<.001,"70 to 140 doubles GUI size");
            }
            CherryBlossom.animationMode.setModeIndex(2);Spring spring=new Spring(0,8);
            check(spring.target(1).update(0)==1,"Off applies control changes instantly");
            CherryBlossom.animationMode.setModeIndex(0);spring=new Spring(0,8);float smooth=spring.target(1).update(.016f);
            check(smooth>0&&smooth<1,"Normal animates gradually");
            CherryBlossom.animationMode.setModeIndex(1);spring=new Spring(0,8);spring.target(1);boolean overshoot=false;
            for(int i=0;i<180;i++)overshoot|=spring.update(.016f)>1.005;
            check(overshoot&&Math.abs(spring.value()-1)<.001,"Positive springs settle after lively motion");
            capture=true;submissions=0;CherryBlossom.uiSounds.setValue(false);CherryBlossom.uiVolume.getValue(100);
            CherryBlossomSounds.play(CherryBlossomSounds.CLICK,1);
            check(submissions==0,"UI Sounds off prevents sound-engine submissions");
            CherryBlossom.uiSounds.setValue(true);CherryBlossom.uiVolume.getValue(0);CherryBlossomSounds.play(CherryBlossomSounds.CLICK,1);
            check(submissions==0,"UI Volume zero is silent");
            CherryBlossom.uiVolume.getValue(25);CherryBlossomSounds.play(CherryBlossomSounds.CLICK,1);float quiet=lastVolume;
            check(submissions==1&&Math.abs(quiet-.075f)<.001,"UI Volume 25 reaches sound engine at quarter gain");
            CherryBlossom.uiVolume.getValue(100);CherryBlossomSounds.play(CherryBlossomSounds.CLICK,1);
            check(submissions==2&&Math.abs(lastVolume/quiet-4)<.001,"UI Volume changes real playback gain");
            return checks;
        }finally{capture=false;CherryBlossom.guiSize.getValue(size);CherryBlossom.uiVolume.getValue(volume);CherryBlossom.uiSounds.setValue(sounds);CherryBlossom.animationMode.setModeIndex(animations);}
    }
}
