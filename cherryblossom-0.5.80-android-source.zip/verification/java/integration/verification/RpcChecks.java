package integration.verification;

import com.google.gson.*;
import dev.cherryblossom.client.discord.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/** Isolated fake Discord server; never writes presence to the user's Discord. */
public final class RpcChecks {
    private static int checks;
    private static final String ID="123456789012345678",INVITE="https://discord.gg/vaQtF4TyW";
    private static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);checks++;System.out.println("RPC PASS: "+text);}
    private static void await(BooleanSupplier predicate,String text)throws Exception{
        long limit=System.nanoTime()+TimeUnit.SECONDS.toNanos(6);
        while(!predicate.getAsBoolean()&&System.nanoTime()<limit)Thread.sleep(10);
        check(predicate.getAsBoolean(),text);
    }
    private static final class Mock implements DiscordIpc.Connection {
        final PipedInputStream clientIn=new PipedInputStream(65536),serverIn=new PipedInputStream(65536);
        final PipedOutputStream clientOut=new PipedOutputStream(serverIn),serverOut=new PipedOutputStream(clientIn);
        final List<JsonObject> activities=new CopyOnWriteArrayList<>();
        volatile String appId="";
        volatile boolean clear,pong;
        volatile Throwable error;
        Mock()throws IOException{
            Thread server=new Thread(()->{
                try{
                    var hello=DiscordIpc.read(serverIn);if(hello.opcode()!=0)throw new AssertionError("Handshake opcode");
                    appId=hello.json().get("client_id").getAsString();
                    send(1,"{\"cmd\":\"DISPATCH\",\"evt\":\"READY\",\"data\":{}}");
                    boolean ping=false;
                    while(true){
                        var frame=DiscordIpc.read(serverIn);
                        if(frame.opcode()==4){pong=Arrays.equals(frame.payload(),new byte[]{1,2,3});continue;}
                        JsonObject request=frame.json();JsonElement activity=request.getAsJsonObject("args").get("activity");
                        if(activity.isJsonNull())clear=true;else activities.add(activity.getAsJsonObject());
                        JsonObject ack=new JsonObject();ack.addProperty("cmd","SET_ACTIVITY");ack.add("nonce",request.get("nonce"));ack.add("evt",JsonNull.INSTANCE);send(1,ack.toString());
                        if(!ping){serverOut.write(DiscordIpc.packet(3,new byte[]{1,2,3}));serverOut.flush();ping=true;}
                    }
                }catch(IOException expected){}catch(Throwable e){error=e;}
            },"Mock Discord RPC");server.setDaemon(true);server.start();
        }
        void send(int opcode,String json)throws IOException{serverOut.write(DiscordIpc.packet(opcode,json.getBytes(StandardCharsets.UTF_8)));serverOut.flush();}
        void disconnect()throws IOException{send(2,"{}");}
        public InputStream input(){return clientIn;}public OutputStream output(){return clientOut;}
        public void close()throws IOException{clientOut.close();clientIn.close();}
    }
    public static int run()throws Exception{
        check(DiscordPresence.normalizeInvite("discord.gg/vaQtF4TyW").equals(INVITE),"Invite normalization keeps the requested server");
        check(DiscordPresence.normalizeInvite("javascript:alert(1)").isEmpty()&&DiscordPresence.normalizeInvite("https://discord.gg.evil.test/x").isEmpty(),"Invalid button destinations are omitted");
        check(!DiscordPresence.validId("")&&DiscordPresence.validId(ID),"Application ID is required");
        byte[] bytes=DiscordIpc.packet(1,"{\"text\":\"Cherry 🌸\"}".getBytes(StandardCharsets.UTF_8));
        var fragmented=new FilterInputStream(new ByteArrayInputStream(bytes)){public int read(byte[] b,int off,int len)throws IOException{return super.read(b,off,Math.min(len,1));}};
        check(DiscordIpc.read(fragmented).json().get("text").getAsString().equals("Cherry 🌸"),"Framing handles partial reads and UTF-8");
        boolean rejected=false;try{DiscordIpc.read(new ByteArrayInputStream(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putInt(1).putInt(2_000_000).array()));}catch(IOException expected){rejected=true;}
        check(rejected,"Oversized IPC frames are rejected");
        List<Mock> servers=new CopyOnWriteArrayList<>();
        try(DiscordPresence client=new DiscordPresence(()->{Mock mock=new Mock();servers.add(mock);return mock;},50)){
            client.configure(new DiscordPresence.Config(true,ID,INVITE,false));client.start();
            await(()->!servers.isEmpty()&&!servers.getFirst().activities.isEmpty(),"Handshake and SET_ACTIVITY completed");
            Mock first=servers.getFirst();JsonObject activity=first.activities.getFirst();
            check(first.appId.equals(ID),"Correct application ID used in handshake");
            check(activity.get("details").getAsString().equals("Using CherryBlossomClient"),"Presence uses CherryBlossomClient branding");
            JsonObject button=activity.getAsJsonArray("buttons").get(0).getAsJsonObject();
            check(button.get("label").getAsString().equals("Discord")&&button.get("url").getAsString().equals(INVITE),"Discord button opens the supplied invite");
            await(()->first.pong,"Discord heartbeat receives an exact pong");
            client.configure(new DiscordPresence.Config(true,ID,INVITE,true));
            await(()->first.activities.size()>=2,"Entering a world updates presence after the ACK");
            check(first.activities.get(1).get("state").getAsString().equals("Playing Minecraft"),"Gameplay status is generic");
            check(activity.getAsJsonObject("timestamps").equals(first.activities.get(1).getAsJsonObject("timestamps")),"Elapsed session time survives updates");
            first.disconnect();await(()->servers.size()>=2&&!servers.get(1).activities.isEmpty(),"Discord restart reconnects and restores presence");
            Mock second=servers.get(1);client.configure(new DiscordPresence.Config(false,ID,INVITE,true));
            await(()->second.clear,"Disabling RPC clears the activity");
            check(first.error==null&&second.error==null,"Mock server found no protocol errors");
        }
        try(DiscordPresence absent=new DiscordPresence(()->{throw new IOException("Offline");},50)){
            absent.configure(new DiscordPresence.Config(true,ID,INVITE,false));absent.start();
            await(()->absent.status().equals("Waiting for Discord desktop"),"Missing Discord is handled without failing Minecraft");
        }
        return checks;
    }
}
