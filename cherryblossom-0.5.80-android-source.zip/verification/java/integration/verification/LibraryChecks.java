package integration.verification;

import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.setting.TotemPickerSetting;
import dev.cherryblossom.client.ui.*;
import java.lang.reflect.*;
import java.util.*;
import cherryblossom.feature.*;
import cherryblossom.itemfx.*;

public final class LibraryChecks {
    public static int run()throws Exception {
        int checks=0;
        if(TotemAssets.entries().size()!=9)throw new AssertionError("All nine pack entries must be listed");checks++;
        var module=ModuleManager.all().stream().filter(m->m.name().equals("Custom Totem")).findFirst().orElseThrow();
        TotemPickerSetting selector=(TotemPickerSetting)module.settings().stream().filter(s->s instanceof TotemPickerSetting).findFirst().orElseThrow();
        String before=selector.get();
        try {
            for(int i=0;i<9;i++) {
                TotemPickerPanel.open(selector);boolean selected=TotemPickerPanel.select(i+5);
                if(selected!=TotemAssets.entries().get(i).available())throw new AssertionError("Unavailable pack was selected");
                if(selected&&CustomTotemModule.designIndex()!=i+5)throw new AssertionError("Picker did not update the real module");checks++;
            }
        } finally {TotemPickerPanel.close();selector.set(before);}
        var theme=cherryblossom.module.modules.client.CherryBlossom.theme;int saved=theme.getModeIndex();
        Field time=UiPalette.class.getDeclaredField("changedAt");time.setAccessible(true);
        try {
            for(int i=0;i<UiPalette.values().length;i++) {
                theme.setModeIndex(i);UiPalette.accent(1);time.setLong(null,System.nanoTime()-1_000_000_000L);
                Theme.beginFrame();int expected=UiPalette.selected().previewAccent();
                if(Theme.accentBright()!=expected||CherryHudPalette.accent(1)!=expected)throw new AssertionError("UI/HUD colours diverged for "+UiPalette.values()[i]);
                if(UiPalette.values()[i]!=UiPalette.Rose&&Theme.tint(0xFFFFA5CA)==0xFFFFA5CA)throw new AssertionError("Tree stayed pink for "+UiPalette.values()[i]);checks++;
            }
        } finally {theme.setModeIndex(saved);UiPalette.accent(1);time.setLong(null,System.nanoTime()-1_000_000_000L);Theme.beginFrame();}
        return checks;
    }
    public static TotemPickerSetting selector(){return (TotemPickerSetting)ModuleManager.all().stream().filter(m->m.name().equals("Custom Totem")).findFirst().orElseThrow().settings().stream().filter(s->s instanceof TotemPickerSetting).findFirst().orElseThrow();}
}
