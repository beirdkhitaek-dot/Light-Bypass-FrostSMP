package integration.verification;

import com.google.gson.*;
import dev.cherryblossom.client.module.CherryBlossomModule;
import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.setting.ModuleResetSetting;
import cherryblossom.module.setting.*;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.class_310;

/** Resets every module after modifying native values, with isolation and persistence checks. */
public final class ResetChecks {
    private static int checks;
    private static boolean done;
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;System.out.println("RESET PASS: "+message);}
    private static JsonObject others(JsonObject all,String name){JsonObject copy=all.deepCopy();copy.remove(name);copy.remove("_layout");return copy;}
    public static int run()throws Exception {
        if(done)return 0;done=true;
        var manager=cherryblossom.CherryBlossom.INSTANCE.getSettingsManager();var snapshot=manager.capture();
        Field defaultsField=manager.getClass().getDeclaredField("defaults");defaultsField.setAccessible(true);JsonObject defaults=(JsonObject)defaultsField.get(manager);
        try {
            for(var base:ModuleManager.all()){
                var wrapper=(CherryBlossomModule)base;var nativeModule=wrapper.nativeModule();String name=nativeModule.getName().toString();
                var action=(ModuleResetSetting)base.settings().stream().filter(s->s instanceof ModuleResetSetting).findFirst().orElseThrow();
                check(base.settings().stream().filter(s->s instanceof ModuleResetSetting).count()==1,base.name()+" exposes both reset actions");
                for(var setting:nativeModule.getSettings())mutate(setting);
                base.keybind().set(65);wrapper.pull();JsonObject before=manager.capture();boolean enabled=nativeModule.isEnabled();
                action.resetOptions();JsonObject after=manager.capture(),expected=defaults.getAsJsonObject(name).deepCopy();
                expected.addProperty("enabled",enabled);expected.addProperty("$keybind",65);
                for(var setting:nativeModule.getSettings())if(setting instanceof BindSetting bind&&bind.isModuleKey())expected.addProperty(setting.getName().toString(),65);
                check(after.getAsJsonObject(name).equals(expected),base.name()+" restores all default options while preserving bind and enabled state");
                check(others(before,name).equals(others(after,name)),base.name()+" reset leaves other modules unchanged");
                dev.cherryblossom.client.CherryBlossomController.get().startKeyCapture(base.keybind());
                action.resetKeybind();JsonObject cleared=manager.capture();expected.addProperty("$keybind",-1);
                for(var setting:nativeModule.getSettings())if(setting instanceof BindSetting bind&&bind.isModuleKey())expected.addProperty(setting.getName().toString(),-1);
                check(cleared.getAsJsonObject(name).equals(expected)&&base.keybind().get()==-1&&!dev.cherryblossom.client.CherryBlossomController.get().isCapturing(base.keybind()),base.name()+" clears the native/UI bind and pending capture without resetting options");
            }
            var hud=ModuleManager.all().stream().filter(m->m.name().equals("HUD")).findFirst().orElseThrow();
            hud.setEnabled(true);((ModuleResetSetting)hud.settings().stream().filter(s->s instanceof ModuleResetSetting).findFirst().orElseThrow()).resetOptions();
            check(hud.enabled(),"Reset settings preserves an enabled module");
            var path=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("cherryblossom.json");
            check(JsonParser.parseString(java.nio.file.Files.readString(path)).getAsJsonObject().equals(manager.capture()),"Reset values are persisted to the native settings file");
        } finally {manager.apply(snapshot);for(var module:ModuleManager.all())((CherryBlossomModule)module).pull();}
        return checks;
    }
    public static int renderClicks(Object gui,dev.cherryblossom.client.render.UiCanvas canvas,dev.cherryblossom.client.render.text.FontAtlas fonts)throws Exception {
        int before=checks;
        var module=ModuleManager.all().stream().filter(m->m.name().equals("JumpCircles")).findFirst().orElseThrow();
        var slider=(dev.cherryblossom.client.setting.SliderSetting)module.settings().stream().filter(s->s instanceof dev.cherryblossom.client.setting.SliderSetting).findFirst().orElseThrow();
        module.keybind().set(65);slider.set(slider.get().equals(slider.min())?slider.max():slider.min());
        var method=gui.getClass().getDeclaredMethod("drawWheelExpandedSettings",dev.cherryblossom.client.render.UiCanvas.class,dev.cherryblossom.client.ui.UiInput.class,dev.cherryblossom.client.render.text.FontAtlas.class,dev.cherryblossom.client.module.Module.class,float.class,float.class,float.class,float.class,float.class,float.class,float.class);method.setAccessible(true);
        for(float x:new float[]{90,320}){
            var input=new dev.cherryblossom.client.ui.UiInput();input.active=true;input.x=x;input.y=150;input.down=true;input.pressed=true;
            input.beginFrame();method.invoke(gui,canvas,input,fonts,module,20f,100f,400f,480f,1f,0f,580f);input.endFrame();
            input.down=false;input.released=true;input.beginFrame();method.invoke(gui,canvas,input,fonts,module,20f,100f,400f,480f,1f,0f,580f);input.endFrame();
        }
        check(module.keybind().get()==-1,"Tree Reset keybind button clears the real binding");
        check(slider.get().equals(slider.defaultValue()),"Tree Reset settings button restores native options");
        return checks-before;
    }
    private static void mutate(Setting setting){
        if(setting instanceof BooleanSetting s)s.setValue(!s.getDefaultValue());
        else if(setting instanceof NumberSetting s)s.setStoredValue(s.getValue()==s.getMin()?s.getMax():s.getMin());
        else if(setting instanceof ModeSetting<?> s)s.setModeIndex((s.getModeIndex()+1)%s.getPossibleValues().size());
        else if(setting instanceof ChoiceSetting s){var modes=s.getModes();s.setMode(modes.get((modes.indexOf(s.getMode())+1)%modes.size()));}
        else if(setting instanceof StringSetting s)s.setValue("reset verification");
        else if(setting instanceof BindSetting s)s.setValue(66);
        else if(setting instanceof RgbSetting s)s.setArgb(s.getArgb()^0x00112233);
        else if(setting instanceof MinMaxSetting s){s.setCurrentMin(s.getMinValue());s.setCurrentMax(s.getMaxValue());}
        else if(setting instanceof ItemSetting s)s.setItem(net.minecraft.class_1802.field_8467);
        else if(setting instanceof StorageBlocksSetting s)for(var e:s.entries()){e.toggle();e.setColor(java.awt.Color.GREEN);}
    }
}
