package integration.verification.mixin;

import integration.verification.ControlsChecks;

import net.minecraft.class_1113;
import net.minecraft.class_1144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Observes real sound-engine submissions in the isolated verifier only. */
@Mixin(value=class_1144.class,remap=false)
public abstract class SoundCaptureMixin {
    @Inject(method="method_4873",at=@At("HEAD"),remap=false)
    private void capture(class_1113 sound,CallbackInfoReturnable<?> result){
        if(ControlsChecks.capture)ControlsChecks.record(sound);
    }
}
