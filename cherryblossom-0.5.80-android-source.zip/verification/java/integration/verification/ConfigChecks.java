package integration.verification;

import com.google.gson.JsonObject;
import cherryblossom.manager.ConfigLibrary;
import dev.cherryblossom.client.ui.ConfigPanel;
import java.nio.file.Files;
import net.minecraft.class_310;

public final class ConfigChecks {
    private static boolean clicked;
    public static void clicks(Object gui,dev.cherryblossom.client.render.UiCanvas c,dev.cherryblossom.client.render.text.FontAtlas fonts)throws Exception{
        if(clicked)return;clicked=true;
        var field=gui.getClass().getDeclaredField("configs");field.setAccessible(true);
        ConfigPanel panel=(ConfigPanel)field.get(gui);
        var render=gui.getClass().getDeclaredMethod("render",dev.cherryblossom.client.render.UiCanvas.class,dev.cherryblossom.client.ui.UiInput.class,dev.cherryblossom.client.render.text.FontAtlas.class,float.class);render.setAccessible(true);
        var back=gui.getClass().getDeclaredMethod("backToWheel");back.setAccessible(true);back.invoke(gui);panel.close();
        click(gui,c,fonts,render,620,ConfigPanel.buttonY()+22);
        check(panel.isOpen(),"Bottom-of-screen button opens config page");
        click(gui,c,fonts,render,950,300);
        var selected=ConfigPanel.class.getDeclaredField("selected");selected.setAccessible(true);
        check(selected.getInt(panel)==3,"Fourth slot selected through UI");
        click(gui,c,fonts,render,710,397);
        check(panel.library().slot(3)!=null,"Save button works through mouse input");
        click(gui,c,fonts,render,690,113);
        check(!panel.isOpen(),"Tree button returns from config page");
        panel.open();
    }
    private static void click(Object gui,dev.cherryblossom.client.render.UiCanvas c,dev.cherryblossom.client.render.text.FontAtlas f,java.lang.reflect.Method render,float x,float y)throws Exception{
        var input=new dev.cherryblossom.client.ui.UiInput();input.active=true;input.x=x;input.y=y;
        input.pressed=true;input.down=true;input.beginFrame();render.invoke(gui,c,input,f,2f);input.endFrame();
        input.down=false;input.released=true;input.beginFrame();render.invoke(gui,c,input,f,2f);input.endFrame();
    }
    private static int checks;
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;System.out.println("CONFIG PASS: "+message);}
    public static int run() throws Exception {
        var settings=cherryblossom.CherryBlossom.INSTANCE.getSettingsManager();
        JsonObject original=settings.capture();
        String clipboard=class_310.method_1551().field_1774.method_1460();
        try {
            var panel=new ConfigPanel();var lib=panel.library();
            for(int i=0;i<4;i++){
                check(lib.slot(i)==null,"Slot starts empty: "+i);
                panel.action("save",i);
                check(lib.slot(i)!=null&&lib.slot(i).data().equals(original),"Save captures complete current settings: "+i);
            }
            check(lib.profiles().size()==4,"Exactly four slots");
            var reopened=new ConfigPanel().library();
            check(reopened.slot(3).data().equals(original),"Slot 4 survives library restart");
            panel.action("copy",0);
            String code=class_310.method_1551().field_1774.method_1460();
            check(code.startsWith("CBSP1:"),"Copy exports shareable clipboard code");
            var theme=cherryblossom.module.modules.client.CherryBlossom.theme;
            theme.setModeIndex((theme.getModeIndex()+1)%theme.getPossibleValues().size());
            JsonObject changed=settings.capture();
            check(!changed.equals(original),"Test changes actual UI theme");
            panel.action("save",1);
            check(lib.slot(1).data().equals(changed),"Save overwrites an occupied slot");
            panel.action("paste",1);
            check(lib.slot(1).data().equals(original),"Paste overwrites selected occupied slot");
            check(settings.capture().equals(changed),"Paste does not apply settings until Load");
            panel.action("load",1);
            check(settings.capture().equals(original),"Load restores live modules, settings and layout");
            class_310.method_1551().field_1774.method_1455("invalid config");panel.action("paste",1);
            check(lib.slot(1).data().equals(original),"Invalid clipboard leaves saved slot intact");
            check(lib.profiles().size()==4,"Replacing and invalid import never add a fifth slot");
            boolean rejected=false;try{lib.saveSlot(4);}catch(IllegalArgumentException expected){rejected=true;}
            check(rejected,"Fifth slot rejected");
            check(!Files.exists(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("cherryblossom-configs.json")),"Old profile library remains untouched");
        }finally{settings.apply(original);class_310.method_1551().field_1774.method_1455(clipboard);}
        return checks;
    }
}
