package integration.verification;

import dev.cherryblossom.client.CherryBlossomController;
import dev.cherryblossom.client.module.Category;
import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.render.*;
import dev.cherryblossom.client.ui.UiInput;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import cherryblossom.feature.*;
import net.minecraft.*;
import org.lwjgl.glfw.GLFW;

/** Reproductions of the user's HUD, scrolling and focus regressions. */
public final class FixChecks {
    private static int checks;
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
    private static Field field(Object target,String name)throws Exception{Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f;}
    @SuppressWarnings("unchecked")
    public static int run(class_310 mc,Object gui)throws Exception {
        check(ModuleManager.all().size()==69,"Registry includes Spotify HUD and JumpCircles and excludes Halloween");
        check(ModuleManager.all().stream().noneMatch(m->m.name().equalsIgnoreCase("Halloween")),"Halloween is absent from the registry");
        check(ModuleManager.all().stream().anyMatch(m->m.name().equals("CherryBlossom+")),"Client module rebranded");
        check(ModuleManager.all().stream().allMatch(m->((dev.cherryblossom.client.module.CherryBlossomModule)m).nativeModule().getClass().getName().startsWith("cherryblossom.")),"All native module classes use the CherryBlossom package");
        var restoredTitle=new cherryblossom.module.setting.StringSetting("Title","CherryBlossom");
        restoredTitle.setValue("My client");check(restoredTitle.getValue().equals("My client"),"Custom string settings retain their supplied value");
        hudChecks();
        spotifyChecks();
        checks+=ResetChecks.run();
        var hud=ModuleManager.all().stream().filter(m->m.name().equals("HUD")).findFirst().orElseThrow();
        Field cats=field(gui,"wheelCategories"),scroll=field(gui,"wheelScroll"),target=field(gui,"wheelScrollTarget"),expand=field(gui,"expandFrame");
        Object oldCats=cats.get(gui);float oldScroll=scroll.getFloat(gui),oldTarget=target.getFloat(gui);
        Map<String,Float> expanded=(Map<String,Float>)expand.get(gui);Float previous=expanded.put(hud.id(),1f);
        AtomicInteger visits=new AtomicInteger();hud.keybind().visibleWhen(()->{visits.incrementAndGet();return true;});
        try {
            cats.set(gui,List.of(Category.CLIENT));scroll.setFloat(gui,120);target.setFloat(gui,120);
            Method draw=gui.getClass().getDeclaredMethod("drawWheelModules",UiCanvas.class,UiInput.class,dev.cherryblossom.client.render.text.FontAtlas.class,float.class,float.class);draw.setAccessible(true);
            try(UiCanvas canvas=new UiCanvas()) {canvas.begin(ScreenSurface.INSTANCE);draw.invoke(gui,canvas,UiInput.INERT,UiResources.atlas(),0f,2f);}
            check(visits.get()>=3,"Expanded controls render after their module heading scrolls above the viewport");
            scroll.setFloat(gui,1e8f);target.setFloat(gui,1e8f);
            try(UiCanvas canvas=new UiCanvas()) {canvas.begin(ScreenSurface.INSTANCE);draw.invoke(gui,canvas,UiInput.INERT,UiResources.atlas(),0f,2f);}
            check(scroll.getFloat(gui)<1e8f&&scroll.getFloat(gui)==target.getFloat(gui),"Both scroll position and target clamp immediately at the bottom");
        } finally {
            hud.keybind().visibleWhen(()->true);cats.set(gui,oldCats);scroll.setFloat(gui,oldScroll);target.setFloat(gui,oldTarget);
            if(previous==null)expanded.remove(hud.id());else expanded.put(hud.id(),previous);
        }
        cursorChecks(mc);
        return checks;
    }
    private static void cursorChecks(class_310 mc)throws Exception {
        Object c=CherryBlossomController.get();Field state=field(c,"state");Object old=state.get(c);
        Object panel=CherryBlossomController.get().mainPanel;Field open=field(panel,"clickGuiOpen");boolean oldOpen=open.getBoolean(panel);
        class_437 previousScreen=mc.field_1755;
        try {
            Object on=Arrays.stream(state.getType().getEnumConstants()).filter(v->v.toString().equals("ON")).findFirst().orElseThrow();
            state.set(c,on);open.setBoolean(panel,true);
            check(CherryBlossomController.get().screenClickGuiActive(),"Focus test uses the real active wheel condition");
            mc.field_1729.method_1612();
            check(!mc.field_1729.method_1613(),"Refocusing cannot lock the mouse while the wheel is open");
            Field lock=field(mc.field_1729,"field_1783"),dx=field(mc.field_1729,"field_1789"),dy=field(mc.field_1729,"field_1787");
            lock.setBoolean(mc.field_1729,true);dx.setDouble(mc.field_1729,80);dy.setDouble(mc.field_1729,-60);
            GLFW.glfwSetInputMode(mc.method_22683().method_4490(),GLFW.GLFW_CURSOR,GLFW.GLFW_CURSOR_DISABLED);
            Method update=mc.field_1729.getClass().getDeclaredMethod("method_1606",double.class);update.setAccessible(true);update.invoke(mc.field_1729,.016);
            check(!mc.field_1729.method_1613(),"An unexpected cursor grab is released before camera motion");
            check(dx.getDouble(mc.field_1729)==0&&dy.getDouble(mc.field_1729)==0,"GUI movement deltas are discarded");
            check(GLFW.glfwGetInputMode(mc.method_22683().method_4490(),GLFW.GLFW_CURSOR)==GLFW.GLFW_CURSOR_NORMAL,"Pointer returns to normal GUI mode");
            open.setBoolean(panel,false);
            check(!cherryblossom.integration.CherryGui.screenGuiActive(),"Mouse guard disengages when GUI closes");
        } finally {state.set(c,old);open.setBoolean(panel,oldOpen);mc.method_1507(previousScreen);mc.field_1729.method_1610();}
    }
    private static void hudChecks() {
        RecordingRenderer renderer=new RecordingRenderer();HudLayoutEditor hud=new HudLayoutEditor();
        var options=new HudLayoutEditor.adhvjlahyjurfh();options.time=false;options.info=false;options.player=false;options.coords=false;options.modules=false;
        hud.render(renderer,1240,720,null,options,1,false,0,0);
        check(renderer.texts.contains("CherryBlossom"),"HUD watermark is CherryBlossom");
        check(renderer.texts.stream().filter(s->s.equals("CherryBlossom")).count()==1,"HUD contains one CherryBlossom watermark");
        int title=renderer.textColors.get(renderer.texts.indexOf("CherryBlossom"));
        check((title&0xFFFFFF)==0xFF8FBD,"HUD title is Cherry Blossom pink");
        check(renderer.colors.stream().anyMatch(v->(v&0xFFFFFF)==0x34202D),"HUD panels use rose glass instead of grey");
        check(renderer.colors.stream().anyMatch(v->(v&0xFFFFFF)==0xFFD1E3),"HUD draws the blossom petals");
    }
    private static void spotifyChecks(){
        long now=System.nanoTime();
        var playing=SpotifyNowPlaying.parse("{\"status\":\"ready\",\"title\":\"Test song\",\"artist\":\"Test artist\",\"playing\":true,\"positionMs\":30000,\"durationMs\":180000}",now);
        check(playing.present()&&playing.positionAt(now+2_000_000_000L)==32000,"Spotify playing progress advances");
        check(playing.positionAt(now+300_000_000_000L)==180000,"Spotify progress clamps at duration");
        var paused=SpotifyNowPlaying.parse("{\"status\":\"ready\",\"title\":\"Paused song\",\"artist\":\"Artist\",\"playing\":false,\"positionMs\":1000,\"durationMs\":90000}",now);
        check(paused.positionAt(now+10_000_000_000L)==1000,"Spotify paused position stays fixed");
        check(SpotifyNowPlaying.commandFor(SpotifyNowPlaying.Control.TOGGLE,playing).equals("pause"),"Pause icon sends an explicit pause while playing");
        check(SpotifyNowPlaying.commandFor(SpotifyNowPlaying.Control.TOGGLE,paused).equals("play"),"Play icon sends an explicit play while paused");
        check(!SpotifyNowPlaying.parse("{\"status\":\"idle\"}",now).present(),"Spotify idle state has no track");
        check(SpotifyHudRenderer.time(127694).equals("2:07"),"Spotify duration formatting");
        check(SpotifyHudRenderer.controlAt(111,111)==SpotifyNowPlaying.Control.PREVIOUS,"Previous button hit area");
        check(SpotifyHudRenderer.controlAt(155,111)==SpotifyNowPlaying.Control.TOGGLE,"Play/pause button hit area");
        check(SpotifyHudRenderer.controlAt(199,111)==SpotifyNowPlaying.Control.NEXT,"Next button hit area");
        check(SpotifyHudRenderer.controlAt(155,60)==null&&SpotifyHudRenderer.controlAt(135,111)==null,"Dragging artwork/title/gaps does not trigger playback");
        RecordingRenderer r=new RecordingRenderer();SpotifyHudRenderer.draw(r,0,0,1,.72f,playing);
        check(r.texts.containsAll(List.of("SPOTIFY","PLAYING","Test song","Test artist","3:00")),"Spotify track, artist, progress and status render");
        r.texts.clear();SpotifyHudRenderer.draw(r,0,0,1,.72f,paused);check(r.texts.contains("PAUSED"),"Spotify paused badge renders");
        r.texts.clear();SpotifyHudRenderer.draw(r,0,0,1,.72f,SpotifyNowPlaying.parse("{\"status\":\"idle\"}",now));check(r.texts.contains("Nothing playing"),"Spotify idle panel renders");
    }
    public static void renderHud(class_310 mc,class_332 context) {
        float scale=(float)mc.method_22683().method_4495();
        context.method_51448().pushMatrix();context.method_51448().scale(1/scale,1/scale);
        try {
            var options=new HudLayoutEditor.adhvjlahyjurfh();options.info=false;options.player=false;options.coords=false;options.modules=false;
            new HudLayoutEditor().render(new MinecraftUiRenderer(context,scale),mc.method_22683().method_4489(),mc.method_22683().method_4506(),null,options,1,false,0,0);
            SpotifyHudRenderer.draw(new MinecraftUiRenderer(context,scale),20,mc.method_22683().method_4506()-147,1,.72f,new SpotifyNowPlaying.Track("Preview track","Preview artist",false,42000,180000,System.nanoTime(),"ready"));
        } finally {context.method_51448().popMatrix();}
    }
    private static final class RecordingRenderer extends UiRenderer {
        final List<String> texts=new ArrayList<>();final List<Integer> colors=new ArrayList<>(),textColors=new ArrayList<>();
        protected void fillRaw(int x,int y,int x1,int y1,int color){colors.add(color);}
        protected void gradientRaw(int x,int y,int x1,int y1,int top,int bottom){colors.add(top);colors.add(bottom);}
        protected void blitRaw(UiTextureData t,int a,int b,int c,int d,int e,int f,int g,int h,int color){}
        public void pushTransform(float x,float y,float scale){} public void popTransform(){} public float scale(){return 1;}
        public void pushClip(float x,float y,float w,float h){} public void popClip(){} public void head(float x,float y,float s){} public void item(Object o,float x,float y,float s){}
        public float text(String text,float x,float y,float size,int weight,int color){texts.add(text);textColors.add(color);return x+textWidth(text,size,weight);}
        public float textWidth(String text,float size,int weight){return text.length()*size*.6f;}
    }
}
