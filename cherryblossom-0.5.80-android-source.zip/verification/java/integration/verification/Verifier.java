package integration.verification;

import com.google.gson.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.*;
import org.lwjgl.glfw.GLFW;

/** Isolated test mod, never included in the shipping artifact. */
@SuppressWarnings("unchecked")
public final class Verifier implements ClientModInitializer {
    private static final Path OUTPUT=Path.of(System.getProperty("cherryblossom.verification.output"));
    private static final long START=System.nanoTime();
    private static int checks, phase=-1;
    private static boolean finished, shotRequested;
    private static volatile boolean shotWritten;
    private static volatile Throwable shotFailure;
    private static long since;
    private static Object gui;
    private static List<?> wheelEntries;
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    public void onInitializeClient() { ClientTickEvents.END_CLIENT_TICK.register(Verifier::tick); }
    private static void check(boolean condition,String message) {
        if(!condition) throw new AssertionError(message);
        checks++;
    }
    private static Object call(Object receiver,String name,Object... args)throws Exception {
        for(Class<?> type=receiver.getClass();type!=null;type=type.getSuperclass()) for(Method m:type.getDeclaredMethods()) if(m.getName().equals(name)&&m.getParameterCount()==args.length) {
            m.setAccessible(true); return m.invoke(receiver,args);
        }
        throw new NoSuchMethodException(name);
    }
    private static Object stat(String type,String name)throws Exception { return Class.forName(type).getMethod(name).invoke(null); }
    private static void tick(class_310 mc) {
        if(finished) return;
        try {
            if(mc.method_22683()!=null) GLFW.glfwHideWindow(mc.method_22683().method_4490());
            if((System.nanoTime()-START)/1e9<10||mc.method_18506()!=null) return;
            Files.createDirectories(OUTPUT);
            if(Boolean.getBoolean("cherry.verification.device")){finished=DeviceChecks.tick(mc,OUTPUT);return;}
            if(Boolean.getBoolean("cherry.verification.trialExpired")){finished=TrialChecks.expired(mc,OUTPUT);return;}
            if(phase==-1) {
                if(Boolean.getBoolean("cherry.verification.trial"))checks+=TrialChecks.active();
                verify();
                Object controller=stat("dev.cherryblossom.client.CherryBlossomController","get");
                Object panel=controller.getClass().getField("mainPanel").get(controller);
                Field field=panel.getClass().getDeclaredField("clickGui");field.setAccessible(true);gui=field.get(panel);
                wheelEntries=(List<?>)call(gui,"wheelEntries");
                check(wheelEntries.size()==6,"Exactly six wheel nodes");
                checks+=FixChecks.run(mc,gui);
                checks+=LibraryChecks.run();
                checks+=ConfigChecks.run();
                checks+=ControlsChecks.run(mc);
                checks+=RpcChecks.run();
                TotemChecks.start(mc);
                mc.method_1507(new class_437(class_2561.method_43470("Cherry CherryBlossom GUI verification")) {
                    @Override public void method_25394(class_332 context,int x,int y,float delta) {
                        try { render(mc); FixChecks.renderHud(mc,context); if(phase<7)TotemChecks.render(context); } catch(Exception e) { throw new RuntimeException(e); }
                    }
                });
                phase=0;since=System.nanoTime();return;
            }
            if(shotFailure!=null) throw shotFailure;
            boolean totemsReady=TotemChecks.poll();
            if(!shotRequested && (System.nanoTime()-since)/1e9>1) {
                String file=phase==0?"tree-ui.png":"tab-"+phase+".png";
                shotRequested=true;
                class_318.method_1663(mc.method_1522(),img->{
                    try {img.method_4314(OUTPUT.resolve(file));shotWritten=true;}
                    catch(Throwable error){shotFailure=error;}finally{img.close();}
                });
            }
            if(!shotWritten) return;
            if(phase==6&&!totemsReady)return;
            check(Files.size(OUTPUT.resolve(phase==0?"tree-ui.png":"tab-"+phase+".png"))>10000,"GUI screenshot rendered for phase "+phase);
            if(phase<6) {
                Object entry=wheelEntries.get(phase);
                call(gui,"openWheelEntry",entry);
                List<?> categories=(List<?>)call(entry,"categories");
                List<?> wrappers=(List<?>)stat("dev.cherryblossom.client.module.ModuleManager","all");
                Object first=wrappers.stream().filter(w->{try{return categories.contains(call(w,"category"));}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow();
                Field expanded=gui.getClass().getDeclaredField("expanded");expanded.setAccessible(true);
                ((Set<Object>)expanded.get(gui)).add(call(first,"id"));
                phase++;since=System.nanoTime();shotRequested=false;shotWritten=false;return;
            }
            if(phase==6){
                cherryblossom.module.modules.client.CherryBlossom.theme.setModeIndex(3);
                cherryblossom.feature.UiPalette.accent(1);
                Field changed=cherryblossom.feature.UiPalette.class.getDeclaredField("changedAt");changed.setAccessible(true);changed.setLong(null,System.nanoTime()-1_000_000_000L);
                dev.cherryblossom.client.ui.TotemPickerPanel.open(LibraryChecks.selector());
                phase=7;since=System.nanoTime();shotRequested=false;shotWritten=false;return;
            }
            if(phase==7){
                for(int i=0;i<10;i++)dev.cherryblossom.client.ui.TotemPickerPanel.key(264,1);
                phase=8;since=System.nanoTime();shotRequested=false;shotWritten=false;return;
            }
            dev.cherryblossom.client.ui.TotemPickerPanel.close();
            if(phase==8){
                cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue(70);
                cherryblossom.module.modules.client.CherryBlossom.animationMode.setModeIndex(2);
                cherryblossom.module.modules.client.CherryBlossom.theme.setModeIndex(cherryblossom.feature.UiPalette.Rose.ordinal());
                for(Object entry:wheelEntries)if(call(entry,"title").equals("Client"))call(gui,"openWheelEntry",entry);
                Object wrapper=dev.cherryblossom.client.module.ModuleManager.all().stream().filter(m->m.name().equals("CherryBlossom+")).findFirst().orElseThrow();
                Field expanded=gui.getClass().getDeclaredField("expanded");expanded.setAccessible(true);((Set<Object>)expanded.get(gui)).add(call(wrapper,"id"));
                phase=9;since=System.nanoTime();shotRequested=false;shotWritten=false;return;
            }
            if(phase==9){cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue(140);phase=10;since=System.nanoTime();shotRequested=false;shotWritten=false;return;}
            if(phase==10){
                cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue(100);
                call(gui,"backToWheel");Field cf=gui.getClass().getDeclaredField("configs");cf.setAccessible(true);((dev.cherryblossom.client.ui.ConfigPanel)cf.get(gui)).open();
                phase=11;since=System.nanoTime();shotRequested=false;shotWritten=false;return;
            }
            if(phase>=11&&phase<15){
                if(phase==11){Field cf=gui.getClass().getDeclaredField("configs");cf.setAccessible(true);((dev.cherryblossom.client.ui.ConfigPanel)cf.get(gui)).close();call(gui,"backToWheel");}
                else DropdownChecks.prepare(gui,phase+1);
                phase++;since=System.nanoTime();shotRequested=false;shotWritten=false;return;
            }
            check(mc.field_1687==null&&mc.field_1724==null,"No world or server entered");
            TotemChecks.finish();
            String result="PASS: "+checks+" runtime checks plus five totem models, PNG import/color/transparency/persistence, GPU shader checks and model-failure isolation; 69 modules including Spotify HUD, Halloween removed, six tabs rendered; pink CherryBlossom HUD and CherryBlossom+ branding; expanded-settings scrolling and cursor re-grab regression checks passed; native settings and config round-trip verified. No world or server entered.\n";
            Files.writeString(OUTPUT.resolve("runtime-results.txt"),result);
            System.out.println(result);finished=true;mc.method_1490();
        } catch(Throwable failure) {
            finished=true;failure.printStackTrace();
            try {StringWriter sw=new StringWriter();failure.printStackTrace(new PrintWriter(sw));Files.writeString(OUTPUT.resolve("runtime-failure.txt"),sw.toString());}catch(Exception ignored){}
            mc.method_1490();
        }
    }
    private static void verify()throws Exception {
        List<?> wrappers=(List<?>)stat("dev.cherryblossom.client.module.ModuleManager","all");
        Object runtime=Class.forName("cherryblossom.CherryBlossom").getField("INSTANCE").get(null);
        Object manager=call(runtime,"getModuleManager");
        List<?> originals=(List<?>)call(manager,"c");
        check(wrappers.size()==originals.size(),"One wrapper for each native module");
        Set<String> expected=new HashSet<>();
        try(Reader r=new InputStreamReader(Verifier.class.getResourceAsStream("/expected-modules.json"),java.nio.charset.StandardCharsets.UTF_8)) {
            String text=new BufferedReader(r).lines().reduce("",(a,b)->a+b).replace("\uFEFF","");
            for(JsonElement element:JsonParser.parseString(text).getAsJsonArray())expected.add(element.getAsString());
        }
        Set<String> found=new HashSet<>();
        Map<String,Integer> tabs=new LinkedHashMap<>();
        JsonArray inventory=new JsonArray();
        int bools=0,numbers=0;
        for(Object wrapper:wrappers) {
            Object original=call(wrapper,"nativeModule");
            found.add(original.getClass().getSimpleName());
            check(originals.contains(original),"Adapter delegates to original instance");
            String category=call(wrapper,"category").toString();
            check(category.equals(call(original,"getCategory").toString()),"Original tab preserved");
            tabs.merge(category,1,Integer::sum);
            JsonObject info=new JsonObject();info.addProperty("name",call(wrapper,"name").toString());info.addProperty("tab",category);
            List<?> controls=(List<?>)call(wrapper,"settings");info.addProperty("controls",controls.size());inventory.add(info);
            Object key=call(wrapper,"keybind");int keyBefore=(Integer)call(original,"getKeybind");
            key.getClass().getMethod("set",Object.class).invoke(key,290);
            check((Integer)call(original,"getKeybind")==290,"GUI keybind writes through");
            key.getClass().getMethod("set",Object.class).invoke(key,keyBefore);
            List<?> nativeSettings=(List<?>)call(original,"getSettings");
            for(Object source:nativeSettings) {
                if(source.getClass().getSimpleName().equals("BooleanSetting")) {
                    Object target=controls.stream().filter(c->{try{return c.getClass().getSimpleName().equals("BoolSetting")&&call(c,"name").toString().equals(call(source,"getName").toString());}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow();
                    boolean before=(Boolean)call(source,"getValue");
                    target.getClass().getMethod("set",Object.class).invoke(target,!before);
                    check((Boolean)call(source,"getValue")==!before,"Boolean setting writes to native runtime");
                    target.getClass().getMethod("set",Object.class).invoke(target,before);bools++;break;
                }
            }
            for(Object source:nativeSettings) if(source.getClass().getSimpleName().equals("NumberSetting")) {
                Object target=controls.stream().filter(c->{try{return c.getClass().getSimpleName().equals("SliderSetting")&&call(c,"name").toString().equals(call(source,"getName").toString());}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow();
                double before=(Double)call(source,"getValue"),minimum=(Double)call(source,"getMin"),maximum=(Double)call(source,"getMax");
                double value=before==minimum?maximum:minimum;
                target.getClass().getMethod("set",Object.class).invoke(target,value);
                double step=(Double)call(source,"getFormat");
                double expectedValue=Math.round(value/step)*step;
                check(Math.abs((Double)call(source,"getValue")-expectedValue)<.0001,"Numeric setting writes to native runtime: "+call(wrapper,"name")+" / "+call(source,"getName")+" requested="+value+" expected="+expectedValue+" actual="+call(source,"getValue"));
                target.getClass().getMethod("set",Object.class).invoke(target,before);numbers++;break;
            }
        }
        check(found.equals(expected),"Every ZIP module registered. Missing: "+difference(expected,found));
        check(tabs.size()==6,"All six imported tabs populated");
        check(bools>30&&numbers>30,"Broad setting coverage");
        Object hud=wrappers.stream().filter(w->{try{return call(w,"nativeModule").getClass().getSimpleName().equals("HudModule");}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow();
        call(hud,"setEnabled",true);check((Boolean)call(call(hud,"nativeModule"),"isEnabled"),"Toggle enables native module");
        call(hud,"setEnabled",false);check(!(Boolean)call(call(hud,"nativeModule"),"isEnabled"),"Toggle disables native module");
        Object settings=call(runtime,"getSettingsManager");Object saved=call(settings,"capture");
        call(settings,"apply",saved);
        Files.writeString(OUTPUT.resolve("config-before.json"),JSON.toJson(saved));
        Files.writeString(OUTPUT.resolve("config-after.json"),JSON.toJson(call(settings,"capture")));
        check(saved.equals(call(settings,"capture")),"Native config round-trip preserves all settings and layout");
        Class.forName("dev.cherryblossom.client.setting.SettingsStore").getMethod("saveNow").invoke(null);
        check(Class.forName("dev.cherryblossom.client.module.ModuleManager").getMethod("get",String.class).invoke(null,"weather")==null,"Original Cherry modules retired");
        Files.writeString(OUTPUT.resolve("runtime-module-inventory.json"),JSON.toJson(inventory));
        Files.writeString(OUTPUT.resolve("tabs.json"),JSON.toJson(tabs));
    }
    private static Set<String> difference(Set<String>a,Set<String>b){Set<String>r=new HashSet<>(a);r.removeAll(b);return r;}
    private static void render(class_310 mc)throws Exception {
        Class<?> canvasType=Class.forName("dev.cherryblossom.client.render.UiCanvas"),surfaceType=Class.forName("dev.cherryblossom.client.render.Surface"),inputType=Class.forName("dev.cherryblossom.client.ui.UiInput");
        Object font=stat("dev.cherryblossom.client.render.UiResources","atlas"),input=inputType.getField("INERT").get(null),surface=Class.forName("dev.cherryblossom.client.render.ScreenSurface").getField("INSTANCE").get(null);
        int width=mc.method_22683().method_4489(),height=mc.method_22683().method_4506();float scale=dev.cherryblossom.client.CherryBlossomController.get().clickGuiScreenScale();
        try(AutoCloseable canvas=(AutoCloseable)canvasType.getConstructor().newInstance()) {
            canvasType.getMethod("begin",surfaceType).invoke(canvas,surface);call(canvas,"push");
            canvasType.getMethod("translate",float.class,float.class).invoke(canvas,(width-1240*scale)/2,(height-580*scale)/2);
            canvasType.getMethod("scale",float.class,float.class,float.class).invoke(canvas,scale,0f,0f);
            Method render=gui.getClass().getDeclaredMethod("render",canvasType,inputType,font.getClass(),float.class);render.setAccessible(true);render.invoke(gui,canvas,input,font,2f);if(phase==11)ConfigChecks.clicks(gui,(dev.cherryblossom.client.render.UiCanvas)canvas,(dev.cherryblossom.client.render.text.FontAtlas)font);if(phase==12)checks+=DropdownChecks.run(gui,(dev.cherryblossom.client.render.UiCanvas)canvas,(dev.cherryblossom.client.render.text.FontAtlas)font);call(canvas,"pop");
            Object gpu=stat("dev.cherryblossom.client.render.CherryBlossomGpu","get");Field field=gpu.getClass().getDeclaredField("screenProjection");field.setAccessible(true);Object projection=field.get(gpu);
            Object slice=projection.getClass().getMethod("method_71092",float.class,float.class).invoke(projection,(float)width,(float)height);
            canvasType.getMethod("flush",com.mojang.blaze3d.textures.GpuTextureView.class,org.joml.Matrix4fc.class,com.mojang.blaze3d.buffers.GpuBufferSlice.class,float.class,float.class).invoke(canvas,mc.method_1522().method_71639(),new org.joml.Matrix4f(),slice,2f,1f);
        }
    }
}
