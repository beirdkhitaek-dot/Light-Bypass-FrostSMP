package integration.verification;

import cherryblossom.integration.*;
import dev.cherryblossom.client.CherryBlossomController;
import dev.cherryblossom.client.module.ModuleManager;
import java.nio.file.*;
import net.minecraft.*;
import org.lwjgl.glfw.GLFW;

final class DeviceChecks {
    private static int stage,checks;private static long started;private static volatile boolean shot;private static volatile Throwable failure;
    private static void check(boolean yes,String message){if(!yes)throw new AssertionError(message);checks++;System.out.println("DEVICE RUNTIME PASS: "+message);}
    static boolean tick(class_310 mc,Path output)throws Exception{
        if(failure!=null)throw new AssertionError(failure);
        if(stage==0){
            check(!DeviceAccess.allowed()&&!TrialAccess.allowed(),"No client feature access before a signed device lease");
            check(mc.field_1755 instanceof DeviceNoticeScreen,"A dismissible device activation screen is shown");
            check(ModuleManager.all().size()==76,"Current 76-module inventory is retained");
            for(var wrapper:ModuleManager.all()){
                wrapper.setEnabled(true);check(!wrapper.enabled(),"Wrapper refuses unlicensed activation: "+wrapper.name());
                var module=((dev.cherryblossom.client.module.CherryBlossomModule)wrapper).nativeModule();
                module.toggle(true);module.toggle();module.setEnabled(true);check(!module.isEnabled(),"Native enable paths require a device lease: "+wrapper.name());
                var reset=(dev.cherryblossom.client.setting.ModuleResetSetting)wrapper.settings().stream().filter(s->s instanceof dev.cherryblossom.client.setting.ModuleResetSetting).findFirst().orElseThrow();
                boolean blocked=false;try{reset.resetOptions();}catch(IllegalStateException expected){blocked=true;}check(blocked,"Protected actions require a device lease: "+wrapper.name());
            }
            var controller=CherryBlossomController.get();var state=controller.getClass().getDeclaredField("state");state.setAccessible(true);Object before=state.get(controller);controller.toggle();check(state.get(controller)==before,"Direct GUI entry cannot bypass device activation");
            check(GLFW.glfwGetInputMode(mc.method_22683().method_4490(),GLFW.GLFW_CURSOR)==GLFW.GLFW_CURSOR_NORMAL,"Activation screen keeps the cursor visible");
            stage=1;started=System.nanoTime();return false;
        }
        if(stage==1){
            if(DeviceAccess.status().contains("personal client")){
                check(DeviceAccess.verificationUrl().equals("https://cherryblossom.nikoo.win/account"),"Generic templates link to personal downloads without a confirmation code");
                check(Files.exists(Path.of(System.getProperty("user.home"),".cherryblossom","device","device-key-v1.json")),"Windows-protected identity is saved in the isolated test home");
                class_318.method_1663(mc.method_1522(),image->{try{image.method_4314(output.resolve("device-activation.png"));shot=true;}catch(Throwable e){failure=e;}finally{image.close();}});stage=2;
            }else if(System.nanoTime()-started>90_000_000_000L)throw new AssertionError("Personal-download state did not arrive: "+DeviceAccess.status());
        }
        if(stage==2&&shot){((DeviceNoticeScreen)mc.field_1755).method_25419();check(!(mc.field_1755 instanceof DeviceNoticeScreen),"Closing activation leaves Minecraft usable");
            Files.writeString(output.resolve("runtime-results.txt"),"PASS: "+checks+" device-lock runtime checks, all 76 module gates, published activation API, Windows device record, visible cursor and dismissible notice.\n");Files.writeString(output.resolve("runtime-module-inventory.json"),"[]");mc.method_1490();return true;}
        return false;
    }
}
