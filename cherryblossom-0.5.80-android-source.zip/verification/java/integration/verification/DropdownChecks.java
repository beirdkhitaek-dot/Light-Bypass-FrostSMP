package integration.verification;

import dev.cherryblossom.client.module.Category;
import dev.cherryblossom.client.module.Module;
import dev.cherryblossom.client.module.ModuleManager;
import dev.cherryblossom.client.render.UiCanvas;
import dev.cherryblossom.client.render.text.FontAtlas;
import dev.cherryblossom.client.setting.*;
import dev.cherryblossom.client.ui.*;
import java.lang.reflect.*;
import java.util.*;

/** Real dropdown input, persistence, clipping and shared-setting regression checks. */
public final class DropdownChecks {
    private static boolean done;
    private static int checks;
    private static Method render;
    private static Object gui;
    private static UiCanvas canvas;
    private static FontAtlas fonts;
    private static final float COLUMN=(1208-5*12)/6f;
    private static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);checks++;System.out.println("DROPDOWN PASS: "+text);}
    private static Object field(Object target,String name)throws Exception{var f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}
    private static Object call(Object target,String name,Object...args)throws Exception{for(var m:target.getClass().getDeclaredMethods())if(m.getName().equals(name)&&m.getParameterCount()==args.length){m.setAccessible(true);return m.invoke(target,args);}throw new NoSuchMethodException(name);}
    private static void frame(UiInput input)throws Exception{input.beginFrame();render.invoke(gui,canvas,input,fonts,2f);input.endFrame();}
    private static void warm()throws Exception{render.invoke(gui,canvas,UiInput.INERT,fonts,2f);}
    private static void click(float x,float y)throws Exception{var in=new UiInput();in.active=true;in.x=x;in.y=y;in.down=true;in.pressed=true;frame(in);in.down=false;in.released=true;frame(in);}
    private static float x(Category category){return 16+category.ordinal()*(COLUMN+12);}
    private static TextField search()throws Exception{return (TextField)field(gui,"wheelSearch");}
    private static void query(String text)throws Exception{search().setText(text);warm();}
    @SuppressWarnings("unchecked") private static Set<String> expanded()throws Exception{return (Set<String>)field(gui,"expanded");}
    private static Module module(String name){return ModuleManager.all().stream().filter(m->m.name().equals(name)).findFirst().orElseThrow();}
    private static void expand(Module module)throws Exception{if(!expanded().contains(module.id()))click(x(module.category())+COLUMN-19,177);warm();check(expanded().contains(module.id()),"Module settings expand in its branch");}
    private static float settingY(Module module,Setting<?> wanted)throws Exception{
        float y=199;for(var setting:module.settings()){if(!setting.isVisible())continue;if(setting==wanted)return y;y+=setting instanceof ModeSetting?53:((Number)call(gui,"settingHeight",setting)).floatValue();}throw new AssertionError("Hidden setting");
    }
    public static int run(Object target,UiCanvas c,FontAtlas f)throws Exception{
        if(done)return 0;done=true;gui=target;canvas=c;fonts=f;
        render=gui.getClass().getDeclaredMethod("render",UiCanvas.class,UiInput.class,FontAtlas.class,float.class);render.setAccessible(true);
        var settings=cherryblossom.CherryBlossom.INSTANCE.getSettingsManager();var snapshot=settings.capture();
        String clipboard=net.minecraft.class_310.method_1551().field_1774.method_1460();
        try{
            checks+=ResetChecks.renderClicks(gui,canvas,fonts);
            ((ConfigPanel)field(gui,"configs")).close();call(gui,"backToWheel");expanded().clear();
            click(620,250);
            check(CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Dropdown"),"Center tree icon switches to dropdown mode");
            check(ModuleManager.all().size()==69,"Dropdown shares all 69 real module instances");
            Object dropdown=field(gui,"dropdown");int count=0;
            for(var category:Category.values())count+=((List<?>)call(dropdown,"modules",category,"")).size();
            check(count==69,"All six dropdown branches contain every module exactly once");
            click(460,54);check(dev.cherryblossom.client.CherryBlossomController.get().isFocused(search()),"Dropdown search receives keyboard focus");
            query("Hud");Module hud=ModuleManager.all().stream().filter(m->((dev.cherryblossom.client.module.CherryBlossomModule)m).nativeModule() instanceof cherryblossom.feature.HudModule).findFirst().orElseThrow();
            query(hud.name());
            // HUD query can match Spotify HUD too, so calculate the actual filtered position.
            List<?> matches=(List<?>)call(dropdown,"modules",Category.CLIENT,hud.name().toLowerCase(Locale.ROOT));int index=matches.indexOf(hud);float row=177+index*34;
            boolean before=hud.enabled();click(x(Category.CLIENT)+60,row);check(hud.enabled()!=before,"Dropdown click toggles the native module");click(x(Category.CLIENT)+60,row);
            query("Custom Totem");Module totem=module("Custom Totem");expand(totem);
            var picker=(TotemPickerSetting)totem.settings().stream().filter(s->s instanceof TotemPickerSetting).findFirst().orElseThrow();
            click(x(Category.RENDER)+70,settingY(totem,picker)+34);
            check(TotemPickerPanel.isOpen(),"Totem thumbnail selector opens from dropdown settings");
            check(TotemPickerPanel.select(5),"Totem dropdown selects an available pack");
            check(cherryblossom.feature.CustomTotemModule.designIndex()==5,"Totem choice reaches the native module");
            query("JumpCircles");Module jump=module("JumpCircles");expand(jump);
            var slider=(SliderSetting)jump.settings().stream().filter(s->s instanceof SliderSetting).findFirst().orElseThrow();double old=(Double)slider.get();
            click(x(Category.RENDER)+72,settingY(jump,slider)+33);
            check(Math.abs((Double)slider.get()-old)>.01,"Dropdown numeric slider changes its real setting");
            var bool=(BoolSetting)jump.settings().stream().filter(s->s instanceof BoolSetting).findFirst().orElseThrow();boolean oldBool=bool.on();
            click(x(Category.RENDER)+COLUMN-36,settingY(jump,bool)+13);
            check(bool.on()!=oldBool,"Dropdown boolean switch changes its real setting");
            var resets=(ModuleResetSetting)jump.settings().stream().filter(s->s instanceof ModuleResetSetting).findFirst().orElseThrow();
            jump.keybind().set(65);click(x(Category.RENDER)+45,settingY(jump,resets)+13);
            check(jump.keybind().get()==-1,"Dropdown Reset keybind button clears the real binding");
            slider.set(slider.get().equals(slider.min())?slider.max():slider.min());
            click(x(Category.RENDER)+COLUMN-55,settingY(jump,resets)+13);
            check(slider.get().equals(slider.defaultValue()),"Dropdown Reset settings button restores native options");
            query("CherryBlossom+");Module client=module("CherryBlossom+");expand(client);
            var mode=(ModeSetting)client.settings().stream().filter(s->s instanceof ModeSetting).findFirst().orElseThrow();String oldMode=mode.get();
            float modeY=settingY(client,mode);
            if(modeY+53>522){@SuppressWarnings("unchecked") var offsets=(Map<Category,Float>)field(dropdown,"scroll");offsets.put(Category.CLIENT,modeY-220);warm();modeY=220;}
            click(x(Category.CLIENT)+70,modeY+34);
            check(!mode.get().equals(oldMode),"Dropdown mode choice changes the shared setting");
            query("Anti Vanish");Module vanish=module("Anti Vanish");expand(vanish);
            var text=(TextSetting)vanish.settings().stream().filter(s->s instanceof TextSetting).findFirst().orElseThrow();
            click(x(Category.DONUT)+80,settingY(vanish,text)+((Number)call(gui,"settingHeight",text)).floatValue()-17);warm();
            check(field(gui,"editingText")==text,"Dropdown text setting opens an editable modal");
            ((TextField)field(gui,"textEditor")).setText("CherryVerify,TestStaff");click(860,350);
            check(text.get().equals("CherryVerify,TestStaff")&&field(gui,"editingText")==null,"Text editor Save updates the native text setting");
            var key=(KeySetting)vanish.settings().stream().filter(s->s instanceof KeySetting).findFirst().orElseThrow();
            click(x(Category.DONUT)+COLUMN-45,settingY(vanish,key)+15);
            check(dev.cherryblossom.client.CherryBlossomController.get().isCapturing(key),"Dropdown keybind button captures keyboard input");
            dev.cherryblossom.client.CherryBlossomController.get().stopKeyboardCapture();
            query("");expanded().clear();warm();
            var in=new UiInput();in.active=true;in.x=x(Category.DONUT)+80;in.y=250;in.scroll=-100000;frame(in);
            @SuppressWarnings("unchecked") var offsets=(Map<Category,Float>)field(dropdown,"scroll");float maximum=offsets.get(Category.DONUT);
            check(maximum>0&&Float.isFinite(maximum),"Long branch scroll is bounded");
            in.scroll=-100000;frame(in);check(offsets.get(Category.DONUT)==maximum,"Repeated overscroll cannot move content out of reach");
            check(offsets.get(Category.COMBAT)==0,"Scrolling Donut leaves Combat in place");
            in.scroll=100000;frame(in);check(offsets.get(Category.DONUT)==0,"Reverse overscroll returns to branch top");
            click(x(Category.DONUT)+80,135);check(((Set<?>)field(dropdown,"collapsed")).contains(Category.DONUT),"Branch header collapses its dropdown");
            click(x(Category.DONUT)+80,135);warm();check(!((Set<?>)field(dropdown,"collapsed")).contains(Category.DONUT),"Branch header reopens its dropdown");
            query("not-a-module-qwerty");int empty=0;for(var cat:Category.values())empty+=((List<?>)call(dropdown,"modules",cat,"not-a-module-qwerty")).size();check(empty==0,"Search filters all branches without losing category headers");query("");
            click(620,ConfigPanel.buttonY()+22);var configs=(ConfigPanel)field(gui,"configs");check(configs.isOpen(),"Bottom config button works in dropdown mode");
            click(410,195);click(422,385);var saved=configs.library().slot(0).data().deepCopy();
            check(saved.equals(settings.capture()),"Centered config page saves the current real settings");
            click(686,385);click(675,195);click(818,385);
            check(configs.library().slot(1).data().equals(saved),"Copy and Paste buttons work in the centered config page");
            click(554,385);check(settings.capture().equals(saved),"Centered config Load applies the saved settings");
            click(398,101);check(!configs.isOpen(),"Config Back returns to dropdown layout");
            click(1110,54);check(CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Wheel"),"Tree layout button returns to the tree");
            click(620,250);check(CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Dropdown"),"Tree center can switch layouts repeatedly");
            SettingsStore.saveNow();check(CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Dropdown"),"Layout preference is persisted through the settings store");
            var layout=SettingsStore.write(List.of(CherryBlossomSettings.CLICK_GUI_LAYOUT));CherryBlossomSettings.CLICK_GUI_LAYOUT.set("Wheel");SettingsStore.read(layout,List.of(CherryBlossomSettings.CLICK_GUI_LAYOUT));
            check(CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Dropdown"),"Saved dropdown layout survives settings deserialization");
            var controller=dev.cherryblossom.client.CherryBlossomController.get();Object panel=field(controller,"mainPanel");call(panel,"openClickGui");
            check(CherryBlossomSettings.CLICK_GUI_LAYOUT.is("Dropdown"),"Reopening Click GUI preserves dropdown layout");
            double size=cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue();
            for(int percent:new int[]{70,100,140}){cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue(percent);float scale=controller.clickGuiScreenScale();var window=net.minecraft.class_310.method_1551().method_22683();check(controller.clickGuiScreenLeft()>=0&&controller.clickGuiScreenTop()>=0&&1240*scale<=window.method_4489()&&580*scale<=window.method_4506(),"Dropdown fits viewport at "+percent+"% size");}
            cherryblossom.module.modules.client.CherryBlossom.guiSize.getValue(size);
        }finally{
            TotemPickerPanel.close();((ConfigPanel)field(gui,"configs")).close();search().clear();expanded().clear();
            settings.apply(snapshot);net.minecraft.class_310.method_1551().field_1774.method_1455(clipboard);canvas=null;fonts=null;
        }
        return checks;
    }
    public static void prepare(Object gui,int phase)throws Exception{
        var dropdown=field(gui,"dropdown");((Map<?,?>)field(dropdown,"scroll")).clear();
        var configs=(ConfigPanel)field(gui,"configs");configs.close();
        var expanded=(Set<String>)field(gui,"expanded");expanded.clear();
        var query=(TextField)field(gui,"wheelSearch");query.clear();
        if(phase==13||phase==14){query.setText("Custom Totem");expanded.add(module("Custom Totem").id());}
        if(phase==14)TotemPickerPanel.open(LibraryChecks.selector());
        if(phase==15){TotemPickerPanel.close();configs.open();}
    }
}
