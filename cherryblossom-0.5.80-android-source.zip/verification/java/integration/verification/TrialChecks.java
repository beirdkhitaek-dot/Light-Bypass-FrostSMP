package integration.verification;

import java.nio.file.*;
import cherryblossom.integration.*;
import dev.cherryblossom.client.CherryBlossomController;
import dev.cherryblossom.client.module.ModuleManager;
import net.minecraft.*;

final class TrialChecks {
    private static int stage;
    private static long since;
    private static volatile boolean shot;
    private static volatile Throwable failure;
    static int active(){
        if(!TrialAccess.isTrial()||!TrialAccess.allowed())throw new AssertionError("Trial build is active");
        long left=TrialAccess.remainingMillis();if(left<TrialClock.DURATION-180_000||left>TrialClock.DURATION)throw new AssertionError("Trial deadline is 72h after isolated first launch");
        System.out.println("TRIAL PASS: first launch starts a 72-hour trial with a persisted deadline");return 2;
    }
    static boolean expired(class_310 mc,Path output)throws Exception{
        if(failure!=null)throw new AssertionError(failure);
        if(stage==0){
            if(!TrialAccess.isTrial()||TrialAccess.allowed()||TrialAccess.remainingMillis()!=0)throw new AssertionError("Expired trial must deny access");
            if(!(mc.field_1755 instanceof TrialNoticeScreen))throw new AssertionError("Expiry notice is shown");
            for(var wrapper:ModuleManager.all()){
                wrapper.setEnabled(true);if(wrapper.enabled())throw new AssertionError("Expired GUI toggle enabled "+wrapper.name());
                var module=((dev.cherryblossom.client.module.CherryBlossomModule)wrapper).nativeModule();
                module.toggle(true);module.toggle();module.setEnabled(true);if(module.isEnabled())throw new AssertionError("Expired native toggle enabled "+module.getName());
                var reset=(dev.cherryblossom.client.setting.ModuleResetSetting)wrapper.settings().stream().filter(s->s instanceof dev.cherryblossom.client.setting.ModuleResetSetting).findFirst().orElseThrow();
                for(boolean keybindOnly:new boolean[]{true,false}){
                    try{if(keybindOnly)reset.resetKeybind();else reset.resetOptions();throw new AssertionError("Expired reset action was accepted");}
                    catch(IllegalStateException expected){}
                }
            }
            System.out.println("TRIAL PASS: both reset actions are blocked for all 69 modules after expiry");
            var configPanel=new dev.cherryblossom.client.ui.ConfigPanel();
            configPanel.action("save",0);configPanel.action("paste",0);configPanel.action("load",0);
            if(Files.exists(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("cherryblossom-slots.json")))throw new AssertionError("Expired config actions changed saved slots");
            System.out.println("TRIAL PASS: expired config save, paste and load actions are blocked");
            var controller=CherryBlossomController.get();var state=controller.getClass().getDeclaredField("state");state.setAccessible(true);Object before=state.get(controller);controller.toggle();
            if(state.get(controller)!=before)throw new AssertionError("Expired GUI opened");
            stage=1;since=System.nanoTime();System.out.println("TRIAL PASS: expired build blocks all 69 modules and GUI entry");return false;
        }
        if(stage==1&&System.nanoTime()-since>1_000_000_000L){stage=2;class_318.method_1663(mc.method_1522(),image->{try{image.method_4314(output.resolve("trial-expired.png"));shot=true;}catch(Throwable e){failure=e;}finally{image.close();}});}
        if(stage==2&&shot){
            ((TrialNoticeScreen)mc.field_1755).method_25419();if(mc.field_1755 instanceof TrialNoticeScreen)throw new AssertionError("Expiry notice dismisses");
            Files.writeString(output.resolve("runtime-results.txt"),"PASS: expired trial blocks all 69 module enable paths, blocks Cherry GUI, shows a dismissible expiry notice and leaves Minecraft running.\n");Files.writeString(output.resolve("runtime-module-inventory.json"),"[]");mc.method_1490();return true;
        }
        return false;
    }
}
