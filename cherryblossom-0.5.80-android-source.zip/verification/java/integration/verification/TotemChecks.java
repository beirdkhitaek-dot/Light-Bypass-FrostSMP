package integration.verification;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import cherryblossom.feature.CustomTotemModule;
import cherryblossom.itemfx.*;
import cherryblossom.module.ext.ModuleRegistry;
import net.minecraft.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public final class TotemChecks {
    private static final int[] KEYS={201,202,1,2,7};
    private static Method prepare;
    private static boolean enabled;
    private static int previousDesign;
    private static boolean reported;
    private static long started;
    private static CustomTotemModule module;
    private static Field rendererFailed;
    private static Path fixture;
    private static boolean importedChecked;
    public static void start(class_310 mc)throws Exception {
        started=System.nanoTime();module=ModuleRegistry.get(CustomTotemModule.class);
        enabled=module.isEnabled();previousDesign=CustomTotemModule.design.getModeIndex();module.toggle(true);
        Class<?> renderer=ItemFxRenderer.class;
        prepare=renderer.getDeclaredMethod("prepare",int.class);prepare.setAccessible(true);
        rendererFailed=renderer.getDeclaredField("failed");rendererFailed.setAccessible(true);
        Field builds=renderer.getDeclaredField("BUILDS");builds.setAccessible(true);
        @SuppressWarnings("unchecked") Map<Integer,CompletableFuture<?>> pending=(Map<Integer,CompletableFuture<?>>)builds.get(null);
        pending.put(99999,CompletableFuture.failedFuture(new IllegalStateException("Expected test failure for an isolated model")));
        Method ready=renderer.getDeclaredMethod("ready",int.class);ready.setAccessible(true);
        if((Boolean)ready.invoke(null,99999)||rendererFailed.getBoolean(null))throw new AssertionError("One bad model disabled the shared renderer");
        class_811 gui=Arrays.stream(class_811.values()).filter(v->v.method_15434().equals("gui")).findFirst().orElseThrow();
        for(int i=0;i<4;i++) {
            CustomTotemModule.design.setModeIndex(i);
            class_10444 state=new class_10444();
            mc.method_65386().method_65598(state,stack(),gui,null,null,0);
            int fx=((ItemFxState)state).cherryblossom$fx();
            if(fx==0||((fx>>12)&15)!=i)throw new AssertionError("Custom Totem design "+i+" did not tag the real item state");
        }
        CustomTotemModule.design.setModeIndex(0);
        fixture=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("totem-test-source.png");
        BufferedImage png=new BufferedImage(16,16,BufferedImage.TYPE_INT_ARGB);
        for(int y=2;y<14;y++)for(int x=5;x<11;x++)png.setRGB(x,y,0xFFFF8FBD);
        ImageIO.write(png,"PNG",fixture.toFile());
        ImportedTotem.importAsync(fixture.toString());
    }
    private static class_1799 stack(){return new class_1799(class_7923.field_41178.method_63535(class_2960.method_60654("minecraft:totem_of_undying")));}
    public static boolean poll()throws Exception {
        if(rendererFailed.getBoolean(null))throw new AssertionError("Custom item renderer failed");
        if(!CustomTotemModule.imagePath.getValue().equals(fixture.toString()))return false;
        if(!importedChecked){
            Path copy=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("cherryblossom/totem/imported.png");
            if(!Files.isRegularFile(copy))throw new AssertionError("Imported PNG was not saved");
            BufferedImage restored=ImportedTotem.read(copy);
            if(restored.getRGB(6,6)!=0xFFFF8FBD||restored.getRGB(0,0)!=0)throw new AssertionError("PNG colors or transparency changed");
            var mesh=ImportedTotem.mesh();
            if(mesh.vertexCount==0||Arrays.stream(mesh.rgba).noneMatch(c->c==0xFFFF8FBD))throw new AssertionError("Imported PNG has no colored mesh");
            Files.delete(fixture);
            if(!Files.isRegularFile(copy))throw new AssertionError("Managed PNG disappeared when the original moved");
            importedChecked=true;
        }
        boolean all=true;
        for(int key:KEYS)if(!(Boolean)prepare.invoke(null,key))all=false;
        for(int i=0;i<TotemAssets.entries().size();i++)if(TotemAssets.entries().get(i).available()) {
            int key=10000+i*10000+TotemAssets.pack(i).frame(0);
            if(!(Boolean)prepare.invoke(null,key))all=false;
        }
        if(!all&&(System.nanoTime()-started)/1e9>90)throw new AssertionError("Custom Totem models or shaders did not become ready");
        if(all&&!reported){reported=true;System.out.println("PASS: four built-in totems and imported PNG uploaded; PNG color, transparency and persistence verified; GPU shaders compiled; model failures isolated.");}
        return all;
    }
    public static void render(class_332 context) {
        context.method_51448().pushMatrix();context.method_51448().translate(12,36);context.method_51448().scale(3,3);
        try {
            for(int i=0;i<(importedChecked?5:4);i++){CustomTotemModule.design.setModeIndex(i);context.method_51427(stack(),i*22,0);}
            context.method_51448().scale(.5f,.5f);
            for(int i=0;i<TotemAssets.entries().size();i++)if(TotemAssets.entries().get(i).available()) {
                CustomTotemModule.design.setModeIndex(i+5);context.method_51427(stack(),i*27,70);
            }
        }finally{context.method_51448().popMatrix();CustomTotemModule.design.setModeIndex(0);}
    }
    public static void finish(){CustomTotemModule.design.setModeIndex(previousDesign);module.toggle(enabled);}
}
