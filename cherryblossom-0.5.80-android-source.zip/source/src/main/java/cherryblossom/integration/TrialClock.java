package cherryblossom.integration;

import com.google.gson.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.function.LongSupplier;

/** Persistent wall-clock deadline, with monotonic time and rollback checks. */
public final class TrialClock {
    public static final long DURATION=72L*60*60*1000;
    private static final long ROLLBACK_TOLERANCE=120_000;
    private final Path file;
    private final LongSupplier wall,nanos;
    private final long launchWall,launchNanos;
    private long started,lastSeen,lastSaved;
    private volatile long expires;
    private volatile boolean expired;
    private volatile String reason="Your 72-hour trial has ended.";
    public TrialClock(Path file,LongSupplier wall,LongSupplier nanos){
        this.file=file;this.wall=wall;this.nanos=nanos;launchWall=wall.getAsLong();launchNanos=nanos.getAsLong();
        try{
            if(Files.exists(file)){
                var data=JsonParser.parseString(Files.readString(file)).getAsJsonObject();
                started=data.get("started").getAsLong();lastSeen=data.get("lastSeen").getAsLong();expires=data.get("expires").getAsLong();expired=data.get("expired").getAsBoolean();
                if(started<=0||lastSeen<started||expires!=Math.addExact(started,DURATION))throw new IllegalArgumentException("Invalid trial state");
            }else{started=launchWall;lastSeen=started;expires=Math.addExact(started,DURATION);}
            update(true);
        }catch(Exception e){expired=true;reason="The trial record could not be verified or saved.";}
    }
    private long now(){long elapsed=Math.max(0,(nanos.getAsLong()-launchNanos)/1_000_000);return Math.max(wall.getAsLong(),launchWall+elapsed);}
    public boolean allowed(){return !expired&&now()<expires&&wall.getAsLong()+ROLLBACK_TOLERANCE>=lastSeen;}
    public long remainingMillis(){return allowed()?Math.max(0,expires-now()):0;}
    public long expiresAt(){return expires;}
    public String reason(){return reason;}
    public synchronized void update(boolean force){
        long now=now();boolean wasExpired=expired;
        if(wall.getAsLong()+ROLLBACK_TOLERANCE<lastSeen){expired=true;reason="The system clock moved behind the saved trial time.";}
        if(now>=expires)expired=true;
        lastSeen=Math.max(lastSeen,now);
        if(force||expired!=wasExpired||now-lastSaved>=60_000){
            try{
                Files.createDirectories(file.getParent());
                JsonObject data=new JsonObject();data.addProperty("started",started);data.addProperty("expires",expires);data.addProperty("lastSeen",lastSeen);data.addProperty("expired",expired);
                Path temp=Files.createTempFile(file.getParent(),"trial-",".tmp");
                try{Files.writeString(temp,data.toString(),StandardCharsets.UTF_8);try{Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}}finally{Files.deleteIfExists(temp);}
                lastSaved=now;
            }catch(Exception e){expired=true;reason="The trial record could not be saved.";}
        }
    }
}
