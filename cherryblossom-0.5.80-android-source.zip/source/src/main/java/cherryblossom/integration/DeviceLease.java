package cherryblossom.integration;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/** Verifies server-issued, short-lived leases against the client-pinned public key. */
public final class DeviceLease {
    private DeviceLease(){}
    public static long verify(String token,String publicKey,String issuer,String fingerprint,String edition,String challenge,long serverTime)throws Exception{
        if(token==null||token.length()>8192)throw new SecurityException("Invalid license response.");
        String[] parts=token.split("\\.",-1);if(parts.length!=3)throw new SecurityException("Invalid license response.");
        Base64.Decoder decoder=Base64.getUrlDecoder();
        JsonObject header=JsonParser.parseString(new String(decoder.decode(parts[0]),StandardCharsets.UTF_8)).getAsJsonObject();
        if(!header.get("alg").getAsString().equals("ES256")||!header.get("typ").getAsString().equals("CBL1"))throw new SecurityException("Invalid license signature.");
        Signature verifier=Signature.getInstance("SHA256withECDSAinP1363Format");verifier.initVerify(KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(decoder.decode(publicKey))));verifier.update((parts[0]+"."+parts[1]).getBytes(StandardCharsets.UTF_8));
        if(!verifier.verify(decoder.decode(parts[2])))throw new SecurityException("Invalid license signature.");
        JsonObject payload=JsonParser.parseString(new String(decoder.decode(parts[1]),StandardCharsets.UTF_8)).getAsJsonObject();
        if(!issuer.equals(payload.get("iss").getAsString())||!"CherryBlossomClient".equals(payload.get("aud").getAsString())||payload.get("v").getAsInt()!=1||!fingerprint.equals(payload.get("device").getAsString())||!edition.equals(payload.get("edition").getAsString())||!challenge.equals(payload.get("challenge").getAsString())||!payload.get("sub").getAsString().matches("[0-9]{15,22}"))throw new SecurityException("This license belongs to another device or edition.");
        long issued=payload.get("iat").getAsLong(),expires=payload.get("exp").getAsLong();
        if(issued<0||serverTime<issued||serverTime-issued>60000||expires<=serverTime||expires<issued||expires-issued>300000)throw new SecurityException("License response expired.");
        return Math.min(300000,expires-serverTime);
    }
}
