package cherryblossom.integration;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Public application ID and invite; no Discord credentials are used. */
public final class DiscordDefaults {
    private static final JsonObject VALUES=read();
    private static JsonObject read(){
        try(var stream=DiscordDefaults.class.getResourceAsStream("/assets/cherryblossom/discord.json")){
            return stream==null?new JsonObject():JsonParser.parseReader(new InputStreamReader(stream,StandardCharsets.UTF_8)).getAsJsonObject();
        }catch(Exception e){return new JsonObject();}
    }
    public static String get(String key){return VALUES.has(key)?VALUES.get(key).getAsString():"";}
    private DiscordDefaults(){}
}
