package cherryblossom.integration;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

public final class DeviceNoticeScreen extends Screen {
    private final Screen previous;
    private static boolean pressed;
    public DeviceNoticeScreen(Screen previous){super(Text.literal("CherryBlossom device activation"));this.previous=previous;}
    public static void pollActivationKey(){MinecraftClient mc=MinecraftClient.getInstance();boolean down=GLFW.glfwGetKey(mc.getWindow().getHandle(),GLFW.GLFW_KEY_F8)==GLFW.GLFW_PRESS;if(down&&!pressed&&!DeviceAccess.allowed()&&!(mc.currentScreen instanceof DeviceNoticeScreen))mc.setScreen(new DeviceNoticeScreen(mc.currentScreen));pressed=down;}
    @Override protected void init(){
        addDrawableChild(ButtonWidget.builder(Text.literal("Open my downloads"),b->Util.getOperatingSystem().open(DeviceAccess.verificationUrl())).dimensions(width/2-110,height/2+12,220,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Retry connection"),b->DeviceAccess.retry()).dimensions(width/2-110,height/2+60,220,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Continue to Minecraft"),b->close()).dimensions(width/2-110,height/2+84,220,20).build());
    }
    @Override public void close(){if(client!=null)client.setScreen(previous);}
    @Override public boolean shouldPause(){return false;}
    @Override public void tick(){DeviceAccess.tick();if(DeviceAccess.allowed())close();}
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){
        context.fill(0,0,width,height,0xF01F1420);context.drawCenteredTextWithShadow(textRenderer,"CherryBlossom · Device access",width/2,height/2-88,0xFFFF8FBD);
        context.drawCenteredTextWithShadow(textRenderer,DeviceAccess.status(),width/2,height/2-63,0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,"Personal downloads bind automatically on their first PC.",width/2,height/2-39,0xFFFFAED0);
        context.drawCenteredTextWithShadow(textRenderer,"One computer per account. F8 reopens device status.",width/2,height/2-17,0xFFE6C6D7);super.render(context,mouseX,mouseY,delta);
    }
}
