package cherryblossom.integration;

import java.nio.file.Path;

/** Enabled only by the separate trial artifact; the full build has no policy asset. */
public final class TrialAccess {
    private static final boolean TRIAL=TrialAccess.class.getResource("/assets/cherryblossom/trial72h.flag")!=null;
    private static final TrialClock CLOCK=TRIAL?new TrialClock(Path.of(System.getProperty("user.home"),".cherryblossom","trials","trial72h-v1.json"),System::currentTimeMillis,System::nanoTime):null;
    private TrialAccess(){}
    public static boolean isTrial(){return TRIAL;}
    public static boolean allowed(){return DeviceAccess.allowed()&&(!TRIAL||CLOCK.allowed());}
    public static void tick(){DeviceAccess.tick();if(TRIAL)CLOCK.update(false);}
    public static void save(){if(TRIAL)CLOCK.update(true);}
    public static long remainingMillis(){return TRIAL?CLOCK.remainingMillis():Long.MAX_VALUE;}
    public static long expiresAt(){return TRIAL?CLOCK.expiresAt():Long.MAX_VALUE;}
    public static String reason(){return !DeviceAccess.allowed()?DeviceAccess.status():TRIAL?CLOCK.reason():"";}
}
