package cherryblossom.integration;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.time.*;
import java.time.format.DateTimeFormatter;

/** Dismissible trial notice; expiry never stops Minecraft or disconnects a world. */
public final class TrialNoticeScreen extends Screen {
    private final Screen previous;
    public TrialNoticeScreen(Screen previous){super(Text.literal("CherryBlossom 72-hour trial"));this.previous=previous;}
    @Override protected void init(){addDrawableChild(ButtonWidget.builder(Text.literal("Continue to Minecraft"),button->close()).dimensions(width/2-100,height/2+65,200,20).build());}
    @Override public void close(){if(client!=null)client.setScreen(previous);}
    @Override public boolean shouldPause(){return false;}
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){
        context.fill(0,0,width,height,0xF01F1420);
        context.drawCenteredTextWithShadow(textRenderer,"CherryBlossom 72-hour trial",width/2,height/2-65,0xFFFF8FBD);
        if(TrialAccess.allowed()){
            long minutes=(TrialAccess.remainingMillis()+59_999)/60_000;
            context.drawCenteredTextWithShadow(textRenderer,"Time remaining: "+minutes/60+"h "+minutes%60+"m",width/2,height/2-30,0xFFFFFFFF);
            String deadline=DateTimeFormatter.ofPattern("dd MMM uuuu HH:mm 'UTC'").withZone(ZoneOffset.UTC).format(Instant.ofEpochMilli(TrialAccess.expiresAt()));
            context.drawCenteredTextWithShadow(textRenderer,"Expires: "+deadline,width/2,height/2-10,0xFFE6C6D7);
            context.drawCenteredTextWithShadow(textRenderer,"The timer continues while Minecraft is closed.",width/2,height/2+15,0xFFE6C6D7);
        }else{
            context.drawCenteredTextWithShadow(textRenderer,TrialAccess.reason(),width/2,height/2-25,0xFFFFFFFF);
            context.drawCenteredTextWithShadow(textRenderer,"CherryBlossom features are disabled.",width/2,height/2,0xFFE6C6D7);
            context.drawCenteredTextWithShadow(textRenderer,"You can continue playing Minecraft.",width/2,height/2+20,0xFFE6C6D7);
        }
        super.render(context,mouseX,mouseY,delta);
    }
}
