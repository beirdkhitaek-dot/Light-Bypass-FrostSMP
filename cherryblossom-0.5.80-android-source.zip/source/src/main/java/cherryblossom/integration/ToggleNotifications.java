package cherryblossom.integration;

import cherryblossom.module.Module;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

/** Anubis toast timing/stack rules; presentation is rendered by the retained Cherry GUI. */
public final class ToggleNotifications {
    public record Toggle(String name,boolean enabled,long since){}
    private static final Queue<Toggle> PENDING=new ConcurrentLinkedQueue<>();
    private static final LinkedHashMap<String,Toggle> ACTIVE=new LinkedHashMap<>();
    private static boolean installed;
    public static void show(Module module,boolean enabled){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(!TrialAccess.allowed()||mc.world==null||mc.player==null||module.getName().toString().equals("CherryBlossom+")||!cherryblossom.module.modules.client.CherryBlossom.toggleNotifications.getValue())return;
        PENDING.add(new Toggle(module.getName().toString(),enabled,System.nanoTime()));
    }
    public static synchronized List<Toggle> snapshot(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.world==null||!TrialAccess.allowed()||!cherryblossom.module.modules.client.CherryBlossom.toggleNotifications.getValue()){PENDING.clear();ACTIVE.clear();return List.of();}
        for(Toggle toggle;(toggle=PENDING.poll())!=null;){ACTIVE.remove(toggle.name());ACTIVE.put(toggle.name(),toggle);while(ACTIVE.size()>4)ACTIVE.remove(ACTIVE.keySet().iterator().next());}
        long now=System.nanoTime();ACTIVE.values().removeIf(t->now-t.since()>2_340_000_000L);return List.copyOf(ACTIVE.values());
    }
    public static void install(){
        if(installed)return;installed=true;
        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,Identifier.of("cherryblossom","module_toggle_toasts"),(context,counter)->{
            try{Class.forName("dev.cherryblossom.client.render.ToggleToastRenderer").getMethod("render").invoke(null);}
            catch(ReflectiveOperationException e){throw new IllegalStateException("Toggle notification renderer failed",e);}
        });
    }
    private ToggleNotifications(){}
}
