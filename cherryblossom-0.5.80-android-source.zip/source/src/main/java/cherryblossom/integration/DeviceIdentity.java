package cherryblossom.integration;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** A per-Windows-account device key. Only DPAPI-encrypted private key material is persisted. */
public final class DeviceIdentity {
    private final KeyPair pair;
    private DeviceIdentity(KeyPair pair){this.pair=pair;}
    public static DeviceIdentity loadOrCreate(Path file)throws Exception{
        Files.createDirectories(file.getParent());
        try(var channel=java.nio.channels.FileChannel.open(file.resolveSibling("device-key.lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);var lock=channel.lock()){return unlocked(file);}
    }
    private static DeviceIdentity unlocked(Path file)throws Exception{
        if(Files.exists(file)){
            if(Files.size(file)>32768)throw new IOException("Invalid device key file.");
            JsonObject stored=JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            byte[] privateBytes=protect(Base64.getDecoder().decode(stored.get("protected_private_key").getAsString()),false);
            try{
                KeyFactory factory=KeyFactory.getInstance("EC");
                DeviceIdentity identity=new DeviceIdentity(new KeyPair(factory.generatePublic(new X509EncodedKeySpec(Base64.getUrlDecoder().decode(stored.get("public_key").getAsString()))),factory.generatePrivate(new PKCS8EncodedKeySpec(privateBytes))));
                Signature check=Signature.getInstance("SHA256withECDSAinP1363Format");check.initVerify(identity.pair.getPublic());check.update(new byte[]{1});
                if(!check.verify(identity.sign(new byte[]{1})))throw new IOException("Device key mismatch.");return identity;
            }finally{Arrays.fill(privateBytes,(byte)0);}
        }
        KeyPairGenerator generator=KeyPairGenerator.getInstance("EC");generator.initialize(new ECGenParameterSpec("secp256r1"));DeviceIdentity identity=new DeviceIdentity(generator.generateKeyPair());
        byte[] privateBytes=identity.pair.getPrivate().getEncoded(),protectedBytes;
        try{protectedBytes=protect(privateBytes,true);}finally{Arrays.fill(privateBytes,(byte)0);}
        JsonObject stored=new JsonObject();stored.addProperty("version",1);stored.addProperty("public_key",identity.publicKey());stored.addProperty("protected_private_key",Base64.getEncoder().encodeToString(protectedBytes));
        Files.createDirectories(file.getParent());Path temp=Files.createTempFile(file.getParent(),"device-",".tmp");
        try{Files.writeString(temp,stored.toString(),StandardCharsets.UTF_8);try{Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,file);}}finally{Files.deleteIfExists(temp);}
        if(!windows()){File f=file.toFile();f.setReadable(false,false);f.setReadable(true,true);f.setWritable(false,false);f.setWritable(true,true);}
        return identity;
    }
    public String publicKey(){return Base64.getUrlEncoder().withoutPadding().encodeToString(pair.getPublic().getEncoded());}
    public String fingerprint()throws Exception{return Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(publicKey().getBytes(StandardCharsets.UTF_8)));}
    public byte[] sign(byte[] message)throws Exception{Signature signature=Signature.getInstance("SHA256withECDSAinP1363Format");signature.initSign(pair.getPrivate());signature.update(message);return signature.sign();}
    private static boolean windows(){return System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows");}
    private static byte[] protect(byte[] input,boolean encrypt)throws Exception{
        // Android/Linux/macOS have no DPAPI: the key stays in an owner-only file inside the app's private storage.
        if(!windows())return input.clone();
        String method=encrypt?"Protect":"Unprotect";
        String script="$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Security;$inputBytes=[Convert]::FromBase64String([Console]::In.ReadToEnd());$result=[Security.Cryptography.ProtectedData]::"+method+"($inputBytes,[Text.Encoding]::UTF8.GetBytes('CherryBlossom.Device.v1'),[Security.Cryptography.DataProtectionScope]::CurrentUser);[Console]::Out.Write([Convert]::ToBase64String($result))";
        String systemRoot=System.getenv("SystemRoot");if(systemRoot==null)throw new IOException("Windows security service unavailable.");
        Path powershell=Path.of(systemRoot,"System32","WindowsPowerShell","v1.0","powershell.exe");
        Process process=new ProcessBuilder(powershell.toString(),"-NoLogo","-NoProfile","-NonInteractive","-WindowStyle","Hidden","-EncodedCommand",Base64.getEncoder().encodeToString(script.getBytes(StandardCharsets.UTF_16LE))).redirectError(ProcessBuilder.Redirect.DISCARD).start();
        try{
            try(OutputStream stdin=process.getOutputStream()){stdin.write(Base64.getEncoder().encode(input));}
            if(!process.waitFor(15,TimeUnit.SECONDS)){process.destroyForcibly();throw new IOException("Windows key protection timed out.");}
            byte[] output=process.getInputStream().readNBytes(32769);
            if(process.exitValue()!=0||output.length>32768)throw new IOException("Windows could not unlock this device key. Contact staff for a device reset.");
            return Base64.getDecoder().decode(new String(output,StandardCharsets.US_ASCII).trim());
        }finally{if(process.isAlive())process.destroyForcibly();}
    }
}
