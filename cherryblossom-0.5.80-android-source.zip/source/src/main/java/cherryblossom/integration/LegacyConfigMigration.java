package cherryblossom.integration;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;

/** Recognize earlier profiles by schema so no old product identifiers remain in code. */
public final class LegacyConfigMigration {
    private LegacyConfigMigration(){}
    public static JsonObject normalize(JsonObject input){
        JsonObject root=input.deepCopy();
        if(!root.has("CherryBlossom+"))for(String key:new ArrayList<>(root.keySet())){
            JsonElement value=root.get(key);
            if(key.endsWith("+")&&value.isJsonObject()&&value.getAsJsonObject().has("GUI Size")&&value.getAsJsonObject().has("Animations")){
                root.add("CherryBlossom+",value);root.remove(key);break;
            }
        }
        return root;
    }
    private static boolean profile(JsonObject root){return root.has("HUD")&&root.has("Custom Totem")&&root.has("Auto Totem");}
    public static void migrate(Path config){
        for(Path dir:List.of(config,config.resolve("cherryblossom"))){
            if(!Files.isDirectory(dir))continue;
            try(var paths=Files.list(dir)){
                for(Path old:paths.filter(p->p.toString().endsWith(".json")).sorted().toList())try{
                    if(!Files.isRegularFile(old)||Files.size(old)>1_048_576)continue;
                    JsonObject root=JsonParser.parseString(Files.readString(old)).getAsJsonObject();String target;
                    if(profile(root)){target=dir.equals(config)?"cherryblossom.json":"cherryblossom-modules.json";root=normalize(root);}
                    else if(dir.equals(config)&&root.has("version")&&root.has("configs")&&root.get("configs").isJsonArray()){
                        boolean found=false;
                        for(JsonElement entry:root.getAsJsonArray("configs"))if(entry.isJsonObject()&&entry.getAsJsonObject().has("data")&&entry.getAsJsonObject().get("data").isJsonObject()&&profile(entry.getAsJsonObject().getAsJsonObject("data"))){entry.getAsJsonObject().add("data",normalize(entry.getAsJsonObject().getAsJsonObject("data")));found=true;}
                        if(!found)continue;target="cherryblossom-configs.json";
                    }else continue;
                    Path destination=dir.resolve(target);if(Files.exists(destination))continue;
                    Files.writeString(destination,new GsonBuilder().setPrettyPrinting().create().toJson(root),StandardOpenOption.CREATE_NEW);
                }catch(Exception ignored){}
            }catch(Exception ignored){}
        }
    }
}
