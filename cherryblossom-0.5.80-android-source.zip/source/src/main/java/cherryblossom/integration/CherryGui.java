package cherryblossom.integration;

import cherryblossom.module.setting.ItemSetting;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Narrow boundary between the original feature runtime and Cherry's presentation. */
public final class CherryGui {
    private CherryGui() {}
    private static Object controller() throws ReflectiveOperationException {
        return Class.forName("dev.cherryblossom.client.CherryBlossomController").getMethod("get").invoke(null);
    }
    public static void toggle() {
        if(!DeviceAccess.allowed()){net.minecraft.client.MinecraftClient mc=net.minecraft.client.MinecraftClient.getInstance();mc.setScreen(new DeviceNoticeScreen(mc.currentScreen));return;}
        if(!TrialAccess.allowed())return;
        try { Object c = controller(); c.getClass().getMethod("toggle").invoke(c); }
        catch (ReflectiveOperationException e) { throw new IllegalStateException("Cherry GUI unavailable", e); }
    }
    public static boolean capturesInput() {
        try {
            Object c = controller();
            return (boolean)c.getClass().getMethod("capturesKeyboard").invoke(c)
                || (boolean)c.getClass().getMethod("moduleUiOpen").invoke(c);
        } catch (ReflectiveOperationException e) { return false; }
    }
    public static boolean capturesKeyboard() {
        try {Object c=controller();return (boolean)c.getClass().getMethod("capturesKeyboard").invoke(c);}
        catch (ReflectiveOperationException e) {return false;}
    }
    public static boolean screenGuiActive() {
        try {Object c=controller();return (boolean)c.getClass().getMethod("screenClickGuiActive").invoke(c);}
        catch (ReflectiveOperationException e) {return false;}
    }
    public static void saveSettings() {
        try {
            Class<?> store=Class.forName("dev.cherryblossom.client.setting.SettingsStore");
            store.getMethod("markDirty").invoke(null);store.getMethod("saveNow").invoke(null);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Could not save CherryBlossom settings",e);}
    }
    public static String itemId(ItemSetting setting) { return Registries.ITEM.getId(setting.getItem()).toString(); }
    public static void setItem(ItemSetting setting, String id) {
        Identifier parsed = Identifier.tryParse(id);
        if (parsed != null && Registries.ITEM.containsId(parsed)) setting.setItem(Registries.ITEM.get(parsed));
    }
}
