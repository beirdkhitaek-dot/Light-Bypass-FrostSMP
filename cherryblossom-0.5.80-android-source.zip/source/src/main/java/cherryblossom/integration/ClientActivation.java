package cherryblossom.integration;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/** Per-download bootstrap credential. It can bind one entitled account, never mint a lease. */
public final class ClientActivation {
    public static final String RESOURCE="/assets/cherryblossom/activation.json";
    private final String token,edition;
    private ClientActivation(String token,String edition){this.token=token;this.edition=edition;}
    @FunctionalInterface public interface Poster {JsonObject post(String path,JsonObject body)throws Exception;}
    public static ClientActivation load(String edition)throws IOException {
        try(InputStream input=ClientActivation.class.getResourceAsStream(RESOURCE)){return input==null?null:parse(input.readNBytes(4097),edition);}
    }
    public static ClientActivation parse(byte[] bytes,String edition){
        try{
            if(bytes.length>4096)throw new IllegalArgumentException();
            var json=JsonParser.parseString(new String(bytes,StandardCharsets.UTF_8)).getAsJsonObject();
            String token=json.get("token").getAsString(),kind=json.get("edition").getAsString();
            if(json.get("version").getAsInt()!=1||!token.matches("[a-f0-9]{64}")||!kind.equals(edition)||!kind.matches("normal|trial"))throw new IllegalArgumentException();
            return new ClientActivation(token,kind);
        }catch(RuntimeException error){throw new SecurityException("Invalid personal activation credential. Download a fresh personal client.");}
    }
    public void bind(DeviceIdentity identity,Poster transport)throws Exception{
        String key=identity.publicKey(),proof="CherryBlossom/auto-bind/v1\n"+token+"\n"+key+"\n"+edition;
        var body=new JsonObject();body.addProperty("token",token);body.addProperty("edition",edition);body.addProperty("public_key",key);
        body.addProperty("signature",Base64.getUrlEncoder().withoutPadding().encodeToString(identity.sign(proof.getBytes(StandardCharsets.UTF_8))));
        var result=transport.post("/api/client/device/auto",body);
        if(result.get("http_status").getAsInt()==200&&result.has("status")&&result.get("status").getAsString().equals("bound"))return;
        String error=result.has("error")?result.get("error").getAsString():"";
        throw new SecurityException(switch(error){
            case "device_locked"->"Your account is already bound to another computer. Contact staff for a device reset.";
            case "personal_download_required"->"Download a fresh personal client from My downloads to bind this PC automatically.";
            case "access_inactive"->"Your Discord access is inactive or this is the wrong client edition.";
            default->"Automatic device binding was denied. Retry or contact staff.";
        });
    }
}
