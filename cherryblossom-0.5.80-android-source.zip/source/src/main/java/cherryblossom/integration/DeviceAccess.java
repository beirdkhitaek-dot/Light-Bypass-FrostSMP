package cherryblossom.integration;

import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Base64;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** No network or Windows security calls run on Minecraft's render thread. */
public final class DeviceAccess {
    public static final String ORIGIN="https://cherryblossom.nikoo.win";
    private static final String PUBLIC_KEY="MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE7vaUXxheeR0KnxpmU1fmueWNkAp742XkYc_K93j9VKs_rae2R4ZfV3y4RPzH4oPr6KaURHwKd1wOv23g4oT7Ww";
    private static final String EDITION=DeviceAccess.class.getResource("/assets/cherryblossom/trial72h.flag")==null?"normal":"trial";
    private static final ExecutorService WORKER=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"CherryBlossom device access");t.setDaemon(true);return t;});
    private static final HttpClient HTTP=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NEVER).build();
    private static final AtomicBoolean BUSY=new AtomicBoolean();
    private static volatile long deadline,nextWork;
    private static volatile String status="Checking this computer...",userCode="",verificationUrl=ORIGIN+"/account";
    private static ClientActivation activation;
    private static boolean activationLoaded;
    private static DeviceIdentity identity;
    private DeviceAccess(){}
    public static boolean allowed(){return deadline!=0&&deadline-System.nanoTime()>0;}
    public static String status(){return allowed()?"Device verified.":status;}
    public static String userCode(){return userCode;}
    public static String verificationUrl(){return verificationUrl;}
    public static void retry(){nextWork=0;tick();}
    public static void tick(){if(System.nanoTime()<nextWork||!BUSY.compareAndSet(false,true))return;WORKER.execute(()->{try{work();}catch(SecurityException e){deadline=0;status=e.getMessage();nextWork=System.nanoTime()+TimeUnit.SECONDS.toNanos(30);}catch(Exception e){status=identity==null?"Cannot unlock the Windows device key. Contact staff if this persists.":"Cannot reach the license service. Check your connection and retry.";nextWork=System.nanoTime()+TimeUnit.SECONDS.toNanos(15);}finally{BUSY.set(false);}});}
    private static JsonObject post(String route,JsonObject body)throws Exception{
        HttpRequest request=HttpRequest.newBuilder(URI.create(ORIGIN+route)).timeout(Duration.ofSeconds(12)).header("Content-Type","application/json").header("User-Agent","CherryBlossomClient/0.5.80").POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
        HttpResponse<InputStream> response=HTTP.send(request,HttpResponse.BodyHandlers.ofInputStream());byte[] bytes;
        try(InputStream input=response.body()){bytes=input.readNBytes(16385);}if(bytes.length>16384)throw new IOException("License response too large.");
        if(response.statusCode()>=500||response.statusCode()==429)throw new IOException("License service unavailable.");
        JsonObject data=JsonParser.parseString(new String(bytes,StandardCharsets.UTF_8)).getAsJsonObject();data.addProperty("http_status",response.statusCode());return data;
    }
    private static JsonObject fields(String... pairs){JsonObject object=new JsonObject();for(int i=0;i<pairs.length;i+=2)object.addProperty(pairs[i],pairs[i+1]);return object;}
    private static void work()throws Exception{
        nextWork=System.nanoTime()+TimeUnit.SECONDS.toNanos(15);
        if(identity==null)identity=DeviceIdentity.loadOrCreate(Path.of(System.getProperty("user.home"),".cherryblossom","device","device-key-v1.json"));
        if(!activationLoaded){activation=ClientActivation.load(EDITION);activationLoaded=true;}
        JsonObject challenge=post("/api/client/challenge",fields("fingerprint",identity.fingerprint(),"edition",EDITION));
        if(challenge.get("http_status").getAsInt()==403&&challenge.has("error")&&challenge.get("error").getAsString().equals("activation_required")){
            deadline=0;
            if(activation==null)throw new SecurityException("Download your personal client from My downloads to bind this PC automatically.");
            status="Binding this computer automatically...";
            activation.bind(identity,DeviceAccess::post);
            challenge=post("/api/client/challenge",fields("fingerprint",identity.fingerprint(),"edition",EDITION));
        }
        if(challenge.get("http_status").getAsInt()!=200)throw new SecurityException("Device access was denied. Check your Discord access.");
        String id=challenge.get("challenge_id").getAsString(),nonce=challenge.get("nonce").getAsString();
        String proof="CherryBlossom/device/v1\n"+id+"\n"+nonce+"\n"+EDITION;
        JsonObject result=post("/api/client/lease",fields("challenge_id",id,"signature",Base64.getUrlEncoder().withoutPadding().encodeToString(identity.sign(proof.getBytes(StandardCharsets.UTF_8)))));
        if(result.get("http_status").getAsInt()!=200)throw new SecurityException("Device access was denied. Check your account or contact staff.");
        long millis=DeviceLease.verify(result.get("lease").getAsString(),PUBLIC_KEY,ORIGIN,identity.fingerprint(),EDITION,id,result.get("server_time").getAsLong());
        deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(millis);nextWork=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(Math.min(120000,Math.max(1000,millis/2)));status="Device verified.";userCode="";
    }
}
