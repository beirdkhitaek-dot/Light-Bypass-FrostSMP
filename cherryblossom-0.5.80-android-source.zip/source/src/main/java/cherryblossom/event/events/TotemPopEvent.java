package cherryblossom.event.events;

import cherryblossom.event.Event;

public final class TotemPopEvent implements Event {
}
