package cherryblossom.event.events;

import cherryblossom.event.CancellableEvent;

public class ChunkMarkClosedEvent extends CancellableEvent {
}
