package cherryblossom.event.events;

import cherryblossom.event.CancellableEvent;

public class BlockBreakingEvent extends CancellableEvent {
}
