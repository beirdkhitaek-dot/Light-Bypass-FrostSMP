package cherryblossom.event.events;

import cherryblossom.event.CancellableEvent;

public class SendMovementPacketsEvent extends CancellableEvent {
}
