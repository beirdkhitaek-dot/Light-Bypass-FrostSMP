package cherryblossom.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
