package cherryblossom.anubis.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionTypes;
import java.util.Locale;

@Environment(EnvType.CLIENT)
public final class LevelUtil {
   private LevelUtil() {
   }

   public static boolean isOverworld(ClientWorld level) {
      return level.getRegistryKey() == World.OVERWORLD || level.getDimensionEntry().matchesKey(DimensionTypes.OVERWORLD);
   }

   public static boolean isLoaded(ClientWorld level, int chunkX, int chunkZ) {
      return level.getChunkManager().isChunkLoaded(chunkX, chunkZ);
   }

   public static boolean isDonutServer(String address,String brand) {
      String serverBrand=brand==null?"":brand.toLowerCase(Locale.ROOT);
      if(serverBrand.contains("donutfolia")||serverBrand.contains("donutsmp"))return true;
      String host=address==null?"":address.trim().toLowerCase(Locale.ROOT);
      int port=host.lastIndexOf(':');if(port>=0)host=host.substring(0,port);
      while(host.endsWith("."))host=host.substring(0,host.length()-1);
      return host.equals("donutsmp.net")||host.endsWith(".donutsmp.net");
   }
}
