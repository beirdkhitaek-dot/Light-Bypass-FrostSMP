package cherryblossom.anubis.module.impl.client;
/** Original fallback budgets when the optional Anubis Performance module is absent. */
public final class PerformanceModule {
    public static boolean optimizationsEnabled(){return false;}
    public static boolean frustumCulling(){return true;}
    public static long scanBudgetNanos(){return 2_000_000L;}
}
