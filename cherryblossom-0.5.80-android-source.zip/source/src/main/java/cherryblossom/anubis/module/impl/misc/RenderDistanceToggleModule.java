package cherryblossom.anubis.module.impl.misc;

import cherryblossom.module.ext.EventHandler;
import cherryblossom.module.ext.Stage;
import cherryblossom.module.ext.event.TickEvent;
import cherryblossom.module.ext.ClientModule;
import cherryblossom.module.ext.ModuleCategory;
import cherryblossom.module.ext.setting.NumberSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

@Environment(EnvType.CLIENT)
public final class RenderDistanceToggleModule extends ClientModule {
   private static final int RESTORE_AFTER_TICKS = 10;
   private static final int REARM_MARGIN = 2;
   private final NumberSetting lowDistance = this.addSetting("low-distance", new NumberSetting("Low Distance", 2.0F, 2.0F, 32.0F).step(1.0F));
   private final NumberSetting resetY = this.addSetting("reset-y", new NumberSetting("Reset Y", -1.0F, -64.0F, 320.0F).step(1.0F));
   private boolean armed = true;
   private boolean restoring;
   private int timer;
   private int savedDistance = -1;

   public RenderDistanceToggleModule() {
      super("render-distance-toggle", "Auto Render Distance", "Reloads chunks when you go below a Y level.", ModuleCategory.BASE_RAID);
   }

   @Override
   public void onEnable() {
      this.armed = true;
      this.restoring = false;
      this.timer = 0;
      this.savedDistance = -1;
   }

   @Override
   public void onDisable() {
      if (this.restoring) {
         this.restore(MinecraftClient.getInstance());
      }
   }

   @EventHandler(
      stage = Stage.POST
   )
   public void onTick(TickEvent event) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.world != null) {
         int y = mc.player.getBlockY();
         if (!this.restoring && y > this.resetY.getInt() + 2) {
            this.armed = true;
         }

         if (this.armed && y <= this.resetY.getInt()) {
            this.armed = false;
            this.restoring = true;
            this.timer = 0;
            this.savedDistance = (Integer)mc.options.getViewDistance().getValue();
            apply(mc, this.lowDistance.getInt());
         } else if (this.restoring && ++this.timer >= 10) {
            this.restore(mc);
         }
      } else {
         if (this.restoring) {
            this.restore(mc);
         }
      }
   }

   private void restore(MinecraftClient mc) {
      if (this.savedDistance >= 0) {
         apply(mc, this.savedDistance);
      }

      this.restoring = false;
   }

   private static void apply(MinecraftClient mc, int chunks) {
      mc.options.getViewDistance().setValue(chunks);
      mc.options.sendClientSettings();
   }
}
