package cherryblossom.anubis.module.impl.render;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongLinkedOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongListIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2LongMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.LongPredicate;
import cherryblossom.module.ext.EventHandler;
import cherryblossom.module.ext.Stage;
import cherryblossom.module.ext.event.BlockUpdateEvent;
import cherryblossom.module.ext.event.PacketReceiveNettyEvent;
import cherryblossom.module.ext.event.Render3DEvent;
import cherryblossom.module.ext.event.TickEvent;
import cherryblossom.anubis.gui.ChallengeToast;
import cherryblossom.module.ext.ClientModule;
import cherryblossom.module.ext.ModuleCategory;
import cherryblossom.module.ext.setting.BooleanSetting;
import cherryblossom.module.ext.setting.ColorSetting;
import cherryblossom.anubis.util.ChunkAreas;
import cherryblossom.anubis.util.ChunkOverlay;
import cherryblossom.anubis.util.LevelUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.AbstractRedstoneGateBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CaveVines;
import net.minecraft.block.CrafterBlock;
import net.minecraft.block.DaylightDetectorBlock;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.ObserverBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.PistonExtensionBlock;
import net.minecraft.block.PistonHeadBlock;
import net.minecraft.block.RedstoneBlock;
import net.minecraft.block.RedstoneLampBlock;
import net.minecraft.block.RedstoneTorchBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.TargetBlock;
import net.minecraft.block.TripwireHookBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.LightData;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkNibbleArray;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.light.ChunkLightingView;

@Environment(EnvType.CLIENT)
public final class PrimeChunkFinderModule extends ClientModule {
   private static final int SECTION_BYTES = 2048;
   private static final int MAX_FLAGGED_CHUNKS = 256;
   private static final int AMETHYST_MAX_LIGHT = 5;
   private static final int AMETHYST_REACH = 5;
   private static final int ACTIVE_CHANGES = 5;
   private static final int NOTIFY_AREA = 3;
   private static final int ORE_LIGHT = 9;
   private static final long[] NO_ORES = new long[0];
   private static final int LAMP_LIGHT = 14;
   private static final int[] NO_LAMPS = new int[0];
   private static final long GONE_LAMP_MS = 5000L;
   private static final int MAX_TRACKED_CHUNKS = 5000;
   private static final int SNAPSHOT_RADIUS = 32;
   private static final byte[] ZERO_SECTION = new byte[2048];
   private static final int MAX_Y = 0;
   private final BooleanSetting skyLight = this.addSetting("sky-light", new BooleanSetting("Sky Light", true));
   private final ColorSetting chunkColor = this.addSetting("chunk-color", new ColorSetting("Chunk Color", 1342242650));
   private final BooleanSetting tracers = this.addSetting("tracers", new BooleanSetting("Tracers", true));
   private final BooleanSetting sound = this.addSetting("sound", new BooleanSetting("Sound", true));
   private final LinkedHashMap<Long, Map<Integer, byte[]>> chunkLight = new LinkedHashMap<>(256, 0.75F, true);
   private final LinkedHashMap<Long, Map<Integer, byte[]>> chunkSky = new LinkedHashMap<>(256, 0.75F, true);
   private final LongOpenHashSet passedChunks = new LongOpenHashSet();
   private final LongLinkedOpenHashSet flaggedChunks = new LongLinkedOpenHashSet();
   private final LongOpenHashSet shownChunks = new LongOpenHashSet();
   private final ChunkAreas chunkAreas = new ChunkAreas();
   private final ChunkOverlay chunkOverlay = new ChunkOverlay();
   private final LongOpenHashSet checkedSections = new LongOpenHashSet();
   private final LongOpenHashSet amethystSections = new LongOpenHashSet();
   private final Long2ObjectOpenHashMap<long[]> oreSections = new Long2ObjectOpenHashMap();
   private final Long2ObjectOpenHashMap<int[]> lampSections = new Long2ObjectOpenHashMap();
   private final Long2LongOpenHashMap goneLamps = new Long2LongOpenHashMap();
   private final Mutable cursor = new Mutable();
   private final Long2IntOpenHashMap changes = new Long2IntOpenHashMap();
   private ClientWorld lastLevel;

   public PrimeChunkFinderModule() {
      super("prime-chunk-finder", "Chunk Finder", "Flags chunks with light and redstone changes below Y 0.", ModuleCategory.BASE_RAID);
      BooleanSetting notifications = this.usesNotifications();
      this.sound.visibleWhen(notifications::get);
      this.skyLight.onChange(this::skyLightChanged);
   }

   @Override
   public boolean persistEnabled() {
      return false;
   }

   @Override
   public void onEnable() {
      this.reset();
      this.lastLevel = MinecraftClient.getInstance().world;
      this.snapshotLoadedChunks(true);
      this.on(PacketReceiveNettyEvent.TYPE, this::onPacket);
   }

   @Override
   public void onDisable() {
      this.reset();
      this.lastLevel = null;
   }

   private void onPacket(PacketReceiveNettyEvent event) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (event.packet instanceof GameJoinS2CPacket) {
         mc.execute(() -> {
            if (this.isEnabled()) {
               this.reset();
            }
         });
      } else if (event.packet instanceof ChunkDataS2CPacket packet) {
         int chunkX = packet.getChunkX();
         int chunkZ = packet.getChunkZ();
         LightData data = packet.getLightData();
         mc.execute(() -> {
            if (this.isEnabled() && mc.world != null) {
               this.baselineChunk(chunkX, chunkZ, data);
            }
         });
      } else if (event.packet instanceof LightUpdateS2CPacket packet) {
         int chunkX = packet.getChunkX();
         int chunkZ = packet.getChunkZ();
         LightData data = packet.getData();
         mc.execute(() -> {
            if (this.isEnabled() && mc.world != null) {
               this.detectChanges(chunkX, chunkZ, data);
            }
         });
      }
   }

   @EventHandler
   public void onBlockUpdate(BlockUpdateEvent event) {
      if (event.oldState != event.newState && MinecraftClient.getInstance().world != null) {
         this.rememberGoneLamp(event.pos, event.oldState, event.newState);
         this.detectRedstone(event.pos, event.oldState, event.newState);
      }
   }

   @EventHandler(
      stage = Stage.POST
   )
   public void onTick(TickEvent event) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if(mc.world!=this.lastLevel){
         this.reset();this.lastLevel=mc.world;
         if(mc.world!=null)this.snapshotLoadedChunks(true);
      }
      if (mc.world == null) {
         this.reset();
      } else {
         if (mc.player != null && mc.player.getY() < 0.0) {
            this.passedChunks.add(mc.player.getChunkPos().toLong());
         }

         this.forgetOldLamps();
         this.refreshShown(mc.world);
      }
   }

   private void refreshShown(ClientWorld level) {
      this.shownChunks.clear();
      LongListIterator var2 = this.flaggedChunks.iterator();

      while (var2.hasNext()) {
         long key = (Long)var2.next();
         if (LevelUtil.isLoaded(level, ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key))) {
            this.shownChunks.add(key);
         }
      }
   }

   @EventHandler
   public void onRender3D(Render3DEvent event) {
      if (!this.shownChunks.isEmpty() && MinecraftClient.getInstance().world != null) {
         int fill = this.chunkColor.argb();
         this.chunkOverlay.draw(this.shownChunks, fill, event.partialTick);
         if (this.tracers.get()) {
            this.chunkAreas.drawTracers(this.shownChunks, 63.0, ColorHelper.fullAlpha(fill));
         }
      }
   }

   private void flagChunk(long key) {
      this.flaggedChunks.addAndMoveToLast(key);
      this.shownChunks.add(key);

      while (this.flaggedChunks.size() > 256) {
         this.flaggedChunks.removeFirstLong();
      }
   }

   private void skyLightChanged() {
      this.chunkSky.clear();
      if (this.isEnabled() && this.skyLight.get()) {
         this.snapshotLoadedChunks(false);
      }
   }

   private void snapshotLoadedChunks(boolean block) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null && mc.player != null) {
         int centerX = mc.player.getBlockX() >> 4;
         int centerZ = mc.player.getBlockZ() >> 4;

         for (int chunkX = centerX - 32; chunkX <= centerX + 32; chunkX++) {
            for (int chunkZ = centerZ - 32; chunkZ <= centerZ + 32; chunkZ++) {
               long key = ChunkPos.toLong(chunkX, chunkZ);
               Map<Integer, byte[]> sections = block ? this.snapshotChunk(LightType.BLOCK, chunkX, chunkZ) : null;
               if (sections != null) {
                  this.chunkLight.put(key, sections);
               }

               Map<Integer, byte[]> sky = this.skyLight.get() ? this.snapshotChunk(LightType.SKY, chunkX, chunkZ) : null;
               if (sky != null) {
                  this.chunkSky.put(key, sky);
               }
            }
         }

         this.trimChunkCache();
      }
   }

   private Map<Integer, byte[]> snapshotChunk(LightType layer, int chunkX, int chunkZ) {
      ClientWorld level = MinecraftClient.getInstance().world;
      if (level == null) {
         return null;
      } else {
         ClientChunkManager chunkSource = level.getChunkManager();
         if (!chunkSource.isChunkLoaded(chunkX, chunkZ)) {
            return null;
         } else {
            ChunkLightingView light = chunkSource.getLightingProvider().get(layer);
            Map<Integer, byte[]> sections = (Map<Integer, byte[]>)(layer == LightType.SKY ? new HashMap<>() : this.createZeroedChunk());

            for (int sectionY = this.bottomSection(); sectionY <= this.topSection(); sectionY++) {
               ChunkNibbleArray data = light.getLightSection(ChunkSectionPos.from(chunkX, sectionY, chunkZ));
               if (data != null) {
                  sections.put(sectionY, data.isUninitialized(0) ? ZERO_SECTION : Arrays.copyOf(data.asByteArray(), 2048));
               }
            }

            return sections;
         }
      }
   }

   private void baselineChunk(int chunkX, int chunkZ, LightData data) {
      long key = ChunkPos.toLong(chunkX, chunkZ);
      Map<Integer, byte[]> sections = this.createZeroedChunk();
      this.applySections(LightType.BLOCK, data, sections, chunkX, chunkZ, false, null);
      this.chunkLight.put(key, sections);
      if (this.skyLight.get()) {
         Map<Integer, byte[]> sky = new HashMap<>();
         this.applySections(LightType.SKY, data, sky, chunkX, chunkZ, false, null);
         this.chunkSky.put(key, sky);
      }

      this.trimChunkCache();
   }

   private void detectChanges(int chunkX, int chunkZ, LightData data) {
      long key = ChunkPos.toLong(chunkX, chunkZ);
      this.checkedSections.clear();
      this.amethystSections.clear();
      this.oreSections.clear();
      this.lampSections.clear();
      Map<Integer, byte[]> sections = this.chunkLight.get(key);
      if (sections == null) {
         sections = this.snapshotChunk(LightType.BLOCK, chunkX, chunkZ);
      }

      boolean compare = sections != null && !this.isOwnChunk(key);
      if (sections == null) {
         sections = this.createZeroedChunk();
      }

      PrimeChunkFinderModule.ChangeSummary summary = new PrimeChunkFinderModule.ChangeSummary(false);
      this.applySections(LightType.BLOCK, data, sections, chunkX, chunkZ, compare, summary);
      this.chunkLight.put(key, sections);
      PrimeChunkFinderModule.ChangeSummary sky = this.skyLight.get() ? this.skyChanges(key, chunkX, chunkZ, data) : null;
      this.trimChunkCache();
      if (summary.count == 0 && sky != null) {
         summary = sky;
      }

      if (summary.count != 0) {
         this.activity(key, Items.EMERALD_BLOCK, summary.sky ? "Sky " : "", summary.x, summary.y, summary.z);
      }
   }

   private PrimeChunkFinderModule.ChangeSummary skyChanges(long key, int chunkX, int chunkZ, LightData data) {
      Map<Integer, byte[]> sections = this.chunkSky.get(key);
      if (sections == null) {
         sections = this.snapshotChunk(LightType.SKY, chunkX, chunkZ);
      }

      boolean compare = sections != null && !this.nearOwnChunk(key);
      if (sections == null) {
         sections = new HashMap<>();
      }

      PrimeChunkFinderModule.ChangeSummary summary = new PrimeChunkFinderModule.ChangeSummary(true);
      this.applySections(LightType.SKY, data, sections, chunkX, chunkZ, compare, summary);
      this.chunkSky.put(key, sections);
      return summary;
   }

   private void rememberGoneLamp(BlockPos pos, BlockState previous, BlockState state) {
      if (isLamp(previous)) {
         int light = previous.getLuminance();
         if (!isLamp(state) || state.getLuminance() < light) {
            this.goneLamps.put(pos.asLong(), Util.getMeasuringTimeMs() + 5000L << 4 | light);
         }
      }
   }

   private void forgetOldLamps() {
      if (!this.goneLamps.isEmpty()) {
         long now = Util.getMeasuringTimeMs();
         LongIterator it = this.goneLamps.values().iterator();

         while (it.hasNext()) {
            if (it.nextLong() >>> 4 < now) {
               it.remove();
            }
         }
      }
   }

   private void detectRedstone(BlockPos pos, BlockState previous, BlockState state) {
      if (pos.getY() < 0 && (isRedstone(state) || isRedstone(previous))) {
         long key = ChunkPos.toLong(pos.getX() >> 4, pos.getZ() >> 4);
         if (!this.isOwnChunk(key)) {
            this.activity(key, Items.EMERALD_BLOCK, "", pos.getX(), pos.getY(), pos.getZ());
         }
      }
   }

   private void activity(long key, Item icon, String label, int x, int y, int z) {
      boolean fresh = !nearby(key, this.flaggedChunks::contains);
      this.flagChunk(key);
      int count = this.changes.addTo(key, 1) + 1;
      if (this.notificationsOn()) {
         String at = label + x + ", " + y + ", " + z;
         if (fresh) {
            ChallengeToast.addOrUpdate(new ItemStack(icon), this.name(), Text.literal(at), this.sound.get());
         } else if (count == 5 && !nearby(key, other -> other != key && this.changes.get(other) >= 5)) {
            ChallengeToast.addOrUpdate(new ItemStack(icon), this.name(), Text.literal("Active " + at), this.sound.get());
         }
      }
   }

   private static boolean nearby(long key, LongPredicate test) {
      int chunkX = ChunkPos.getPackedX(key);
      int chunkZ = ChunkPos.getPackedZ(key);

      for (int dx = -3; dx <= 3; dx++) {
         for (int dz = -3; dz <= 3; dz++) {
            if (test.test(ChunkPos.toLong(chunkX + dx, chunkZ + dz))) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean isRedstone(BlockState state) {
      Block block = state.getBlock();
      return block instanceof RedstoneWireBlock
         || block instanceof AbstractRedstoneGateBlock
         || block instanceof RedstoneTorchBlock
         || block instanceof RedstoneLampBlock
         || block instanceof ObserverBlock
         || block instanceof PistonBlock
         || block instanceof PistonHeadBlock
         || block instanceof PistonExtensionBlock
         || block instanceof DispenserBlock
         || block instanceof HopperBlock
         || block instanceof NoteBlock
         || block instanceof DaylightDetectorBlock
         || block instanceof LeverBlock
         || block instanceof ButtonBlock
         || block instanceof AbstractPressurePlateBlock
         || block instanceof TripwireHookBlock
         || block instanceof TargetBlock
         || block instanceof CrafterBlock
         || block instanceof RedstoneBlock;
   }

   private boolean isOwnChunk(long key) {
      if (this.passedChunks.contains(key)) {
         return true;
      } else {
         MinecraftClient mc = MinecraftClient.getInstance();
         return mc.player != null && mc.player.getChunkPos().toLong() == key;
      }
   }

   private boolean nearOwnChunk(long key) {
      int chunkX = ChunkPos.getPackedX(key);
      int chunkZ = ChunkPos.getPackedZ(key);

      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            if (this.isOwnChunk(ChunkPos.toLong(chunkX + dx, chunkZ + dz))) {
               return true;
            }
         }
      }

      return false;
   }

   private void applySections(
      LightType layer, LightData data, Map<Integer, byte[]> sections, int chunkX, int chunkZ, boolean compare, PrimeChunkFinderModule.ChangeSummary summary
   ) {
      boolean sky = layer == LightType.SKY;
      BitSet mask = sky ? data.getInitedSky() : data.getInitedBlock();
      List<byte[]> updates = sky ? data.getSkyNibbles() : data.getBlockNibbles();
      int next = 0;

      for (int bit = mask.nextSetBit(0); bit >= 0 && next < updates.size(); bit = mask.nextSetBit(bit + 1)) {
         byte[] update = updates.get(next++);
         int sectionY = this.lightSectionY(bit);
         if (this.isTrackedSection(sectionY) && update.length == 2048) {
            this.updateSection(sections, chunkX, chunkZ, sectionY, Arrays.copyOf(update, 2048), compare, summary);
         }
      }

      BitSet empty = sky ? data.getUninitedSky() : data.getUninitedBlock();

      for (int bitx = empty.nextSetBit(0); bitx >= 0; bitx = empty.nextSetBit(bitx + 1)) {
         int sectionY = this.lightSectionY(bitx);
         if (this.isTrackedSection(sectionY)) {
            this.updateSection(sections, chunkX, chunkZ, sectionY, ZERO_SECTION, compare, summary);
         }
      }
   }

   private void updateSection(
      Map<Integer, byte[]> sections, int chunkX, int chunkZ, int sectionY, byte[] light, boolean compare, PrimeChunkFinderModule.ChangeSummary summary
   ) {
      byte[] previous = sections.get(sectionY);
      if (compare && previous != null && summary != null && !isDark(previous) && !isDark(light)) {
         this.compareSection(previous, light, chunkX, chunkZ, sectionY, summary);
      }

      sections.put(sectionY, light);
   }

   private static boolean isDark(byte[] light) {
      if (light == ZERO_SECTION) {
         return true;
      } else {
         for (byte value : light) {
            if (value != 0) {
               return false;
            }
         }

         return true;
      }
   }

   private void compareSection(byte[] previous, byte[] light, int chunkX, int chunkZ, int sectionY, PrimeChunkFinderModule.ChangeSummary summary) {
      for (int i = 0; i < 2048; i++) {
         int was = previous[i] & 255;
         int now = light[i] & 255;
         int changed = was ^ now;
         if ((changed & 15) != 0) {
            this.recordChange(chunkX, chunkZ, sectionY, i << 1, was & 15, now & 15, summary);
         }

         if ((changed & 240) != 0) {
            this.recordChange(chunkX, chunkZ, sectionY, (i << 1) + 1, was >>> 4 & 15, now >>> 4 & 15, summary);
         }
      }
   }

   private void recordChange(int chunkX, int chunkZ, int sectionY, int index, int oldValue, int newValue, PrimeChunkFinderModule.ChangeSummary summary) {
      int x = (chunkX << 4) + (index & 15);
      int y = (sectionY << 4) + (index >>> 8 & 15);
      int z = (chunkZ << 4) + (index >>> 4 & 15);
      if (y < 0) {
         int value = Math.max(oldValue, newValue);
         if (summary.sky || !this.fromAmethyst(x, y, z, oldValue, newValue) && !this.fromRedstoneOre(x, y, z, value) && !this.fromLamp(x, y, z, value)) {
            summary.add(x, y, z, oldValue, newValue);
         }
      }
   }

   private boolean fromLamp(int x, int y, int z, int value) {
      if (value > 14) {
         return false;
      } else {
         ClientWorld level = MinecraftClient.getInstance().world;
         if (level == null) {
            return false;
         } else {
            int reach = 14 - value;

            for (int sx = x - reach >> 4; sx <= x + reach >> 4; sx++) {
               for (int sy = y - reach >> 4; sy <= y + reach >> 4; sy++) {
                  for (int sz = z - reach >> 4; sz <= z + reach >> 4; sz++) {
                     for (int lamp : this.lamps(level, sx, sy, sz)) {
                        int index = lamp >>> 4;
                        int lx = (sx << 4) + (index & 15);
                        int ly = (sy << 4) + (index >>> 8);
                        int lz = (sz << 4) + (index >>> 4 & 15);
                        if (Math.abs(lx - x) + Math.abs(ly - y) + Math.abs(lz - z) <= (lamp & 15) - value) {
                           return true;
                        }
                     }
                  }
               }
            }

            long now = Util.getMeasuringTimeMs();
            ObjectIterator var19 = this.goneLamps.long2LongEntrySet().iterator();

            while (var19.hasNext()) {
               Entry gone = (Entry)var19.next();
               long packed = gone.getLongValue();
               if (packed >>> 4 >= now) {
                  long pos = gone.getLongKey();
                  int distance = Math.abs(BlockPos.unpackLongX(pos) - x) + Math.abs(BlockPos.unpackLongY(pos) - y) + Math.abs(BlockPos.unpackLongZ(pos) - z);
                  if (distance <= (int)(packed & 15L) - value) {
                     return true;
                  }
               }
            }

            return false;
         }
      }
   }

   private int[] lamps(ClientWorld level, int sectionX, int sectionY, int sectionZ) {
      long key = ChunkSectionPos.asLong(sectionX, sectionY, sectionZ);
      int[] cached = (int[])this.lampSections.get(key);
      if (cached != null) {
         return cached;
      } else {
         int[] found = scanLamps(level, sectionX, sectionY, sectionZ);
         this.lampSections.put(key, found);
         return found;
      }
   }

   private static int[] scanLamps(ClientWorld level, int sectionX, int sectionY, int sectionZ) {
      if (sectionY >= level.getBottomSectionCoord() && sectionY <= level.getTopSectionCoord()) {
         WorldChunk chunk = level.getChunkManager().getChunk(sectionX, sectionZ, ChunkStatus.FULL, false);
         if (chunk == null) {
            return NO_LAMPS;
         } else {
            ChunkSection section = chunk.getSection(chunk.sectionCoordToIndex(sectionY));
            if (!section.isEmpty() && section.getBlockStateContainer().hasAny(PrimeChunkFinderModule::isLamp)) {
               IntArrayList lamps = new IntArrayList();

               for (int index = 0; index < 4096; index++) {
                  BlockState state = section.getBlockState(index & 15, index >>> 8, index >>> 4 & 15);
                  if (isLamp(state)) {
                     lamps.add(index << 4 | state.getLuminance());
                  }
               }

               return lamps.isEmpty() ? NO_LAMPS : lamps.toIntArray();
            } else {
               return NO_LAMPS;
            }
         }
      } else {
         return NO_LAMPS;
      }
   }

   private static boolean isLamp(BlockState state) {
      return state.isOf(Blocks.TORCH)
         || state.isOf(Blocks.WALL_TORCH)
         || state.isOf(Blocks.SOUL_TORCH)
         || state.isOf(Blocks.SOUL_WALL_TORCH)
         || state.isOf(Blocks.COPPER_TORCH)
         || state.isOf(Blocks.COPPER_WALL_TORCH)
         || CaveVines.hasBerries(state);
   }

   private boolean fromAmethyst(int x, int y, int z, int oldValue, int newValue) {
      if (Math.max(oldValue, newValue) > 5) {
         return false;
      } else {
         ClientWorld level = MinecraftClient.getInstance().world;
         if (level != null && this.amethystSectionNear(level, x, y, z)) {
            for (int dx = -5; dx <= 5; dx++) {
               int restX = 5 - Math.abs(dx);

               for (int dy = -restX; dy <= restX; dy++) {
                  int restY = restX - Math.abs(dy);

                  for (int dz = -restY; dz <= restY; dz++) {
                     if (isAmethyst(level.getBlockState(this.cursor.set(x + dx, y + dy, z + dz)))) {
                        return true;
                     }
                  }
               }
            }

            return false;
         } else {
            return false;
         }
      }
   }

   private boolean amethystSectionNear(ClientWorld level, int x, int y, int z) {
      for (int sx = x - 5 >> 4; sx <= x + 5 >> 4; sx++) {
         for (int sy = y - 5 >> 4; sy <= y + 5 >> 4; sy++) {
            for (int sz = z - 5 >> 4; sz <= z + 5 >> 4; sz++) {
               long key = ChunkSectionPos.asLong(sx, sy, sz);
               if (this.checkedSections.add(key) && sectionHasAmethyst(level, sx, sy, sz)) {
                  this.amethystSections.add(key);
               }

               if (this.amethystSections.contains(key)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static boolean sectionHasAmethyst(ClientWorld level, int sectionX, int sectionY, int sectionZ) {
      if (sectionY >= level.getBottomSectionCoord() && sectionY <= level.getTopSectionCoord()) {
         WorldChunk chunk = level.getChunkManager().getChunk(sectionX, sectionZ, ChunkStatus.FULL, false);
         if (chunk == null) {
            return false;
         } else {
            ChunkSection section = chunk.getSection(chunk.sectionCoordToIndex(sectionY));
            return !section.isEmpty() && section.getBlockStateContainer().hasAny(PrimeChunkFinderModule::isAmethyst);
         }
      } else {
         return false;
      }
   }

   private boolean fromRedstoneOre(int x, int y, int z, int value) {
      if (value > 9) {
         return false;
      } else {
         ClientWorld level = MinecraftClient.getInstance().world;
         if (level == null) {
            return false;
         } else {
            int reach = 9 - value;

            for (int sx = x - reach >> 4; sx <= x + reach >> 4; sx++) {
               for (int sy = y - reach >> 4; sy <= y + reach >> 4; sy++) {
                  for (int sz = z - reach >> 4; sz <= z + reach >> 4; sz++) {
                     for (long ore : this.exposedOres(level, sx, sy, sz)) {
                        int distance = Math.abs(BlockPos.unpackLongX(ore) - x)
                           + Math.abs(BlockPos.unpackLongY(ore) - y)
                           + Math.abs(BlockPos.unpackLongZ(ore) - z);
                        if (distance <= reach) {
                           return true;
                        }
                     }
                  }
               }
            }

            return false;
         }
      }
   }

   private long[] exposedOres(ClientWorld level, int sectionX, int sectionY, int sectionZ) {
      long key = ChunkSectionPos.asLong(sectionX, sectionY, sectionZ);
      long[] cached = (long[])this.oreSections.get(key);
      if (cached != null) {
         return cached;
      } else {
         long[] found = this.scanExposedOres(level, sectionX, sectionY, sectionZ);
         this.oreSections.put(key, found);
         return found;
      }
   }

   private long[] scanExposedOres(ClientWorld level, int sectionX, int sectionY, int sectionZ) {
      if (sectionY >= level.getBottomSectionCoord() && sectionY <= level.getTopSectionCoord()) {
         WorldChunk chunk = level.getChunkManager().getChunk(sectionX, sectionZ, ChunkStatus.FULL, false);
         if (chunk == null) {
            return NO_ORES;
         } else {
            ChunkSection section = chunk.getSection(chunk.sectionCoordToIndex(sectionY));
            if (!section.isEmpty() && section.getBlockStateContainer().hasAny(PrimeChunkFinderModule::isRedstoneOre)) {
               LongArrayList ores = new LongArrayList();

               for (int ly = 0; ly < 16; ly++) {
                  for (int lz = 0; lz < 16; lz++) {
                     for (int lx = 0; lx < 16; lx++) {
                        if (isRedstoneOre(section.getBlockState(lx, ly, lz))) {
                           int wx = (sectionX << 4) + lx;
                           int wy = (sectionY << 4) + ly;
                           int wz = (sectionZ << 4) + lz;
                           if (this.exposed(level, wx, wy, wz)) {
                              ores.add(BlockPos.asLong(wx, wy, wz));
                           }
                        }
                     }
                  }
               }

               return ores.isEmpty() ? NO_ORES : ores.toLongArray();
            } else {
               return NO_ORES;
            }
         }
      } else {
         return NO_ORES;
      }
   }

   private boolean exposed(ClientWorld level, int x, int y, int z) {
      for (Direction direction : Direction.values()) {
         BlockState neighbour = level.getBlockState(this.cursor.set(x + direction.getOffsetX(), y + direction.getOffsetY(), z + direction.getOffsetZ()));
         if (neighbour.isAir() || !neighbour.isOpaque()) {
            return true;
         }
      }

      return false;
   }

   private static boolean isRedstoneOre(BlockState state) {
      return state.isOf(Blocks.REDSTONE_ORE) || state.isOf(Blocks.DEEPSLATE_REDSTONE_ORE);
   }

   private static boolean isAmethyst(BlockState state) {
      return state.isOf(Blocks.AMETHYST_CLUSTER)
         || state.isOf(Blocks.LARGE_AMETHYST_BUD)
         || state.isOf(Blocks.MEDIUM_AMETHYST_BUD)
         || state.isOf(Blocks.SMALL_AMETHYST_BUD)
         || state.isOf(Blocks.BUDDING_AMETHYST)
         || state.isOf(Blocks.AMETHYST_BLOCK);
   }

   private Map<Integer, byte[]> createZeroedChunk() {
      Map<Integer, byte[]> sections = new HashMap<>();

      for (int sectionY = this.bottomSection(); sectionY <= this.topSection(); sectionY++) {
         sections.put(sectionY, ZERO_SECTION);
      }

      return sections;
   }

   private int lightSectionY(int index) {
      ClientWorld level = MinecraftClient.getInstance().world;
      return level == null ? Integer.MIN_VALUE : level.getChunkManager().getLightingProvider().getBottomY() + index;
   }

   private int bottomSection() {
      return MinecraftClient.getInstance().world.getBottomSectionCoord();
   }

   private int topSection() {
      return Math.min(MinecraftClient.getInstance().world.getTopSectionCoord(), ChunkSectionPos.getSectionCoord(-1));
   }

   private boolean isTrackedSection(int sectionY) {
      return sectionY >= this.bottomSection() && sectionY <= this.topSection();
   }

   private void trimChunkCache() {
      trimCache(this.chunkLight);
      trimCache(this.chunkSky);
   }

   private static void trimCache(LinkedHashMap<Long, Map<Integer, byte[]>> cache) {
      while (cache.size() > 5000) {
         Iterator<Long> keys = cache.keySet().iterator();
         keys.next();
         keys.remove();
      }
   }

   private void reset() {
      this.chunkLight.clear();
      this.chunkSky.clear();
      this.passedChunks.clear();
      this.flaggedChunks.clear();
      this.shownChunks.clear();
      this.changes.clear();
      this.lampSections.clear();
      this.goneLamps.clear();
   }

   @Environment(EnvType.CLIENT)
   private static final class ChangeSummary {
      final boolean sky;
      int count;
      int x;
      int y;
      int z;
      int oldValue;
      int newValue;

      ChangeSummary(boolean sky) {
         this.sky = sky;
      }

      void add(int x, int y, int z, int oldValue, int newValue) {
         if (this.count == 0 || Math.abs(newValue - oldValue) > Math.abs(this.newValue - this.oldValue)) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.oldValue = oldValue;
            this.newValue = newValue;
         }

         this.count++;
      }
   }
}
