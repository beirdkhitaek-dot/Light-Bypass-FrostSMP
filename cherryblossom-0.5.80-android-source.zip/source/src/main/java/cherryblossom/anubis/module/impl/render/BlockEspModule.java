package cherryblossom.anubis.module.impl.render;

import java.util.Set;
import java.util.function.LongPredicate;
import cherryblossom.anubis.esp.BlockLayer;
import cherryblossom.anubis.esp.ChunkScanner;
import cherryblossom.anubis.esp.EspStyle;
import cherryblossom.module.ext.EventHandler;
import cherryblossom.module.ext.event.Render3DEvent;
import cherryblossom.module.ext.ClientModule;
import cherryblossom.module.ext.ModuleCategory;
import cherryblossom.anubis.setting.BlockColorListSetting;
import cherryblossom.module.ext.setting.BooleanSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;

@Environment(EnvType.CLIENT)
public final class BlockEspModule extends ClientModule implements ChunkScanner.Consumer {
   private final EspStyle style = new EspStyle(new EspStyle.Registrar(){public <S extends cherryblossom.module.ext.setting.Setting>S add(String id,S setting){return addSetting(id,setting);}}, "Outline", 0.2F, 2048.0F);
   private final BooleanSetting sTracers = this.addSetting("tracers", new BooleanSetting("Tracers", false));
   private final BlockColorListSetting sBlockColors = this.addSetting(BlockColorListSetting.createDefault());
   private final BlockLayer layer = new BlockLayer(new BlockLayer.Palette() {
      @Override
      public int color(Object kind) {
         return BlockEspModule.this.sBlockColors.colorArgb((Block)kind);
      }

      @Override
      public int tracerColor(Object kind) {
         return BlockEspModule.this.sBlockColors.tracerColorArgb((Block)kind);
      }
   }, () -> MinecraftClient.getInstance().world == null ? null : MinecraftClient.getInstance().world.getRegistryKey());
   private Set<String> scannedIds = Set.of();

   public BlockEspModule() {
      super("block-esp", "Block ESP", "Highlights chosen blocks; touching blocks merge into one shape.", ModuleCategory.RENDER);
      this.sBlockColors.onChange(this::rescan);
   }

   private void rescan() {
      if (this.isEnabled()) {
         Set<String> ids = this.sBlockColors.enabledIds();
         if (!ids.equals(this.scannedIds)) {
            boolean removed = !ids.containsAll(this.scannedIds);
            this.scannedIds = ids;
            if (removed) {
               this.layer.clear();
            }

            ChunkScanner.rescan();
         }
      }
   }

   @Override
   public void onEnable() {
      this.scannedIds = this.sBlockColors.enabledIds();
      ChunkScanner.register(this);
   }

   @Override
   public void onDisable() {
      ChunkScanner.unregister(this);
      this.layer.clear();
   }

   @Override
   public boolean wants(BlockState state) {
      return this.sBlockColors.isEnabled(state.getBlock());
   }

   @Override
   public void found(long pos, BlockState state) {
      this.layer.put(pos, state.getBlock());
   }

   @Override
   public void removed(long pos) {
      this.layer.remove(pos);
   }

   @Override
   public void reset() {
      this.layer.clear();
   }

   @Override
   public void chunkScanned(long chunkKey, LongPredicate stillThere) {
      this.layer.retainChunk(chunkKey, stillThere);
   }

   @EventHandler
   public void onRender3D(Render3DEvent event) {
      this.layer.render(event, this.style);
      if (this.sTracers.get() && this.sBlockColors.hasAnyTracerEnabled()) {
         this.layer.renderTracers(this.style);
      }
   }
}
