package cherryblossom.anubis.setting;
/** Tiny value adapter; the Cherry GUI owns presentation rather than ImGui. */
public final class ImBoolean {
    private boolean value;
    public ImBoolean(boolean value){this.value=value;}
    public boolean get(){return value;}
    public void set(boolean value){this.value=value;}
}
