package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.knife.KnifeRenderer;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.*;
import java.util.List;
import org.lwjgl.glfw.GLFW;

/** Kuro knife visuals integrated with CherryBlossom settings and input capture. */
public final class KnifeModule extends Module {
    private static KnifeModule instance;
    private final ChoiceSetting knife = new ChoiceSetting("Knife", KnifeRenderer.KNIVES[0], List.of(KnifeRenderer.KNIVES));
    private final NumberSetting size = new NumberSetting("Size", .5, 2, 1, .05);
    private final BooleanSetting trail = new BooleanSetting("Trail", true);
    private final NumberSetting trailLength = new NumberSetting("Trail Length (s)", .1, .8, .2, .05);
    private final BindSetting inspectKey = new BindSetting("Inspect Key", GLFW.GLFW_KEY_G, false)
        .setDescription("Hold to inspect your knife. Default: G.");
    private final NumberSetting offX = new NumberSetting("Offset X", -.4, .4, 0, .01);
    private final NumberSetting offY = new NumberSetting("Offset Y", -.4, .4, 0, .01);
    private final NumberSetting offZ = new NumberSetting("Offset Z (+ = closer)", -.4, .4, 0, .01);
    private final BooleanSetting material = new BooleanSetting("Match Sword Material", true);
    private final BooleanSetting deploy = new BooleanSetting("Draw Animation", true);
    private final BooleanSetting cancelOnSwing = new BooleanSetting("Hit Cancels Inspect", true);
    private final BooleanSetting attackAnimation = new BooleanSetting("Attack Animation", true);

    public KnifeModule() {
        super("Knifes", "Replace first-person swords with animated knives; hold the inspect key to inspect.", -1, Category.RENDER);
        addSettings(knife, size, trail, trailLength, inspectKey, offX, offY, offZ, material, deploy, cancelOnSwing, attackAnimation);
        instance = this;
    }
    public static KnifeModule get() { return instance; }
    public static boolean active() { return instance != null && instance.isEnabled(); }
    public float size() { return (float)size.getValue(); }
    public boolean matchMaterial() { return material.getValue(); }
    public float offX() { return (float)offX.getValue(); }
    public float offY() { return (float)offY.getValue(); }
    public float offZ() { return (float)offZ.getValue(); }
    public int knife() { return knife.getIndex() + 1; }
    public boolean attackAnimation() { return attackAnimation.getValue(); }
    public float trailSeconds() { return trail.getValue() ? (float)trailLength.getValue() : 0; }
    @Override public void onEnable() { KnifeRenderer.reset(); }
    @Override public void onDisable() { KnifeRenderer.reset(); }
    @EventListener public void onTick(TickEvent event) {
        if (!isEnabled()) return;
        int key = inspectKey.getValue();
        boolean input = mc.player != null && mc.currentScreen == null && mc.isWindowFocused()
            && !cherryblossom.integration.CherryGui.capturesInput();
        boolean down = input && key >= GLFW.GLFW_KEY_SPACE && key <= GLFW.GLFW_KEY_LAST
            && GLFW.glfwGetKey(mc.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
        KnifeRenderer.tick(down, deploy.getValue(), cancelOnSwing.getValue());
    }
}
