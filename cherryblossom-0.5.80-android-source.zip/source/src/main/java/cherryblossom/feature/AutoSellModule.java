package cherryblossom.feature;

import java.awt.Color;
import java.util.Locale;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.ModeSetting;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.module.setting.Setting;
import cherryblossom.module.setting.StorageBlocksSetting;
import cherryblossom.module.setting.StorageBlocksSetting.Entry;
import cherryblossom.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class AutoSellModule extends Module {
   private static final int SELL_MENU_ROWS = 5;
   private final ModeSetting<AutoSellModule.SellingMode> mode;
   private final StorageBlocksSetting items;
   private final NumberSetting delay;
   private final BooleanSetting notifications;
   private int delayCounter;
   private boolean needsReopen;

   public AutoSellModule() {
      super(EncryptedString.of("Auto Sell"), EncryptedString.of("Automatically sells items"), -1, Category.MISC);
      mode = new ModeSetting<>(EncryptedString.of("Sell Mode"), SellingMode.Whitelist, SellingMode.class)
            .setDescription(EncryptedString.of("Whether to whitelist or blacklist the selected items"));
      items = createItemList();
      delay = new NumberSetting(EncryptedString.of("Delay"), 0.0, 20.0, 1.0, 1.0)
            .getValue(EncryptedString.of("Delay in ticks between actions"));
      notifications = new BooleanSetting(EncryptedString.of("Notifications"), true)
            .setDescription(EncryptedString.of("Show chat feedback"));
      addSettings(new Setting[]{mode, items, delay, notifications});
   }

   private static StorageBlocksSetting createItemList() {
      StorageBlocksSetting var0 = new StorageBlocksSetting(
            EncryptedString.of("Items")
         )
         .pickerOnly();
      Color var1 = new Color(75, 125, 185);

      for (Item var3 : Registries.ITEM) {
         if (var3 != Items.AIR) {
            Identifier var4 = Registries.ITEM.getId(var3);
            var0.add(
               var4.toString(),
               prettyName(var4.getPath()),
               var3,
               ((var3 == Items.SEA_PICKLE)),
               var1
            );
         }
      }

      return var0;
   }

   private static String prettyName(String var0) {
      StringBuilder var1 = new StringBuilder();
      String[] var2 = var0.split("_");
      int var3 = var2.length;

      for (int var4 = 0; var4 < var3; var4++) {
         String var5 = var2[var4];
         if (!var5.isEmpty()) {
            if (!var1.isEmpty()) {
               var1.append((char)(32));
            }

            var1.append(var5.substring(0, 1).toUpperCase(Locale.ROOT))
               .append(var5.substring(1));
         }
      }

      return var1.toString();
   }

   public void onEnable() {
      this.delayCounter = 20;
      this.needsReopen = false;
      super.onEnable();
   }

   public void onDisable() {
      this.needsReopen = false;
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.interactionManager != null && this.mc.getNetworkHandler() != null) {
         if (this.delayCounter > 0) {
            this.delayCounter -= 1;
         } else if (this.needsReopen) {
            this.openSell();
            this.needsReopen = false;
            this.delayCounter = 20;
         } else {
            GenericContainerScreenHandler var2 = this.container();
            if (var2 == null) {
               this.openSell();
               this.delayCounter = 20;
            } else if (this.firstEmptyUsableSlot(var2) < 0) {
               this.mc.player.closeHandledScreen();
               this.needsReopen = this.hasMatchingItems(var2);
               if (!this.needsReopen) {
                  this.info("All items sold.");
                  this.toggle();
               }

               this.delayCounter = this.delay.getIntValue();
            } else {
               int var3 = var2.getRows() * (9);

               for (int var4 = var3; var4 < var2.slots.size(); var4++) {
                  ItemStack var5 = var2.getSlot(var4).getStack();
                  if (!var5.isEmpty() && this.shouldSellItem(var5.getItem())) {
                     this.mc.interactionManager.clickSlot(var2.syncId, var4, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                     this.delayCounter = this.delay.getIntValue();
                     return;
                  }
               }

               this.mc.player.closeHandledScreen();
               this.info("All items sold.");
               this.toggle();
            }
         }
      }
   }

   private void openSell() {
      this.mc.getNetworkHandler().sendChatCommand("sell");
   }

   private GenericContainerScreenHandler container() {
      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler var1) {
         int var3 = this.mc.currentScreen != null
               && this.mc
                  .currentScreen
                  .getTitle()
                  .getString()
                  .toLowerCase(Locale.ROOT)
                  .contains("sell")
            ? 1
            : 0;
         if (var3 != 0 || var1.getRows() == (5)) {
            return var1;
         }
      }

      return null;
   }

   private int usableSlots(GenericContainerScreenHandler var1) {
      return Math.max(9, (var1.getRows() - (1)) * (9));
   }

   private int firstEmptyUsableSlot(GenericContainerScreenHandler var1) {
      int var2 = Math.min(this.usableSlots(var1), var1.slots.size());

      for (int var3 = 0; var3 < var2; var3++) {
         if (var1.getSlot(var3).getStack().isEmpty()) {
            return var3;
         }
      }

      return -1;
   }

   private boolean hasMatchingItems(GenericContainerScreenHandler var1) {
      int var2 = var1.getRows() * (9);

      for (int var3 = var2; var3 < var1.slots.size(); var3++) {
         ItemStack var4 = var1.getSlot(var3).getStack();
         if (!var4.isEmpty() && this.shouldSellItem(var4.getItem())) {
            return true;
         }
      }

      return false;
   }

   private boolean shouldSellItem(Item var1) {
      Entry var2 = this.items.get(Registries.ITEM.getId(var1).toString());
      int var3 = var2 != null && var2.enabled() ? 1 : 0;
      return ((this.mode.isMode(AutoSellModule.SellingMode.Whitelist) ? var3 : (var3 == 0 ? 1 : 0)) != 0);
   }

   private void info(String var1) {
      if (this.notifications.getValue() && this.mc.player != null) {
         this.mc.player.sendMessage(Text.literal("§a[Auto Sell] §f" + var1), false);
      }
   }

   public static enum SellingMode {
      Whitelist,
      Blacklist;
   }
}
