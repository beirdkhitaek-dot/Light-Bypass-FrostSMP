package cherryblossom.feature;

import cherryblossom.schematic.SchematicIntegration;
import cherryblossom.schematic.setting.SchematicFileSetting;
import cherryblossom.schematic.ui.Gfx;
import cherryblossom.schematic.ui.HudStyle;
import cherryblossom.schematic.ui.HudWidget;
import cherryblossom.schematic.ui.Icons;
import cherryblossom.schematic.ui.Ui;


import cherryblossom.mixin.SchematicPlayerAccessor;
import cherryblossom.schematic.setting.BooleanSetting;
import cherryblossom.schematic.setting.ButtonSetting;
import cherryblossom.schematic.setting.ModeSetting;
import cherryblossom.schematic.SchematicModuleSupport;
import cherryblossom.schematic.setting.Setting;
import cherryblossom.schematic.setting.SliderSetting;


import cherryblossom.schematic.render.Esp3D;
import cherryblossom.schematic.render.EspBoxRenderer;
import cherryblossom.schematic.BuildCamera;
import cherryblossom.schematic.HumanLook;
import cherryblossom.schematic.Pathfinder;
import cherryblossom.schematic.Placement;
import cherryblossom.schematic.Schematic;
import cherryblossom.schematic.SchematicPreviewScreen;
import cherryblossom.schematic.SchematicSetupScreen;
import cherryblossom.schematic.BotDig;
import cherryblossom.schematic.ui.Colors;
import cherryblossom.schematic.ui.Guide;
import java.awt.Color;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.BlockModelPart;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.GameMode;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;

public class AutoSchematicBuilderModule extends SchematicModuleSupport implements HudWidget {
   private static final int CYAN = -14560274;
   private static final int RED = -489871;
   private static final int ORANGE = -290244;
   private static final int GREEN = -11870592;
   private static AutoSchematicBuilderModule instance;
   private static final String SUPPORT = "cherryblossom:support";
   private static final String REMOVE = "cherryblossom:remove";
   private static final long SKIP_MS = 6000L;
   private static final double CROUCH_DROP = -0.35;
   private static final int MAX_TOWER = 12;
   private static final String[] SCAFFOLD = new String[]{
      "dirt",
      "cobblestone",
      "netherrack",
      "cobbled_deepslate",
      "andesite",
      "diorite",
      "granite",
      "tuff",
      "blackstone",
      "end_stone",
      "stone",
      "deepslate",
      "oak_planks",
      "spruce_planks",
      "birch_planks"
   };
   public final ButtonSetting setup = this.addSetting(
      new ButtonSetting("Set up schematic", "Pick a schematic, place it, check materials and start building.", this::openSetup)
   );
   public final ButtonSetting howTo = this.addSetting(
      new ButtonSetting("How to use", "Opens a step-by-step guide.", () -> Guide.open("Auto SchematicBuilder", Icons.Type.CUBE, this.guideSteps()))
   );
   public final SchematicFileSetting file = this.addSetting(
      new SchematicFileSetting("Schematic", "A .litematic or .schem file from the schematics folder.", AutoSchematicBuilderModule::listFiles)
   );
   public final ModeSetting rotation = this.addSetting(new ModeSetting("Rotation", new String[]{"0", "90", "180", "270"}, "0"));
   public final SliderSetting offsetX = this.addSetting(new SliderSetting("Offset X", -64.0F, 64.0F, 0.0F, 1.0F));
   public final SliderSetting offsetY = this.addSetting(new SliderSetting("Offset Y", -64.0F, 64.0F, 0.0F, 1.0F));
   public final SliderSetting offsetZ = this.addSetting(new SliderSetting("Offset Z", -64.0F, 64.0F, 0.0F, 1.0F));
   public final BooleanSetting building = this.addSetting(new BooleanSetting("Build", false));
   public final BooleanSetting preview3d = this.addSetting(new BooleanSetting("3D preview", false));
   public final BooleanSetting materials = this.addSetting(new BooleanSetting("Materials list", false));
   public final ModeSetting camera = this.addSetting(new ModeSetting("Camera", new String[]{"Follow builder", "Free", "Locked"}, "Follow builder"));
   public final ModeSetting ghostStyle = this.addSetting(new ModeSetting("Ghost blocks style", new String[]{"Focused", "All"}, "All"));
   public final BooleanSetting layerByLayer = this.addSetting(new BooleanSetting("Layer by layer", false));
   public final BooleanSetting walk = this.addSetting(new BooleanSetting("Walk around", true));
   public final BooleanSetting scaffold = this.addSetting(new BooleanSetting("Build up with scaffold", true));
   public final BooleanSetting clearWrong = this.addSetting(new BooleanSetting("Clear blocks in the way", true));
   public final BooleanSetting fixFacing = this.addSetting(new BooleanSetting("Fix wrong facing", true));
   public final BooleanSetting fromInventory = this.addSetting(new BooleanSetting("Take from inventory", true));
   public final BooleanSetting pullFromChest = this.addSetting(new BooleanSetting("Take from chest", true));
   public final BooleanSetting takeAll = this.addSetting(new BooleanSetting("Take everything from chest", false));
   public final SliderSetting delay = this.addSetting(new SliderSetting("Place delay", 1.0F, 10.0F, 2.0F, 1.0F, " ticks"));
   public final SliderSetting reach = this.addSetting(new SliderSetting("Reach", 3.0F, 4.5F, 4.0F, 0.1F));
   public final BooleanSetting human = this.addSetting(new BooleanSetting("Natural movement", true));
   public final BooleanSetting ghost = this.addSetting(new BooleanSetting("Show ghost blocks", true));
   public final BooleanSetting hud = this.addSetting(new BooleanSetting("Materials HUD", true));
   private final SliderSetting hudX = this.addSetting(new SliderSetting("HUD X", 0.0F, 100.0F, 98.0F, 0.5F));
   private final SliderSetting hudY = this.addSetting(new SliderSetting("HUD Y", 0.0F, 100.0F, 30.0F, 0.5F));
   private final KeyBinding placeKey;
   private final KeyBinding buildKey;
   private final KeyBinding previewKey;
   private final Random rng = new Random();
   private final HumanLook look = new HumanLook();
   private Schematic schematic;
   private String loadedFile = "";
   private BlockPos anchor;
   private String layoutKey = "";
   private List<AutoSchematicBuilderModule.Target> targets = List.of();
   private Map<BlockPos, AutoSchematicBuilderModule.Target> byPos = new HashMap<>();
   private Map<String, Integer> byHand = new HashMap<>();
   private BlockPos boxMin;
   private BlockPos boxMax;
   private boolean listAfterLayout;
   private int placedCount;
   private List<AutoSchematicBuilderModule.Need> needs = List.of();
   private Set<Item> inInventory = Set.of();
   private final Map<BlockPos, Long> skipUntil = new HashMap<>();
   private final Map<BlockPos, AutoSchematicBuilderModule.Cached> optionCache = new HashMap<>();
   private final Set<BlockPos> toAdjust = new LinkedHashSet<>();
   private final Set<BlockPos> scaffoldBlocks = new LinkedHashSet<>();
   private int tickCounter;
   private final float[] bounds = new float[4];
   private AutoSchematicBuilderModule.Phase phase = AutoSchematicBuilderModule.Phase.IDLE;
   private boolean holdingKeys;
   private int chooseDelay;
   private int cooldown;
   private int switchDelay;
   private int pause;
   private int sincePause;
   private int nextPauseAt = 25;
   private boolean warnedScaffold;
   private AutoSchematicBuilderModule.Target aim;
   private boolean adjusting;
   private Placement.Choice choice;
   private int alignedTicks;
   private int aimTicks;
   private int sneakTicks;
   private List<BlockPos> path;
   private int pathIndex;
   private boolean towerAfterWalk;
   private int towerGoalY;
   private AutoSchematicBuilderModule.Target walkTarget;
   private double bestDist;
   private int noProgress;
   private int replans;
   private int jumpFromY = Integer.MIN_VALUE;
   private BlockPos breaking;
   private boolean onTower;
   private AutoSchematicBuilderModule.Target towerFor;
   private Set<BlockPos> adjustable = new HashSet<>();
   private final Map<BlockPos, Integer> adjustTries = new HashMap<>();
   private final Map<BlockPos, Integer> attempts = new HashMap<>();
   private boolean precise;
   private int lastClickTick = -1000;
   private BlockPos pendingSign;
   private long pendingSignUntil;
   private int automaticSignsFinished;
   private String waitReason = "";
   private float hudScroll;
   private final Map<BlockPos, Integer> missing = new HashMap<>();
   private final Map<BlockPos, Long> placedAt = new HashMap<>();
   private List<AutoSchematicBuilderModule.Target> supports = List.of();
   private final Set<BlockPos> supportPlaced = new LinkedHashSet<>();
   private final Set<BlockPos> impossible = new HashSet<>();
   private long stuckSince;
   private final Map<BlockPos, Long> chainFailUntil = new HashMap<>();
   private static final Map<BlockState, List<Direction>> ATTACH = new HashMap<>();
   private final Map<Item, Long> checkedAt = new HashMap<>();
   private boolean hadAll;
   private boolean celebratedHaveAll;
   private long celebrateAt;
   private final ArrayDeque<Long> placeTimes = new ArrayDeque<>();
   private int tempNeed;
   private int tempHave;
   private long supportsAt;
   private int supportsPlacedAt = -1;
   private long dirtPlanAt;
   private List<AutoSchematicBuilderModule.Target> dirtPlan = List.of();
   private static final int GHOST_READY = 0;
   private static final int GHOST_NO_ITEM = 1;
   private static final int GHOST_BLOCKED = 2;
   private static final long PLACED_MS = 900L;
   private static final long REJECTED_MS = 700L;
   private final Map<BlockPos, Long> unconfirmed = new HashMap<>();
   private final Map<BlockPos, Long> rejectedAt = new HashMap<>();
   private final ArrayDeque<Long> rejectTimes = new ArrayDeque<>();
   private int slowdown;
   private int goodRun;
   private long lastRejectNote;
   private int keptSupports;
   private int mineAligned;
   private long descendUntil;
   private long stayTopFailUntil;
   private int topFailLayer = Integer.MIN_VALUE;
   private long topFailUntil;
   private boolean topWalk;
   private int topLayer;
   private AutoSchematicBuilderModule.Target selfFor;
   private float selfYaw;
   private int selfFails;
   private int strandedSupports;
   private AutoSchematicBuilderModule.Target bridgeFor;
   private BlockPos bridgeFrom;
   private Placement.Option bridgeOption;
   private boolean bridgeAfterWalk;
   private int bridgeTicks;
   private static final Direction[] SIDES = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
   private long bridgeFailUntil;
   private final Map<BlockPos, Integer> reorientTries = new HashMap<>();
   private static final String[] ORIENT = new String[]{"facing", "axis", "rotation", "half", "face", "attachment", "hinge", "orientation"};
   private boolean toBestSpot;
   private int workLayer = Integer.MAX_VALUE;
   private final List<BlockPos> digQueue = new ArrayList<>();
   private int digTicks;
   private boolean escapeTower;
   private BlockPos digAt;
   private Vec3d digEye;
   private float[] digAngles;
   private int layerFloor = Integer.MIN_VALUE;
   private int timedLayer = Integer.MIN_VALUE;
   private int timedLeft = -1;
   private long timedSince;
   private List<AutoSchematicBuilderModule.Target> openNow = List.of();
   private int blockedTicks;
   private Placement.Choice aimFor;
   private Vec3d aimEye;
   private float[] aimAngles;
   private int dwell = 4;
   private int sneakHold;
   private long lastProgressMs;
   private long stallSince;
   private Vec3d stallPosition;
   private int stallPlaced=-1;
   private int stallSupports=-1;
   private long lastRecoveryNotice;
   private long towerSince;
   private int towerRetries;
   private BlockPos supplyPos;
   private boolean attackWasDown;
   private int supplyState;
   private int supplyWait;
   private long supplyStart;
   private List<BlockPos> supplyPath;
   private int supplyIndex;
   private long supplyPathAt;
   private long lastSupplyMs;
   private final Map<Integer, Integer> supplyTries = new HashMap<>();
   private int pendingSlot = -1;
   private Item pendingItem;
   private int pendingCount;
   private int supplyTaken;
   private float towerPitch = Float.NaN;
   private static final Map<BlockState, double[][]> SHAPES = new HashMap<>();
   private static final Map<BlockState, Boolean> FULL = new HashMap<>();
   private static final Map<BlockState, Integer> COLORS = new HashMap<>();
   private static final double[][] CUBE = new double[][]{
      {0.0, 0.0, 0.0, 1.0, 0.0, 0.0},
      {0.0, 0.0, 1.0, 1.0, 0.0, 1.0},
      {0.0, 1.0, 0.0, 1.0, 1.0, 0.0},
      {0.0, 1.0, 1.0, 1.0, 1.0, 1.0},
      {0.0, 0.0, 0.0, 0.0, 1.0, 0.0},
      {1.0, 0.0, 0.0, 1.0, 1.0, 0.0},
      {0.0, 0.0, 1.0, 0.0, 1.0, 1.0},
      {1.0, 0.0, 1.0, 1.0, 1.0, 1.0},
      {0.0, 0.0, 0.0, 0.0, 0.0, 1.0},
      {1.0, 0.0, 0.0, 1.0, 0.0, 1.0},
      {0.0, 1.0, 0.0, 0.0, 1.0, 1.0},
      {1.0, 1.0, 0.0, 1.0, 1.0, 1.0}
   };
   private static final float GHOST_ALPHA = 0.42F;
   private static final double GHOST_MODEL_DIST2 = 484.0;
   private static final int GHOST_MODEL_MAX = 700;
   private static final Map<BlockState, List<BlockModelPart>> MODEL_PARTS = new HashMap<>();
   private static final net.minecraft.util.math.random.Random GHOST_RANDOM = net.minecraft.util.math.random.Random.create(42L);
   private static Object modelsProbe;
   private static final int HUD_ROWS = 8;

   public AutoSchematicBuilderModule() {
      super(
         "Auto SchematicBuilder",
         "DONUT",
         "Builds a .litematic or .schem from the blocks in your inventory. J places it where you stand, K starts and stops building, O opens the 3D preview."
      );
      instance = this;
      cherryblossom.schematic.render.Esp3D.init();
      this.placeKey = new KeyBinding("key.cherryblossom.schematic_place", Type.KEYSYM, 74, SchematicIntegration.CATEGORY);
      this.buildKey = new KeyBinding("key.cherryblossom.schematic_build", Type.KEYSYM, 75, SchematicIntegration.CATEGORY);
      this.previewKey = new KeyBinding("key.cherryblossom.schematic_preview", Type.KEYSYM, 79, SchematicIntegration.CATEGORY);
      net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(this.placeKey);
      net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(this.buildKey);
      net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(this.previewKey);
      this.human.visibleWhen(()->true);
      this.file.visibleWhen(() -> false);
      this.rotation.visibleWhen(() -> false);
      this.offsetX.visibleWhen(() -> false);
      this.offsetY.visibleWhen(() -> false);
      this.offsetZ.visibleWhen(() -> false);
      this.preview3d.visibleWhen(() -> false);
      this.materials.visibleWhen(() -> false);
      this.hudX.visibleWhen(() -> false);
      this.hudY.visibleWhen(() -> false);

      for (Setting<?> s : new Setting[]{
         this.camera, this.ghostStyle, this.walk, this.scaffold, this.fromInventory, this.delay, this.reach, this.ghost
      }) {
         s.visibleWhen(() -> false);
      }

      ClientTickEvents.END_CLIENT_TICK.register(this::tick);
      WorldRenderEvents.AFTER_ENTITIES.register(this::render);
      HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT, Identifier.of("cherryblossom", "schematic_hud"), this::renderHud);
      ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
         BuildCamera.end(this,client.player);
         this.stopActing(client);
         this.cancelPreparation();
         this.anchor = null;
         this.building.setValue(false);
         this.holdingKeys = false;
         this.scaffoldBlocks.clear();
                  this.onTower = false;
         this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      });
   }

   public static Path folder() {
      return FabricLoader.getInstance().getGameDir().resolve("schematics");
   }

   private static List<String> listFiles() {
      Path dir = folder();

      try {
         Files.createDirectories(dir);

         List var2;
         try (Stream<Path> s = Files.list(dir)) {
            var2 = s.<String>map(p -> p.getFileName().toString())
               .filter(n -> n.endsWith(".litematic") || n.endsWith(".schem"))
               .sorted(String.CASE_INSENSITIVE_ORDER)
               .toList();
         }

         return var2;
      } catch (Exception var6) {
         return List.of();
      }
   }

   private List<Guide.Step> guideSteps() {
      String place = Guide.key(this.placeKey);
      String build = Guide.key(this.buildKey);
      String preview = Guide.key(this.previewKey);
      return List.of(
         new Guide.Step(
            Guide.Visual.FILE,
            "Pick a schematic",
            "Drop .litematic or .schem files in the schematics folder of your Minecraft folder, then pick one in the setup screen."
         ),
         new Guide.Step(
            Guide.Visual.KEY,
            "Put it down",
            "Stand where the build should go and press " + place + ". It snaps to your feet. Press " + preview + " for a 3D preview to check it.",
            place,
            preview
         ),
         new Guide.Step(
            Guide.Visual.CHEST,
            "Bring the blocks",
            "Carry them, or mark a supply chest: with building off, hit a chest, barrel or shulker. It grabs what it needs and comes back for more."
         ),
         new Guide.Step(
            Guide.Visual.BUILD,
            "Start building",
            "Press " + build + ". It builds the bottom layer first and works up, placing only against real blocks, within normal reach.",
            build
         ),
         new Guide.Step(
            Guide.Visual.CAMERA,
            "Sit back",
            "The camera follows its head smoothly. It stays on the build, crouches at edges and never jumps off. " + build + " pauses it.",
            build
         ),
         new Guide.Step(
            Guide.Visual.DONE, "Clean finish", "When it's done it takes out every temporary block it used and tells you about anything it couldn't place."
         )
      );
   }

   @Override
   public void onEnable() {
      this.building.setValue(false);
      listFiles();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && "none".equals(this.file.get()) && !(mc.currentScreen instanceof SchematicSetupScreen)) {
         mc.execute(this::openSetup);
      }
   }

   @Override
   public void onDisable() {
      BuildCamera.end(this,MinecraftClient.getInstance().player);
      this.building.setValue(false);
      this.cancelPreparation();
      this.stopActing(MinecraftClient.getInstance());
      this.schematicMesh.close();this.layoutKey="";
   }

   private void legitSetup() {
      if (!this.camera.is("Follow builder")) {
         this.camera.setValue("Follow builder");
      }

      // Preserve the chosen preview style.

      if (this.reach.getFloat() != 4.0F) {
         this.reach.setValue(4.0F);
      }

      if (this.delay.getFloat() != 2.0F) {
         this.delay.setValue(2.0F);
      }

      for (BooleanSetting b : new BooleanSetting[]{this.walk, this.scaffold, this.fromInventory, this.human, this.ghost}) {
         if (!b.get()) {
            b.setValue(true);
         }
      }
   }

   public static float[] headView(float partial) {
      AutoSchematicBuilderModule m = instance;
      ClientPlayerEntity p = MinecraftClient.getInstance().player;
      return m != null && p != null && m.isEnabled() && m.building.get() ? m.look.view(p, partial) : null;
   }

   public static boolean drivingPlayer() {
      return instance != null && instance.isEnabled() && instance.building.get();
   }
   public static boolean finishAutomaticSign(net.minecraft.block.entity.SignBlockEntity sign,boolean front){
      var m=instance;
      if(m==null||!m.isEnabled()||!sign.getPos().equals(m.pendingSign)||System.currentTimeMillis()>m.pendingSignUntil)return false;
      var mc=MinecraftClient.getInstance();
      if(mc.getNetworkHandler()==null)return false;
      var text=sign.getText(front).getMessages(false);
      mc.getNetworkHandler().sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSignC2SPacket(sign.getPos(),front,text[0].getString(),text[1].getString(),text[2].getString(),text[3].getString()));
      m.pendingSign=null;m.automaticSignsFinished++;m.look.reset();return true;
   }

   private void tick(MinecraftClient mc) {
      if(!cherryblossom.integration.TrialAccess.allowed()){this.building.setValue(false);this.stopActing(mc);return;}
      if(!this.isEnabled()){
         while(this.placeKey.wasPressed()){} while(this.buildKey.wasPressed()){} while(this.previewKey.wasPressed()){}
         BuildCamera.end(this,mc.player);return;
      }
      if(cherryblossom.integration.CherryGui.capturesInput()){
         this.stopActing(mc);BuildCamera.end(this,mc.player);return;
      }
      if (mc.player != null) {
         this.setup.poll();
         this.howTo.poll();
      }


      boolean camera = this.isEnabled()
         && this.building.get()
         && !this.camera.is("Locked")
         && mc.player != null
         && !SchematicIntegration.freecam()
         && !SchematicIntegration.freelook()
         && !SchematicPreviewScreen.isOpen();
      if (camera) {
         BuildCamera.begin(this, mc.player, this.camera.is("Follow builder"));
      } else {
         BuildCamera.end(this, mc.player);
      }

      for (; this.placeKey.wasPressed(); this.placeHere(mc)) {
         if (!this.isEnabled() && SchematicIntegration.MANAGER != null) {
            SchematicIntegration.MANAGER.setEnabled(this, true);
         }
      }

      while (this.buildKey.wasPressed()) {
         if (this.isEnabled()) {
            this.setBuilding(mc, !this.building.get());
         }
      }

      while (this.previewKey.wasPressed()) {
         if (this.isEnabled()) {
            this.openPreview(mc);
         }
      }

      if (this.isEnabled() && mc.player != null && mc.world != null) {
         if (!this.file.getValue().equals(this.loadedFile)) {
            this.load(mc, this.file.getValue());
         }

         if (this.schematic == null) {
            this.stopActing(mc);
         } else {
            if (this.anchor == null) {
               this.placeHere(mc);
            }

            String key = this.anchor + "|" + this.rotation.get() + "|" + this.offsetX.getInt() + "," + this.offsetY.getInt() + "," + this.offsetZ.getInt();
            if (!key.equals(this.layoutKey)) {
               this.layoutKey = key;
               this.layout();
            }

            if(this.preparingLayout){this.releaseKeys(mc);return;}
            this.auditCompletion(mc.world);
            this.advanceLayer(mc.world);
            if (++this.tickCounter % (this.targets.size()>4096?1:10) == 0) {
               this.refresh(mc);
            }
            if(this.building.get()&&this.tickCounter%20==0){this.supports=this.planSupports(mc);this.updateTemporary(mc);}

            if (this.tickCounter % 3 == 0) {
               this.updateGhosts(mc.world);
            }

            if (this.materials.get() || this.listAfterLayout) {
               this.materials.setValue(false);
               this.listAfterLayout = false;
               this.printMaterials(mc);
            }

            if (this.preview3d.get()) {
               this.preview3d.setValue(false);
               this.openPreview(mc);
            }

            if (this.pullFromChest.get() && !this.building.get() && mc.interactionManager != null) {
               boolean atk = mc.options.attackKey.isPressed();
               if (atk
                  && !this.attackWasDown
                  && mc.crosshairTarget instanceof BlockHitResult bh
                  && mc.crosshairTarget.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK
                  && isContainer(mc.world, bh.getBlockPos())) {
                  this.supplyPos = bh.getBlockPos();
                  mc.interactionManager.cancelBlockBreaking();
                  message(mc, "Supply chest set. It'll grab what it needs here when you start building.");
               }

               this.attackWasDown = atk;
            }

            if (this.building.get()) {
               this.build(mc);
            } else {
               this.stopActing(mc);
            }

            if (!this.hud.get() && this.tickCounter % 20 == 0) {
               this.status(mc);
            }
         }
      } else {
         this.releaseKeys(mc);
      }
   }

   public void startBuilding() {
      this.setBuilding(MinecraftClient.getInstance(), true);
   }

   private void setBuilding(MinecraftClient mc, boolean on) {
      this.building.setValue(on);
      this.look.reset();
      this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      this.replans = 0;
      this.attempts.clear();
      this.skipUntil.clear();
      this.impossible.clear();
      this.layerFloor = Integer.MIN_VALUE;
      this.timedLayer = Integer.MIN_VALUE;
      this.stuckSince = 0L;
      this.waitReason = "";
      this.descendUntil = 0L;
      this.lastProgressMs = System.currentTimeMillis();
      this.stallSince=0;this.blockProgressSince=0;
      if(on){completionVerified=false;completeSince=0;auditCursor=0;auditDone=0;auditLowest=Integer.MAX_VALUE;adjustTries.clear();reorientTries.clear();}
      if (!on) {
         this.stopActing(mc);
      }

      if (on) {
         this.startSupply(mc);
      }

      message(
         mc,
         !on
            ? "Building paused."
            : (
               !this.camera.is("Locked")
                  ? "Building started. Move the mouse to look around; K to pause."
                  : "Building started. Move the mouse to take over, K to pause."
            )
      );
   }

   public void openSetup() {
      if(!cherryblossom.integration.TrialAccess.allowed())return;
      SchematicIntegration.closeGui();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (!this.isEnabled() && SchematicIntegration.MANAGER != null) {
         SchematicIntegration.MANAGER.setEnabled(this, true);
      }

      mc.setScreen(new SchematicSetupScreen(this, mc.currentScreen));
   }

   public static List<String> files() {
      return listFiles();
   }

   public String selectedFile() {
      return this.file.getValue();
   }

   public void selectFile(String name) {
      this.file.setValue(name);
      if (SchematicIntegration.MANAGER != null) {
         SchematicIntegration.MANAGER.save();
      }
   }

   public String[] loadedInfo() {
      return this.schematic == null
         ? null
         : new String[]{
            this.schematic.name, this.schematic.sizeX + " x " + this.schematic.sizeY + " x " + this.schematic.sizeZ, this.targets.size() + " blocks"
         };
   }

   public BlockPos anchor() {
      return this.anchor;
   }

   public void placeAtFeet() {
      this.placeHere(MinecraftClient.getInstance());
   }

   public int rotationDegrees() {
      return Integer.parseInt(this.rotation.get());
   }

   public void rotateBack() {
      this.rotateQuarter();
      this.rotateQuarter();
      this.rotateQuarter();
   }

   public int[] offset() {
      return new int[]{this.offsetX.getInt(), this.offsetY.getInt(), this.offsetZ.getInt()};
   }

   public List<AutoSchematicBuilderModule.Need> needs() {
      return this.needs;
   }

   public int temporaryNeed() {
      return creative(MinecraftClient.getInstance()) ? 0 : this.tempNeed;
   }

   public int temporaryHave() {
      return this.tempHave;
   }

   public int placedCount() {
      return this.placedCount;
   }

   public int targetCount() {
      return this.targets.size();
   }

   public boolean isBuilding() {
      return this.building.get();
   }

   public boolean creativeMode() {
      return creative(MinecraftClient.getInstance());
   }

   public void setBuildingFromScreen(boolean on) {
      this.setBuilding(MinecraftClient.getInstance(), on);
   }

   public void openPreviewScreen() {
      this.openPreview(MinecraftClient.getInstance());
   }

   private void openPreview(MinecraftClient mc) {
      if (this.schematic != null && !this.targets.isEmpty()) {
         if (this.building.get()) {
            this.setBuilding(mc, false);
         }

         mc.setScreen(new SchematicPreviewScreen(this));
      } else {
         message(mc, "Pick a schematic first.");
      }
   }

   private void placeHere(MinecraftClient mc) {
      if (mc.player != null) {
         ClientPlayerEntity p = mc.player;
         this.anchor = new BlockPos((int)Math.floor(p.getX()), (int)Math.floor(p.getY()), (int)Math.floor(p.getZ()));
         this.layoutKey = "";
         message(mc, "Schematic placed at " + this.anchor.getX() + " " + this.anchor.getY() + " " + this.anchor.getZ() + ".");
      }
   }

   public void rotateQuarter() {
      String[] modes = this.rotation.getModes();
      int i = 0;

      for (int k = 0; k < modes.length; k++) {
         if (modes[k].equals(this.rotation.get())) {
            i = k;
         }
      }

      this.rotation.setValue(modes[(i + 1) % modes.length]);
   }

   public void nudge(int dx, int dy, int dz) {
      this.offsetX.setValue(this.offsetX.getFloat() + dx);
      this.offsetY.setValue(this.offsetY.getFloat() + dy);
      this.offsetZ.setValue(this.offsetZ.getFloat() + dz);
   }

   private void load(MinecraftClient mc,String name){
      cancelPreparation();loadedFile=name;schematic=null;targets=List.of();byPos=new HashMap<>();byHand=new HashMap<>();adjustable=new HashSet<>();layers=new java.util.TreeMap<>();layerChunks=Map.of();missing.clear();ghostCandidates=List.of();needs=List.of();boxMin=null;boxMax=null;layoutKey="";
      if(name.isEmpty()||name.equals("none"))return;
      long serial=++preparationSerial;loadingFile=true;var world=mc.world;
      preparation=SCHEMATIC_WORKER.submit(()->{
         try{
            Path root=folder().toAbsolutePath().normalize(),selected=root.resolve(name).normalize();
            if(!selected.getParent().equals(root)||!name.toLowerCase(java.util.Locale.ROOT).matches(".+\\.(schem|litematic)"))throw new java.io.IOException("Choose a .schem or .litematic from the schematics folder.");
            Schematic parsed=Schematic.load(selected);
            mc.execute(()->{if(serial==preparationSerial&&isEnabled()&&mc.world==world){loadingFile=false;schematic=parsed;layoutKey="";message(mc,"Loaded "+name+": "+parsed.blocks.size()+" blocks. Preparing layers.");}});
         }catch(Exception error){mc.execute(()->{if(serial==preparationSerial){loadingFile=false;message(mc,"Couldn't load "+name+": "+error.getMessage());}});}
      });
   }

   private static final java.util.concurrent.ExecutorService SCHEMATIC_WORKER=java.util.concurrent.Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"CherryBlossom schematic preparation");t.setDaemon(true);t.setPriority(Thread.NORM_PRIORITY-1);return t;});
   private java.util.concurrent.Future<?> preparation;
   private long preparationSerial;
   private boolean loadingFile,preparingLayout;
   private java.util.NavigableMap<Integer,List<Target>> layers=new java.util.TreeMap<>();
   private Map<Long,List<Target>> layerChunks=Map.of();
   private int activeLayer=Integer.MAX_VALUE,layerScan,candidateStart,refreshCursor,refreshDone;
   private boolean layerIncomplete;
   private final Map<Item,Integer> refreshNeed=new HashMap<>();
   private final Map<Item,String> refreshNames=new HashMap<>();
   private List<Target> ghostCandidates=List.of();
   private final SchematicMesh schematicMesh=new SchematicMesh();
   private List<Target> previewTargets=List.of();
   private int visualAuditCursor,auditCursor,auditDone,auditLowest=Integer.MAX_VALUE;
   private boolean completionVerified;
   private long completeSince,blockProgressSince;
   private int previousComplete;
   private boolean lastLayerMode;
   private List<Vec3d> creativeRoute=List.of();
   private int creativeWaypoint;
   private Target creativeTarget;
   private boolean ownedCreativeFlight;
   private long creativeRouteAt;
   private boolean planCreative(MinecraftClient mc,List<Target> candidates,long now){
      if(!creative(mc)||!walk.get()||now-creativeRouteAt<250)return false;
      creativeRouteAt=now;
      List<Target> ordered=new ArrayList<>(candidates);
      ordered.sort(Comparator.comparingDouble(t->mc.player.getEntityPos().squaredDistanceTo(Vec3d.ofCenter(t.pos()))));
      long deadline=System.nanoTime()+5_000_000L;int tried=0;
      for(Target target:ordered){
         if(completeTarget(mc.world,target)||skipUntil.getOrDefault(target.pos(),0L)>now)continue;
         if(tried++>=12)break;
         if(!mc.world.getChunkManager().isChunkLoaded(target.pos().getX()>>4,target.pos().getZ()>>4)){
            Vec3d from=mc.player.getEntityPos(),delta=Vec3d.ofCenter(target.pos()).add(0,2,0).subtract(from);
            Vec3d point=from.add(delta.normalize().multiply(Math.min(20,delta.length())));
            List<Vec3d> route=cherryblossom.schematic.CreativeRoute.find(mc.world,from,point);
            if(!route.isEmpty()){
               if(!mc.player.getAbilities().flying){ownedCreativeFlight=true;mc.player.getAbilities().flying=true;mc.player.sendAbilitiesUpdate();}
               creativeRoute=route;creativeWaypoint=0;creativeTarget=target;waitReason="Approaching unloaded build area";return true;
            }
            continue;
         }
         List<Vec3d> vantage=new ArrayList<>();
         for(int y:new int[]{0,1,-1,2,-2})for(Direction side:Direction.Type.HORIZONTAL){
            BlockPos feet=target.pos().offset(side,2).up(y);Vec3d point=new Vec3d(feet.getX()+.5,feet.getY(),feet.getZ()+.5);
            if(!cherryblossom.schematic.CreativeRoute.clear(mc.world,point))continue;
            Vec3d eye=point.add(0,1.62,0);
            Placement.Choice choice=placed(mc.world,target)?adjustChoice(mc.world,target.pos(),eye,reach.getFloat()-.2):pick(options(mc,target),mc.world,target.pos(),eye,reach.getFloat()-.2);
            if(choice!=null)vantage.add(point);
         }
         vantage.sort(Comparator.comparingDouble(mc.player.getEntityPos()::squaredDistanceTo));
         for(Vec3d point:vantage){
            if(point.squaredDistanceTo(mc.player.getEntityPos())<.08)continue;
            List<Vec3d> route=cherryblossom.schematic.CreativeRoute.find(mc.world,mc.player.getEntityPos(),point);
            if(!route.isEmpty()){
               if(!mc.player.getAbilities().flying){ownedCreativeFlight=true;mc.player.getAbilities().flying=true;mc.player.sendAbilitiesUpdate();}
               creativeRoute=route;creativeWaypoint=0;creativeTarget=target;waitReason="Flying to the next block";return true;
            }
            if(System.nanoTime()>deadline)break;
         }
         if(System.nanoTime()>deadline)break;
      }
      return false;
   }
   private boolean flyCreative(MinecraftClient mc,long now){
      if(creativeRoute.isEmpty())return false;
      if(!creative(mc)||now-creativeRouteAt>12000||creativeTarget!=null&&completeTarget(mc.world,creativeTarget)){
         creativeRoute=List.of();mc.player.setVelocity(Vec3d.ZERO);return false;
      }
      Vec3d point=creativeRoute.get(creativeWaypoint),position=mc.player.getEntityPos();
      Vec3d delta=point.subtract(position);double distance=delta.length();
      if(distance<.16){
         if(++creativeWaypoint>=creativeRoute.size()){creativeRoute=List.of();mc.player.setVelocity(Vec3d.ZERO);chooseDelay=0;return false;}
         return true;
      }
      if(!cherryblossom.schematic.CreativeRoute.corridor(mc.world,position,position.add(delta.normalize().multiply(Math.min(.45,distance))))){
         creativeRoute=List.of();mc.player.setVelocity(Vec3d.ZERO);candidateStart+=256;return false;
      }
      releaseKeys(mc);float[] angles=Placement.angles(mc.player.getEyePos(),point.add(0,1.4,0));look.steer(mc.player,angles[0],angles[1]);
      Vec3d desired=delta.normalize().multiply(Math.min(human.get()?.22:.28,distance*.45));
      mc.player.setVelocity(mc.player.getVelocity().lerp(desired,.45));return true;
   }
   public void setLayerByLayer(boolean enabled){layerByLayer.setValue(enabled);candidateStart=0;SchematicIntegration.MANAGER.save();}
   private record Prepared(List<Target> targets,Map<BlockPos,Target> byPos,Map<String,Integer> byHand,Set<BlockPos> adjustable,BlockPos boxMin,BlockPos boxMax,java.util.NavigableMap<Integer,List<Target>> layers,Map<Long,List<Target>> chunks,SchematicMesh.Data mesh,List<Target> visual){}
   public String preparationStatus(){return loadingFile?"Loading schematic...":preparingLayout?"Preparing layers...":"";}
   public boolean readyToBuild(){return schematic!=null&&!loadingFile&&!preparingLayout&&!targets.isEmpty();}
   public void setNaturalMovement(boolean on){human.setValue(on);if(on&&delay.getFloat()<2)delay.setValue(2f);SchematicIntegration.MANAGER.save();}
   private void cancelPreparation(){preparationSerial++;if(preparation!=null)preparation.cancel(true);if(loadingFile||preparingLayout)loadedFile="";loadingFile=false;preparingLayout=false;}

   private void layout() {
      if(schematic==null)return;
      MinecraftClient mc=MinecraftClient.getInstance();
      long serial=++preparationSerial;Schematic input=schematic;BlockPos base=anchor;
      int turns=Integer.parseInt(rotation.get())/90,ox=offsetX.getInt(),oy=offsetY.getInt(),oz=offsetZ.getInt();
      this.stopActing(mc);this.preparingLayout=true;
      if(preparation!=null)preparation.cancel(true);
      if(input.blocks.size()<=512){installPrepared(prepareLayout(input,base,turns,ox,oy,oz));return;}
      this.targets=List.of();this.byPos=new HashMap<>();this.layers=new java.util.TreeMap<>();this.layerChunks=Map.of();this.adjustable=new HashSet<>();this.optionCache.clear();this.missing.clear();this.ghostCandidates=List.of();
      var world=mc.world;
      preparation=SCHEMATIC_WORKER.submit(()->{
         try{Prepared result=prepareLayout(input,base,turns,ox,oy,oz);mc.execute(()->{if(serial==preparationSerial&&isEnabled()&&mc.world==world)installPrepared(result);});}
         catch(java.util.concurrent.CancellationException ignored){}
         catch(Exception error){mc.execute(()->{if(serial==preparationSerial){preparingLayout=false;message(mc,"Couldn't prepare schematic: "+error.getMessage());}});}
      });
   }
   private void installPrepared(Prepared result){
      schematicMesh.install(result.mesh);previewTargets=result.visual;completionVerified=false;completeSince=0;auditCursor=0;auditDone=0;auditLowest=Integer.MAX_VALUE;blockProgressSince=0;previousComplete=0;
      targets=result.targets;byPos=result.byPos;byHand=result.byHand;adjustable=result.adjustable;boxMin=result.boxMin;boxMax=result.boxMax;
      layers=result.layers;layerChunks=result.chunks;activeLayer=layers.isEmpty()?Integer.MAX_VALUE:layers.firstKey();
      layerScan=0;layerIncomplete=false;layerScannedDone=0;layerDone=0;layerStableSince=0;candidateStart=0;refreshCursor=0;refreshDone=0;refreshNeed.clear();refreshNames.clear();ghostCandidates=List.of();missing.clear();
      preparingLayout=false;stallSince=0;placedCount=0;adjustTries.clear();
      this.skipUntil.clear();
      this.optionCache.clear();
      this.toAdjust.clear();
      this.impossible.clear();
      this.chainFailUntil.clear();
      this.supportsPlacedAt = -1;
      this.dirtPlanAt = 0L;
      this.layerFloor = Integer.MIN_VALUE;
      this.timedLayer = Integer.MIN_VALUE;
      this.stuckSince = 0L;
      this.hadAll = false;
      this.celebratedHaveAll = false;
      this.checkedAt.clear();
      this.placeTimes.clear();
      this.unconfirmed.clear();
      this.rejectedAt.clear();
      this.placedAt.clear();
      this.aim = null;
      this.path = null;
      this.phase = AutoSchematicBuilderModule.Phase.IDLE;
   }


   private static Prepared prepareLayout(Schematic schematic, BlockPos anchor, int turns, int ox, int oy, int oz) {


      BlockRotation rot = switch (turns) {
         case 1 -> BlockRotation.CLOCKWISE_90;
         case 2 -> BlockRotation.CLOCKWISE_180;
         case 3 -> BlockRotation.COUNTERCLOCKWISE_90;
         default -> BlockRotation.NONE;
      };
      int sx = schematic.sizeX;
      int sz = schematic.sizeZ;
      Item none = Blocks.AIR.asItem();
      List<AutoSchematicBuilderModule.Target> out = new ArrayList<>();
      Map<String,Integer> byHand=new HashMap<>();
      Map<BlockPos,BlockState> visualStates=new java.util.LinkedHashMap<>();
      List<Target> visual=new ArrayList<>();
      int minX = Integer.MAX_VALUE;
      int minY = Integer.MAX_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int maxY = Integer.MIN_VALUE;
      int maxZ = Integer.MIN_VALUE;

      int checked=0;
      for (Schematic.Block b : schematic.blocks) {
         if((++checked & 1023)==0 && Thread.currentThread().isInterrupted())throw new java.util.concurrent.CancellationException();
         int rx;
         int rz;
         switch (turns) {
            case 1:
               rx = sz - 1 - b.z();
               rz = b.x();
               break;
            case 2:
               rx = sx - 1 - b.x();
               rz = sz - 1 - b.z();
               break;
            case 3:
               rx = b.z();
               rz = sx - 1 - b.x();
               break;
            default:
               rx = b.x();
               rz = b.z();
         }

         BlockPos pos = anchor.add(ox + rx, oy + b.y(), oz + rz);
         BlockState state = b.state().rotate(rot);
         if(!state.isAir()){visualStates.put(pos,state);visual.add(new Target(pos,state,state.getBlock().asItem(),b.id()));}
         minX = Math.min(minX, pos.getX());
         minY = Math.min(minY, pos.getY());
         minZ = Math.min(minZ, pos.getZ());
         maxX = Math.max(maxX, pos.getX());
         maxY = Math.max(maxY, pos.getY());
         maxZ = Math.max(maxZ, pos.getZ());
         String props = state.toString();
         if (!props.contains("half=upper") && !props.contains("part=head")) {
            Item item = state.getBlock().asItem();
            if (item == none) {
               byHand.merge(b.id().replace("minecraft:", ""), 1, Integer::sum);
            } else {
               out.add(new AutoSchematicBuilderModule.Target(pos, state, item, b.id()));
            }
         }
      }

      out.sort(
         Comparator.<AutoSchematicBuilderModule.Target>comparingInt(tx -> tx.pos().getY())
            .thenComparingInt(tx -> tx.pos().getX())
            .thenComparingInt(tx -> tx.pos().getZ())
      );
      List<Target> targets=List.copyOf(out);
      Map<BlockPos,Target> byPos=new HashMap<>();
      Set<BlockPos> adjustable=new HashSet<>();


      for (AutoSchematicBuilderModule.Target t : out) {
         byPos.put(t.pos(), t);
         String id = Pathfinder.id(t.state().getBlock());
         if (id.contains("repeater")
            || id.equals("note_block")
            || id.equals("comparator")
            || id.equals("daylight_detector")
            || id.equals("lever")
            || (id.contains("door") || id.contains("gate")) && !id.contains("iron")) {
            adjustable.add(t.pos());
         }
      }

      boolean any = minX != Integer.MAX_VALUE;
      BlockPos boxMin = any ? new BlockPos(minX, minY, minZ) : null;
      BlockPos boxMax = any ? new BlockPos(maxX, maxY, maxZ) : null;
      java.util.NavigableMap<Integer,List<Target>> layers=new java.util.TreeMap<>();
      Map<Long,List<Target>> chunks=new HashMap<>();
      for(int first=0;first<targets.size();){int y=targets.get(first).pos().getY(),last=first+1;while(last<targets.size()&&targets.get(last).pos().getY()==y)last++;layers.put(y,targets.subList(first,last));first=last;}
      for(Target t:targets)chunks.computeIfAbsent(BlockPos.asLong(t.pos().getX()>>4,t.pos().getY(),t.pos().getZ()>>4),k->new ArrayList<>()).add(t);
      return new Prepared(targets,byPos,byHand,adjustable,boxMin,boxMax,layers,chunks,SchematicMesh.prepare(visualStates),List.copyOf(visual));
   }

   private static boolean placed(ClientWorld world, AutoSchematicBuilderModule.Target t) {
      if ("cherryblossom:support".equals(t.id())) {
         return !world.getBlockState(t.pos()).isReplaceable();
      } else {
         return "cherryblossom:remove".equals(t.id()) ? world.getBlockState(t.pos()).isReplaceable() : world.getBlockState(t.pos()).getBlock() == t.state().getBlock();
      }
   }

   private List<AutoSchematicBuilderModule.Target> planSupports(MinecraftClient mc) {
      return this.planSupports(mc, this.scaffoldItem(mc));
   }

   private List<AutoSchematicBuilderModule.Target> planSupports(MinecraftClient mc, Item item) {
      if (!this.scaffold.get() || this.schematic == null) {
         return List.of();
      } else if (item == null) {
         return List.of();
      } else {
         BlockState state = Block.getBlockFromItem(item).getDefaultState();
         ClientWorld world = mc.world;
         Set<BlockPos> anchored = new HashSet<>();
         Map<BlockPos, AutoSchematicBuilderModule.Target> open = new HashMap<>();
         List<AutoSchematicBuilderModule.Target> openList = new ArrayList<>();

         int planned=0;long planDeadline=System.nanoTime()+3_000_000L;
         List<Target> candidates=this.activeTargets();int from=Math.min(candidateStart,candidates.size());
         for (Target t : candidates.subList(from,Math.min(from+256,candidates.size()))) {
            if(planned++>=256||System.nanoTime()>planDeadline)break;
            if (!placed(world, t) && !this.impossible.contains(t.pos()) && world.getBlockState(t.pos()).isReplaceable()) {
               if (!this.options(mc, t).isEmpty()) {
                  anchored.add(t.pos());
               } else {
                  open.put(t.pos(), t);
                  openList.add(t);
               }
            }
         }

         Set<BlockPos> supportCells = new LinkedHashSet<>();
         ArrayDeque<BlockPos> queue = new ArrayDeque<>(anchored);
         this.spreadAnchors(world, open, anchored, supportCells, queue);
         long now = System.currentTimeMillis();
         long deadline = System.nanoTime() + 6000000L;
         openList.sort(Comparator.comparingInt(tx -> tx.pos().getY()));

         for (AutoSchematicBuilderModule.Target tx : openList) {
            if (!anchored.contains(tx.pos())) {
               Long failed = this.chainFailUntil.get(tx.pos());
               if (failed == null || failed <= now) {
                  if (System.nanoTime() > deadline) {
                     break;
                  }

                  List<BlockPos> chain = this.supportChain(world, tx, anchored, supportCells);
                  if (chain == null) {
                     this.chainFailUntil.put(tx.pos(), now + 20000L);
                  } else {
                     supportCells.addAll(chain);
                     queue.addAll(chain);
                     this.spreadAnchors(world, open, anchored, supportCells, queue);
                  }
               }
            }
         }

         if (this.chainFailUntil.size() > 20000) {
            this.chainFailUntil.clear();
         }

         Map<BlockPos, AutoSchematicBuilderModule.Target> out = new LinkedHashMap<>();

         for (BlockPos c : supportCells) {
            out.put(c, new AutoSchematicBuilderModule.Target(c, state, item, "cherryblossom:support"));
         }

         return List.copyOf(out.values());
      }
   }

   private void spreadAnchors(
      ClientWorld world, Map<BlockPos, AutoSchematicBuilderModule.Target> open, Set<BlockPos> anchored, Set<BlockPos> supportCells, ArrayDeque<BlockPos> queue
   ) {
      while (!queue.isEmpty()) {
         BlockPos p = queue.poll();
         boolean support = supportCells.contains(p);
         AutoSchematicBuilderModule.Target pt = support ? null : this.byPos.get(p);
         if (support || pt != null && anchored.contains(p)) {
            for (Direction side : Direction.values()) {
               BlockPos q = p.offset(side);
               AutoSchematicBuilderModule.Target t = open.get(q);
               if (t != null
                  && !anchored.contains(q)
                  && attachDirs(t.state()).contains(side.getOpposite())
                  && (support || Placement.faceSolid(world, p, pt.state(), side))) {
                  anchored.add(q);
                  queue.add(q);
               }
            }
         }
      }
   }

   private List<BlockPos> supportChain(ClientWorld world, AutoSchematicBuilderModule.Target t, Set<BlockPos> anchored, Set<BlockPos> supportCells) {
      long deadline=System.nanoTime()+4_000_000L;
      int examined=0;
      PriorityQueue<AutoSchematicBuilderModule.Step> queue = new PriorityQueue<>(Comparator.comparingDouble(AutoSchematicBuilderModule.Step::cost));
      Map<BlockPos, BlockPos> parent = new HashMap<>();
      Map<BlockPos, Double> best = new HashMap<>();

      for (Direction d : attachDirs(t.state())) {
         BlockPos c = t.pos().offset(d);
         if (this.freeForSupport(world, c) && !best.containsKey(c)) {
            best.put(c, 1.0);
            parent.put(c, c);
            queue.add(new AutoSchematicBuilderModule.Step(c, 1.0, 1));
         }
      }

      while (!queue.isEmpty()) {
         AutoSchematicBuilderModule.Step st = queue.poll();
         if(++examined>2048||System.nanoTime()>deadline)return null;
         BlockPos c = st.pos();
         if (!(st.cost() > best.getOrDefault(c, Double.MAX_VALUE))) {
            if (this.touchesSolid(world, c, anchored, supportCells, t.pos())) {
               List<BlockPos> chain = new ArrayList<>();
               BlockPos q = c;

               while (true) {
                  chain.add(q);
                  if (parent.get(q).equals(q)) {
                     return chain;
                  }

                  q = parent.get(q);
               }
            }

            if (st.blocks() < 10) {
               for (Direction dx : Direction.values()) {
                  BlockPos n = c.offset(dx);
                  if (this.freeForSupport(world, n)) {
                     double cost = st.cost() + (dx == Direction.DOWN ? 0.97 : 1.0);
                     if (!(cost >= best.getOrDefault(n, Double.MAX_VALUE))) {
                        best.put(n, cost);
                        parent.put(n, c);
                        queue.add(new AutoSchematicBuilderModule.Step(n, cost, st.blocks() + 1));
                     }
                  }
               }
            }
         }
      }

      return null;
   }

   private boolean freeForSupport(ClientWorld world, BlockPos c) {
      return world.getBlockState(c).isReplaceable() && !this.byPos.containsKey(c) && world.isChunkLoaded(c);
   }

   private boolean touchesSolid(ClientWorld world, BlockPos c, Set<BlockPos> anchored, Set<BlockPos> supportCells, BlockPos except) {
      for (Direction d : Direction.values()) {
         BlockPos n = c.offset(d);
         if (!n.equals(except)) {
            if (supportCells.contains(n)) {
               return true;
            }

            BlockState s = world.getBlockState(n);
            if (!s.isReplaceable() && Placement.faceSolid(world, n, s, d.getOpposite())) {
               return true;
            }

            AutoSchematicBuilderModule.Target nt = this.byPos.get(n);
            if (nt != null && anchored.contains(n) && Placement.faceSolid(world, n, nt.state(), d.getOpposite())) {
               return true;
            }
         }
      }

      return false;
   }

   private static List<Direction> attachDirs(BlockState s) {
      List<Direction> cached = ATTACH.get(s);
      if (cached == null) {
         cached = attachDirsUncached(s);
         ATTACH.put(s, cached);
      }

      return cached;
   }

   private static List<Direction> attachDirsUncached(BlockState s) {
      String id = Pathfinder.id(s.getBlock());
      Map<String, String> p = Placement.props(s, false);
      String face = p.get("face");
      String facing = p.get("facing");
      Direction behind = null;
      if (facing != null) {
         for (Direction d : Direction.values()) {
            if (d.toString().equals(facing)) {
               behind = d.getOpposite();
            }
         }
      }

      if (face != null) {
         if (face.equals("floor")) {
            return List.of(Direction.DOWN);
         } else if (face.equals("ceiling")) {
            return List.of(Direction.UP);
         } else {
            return behind != null ? List.of(behind) : List.of(Direction.values());
         }
      } else if (!"true".equals(p.get("hanging")) && (!id.endsWith("hanging_sign") || id.endsWith("wall_hanging_sign"))) {
         if ((
               id.endsWith("wall_sign")
                  || id.endsWith("wall_torch")
                  || id.endsWith("wall_banner")
                  || id.endsWith("wall_hanging_sign")
                  || id.equals("ladder")
                  || id.equals("tripwire_hook")
                  || id.endsWith("wall_fan")
            )
            && behind != null) {
            return List.of(behind);
         } else {
            return !id.equals("redstone_wire")
                  && !id.equals("repeater")
                  && !id.equals("comparator")
                  && !id.contains("carpet")
                  && !id.contains("pressure_plate")
                  && !id.contains("rail")
                  && !id.endsWith("torch")
                  && !id.endsWith("_sign")
                  && !id.endsWith("_banner")
                  && !id.contains("door")
                  && !id.equals("snow")
                  && !id.contains("candle")
                  && !id.contains("sapling")
                  && !id.equals("lever")
                  && !id.contains("button")
               ? List.of(Direction.values())
               : List.of(Direction.DOWN);
         }
      } else {
         return List.of(Direction.UP);
      }
   }

   private static boolean creative(MinecraftClient mc) {
      return mc.interactionManager != null && mc.interactionManager.getCurrentGameMode() == GameMode.CREATIVE;
   }

   private void refresh(MinecraftClient mc) {
      ClientWorld world=mc.world;
      Map<Item,Integer> have=inventoryCounts(mc);this.inInventory=have.keySet();
      int limit=targets.size()>4096?1024:targets.size(),end=Math.min(targets.size(),refreshCursor+limit);
      for(int i=refreshCursor;i<end;i++){
         Target t=targets.get(i);
         if(placed(world,t)){refreshDone++;if((!layerByLayer.get()||t.pos().getY()==activeLayer)&&adjustable.contains(t.pos())&&clicksToFix(t.state(),world.getBlockState(t.pos()))>0)toAdjust.add(t.pos());}
         else{refreshNeed.merge(t.item(),itemsFor(t),Integer::sum);refreshNames.putIfAbsent(t.item(),t.id().replace("minecraft:",""));}
      }
      refreshCursor=end;
      if(refreshCursor<targets.size())return;
      int done=refreshDone;Map<Item,Integer> need=new HashMap<>(refreshNeed);Map<Item,String> names=new HashMap<>(refreshNames);
      refreshCursor=0;refreshDone=0;refreshNeed.clear();refreshNames.clear();
      this.placedCount = done;
      this.inInventory = have.keySet();
      long nowMs = System.currentTimeMillis();
      if (done != this.supportsPlacedAt || nowMs - this.supportsAt > 3000L) {
         this.supportsPlacedAt = done;
         this.supportsAt = nowMs;
         this.supports = this.planSupports(mc);
      }

      List<AutoSchematicBuilderModule.Need> rows = new ArrayList<>();

      for (Entry<Item, Integer> e : need.entrySet()) {
         rows.add(new AutoSchematicBuilderModule.Need(e.getKey(), names.get(e.getKey()), have.getOrDefault(e.getKey(), 0), e.getValue()));
      }

      rows.sort(Comparator.<AutoSchematicBuilderModule.Need>comparingInt(nx -> nx.have() - nx.need()).thenComparingInt(nx -> -nx.need()));
      this.needs = rows;
      this.updateTemporary(mc);
      boolean all = !rows.isEmpty() && !creative(mc);

      for (AutoSchematicBuilderModule.Need n : rows) {
         if (n.have() < n.need()) {
            all = false;
         } else {
            this.checkedAt.putIfAbsent(n.item(), System.currentTimeMillis());
         }
      }

      this.checkedAt.keySet().removeIf(item -> rows.stream().noneMatch(nx -> nx.item() == item && nx.have() >= nx.need()));
      if (all && !this.hadAll && !this.celebratedHaveAll) {
         this.celebratedHaveAll = true;
         this.celebrateAt = System.currentTimeMillis();

         try {
            float v = this.notifyVolume();
            if (v > 0.0F) {
               mc.getSoundManager().play(PositionedSoundInstance.ui(SoundEvent.of(Identifier.ofVanilla("block.note_block.bell")), 1.25F, v));
               mc.getSoundManager().play(PositionedSoundInstance.ui(SoundEvent.of(Identifier.ofVanilla("block.note_block.bell")), 1.88F, v * 0.8F));
            }
         } catch (RuntimeException var13) {
         }
      }

      this.hadAll = all;
   }

   private float notifyVolume() {
      try {
         float base = (float)(cherryblossom.module.modules.client.CherryBlossom.uiSounds.getValue() ? cherryblossom.module.modules.client.CherryBlossom.uiVolume.getValue()/100.0 : 0.0);
         return 0.35F * Math.max(0.0F, Math.min(1.0F, base));
      } catch (RuntimeException var2) {
         return 0.2F;
      }
   }

   private long secondsLeft() {
      int left = Math.max(0, this.targets.size() - this.placedCount);
      double perBlock = 1.3;
      if (this.placeTimes.size() >= 5) {
         perBlock = Math.max(0.35, (this.placeTimes.peekLast() - this.placeTimes.peekFirst()) / 1000.0 / (this.placeTimes.size() - 1));
      }

      return Math.round(left * perBlock);
   }

   private static String duration(long s) {
      if (s < 60L) {
         return s + "s";
      } else {
         return s < 3600L ? s / 60L + "m " + String.format("%02d", s % 60L) + "s" : s / 3600L + "h " + s % 3600L / 60L + "m";
      }
   }

   private static Map<Item, Integer> inventoryCounts(MinecraftClient mc) {
      PlayerInventory inv = mc.player.getInventory();
      Map<Item, Integer> have = new HashMap<>();

      for (int i = 0; i < 36; i++) {
         ItemStack s = inv.getStack(i);
         if (!s.isEmpty()) {
            have.merge(s.getItem(), s.getCount(), Integer::sum);
         }
      }

      return have;
   }

   private static int itemsFor(AutoSchematicBuilderModule.Target t) {
      return t.state().toString().contains("type=double") ? 2 : 1;
   }

   private void updateTemporary(MinecraftClient mc) {
      if (this.scaffold.get() && this.boxMin != null && this.placedCount < this.targets.size()) {
         ClientWorld world = mc.world;
         List<AutoSchematicBuilderModule.Target> sup = this.supports;
         if (sup.isEmpty() && this.scaffoldItem(mc) == null) {
            long nowMs = System.currentTimeMillis();
            if (nowMs - this.dirtPlanAt > 5000L) {
               this.dirtPlanAt = nowMs;
               Block dirt = Schematic.block("minecraft:dirt");
               this.dirtPlan = dirt != null ? this.planSupports(mc, dirt.asItem()) : List.of();
            }

            sup = this.dirtPlan;
         }

         int supports = 0;

         for (AutoSchematicBuilderModule.Target t : sup) {
            if (!placed(world, t)) {
               supports++;
            }
         }

         int top = this.boxMax.getY();
         int lowest = top;

         lowest=activeLayer==Integer.MAX_VALUE?top:activeLayer;

         int pillar = Math.max(0, top - Math.min(lowest, this.boxMin.getY()) - 3);
         this.tempNeed = supports + (pillar > 0 ? pillar + 2 : 0);
         this.tempHave = this.scaffoldCount(mc);
      } else {
         this.tempNeed = 0;
      }
   }

   private AutoSchematicBuilderModule.Need temporaryRow() {
      if (this.tempNeed > 0 && !creative(MinecraftClient.getInstance())) {
         Block dirt = Schematic.block("minecraft:dirt");
         return dirt == null ? null : new AutoSchematicBuilderModule.Need(dirt.asItem(), "temporary (dirt, cobble...)", this.tempHave, this.tempNeed);
      } else {
         return null;
      }
   }

   private void printMaterials(MinecraftClient mc) {
      if (this.schematic != null && mc.player != null) {
         this.refresh(mc);
         int shortBy = 0;
         int kinds = 0;

         for (AutoSchematicBuilderModule.Need n : this.needs) {
            if (n.have() < n.need()) {
               shortBy += n.need() - n.have();
               kinds++;
            }
         }

         if (this.needs.isEmpty()) {
            message(mc, "Materials: nothing left to place for " + this.schematic.name + ".");
         } else if (shortBy == 0) {
            message(mc, "Materials: you have everything " + this.schematic.name + " needs.");
         } else {
            message(mc, "Materials: short of " + shortBy + " blocks (" + kinds + " kinds). See the Schematic HUD.");
         }

         if (this.tempNeed > 0 && !creative(mc)) {
            message(
               mc,
               "Also bring "
                  + this.tempNeed
                  + " temporary blocks (dirt, cobblestone or similar) to build up and hold parts in place"
                  + (this.tempHave >= this.tempNeed ? " - you have enough." : " - you have " + this.tempHave + ".")
                  + " They all come back out at the end."
            );
         }

         if (!this.byHand.isEmpty()) {
            message(mc, "Place yourself: " + String.join(", ", this.byHand.keySet()) + " (no item for them).");
         }
      }
   }

   private void status(MinecraftClient mc) {
      StringBuilder s = new StringBuilder("§d[CherryBlossom] §f")
         .append(this.schematic.name)
         .append(" §7| §f")
         .append(this.placedCount)
         .append('/')
         .append(this.targets.size())
         .append(" §7placed | ");
      s.append(this.building.get() ? "§a" + this.phaseName() : "§epaused §7(K to build)");
      mc.player.sendMessage(Text.literal(s.toString()), true);
   }

   private String phaseName() {
      return switch (this.phase) {
         case WALK -> this.towerAfterWalk ? "walking to a pillar spot" : (this.topWalk ? "getting on top" : "walking");
         case AIM -> this.adjusting ? "adjusting" : "placing";
         case TOWER_UP -> this.selfFor != null ? "stepping up" : "building up";
         case TOWER_DOWN -> "clearing scaffold";
         default -> this.pause > 0 ? "taking a breath" : (!this.waitReason.isEmpty() ? this.waitReason : "looking for the next block");
         case DIG -> "digging out";
         case SUPPLY -> this.supplyState == 2 ? "taking blocks from the chest" : (this.supplyState == 1 ? "opening the chest" : "walking to the chest");
         case BRIDGE -> "building out across the top";
      };
   }

   private void updateGhosts(ClientWorld world) {
      MinecraftClient mc=MinecraftClient.getInstance();long now=System.currentTimeMillis();boolean free=creative(mc);
      List<Target> visible=new ArrayList<>(4096);int cx=mc.player.getBlockX()>>4,cz=mc.player.getBlockZ()>>4;
      int focus=activeLayer==Integer.MAX_VALUE?mc.player.getBlockY():activeLayer;
      int low=ghostStyle.is("Focused")?focus-1:mc.player.getBlockY()-24;
      int high=ghostStyle.is("Focused")?focus+1:mc.player.getBlockY()+24;
      outer:for(int radius=0;radius<=4;radius++)for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++){
         if(Math.max(Math.abs(x),Math.abs(z))!=radius)continue;
         for(int y=low;y<=high;y++)for(Target t:layerChunks.getOrDefault(BlockPos.asLong(cx+x,y,cz+z),List.of())){
            visible.add(t);if(visible.size()>=4096)break outer;
         }
      }
      this.ghostCandidates=List.copyOf(visible);
      Set<BlockPos> before=new HashSet<>(this.missing.keySet());this.missing.clear();
      for(Target t:visible){
         BlockState cur=world.getBlockState(t.pos());
         if(cur.getBlock()!=t.state().getBlock()){
            int kind=!cur.isReplaceable()?2:(!free&&!this.inInventory.contains(t.item())?1:0);this.missing.put(t.pos(),kind);
            if(t.pos().getY()<activeLayer&&layers.containsKey(t.pos().getY())){activeLayer=t.pos().getY();layerScan=0;layerScannedDone=0;layerIncomplete=false;layerStableSince=0;candidateStart=0;}
         }
      }
      for (BlockPos pos : before) {
         if (!this.missing.containsKey(pos) && this.byPos.containsKey(pos) && placed(world,this.byPos.get(pos))) {
            this.unconfirmed.put(pos, now);
         }
      }

      long confirmMs = confirmMs(MinecraftClient.getInstance());
      Iterator<Entry<BlockPos, Long>> it = this.unconfirmed.entrySet().iterator();

      while (it.hasNext()) {
         Entry<BlockPos, Long> e = it.next();
         if (this.missing.containsKey(e.getKey())) {
            it.remove();
            this.onRejected(e.getKey(), now);
         } else if (now - e.getValue() >= confirmMs) {
            it.remove();
            this.placedAt.put(e.getKey(), now);
            this.stallSince=0;
            if (++this.goodRun >= 10 && this.slowdown > 0) {
               this.slowdown--;
               this.goodRun = 0;
            }
         }
      }

      this.placedAt.values().removeIf(at -> now - at > 900L);
      this.rejectedAt.values().removeIf(at -> now - at > 700L);
   }

   private static long confirmMs(MinecraftClient mc) {
      int ping = 60;

      try {
         if (mc.getNetworkHandler() != null && mc.player != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) {
               ping = Math.max(0, entry.getLatency());
            }
         }
      } catch (RuntimeException var3) {
      }

      return Math.max(250, Math.min(900, ping * 2 + 150));
   }

   private void onRejected(BlockPos pos, long now) {
      this.rejectedAt.put(pos, now);
      this.goodRun = 0;
      this.slowdown = Math.min(14, this.slowdown + 3);
      this.skipUntil.put(pos, now + 1500L);
      this.rejectTimes.addLast(now);

      while (!this.rejectTimes.isEmpty() && now - this.rejectTimes.peekFirst() > 15000L) {
         this.rejectTimes.pollFirst();
      }

      if (this.rejectTimes.size() >= 5) {
         this.rejectTimes.clear();
         this.pause = Math.max(this.pause, 60);
         this.waitReason = "The server keeps undoing blocks, slowing down";
         if (now - this.lastRejectNote > 30000L) {
            this.lastRejectNote = now;
            message(
               MinecraftClient.getInstance(),
               "The server keeps taking placed blocks back (a protected area, or placing too fast). Slowing down; blocks it undoes are retried."
            );
         }
      }
   }

   private void build(MinecraftClient mc) {
      ClientPlayerEntity p = mc.player;
      long now = System.currentTimeMillis();
      boolean supplyScreen = this.phase == AutoSchematicBuilderModule.Phase.SUPPLY
         && mc.currentScreen instanceof HandledScreen
         && !(mc.currentScreen instanceof InventoryScreen)
         && !(mc.currentScreen instanceof CreativeInventoryScreen);
      if (mc.currentScreen != null && !supplyScreen) {
         this.stallSince=0;
         boolean ours = mc.currentScreen instanceof AbstractSignEditScreen
            || mc.currentScreen instanceof HandledScreen
               && !(mc.currentScreen instanceof InventoryScreen)
               && !(mc.currentScreen instanceof CreativeInventoryScreen)
               && this.tickCounter - this.lastClickTick < 20;
         if (ours) {
            mc.currentScreen.close();
            this.look.reset();
         }

         this.releaseKeys(mc);
      } else if (!BuildCamera.isActive() && this.look.overridden(p)) {
         this.setBuilding(mc, false);
         message(mc, "You moved the camera, so building paused. Press K to carry on (or set Camera to Follow builder).");
      } else {
         boolean resting = this.look.tick(p);
         float health = p.getHealth();
         long nowMs = System.currentTimeMillis();
         int descend = 2;
         boolean cleaningUp = this.phase == AutoSchematicBuilderModule.Phase.CLEAN
            || this.phase == AutoSchematicBuilderModule.Phase.TOWER_DOWN
            || this.phase == AutoSchematicBuilderModule.Phase.WALK && this.walkTarget != null && "cherryblossom:remove".equals(this.walkTarget.id());
         boolean stay = this.stayOnBuild(mc.world, playerFeet(p)) && this.phase != AutoSchematicBuilderModule.Phase.SUPPLY && !cleaningUp;
         Pathfinder.maxDrop = creative(mc) ? 12 : (this.onTower ? 1 : (nowMs < this.descendUntil ? descend : (stay ? 1 : 3)));
         ClientWorld w = mc.world;
         Pathfinder.stayOn = stay ? n -> this.onBuild(w, n) : null;
         if (this.cooldown > 0) {
            this.cooldown--;
         }

         if (this.switchDelay > 0) {
            this.switchDelay--;
         }

         if (this.pause > 0) {
            this.stallSince=0;
            this.pause--;
            this.releaseKeys(mc);
         } else {
            if (this.lastProgressMs == 0L) {
               this.lastProgressMs = now;
            }

            if (this.stalled(mc,now) && this.phase != AutoSchematicBuilderModule.Phase.SUPPLY) {
               if (this.walkTarget != null) {
                  this.skipUntil.put(this.walkTarget.pos(), now + 3000L);
               }

               if (this.aim != null) {
                  this.skipUntil.put(this.aim.pos(), now + 3000L);
               }

               this.attempts.clear();this.adjustTries.clear();this.reorientTries.clear();this.impossible.clear();
               candidateStart+=256;blockProgressSince=now;
               this.stopActing(mc);
               this.optionCache.clear();
               this.digQueue.clear();
               this.chooseDelay=2;
               this.cooldown=0;
               this.switchDelay=0;
               this.stallSince=0;
               this.lastProgressMs = now;
               this.waitReason = "Got stuck, trying other blocks";
               if(now-this.lastRecoveryNotice>30000L){this.lastRecoveryNotice=now;message(mc,"No movement or block progress; retrying the next build target.");}
            } else {
               switch (this.phase) {
                  case IDLE:
                     if(!this.flyCreative(mc,now))this.idle(mc, now);
                     break;
                  case WALK:
                     this.walk(mc, now);
                     break;
                  case AIM:
                     this.aimTick(mc, now, resting);
                     if(creative(mc)&&mc.player.getAbilities().flying)mc.player.setVelocity(0,mc.options.sneakKey.isPressed()?mc.player.getAbilities().getFlySpeed()*3:0,0);
                     break;
                  case TOWER_UP:
                     this.towerUp(mc, resting);
                     break;
                  case TOWER_DOWN:
                     this.towerDown(mc, resting);
                     break;
                  case CLEAN:
                     this.clean(mc, resting);
                     break;
                  case DIG:
                     this.dig(mc, now, resting);
                     break;
                  case SUPPLY:
                     this.supply(mc, now, resting);
                     break;
                  case BRIDGE:
                     this.bridge(mc, now, resting);
               }
               if(ownedCreativeFlight&&creative(mc)){
                  if(!p.getAbilities().flying){p.getAbilities().flying=true;p.sendAbilitiesUpdate();}
                  if(creativeRoute.isEmpty()&&(phase==Phase.IDLE||phase==Phase.AIM||phase==Phase.DIG))p.setVelocity(0,mc.options.sneakKey.isPressed()?p.getAbilities().getFlySpeed()*3:0,0);
               }
            }
         }
      }
   }

   private boolean stalled(MinecraftClient mc,long now){
      if(blockProgressSince==0||previousComplete!=placedCount){blockProgressSince=now;previousComplete=placedCount;}
      if(now-blockProgressSince>45000L)return true;
      int supports=this.supportPlaced.size()+this.scaffoldBlocks.size();
      Vec3d position=mc.player.getEntityPos();
      if(this.stallSince==0||this.stallPosition==null||this.stallPlaced!=this.placedCount||this.stallSupports!=supports||this.stallPosition.squaredDistanceTo(position)>.0625){
         this.stallSince=now;this.stallPosition=position;this.stallPlaced=this.placedCount;this.stallSupports=supports;return false;
      }
      return now-this.stallSince>25000L;
   }

   private String buildStatus(){
      String phase=this.phaseName();
      if(this.phase!=AutoSchematicBuilderModule.Phase.IDLE&&!this.waitReason.isEmpty()&&!phase.equalsIgnoreCase(this.waitReason))phase+=" - "+this.waitReason;
      if(this.building.get()&&this.phase!=AutoSchematicBuilderModule.Phase.SUPPLY&&this.stallSince>0&&System.currentTimeMillis()-this.stallSince>15000)phase+=" (retrying shortly)";
      return phase;
   }

   private void clean(MinecraftClient mc, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      Vec3d eye = p.getEyePos();
      double reach = this.reach.getFloat();
      BlockPos next = null;
      BlockPos far = null;
      BlockPos underMe = null;
      double bestKey = Double.MAX_VALUE;
      double farKey = Double.MAX_VALUE;
      Iterator<BlockPos> it = this.supportPlaced.iterator();

      while (it.hasNext()) {
         BlockPos pos = it.next();
         if (world.getBlockState(pos).isReplaceable()) {
            it.remove();
         } else if (this.holdsSomethingUp(world, pos)) {
            it.remove();
            this.keptSupports++;
         } else if (standingOn(p, pos) && dropBelow(world, pos) > 2) {
            underMe = pos;
         } else {
            Vec3d c = Vec3d.ofCenter(pos);
            double d = eye.distanceTo(c);
            if (d <= reach - 0.2 && visibleFace(world, p, eye, pos) != null) {
               double key = -pos.getY() * 1000.0 + d;
               if (key < bestKey) {
                  bestKey = key;
                  next = pos;
               }
            } else if (d < farKey) {
               farKey = d;
               far = pos;
            }
         }
      }

      if (next == null && far == null && underMe != null) {
         this.supportPlaced.remove(underMe);
         this.strandedSupports++;
      } else if (next == null && far != null) {
         this.releaseKeys(mc);
         if (this.attempts.merge(far, 1, Integer::sum) > 4 || !this.walkToReach(mc, far)) {
            this.supportPlaced.remove(far);
            this.strandedSupports++;
         }
      } else if (next == null) {
         if (this.breaking != null) {
            BotDig.stop(mc);
         }

         this.breaking = null;
         if (this.keptSupports > 0) {
            message(
               mc,
               "Left "
                  + this.keptSupports
                  + " support block"
                  + (this.keptSupports == 1 ? "" : "s")
                  + " in: taking "
                  + (this.keptSupports == 1 ? "it" : "them")
                  + " out would break what sits on "
                  + (this.keptSupports == 1 ? "it" : "them")
                  + "."
            );
         }

         if (this.strandedSupports > 0) {
            message(mc, "Left " + this.strandedSupports + " scaffold block" + (this.strandedSupports == 1 ? "" : "s") + " it couldn't get to from up here.");
         }

         this.keptSupports = 0;
         this.strandedSupports = 0;
         this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      } else {
         if (this.digEye == null || !next.equals(this.digAt) || this.digEye.distanceTo(eye) > 0.15) {
            this.digAngles = Placement.angles(eye, visibleFace(world, p, eye, next));
            this.digEye = eye;
            this.digAt = next;
         }

         this.look.lookAt(p, this.digAngles[0], this.digAngles[1]);
         this.releaseKeys(mc);
         this.mine(mc, p, next, resting);
      }
   }

   private static boolean standingOn(ClientPlayerEntity p, BlockPos pos) {
      if (pos.getY() != (int)Math.floor(p.getY() - 0.01)) {
         return false;
      } else {
         double x = p.getX();
         double z = p.getZ();
         return x + 0.3 > pos.getX() && x - 0.3 < pos.getX() + 1 && z + 0.3 > pos.getZ() && z - 0.3 < pos.getZ() + 1;
      }
   }

   private static int dropBelow(ClientWorld world, BlockPos pos) {
      int n = 0;

      for (BlockPos q = pos.down(); n < 8 && Pathfinder.passable(world, q); q = q.down()) {
         n++;
      }

      return n;
   }

   private void mine(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos, boolean resting) {
      if (pos.equals(this.breaking) || this.switchDelay <= 0 && !this.pickTool(p, mc.world.getBlockState(pos))) {
         HitResult r = p.raycast(this.reach.getFloat(), 1.0F, false);
         boolean onIt = r instanceof BlockHitResult bh && r.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK && bh.getBlockPos().equals(pos);
         if (onIt && serverSees(p)) {
            this.mineAligned = !resting && !pos.equals(this.breaking) ? 0 : this.mineAligned + 1;
            if (this.mineAligned >= 3 || pos.equals(this.breaking)) {
               BotDig.dig(mc, pos, ((BlockHitResult)r).getSide());
               this.breaking = pos;
            }
         } else {
            this.mineAligned = 0;
            if (this.breaking != null && !pos.equals(this.breaking) || !onIt && this.breaking != null) {
               BotDig.stop(mc);
               this.breaking = null;
            }
         }
      }
   }

   private boolean pickTool(ClientPlayerEntity p, BlockState s) {
      PlayerInventory inv = p.getInventory();
      int cur = inv.getSelectedSlot();
      int best = cur;
      float bestSpeed = inv.getStack(cur).getMiningSpeedMultiplier(s);

      for (int i = 0; i < 9; i++) {
         float speed = inv.getStack(i).getMiningSpeedMultiplier(s);
         if (speed > bestSpeed + 0.01F) {
            bestSpeed = speed;
            best = i;
         }
      }

      if (best == cur) {
         return false;
      } else {
         inv.setSelectedSlot(best);
         this.switchDelay = 2 + this.rng.nextInt(2);
         return true;
      }
   }

   private boolean holdsSomethingUp(ClientWorld world, BlockPos pos) {
      for (Direction d : Direction.values()) {
         if (d != Direction.DOWN) {
            BlockPos n = pos.offset(d);
            AutoSchematicBuilderModule.Target t = this.byPos.get(n);
            if (t != null && placed(world, t)) {
               BlockState s = world.getBlockState(n);
               String id = Pathfinder.id(s.getBlock());
               boolean falls = id.endsWith("sand") && !id.contains("stone")
                  || id.equals("gravel")
                  || id.contains("concrete_powder")
                  || id.contains("anvil")
                  || id.equals("dragon_egg")
                  || id.equals("scaffolding");
               boolean full = Placement.faceSolid(world, n, s, Direction.UP) && Placement.faceSolid(world, n, s, Direction.DOWN);
               if (d == Direction.UP ? falls || !full : !full) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean walkToReach(MinecraftClient mc, BlockPos pos) {
      ClientWorld world = mc.world;
      double reach = this.reach.getFloat() - 0.4;
      Vec3d c = Vec3d.ofCenter(pos);
      List<BlockPos> route = Pathfinder.find(world, playerFeet(mc.player), n -> {
         if (!n.equals(pos) && !n.up().equals(pos)) {
            Vec3d eye = new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5);
            return eye.distanceTo(c) <= reach && Placement.clearLine(world, eye, c.x, c.y, c.z, pos, pos);
         } else {
            return false;
         }
      }, n -> Math.max(0.0, Math.sqrt(c.squaredDistanceTo(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5)) - reach), this.byPos.keySet(), 3000);
      if (route == null) {
         return false;
      } else {
         BlockState s = world.getBlockState(pos);
         this.beginWalk(new AutoSchematicBuilderModule.Target(pos, s, s.getBlock().asItem(), "cherryblossom:remove"), route, false, 0);
         return true;
      }
   }

   private void idle(MinecraftClient mc, long now) {
      this.releaseKeysKeepSneak(mc);
      if (this.chooseDelay > 0) {
         this.chooseDelay--;
      } else {
         long idleStart = System.nanoTime();
         ClientPlayerEntity p = mc.player;
         ClientWorld world = mc.world;
         Vec3d eye = p.getEyePos();
         boolean free = creative(mc);
         double reach = this.reach.getFloat();

         for (BlockPos pos : List.copyOf(this.toAdjust)) {
            AutoSchematicBuilderModule.Target t = this.byPos.get(pos);
            if(layerByLayer.get()&&t!=null&&t.pos().getY()>activeLayer)continue;
            if (t != null && placed(world, t) && clicksToFix(t.state(), world.getBlockState(pos)) != 0) {
               Placement.Choice c = adjustChoice(world, pos, eye, reach);
               if (c != null) {
                  this.adjustTries.merge(pos, 1, Integer::sum);
                  this.startAim(t, c, true);
                  return;
               }
            } else {
               this.toAdjust.remove(pos);
            }
         }

         List<AutoSchematicBuilderModule.Target> open = new ArrayList<>();
         List<AutoSchematicBuilderModule.Ready> ready = new ArrayList<>();
         int remaining = 0;
         int noItem = 0;
         int blocked = 0;
         int noSupport = 0;
         int waiting = 0;
         boolean holdConfirm = false;
         List<Target> layerWork=activeTargets();
         if(candidateStart>=layerWork.size())candidateStart=0;
         int finish=Math.min(layerWork.size(),candidateStart+256);
         List<Target> work=new ArrayList<>(layerWork.subList(candidateStart,finish));
         for(Target support:this.supports)if((!layerByLayer.get()||support.pos().getY()<=activeLayer)&&work.size()<512)work.add(support);
         int layer = this.currentLayer(mc, now, free);
         List<BlockPos> inTheWay = new ArrayList<>();

         for (AutoSchematicBuilderModule.Target t : work) {
            if (!this.impossible.contains(t.pos())) {
               if (placed(world, t)) {
                  if (this.fixFacing.get()
                     && (!layerByLayer.get() || t.pos().getY() <= layer)
                     && !"cherryblossom:support".equals(t.id())
                     && misoriented(world, t)
                     ) {
                     inTheWay.add(t.pos());
                     remaining++;
                  }
               } else {
                  boolean support = "cherryblossom:support".equals(t.id());
                  if (!support) {
                     remaining++;
                  }

                  if (!layerByLayer.get() || t.pos().getY() <= layer) {
                     Long until = this.skipUntil.get(t.pos());
                     if (until != null && until > now) {
                        waiting++;
                     } else if (!world.getBlockState(t.pos()).isReplaceable()) {
                        blocked++;
                        inTheWay.add(t.pos());
                     } else if (!free && !this.inInventory.contains(t.item())) {
                        noItem++;
                     } else {
                        List<Placement.Option> opts = this.options(mc, t);
                        if (opts.isEmpty()) {
                           if (!support) {
                              noSupport++;
                           }
                        } else if (this.tooManyAttempts(t, now)) {
                           waiting++;
                        } else {
                           open.add(t);
                           double dist = eye.distanceTo(Vec3d.ofCenter(t.pos()));
                           if (!(dist > reach + 1.0) && !intersectsPlayer(p, t.pos()) && !this.aboveHead(p, t.pos())) {
                              Placement.Choice c = pick(opts, world, t.pos(), standingEye(p), reach);
                              if (c != null && faceVisible(world, p, eye, c, c.option().neighbour())) {
                                 if (this.unconfirmed.containsKey(c.option().neighbour())) {
                                    holdConfirm = true;
                                 } else {
                                    float[] a = Placement.angles(eye, c.hit());
                                    double turn = Math.abs(HumanLook.wrap(a[0] - p.getYaw())) + Math.abs(a[1] - p.getPitch());
                                    ready.add(new AutoSchematicBuilderModule.Ready(t, c, t.pos().getY() * 100.0 + dist * 0.5 + turn * 0.04));
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         if(ready.isEmpty())candidateStart=finish;
         if(free&&ready.isEmpty()&&!completionVerified){
            if(!inTheWay.isEmpty()&&clearWrong.get()&&clearInTheWay(mc,inTheWay,false,now))return;
            if(planCreative(mc,work,now))return;
         }
         if(remaining==0&&!completionVerified&&inTheWay.isEmpty()){waitReason="Checking unfinished blocks ("+placedCount+"/"+targets.size()+")";chooseDelay=0;return;}
         if (remaining == 0 && completionVerified) {
            if (this.escapeTower) {
               this.supportPlaced.addAll(this.scaffoldBlocks);
               this.scaffoldBlocks.clear();
                        this.onTower = false;
               this.escapeTower = false;
            }

            if (!this.onTower && this.scaffoldBlocks.isEmpty()) {
               this.supportPlaced.removeIf(posx -> world.getBlockState(posx).isReplaceable());
               if (!this.supportPlaced.isEmpty()) {
                  this.phase = AutoSchematicBuilderModule.Phase.CLEAN;
               } else {
                  this.building.setValue(false);
                  this.stopActing(mc);
                  message(mc, "Finished building " + this.schematic.name + "!");
                  if (!this.impossible.isEmpty()) {
                     StringBuilder which = new StringBuilder();

                     for (BlockPos posx : this.impossible) {
                        AutoSchematicBuilderModule.Target tx = this.byPos.get(posx);
                        if (which.length() > 0) {
                           which.append(", ");
                        }

                        which.append(tx == null ? "?" : Pathfinder.id(tx.state().getBlock()))
                           .append(" at ")
                           .append(posx.getX())
                           .append(' ')
                           .append(posx.getY())
                           .append(' ')
                           .append(posx.getZ());
                        if (which.length() > 160) {
                           which.append(", ...");
                           break;
                        }
                     }

                     message(
                        mc,
                        "Couldn't place "
                           + this.impossible.size()
                           + " block"
                           + (this.impossible.size() == 1 ? "" : "s")
                           + " (nothing to attach "
                           + (this.impossible.size() == 1 ? "it" : "them")
                           + " to, even with supports): "
                           + which
                     );
                  }

                  if (this.strandedSupports > 0) {
                     message(mc, "Left " + this.strandedSupports + " temporary block" + (this.strandedSupports == 1 ? "" : "s") + " it couldn't get to.");
                  }

                  this.strandedSupports = 0;
               }
            } else {
               this.phase = AutoSchematicBuilderModule.Phase.TOWER_DOWN;
            }
         } else {
            open.sort(Comparator.comparingDouble(txx -> eye.distanceTo(Vec3d.ofCenter(txx.pos())) + txx.pos().getY() * 2.0));
            this.openNow = open;
            BlockPos feet = playerFeet(p);
            this.workLayer = layer;
            boolean canLeave = free || layer == Integer.MAX_VALUE || this.onTower || !p.isOnGround() || this.canEscape(world, feet, layer, null, Set.of());
            if (canLeave || !this.walk.get()) {
               ready.sort(Comparator.comparingDouble(AutoSchematicBuilderModule.Ready::score));
               AutoSchematicBuilderModule.Target best = null;
               Placement.Choice bestChoice = null;

               for (AutoSchematicBuilderModule.Ready r : ready) {
                  if (free || !blocksBody(world, r.t()) || this.canEscape(world, feet, layer, r.t().pos(), Set.of())) {
                     best = r.t();
                     bestChoice = r.c();
                     break;
                  }
               }

               if (best == null && holdConfirm) {
                  this.chooseDelay = 2;
               } else if (best != null) {
                  this.waitReason = "";
                  this.startAim(best, bestChoice, false);
               } else {
                  List<BlockPos> ownDirt = this.ownTempInTheWay(inTheWay);
                  List<BlockPos> toClear = this.clearWrong.get() ? inTheWay : ownDirt;
                  if (toClear.isEmpty() || !this.clearInTheWay(mc, toClear, false, now)) {
                     if (!this.planBridge(mc, open, now)) {
                        boolean preferTop = this.preferTop(layer) && this.walk.get();
                        boolean onTop = this.onTopAt(world, feet, layer);
                        if ((preferTop || this.onTower && this.walk.get())
                           && !onTop
                           && p.isOnGround()
                           && (this.onTower || this.topFailLayer != layer || now >= this.topFailUntil)) {
                           int tries = 0;

                           for (AutoSchematicBuilderModule.Target txx : open) {
                              if (tries++ >= 3) {
                                 break;
                              }

                              if (this.planTop(mc, txx, this.options(mc, txx), layer)) {
                                 this.waitReason = "";
                                 return;
                              }
                           }

                           this.topFailLayer = layer;
                           this.topFailUntil = now + 6000L;
                        }

                        if (best != null) {
                           this.waitReason = "";
                           this.startAim(best, bestChoice, false);
                        } else if (toClear.isEmpty() || !this.clearInTheWay(mc, toClear, open.isEmpty() || !ownDirt.isEmpty(), now)) {
                           if (preferTop) {
                              for (AutoSchematicBuilderModule.Target txx : open) {
                                 if (txx.pos().equals(feet) && this.startSelfPillar(mc, txx)) {
                                    return;
                                 }
                              }
                           }

                           if (!this.onTower || this.escapeTower || !p.isOnGround() || !this.raisePillar(mc, open)) {
                              if (this.onTower && !this.escapeTower) {
                                 if (this.walk.get() && p.isOnGround()) {
                                    int tries = 0;

                                    for (AutoSchematicBuilderModule.Target txxx : open) {
                                       if (tries++ >= 10) {
                                          break;
                                       }

                                       if (this.planTop(mc, txxx, this.options(mc, txxx), txxx.pos().getY())) {
                                          this.waitReason = "";
                                          return;
                                       }
                                    }
                                 }

                                 this.phase = AutoSchematicBuilderModule.Phase.TOWER_DOWN;
                              } else {
                                 if (this.walk.get()) {
                                    int tries = 0;
                                    boolean triedClimb = false;
                                    boolean stay = this.stayOnBuild(world, feet);
                                    if (stay && p.isOnGround() && now >= this.stayTopFailUntil) {
                                       int topTries = 0;

                                       for (AutoSchematicBuilderModule.Target txxx : open) {
                                          if (topTries++ >= 10 || topTries > 1 && System.nanoTime() - idleStart > 8000000L) {
                                             break;
                                          }

                                          if (this.planTop(mc, txxx, this.options(mc, txxx), txxx.pos().getY())) {
                                             this.waitReason = "";
                                             return;
                                          }
                                       }

                                       this.stayTopFailUntil = now + 4000L;
                                    }

                                    for (AutoSchematicBuilderModule.Target txxx : open) {
                                       if (tries >= 4) {
                                          break;
                                       }

                                       if (tries > 0 && System.nanoTime() - idleStart > 8000000L) {
                                          this.chooseDelay = 1;
                                          return;
                                       }

                                       tries++;
                                       List<Placement.Option> opts = this.options(mc, txxx);
                                       if (preferTop && onTop && this.planTop(mc, txxx, opts, layer)) {
                                          return;
                                       }

                                       if (stay) {
                                          if (this.scaffold.get() && this.planTower(mc, txxx, opts)) {
                                             return;
                                          }
                                       } else {
                                          if (this.planWalk(mc, txxx, opts)) {
                                             return;
                                          }

                                          if (preferTop && this.scaffold.get() && !triedClimb) {
                                             triedClimb = true;
                                             if (this.planClimb(mc, txxx, layer)) {
                                                return;
                                             }
                                          }

                                          if (this.scaffold.get() && this.planTower(mc, txxx, opts)) {
                                             return;
                                          }

                                          this.skipUntil.put(txxx.pos(), now + 6000L);
                                       }
                                    }

                                    boolean pillarFree = true;

                                    for (int y = feet.getY(); y < layer && pillarFree; y++) {
                                       pillarFree = !this.byPos.containsKey(new BlockPos(feet.getX(), y, feet.getZ()));
                                    }

                                    if (stay
                                       && pillarFree
                                       && !open.isEmpty()
                                       && p.isOnGround()
                                       && feet.getY() < layer
                                       && layer - feet.getY() <= 12
                                       && this.scaffold.get()
                                       && this.scaffoldCount(mc) >= layer - feet.getY()) {
                                       this.selfFor = null;
                                       this.towerFor = null;
                                       this.escapeTower = false;
                                       this.towerGoalY = layer;
                                       this.towerPitch = Float.NaN;
                                       this.jumpFromY = Integer.MIN_VALUE;
                                       this.waitReason = "";
                                       this.phase = AutoSchematicBuilderModule.Phase.TOWER_UP;
                                       return;
                                    }

                                    if (stay && !open.isEmpty()) {
                                       this.descendUntil = now + 30000L;
                                       this.waitReason = "Nothing more in reach from up here, climbing down";
                                       this.chooseDelay = 3;
                                       return;
                                    }
                                 }

                                 if (noItem > 0 && now - this.lastSupplyMs > 30000L && this.startSupply(mc)) {
                                    this.waitReason = "Getting more blocks from the chest";
                                 } else {
                                    if (noSupport <= 0 || !open.isEmpty() || noItem != 0 || blocked != 0 || waiting != 0) {
                                       this.stuckSince = 0L;
                                    } else if (this.stuckSince == 0L) {
                                       this.stuckSince = now;
                                    } else {
                                       if (now - this.stuckSince > 15000L && layer != Integer.MAX_VALUE && this.hasAbove(world, layer)) {
                                          this.waitReason = "Current layer needs support before continuing";
                                          this.stuckSince = 0L;
                                          this.chooseDelay = 2;
                                          return;
                                       }

                                       if (now - this.stuckSince > 15000L) {
                                          for (AutoSchematicBuilderModule.Target txxx : this.targets) {
                                             if (!placed(world, txxx) && this.options(mc, txxx).isEmpty()) {
                                                this.waitReason = "Current layer needs support before continuing";
                                             }
                                          }

                                          this.stuckSince = 0L;
                                          this.waitReason = "";
                                          this.chooseDelay = 2;
                                          return;
                                       }
                                    }

                                    if (noItem > 0 && noItem + waiting >= remaining) {
                                       this.waitReason = "Out of blocks for " + noItem + " (see list)";
                                    } else if (blocked > 0 && open.isEmpty() && noSupport == 0) {
                                       this.waitReason = blocked + " spot" + (blocked == 1 ? " has" : "s have") + " the wrong block in it";
                                    } else if (noSupport > 0 && open.isEmpty()) {
                                       this.waitReason = noSupport + " block" + (noSupport == 1 ? " has" : "s have") + " nothing to attach to yet";
                                    } else if (!open.isEmpty()) {
                                       this.waitReason = "Can't reach "
                                          + open.size()
                                          + " block"
                                          + (open.size() == 1 ? "" : "s")
                                          + (this.scaffold.get() && this.scaffoldItem(mc) == null ? " (no spare blocks to build up with)" : "");
                                    } else {
                                       this.waitReason = "Retrying " + waiting + " block" + (waiting == 1 ? "" : "s") + " shortly";
                                    }

                                    this.chooseDelay = 2;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            } else if (!this.escape(mc, feet, layer)) {
               this.waitReason = "Boxed in, and nothing to climb or dig out with";
               this.chooseDelay = 20;
            }
         }
      }
   }

   private List<BlockPos> ownTempInTheWay(List<BlockPos> inTheWay) {
      List<BlockPos> out = new ArrayList<>();

      for (BlockPos pos : inTheWay) {
         if (this.supportPlaced.contains(pos) || this.scaffoldBlocks.contains(pos)) {
            out.add(pos);
         }
      }

      return out;
   }

   private boolean stayOnBuild(ClientWorld world, BlockPos feet) {
      if (this.boxMin != null && this.walk.get() && System.currentTimeMillis() >= this.descendUntil) {
         int layer = this.workLayer;
         return this.preferTop(layer) && feet.getY() - this.boxMin.getY() >= 2 && this.onBuild(world, feet);
      } else {
         return false;
      }
   }

   private boolean preferTop(int layer) {
      return this.boxMin != null && layer != Integer.MAX_VALUE && this.boxMax.getY() - this.boxMin.getY() >= 2 && layer > this.boxMin.getY() && !this.compact();
   }

   private boolean compact() {
      return this.boxMin != null && Math.max(this.boxMax.getX() - this.boxMin.getX(), this.boxMax.getZ() - this.boxMin.getZ()) + 1 <= 6;
   }

   private boolean raisePillar(MinecraftClient mc, List<AutoSchematicBuilderModule.Target> open) {
      if (this.scaffold.get() && !open.isEmpty()) {
         ClientPlayerEntity p = mc.player;
         ClientWorld world = mc.world;
         double reach = this.reach.getFloat() - 0.25;
         int feetY = (int)Math.floor(p.getY() + 0.01);
         int most = Math.min(3, this.scaffoldCount(mc));
         int fx = (int)Math.floor(p.getX());
         int fz = (int)Math.floor(p.getZ());
         int bestH = Integer.MIN_VALUE;
         int bestCov = 0;

         for (int h = feetY + 1; h <= feetY + most; h++) {
            boolean clear = true;

            for (int y = feetY; y <= h + 1 && clear; y++) {
               BlockPos c = new BlockPos(fx, y, fz);
               clear = y < h + 2 && (y == feetY || Pathfinder.passable(world, c)) && (y >= h || !this.byPos.containsKey(c));
               if (y == h + 1) {
                  clear = clear && Pathfinder.passable(world, c);
               }
            }

            if (!clear) {
               break;
            }

            Vec3d eye = new Vec3d(p.getX(), h + 1.62, p.getZ());
            int cov = 0;

            for (AutoSchematicBuilderModule.Target t : open) {
               if ((t.pos().getX() != fx || t.pos().getZ() != fz)
                  && eye.distanceTo(Vec3d.ofCenter(t.pos())) <= reach + 1.0
                  && pick(this.options(mc, t), world, t.pos(), eye, reach) != null) {
                  cov++;
               }
            }

            if (cov > bestCov) {
               bestCov = cov;
               bestH = h;
            }
         }

         if (bestCov == 0) {
            return false;
         } else {
            this.selfFor = null;
            this.escapeTower = false;
            this.towerGoalY = bestH;
            this.towerPitch = Float.NaN;
            this.jumpFromY = Integer.MIN_VALUE;
            this.waitReason = "";
            this.phase = AutoSchematicBuilderModule.Phase.TOWER_UP;
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean planBridge(MinecraftClient mc, List<AutoSchematicBuilderModule.Target> open, long now) {
      if (this.walk.get() && !open.isEmpty() && now >= this.bridgeFailUntil) {
         ClientPlayerEntity p = mc.player;
         ClientWorld world = mc.world;
         BlockPos feet = playerFeet(p);

         record Cand(AutoSchematicBuilderModule.Target t, Placement.Option o, BlockPos stand, double dist) {
         }

         List<Cand> cands = new ArrayList<>();

         for (AutoSchematicBuilderModule.Target t : open) {
            BlockPos pos = t.pos();
            if (Pathfinder.passable(world, pos.down()) && Pathfinder.passable(world, pos.up()) && Pathfinder.passable(world, pos.up(2))) {
               for (Placement.Option o : this.options(mc, t)) {
                  Direction d = o.side();
                  if (d.getOffsetY() == 0) {
                     BlockPos from = o.neighbour();
                     BlockPos stand = from.up();
                     if (Pathfinder.standable(world, stand)) {
                        double hx = from.getX() + 0.5 + d.getOffsetX() * 0.5 + o.ox();
                        double hy = from.getY() + 0.5 + o.oy();
                        double hz = from.getZ() + 0.5 + d.getOffsetZ() * 0.5 + o.oz();
                        double ex = from.getX() + 0.5 + d.getOffsetX() * 0.75;
                        double ey = stand.getY() + 1.27;
                        double ez = from.getZ() + 0.5 + d.getOffsetZ() * 0.75;
                        if ((o.looks() & 1 << Placement.lookClass(hx - ex, hy - ey, hz - ez)) != 0) {
                           cands.add(new Cand(t, o, stand, Math.sqrt(stand.getSquaredDistance(feet))));
                        }
                     }
                  }
               }
            }
         }

         if (cands.isEmpty()) {
            return false;
         } else {
            cands.sort(Comparator.comparingDouble(Cand::dist));

            for (int i = 0; i < Math.min(5, cands.size()); i++) {
               Cand c = cands.get(i);
               Long until = this.skipUntil.get(c.t().pos());
               if (until == null || until <= now) {
                  BlockPos goal = c.stand();
                  List<BlockPos> route = goal.equals(feet)
                     ? List.of(goal)
                     : Pathfinder.find(world, feet, n -> n.equals(goal), n -> Math.sqrt(n.getSquaredDistance(goal)), this.byPos.keySet(), 2500);
                  if (route != null) {
                     this.attempts.merge(c.t().pos(), 1, Integer::sum);
                     this.beginWalk(c.t(), route, false, 0);
                     this.toBestSpot = true;
                     this.bridgeAfterWalk = true;
                     this.bridgeFor = c.t();
                     this.bridgeFrom = c.o().neighbour();
                     this.bridgeOption = c.o();
                     this.waitReason = "";
                     return true;
                  }
               }
            }

            this.bridgeFailUntil = now + 2000L;
            return false;
         }
      } else {
         return false;
      }
   }

   private void bridge(MinecraftClient mc, long now, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      AutoSchematicBuilderModule.Target t = this.bridgeFor;
      Placement.Option o = this.bridgeOption;
      if (t != null && o != null && !placed(world, t) && world.getBlockState(t.pos()).isReplaceable() && ++this.bridgeTicks <= 100) {
         BlockPos from = this.bridgeFrom;
         Direction d = o.side();
         int feetY = (int)Math.floor(p.getY() + 0.01);
         if (feetY != from.getY() + 1 || Math.abs(p.getX() - (from.getX() + 0.5)) > 1.0 || Math.abs(p.getZ() - (from.getZ() + 0.5)) > 1.0) {
            this.endBridge(mc);
         } else if (!this.ensureItem(mc, t.item())) {
            this.setKeys(mc, false, false, false, true);
         } else {
            double tx = from.getX() + 0.5 + d.getOffsetX() * 0.75;
            double tz = from.getZ() + 0.5 + d.getOffsetZ() * 0.75;
            double dx = tx - p.getX();
            double dz = tz - p.getZ();
            Vec3d hit = new Vec3d(
               from.getX() + 0.5 + d.getOffsetX() * 0.5 + o.ox(), from.getY() + 0.5 + o.oy(), from.getZ() + 0.5 + d.getOffsetZ() * 0.5 + o.oz()
            );
            float[] a = Placement.angles(p.getEyePos(), hit);
            this.look.lookAt(p, a[0], a[1]);
            boolean[] k = shuffleKeys(p, dx, dz);
            boolean moving = Math.hypot(dx, dz) > 0.05 && p.isSneaking() && p.isOnGround();
            this.setKeys(mc, moving && k[0], moving && k[1], moving && k[2], moving && k[3], false, true);
            this.sneakHold = 16;
            BlockHitResult aimed = crosshair(p, this.reach.getFloat(), from, d);
            if (aimed != null && resting && serverSees(p) && this.cooldown <= 0 && this.switchDelay <= 0) {
               ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, aimed);
               p.swingHand(Hand.MAIN_HAND);
               this.lastClickTick = this.tickCounter;
               this.lastProgressMs = now;
               if (r.isAccepted()) {
                  this.attempts.remove(t.pos());
                  if (clicksToFix(t.state(), t.state().getBlock().getDefaultState()) > 0) {
                     this.toAdjust.add(t.pos());
                  }

                  this.placeTimes.addLast(System.currentTimeMillis());

                  while (this.placeTimes.size() > 30) {
                     this.placeTimes.pollFirst();
                  }
               } else {
                  this.skipUntil.put(t.pos(), now + 6000L);
               }

               this.cooldown = Math.max(1, (int)Math.round(this.delay.getFloat() + this.rng.nextGaussian() * 0.8)) + this.slowdown;
               this.endBridge(mc);
            }
         }
      } else {
         if (t != null && !placed(world, t) && this.bridgeTicks > 100) {
            this.skipUntil.put(t.pos(), now + 6000L);
         }

         this.endBridge(mc);
      }
   }

   private void endBridge(MinecraftClient mc) {
      this.bridgeFor = null;
      this.bridgeOption = null;
      this.bridgeFrom = null;
      this.bridgeTicks = 0;
      this.sneakHold = Math.max(this.sneakHold, 12);
      this.releaseKeysKeepSneak(mc);
      this.phase = AutoSchematicBuilderModule.Phase.IDLE;
   }

   private static boolean misoriented(ClientWorld world, AutoSchematicBuilderModule.Target t) {
      BlockState have = world.getBlockState(t.pos());
      if (have.getBlock() != t.state().getBlock()) {
         return false;
      } else {
         Map<String, String> w = Placement.props(t.state(), false);
         Map<String, String> h = Placement.props(have, false);

         for (String k : ORIENT) {
            String a = w.get(k);
            if (a != null && h.get(k) != null && !a.equals(h.get(k))) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean clearInTheWay(MinecraftClient mc, List<BlockPos> spots, boolean mayWalk, long now) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      Vec3d eye = p.getEyePos();
      double reach = this.reach.getFloat();
      BlockPos best = null;
      BlockPos far = null;
      double bestD = Double.MAX_VALUE;
      double farD = Double.MAX_VALUE;

      for (BlockPos pos : spots) {
         Long until = this.skipUntil.get(pos);
         if ((until == null || until <= now) && this.clearable(world, p, pos)) {
            double d = eye.distanceTo(Vec3d.ofCenter(pos));
            if (d <= reach - 0.2 && visibleFace(world, p, eye, pos) != null) {
               if (d < bestD) {
                  bestD = d;
                  best = pos;
               }
            } else if (d < farD) {
               farD = d;
               far = pos;
            }
         }
      }

      if (best != null) {
         AutoSchematicBuilderModule.Target t = this.byPos.get(best);
         if (t != null && placed(world, t)) {
            this.reorientTries.merge(best, 1, Integer::sum);
         }

         this.digQueue.clear();
         this.digQueue.add(best);
         this.digTicks = 0;
         this.waitReason = "Clearing a block in the way";
         this.phase = AutoSchematicBuilderModule.Phase.DIG;
         return true;
      } else {
         if (far != null && mayWalk && this.walk.get()) {
            if (this.attempts.merge(far, 1, Integer::sum) > 4) {
               this.attempts.remove(far);
               this.skipUntil.put(far, now + 3000L);
               return false;
            }

            if (this.walkToReach(mc, far)) {
               this.waitReason = "Going to clear a block in the way";
               return true;
            }

            this.skipUntil.put(far, now + 3000L);
         }

         return false;
      }
   }

   private boolean clearable(ClientWorld world, ClientPlayerEntity p, BlockPos pos) {
      BlockState s = world.getBlockState(pos);
      if (!s.isReplaceable() && s.getFluidState().isEmpty()) {
         float hard = s.getHardness(world, pos);
         if (!(hard < 0.0F) && (!(hard > 5.0F) || hasToolFor(p.getInventory(), s))) {
            if (world.getBlockEntity(pos) != null) {
               Item item = s.getBlock().asItem();
               boolean ours = false;

               for (AutoSchematicBuilderModule.Target t : this.targets) {
                  if (t.item() == item) {
                     ours = true;
                     break;
                  }
               }

               if (!ours) {
                  return false;
               }
            }

            return !standingOn(p, pos) || dropBelow(world, pos) <= 1;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean onBuild(ClientWorld world, BlockPos feet) {
      BlockPos below = feet.down();
      AutoSchematicBuilderModule.Target b = this.byPos.get(below);
      return b != null && !"cherryblossom:support".equals(b.id()) && placed(world, b)
         ? true
         : this.supportPlaced.contains(below) && !world.getBlockState(below).isReplaceable();
   }

   private boolean onTopAt(ClientWorld world, BlockPos feet, int layer) {
      return feet.getY() >= layer && feet.getY() <= layer + 1 && this.onBuild(world, feet);
   }

   private boolean planTop(MinecraftClient mc, AutoSchematicBuilderModule.Target t, List<Placement.Option> opts, int layer) {
      if (opts.isEmpty()) {
         return false;
      } else {
         ClientWorld world = mc.world;
         ClientPlayerEntity p = mc.player;
         double reach = this.reach.getFloat() - 0.25;
         Vec3d c = Vec3d.ofCenter(t.pos());
         Predicate<BlockPos> ok = n -> {
            if (n.getY() >= layer && n.getY() <= layer + 1 && !n.equals(t.pos()) && !n.up().equals(t.pos())) {
               Vec3d eye = new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5);
               return !(eye.distanceTo(c) > reach + 0.9) && this.onBuild(world, n) ? pick(opts, world, t.pos(), eye, reach) != null : false;
            } else {
               return false;
            }
         };
         List<BlockPos> route = Pathfinder.find(
            world,
            playerFeet(p),
            ok,
            n -> Math.max(0.0, Math.sqrt(c.squaredDistanceTo(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5)) - reach) + Math.max(0, layer - n.getY()) * 1.5,
            Set.of(),
            1500
         );
         if (route == null) {
            return false;
         } else {
            List<BlockPos> var15 = this.betterSpot(mc, t, route, ok, layer, layer + 1, Set.of());
            boolean moved = var15 != route;
            BlockPos last = (BlockPos)var15.get(var15.size() - 1);
            if (var15.size() == 1 && Math.hypot(last.getX() + 0.5 - p.getX(), last.getZ() + 0.5 - p.getZ()) < 0.2) {
               return false;
            } else {
               this.attempts.merge(t.pos(), 1, Integer::sum);
               this.beginWalk(t, var15, false, 0);
               this.toBestSpot = moved;
               this.topWalk = true;
               this.topLayer = layer;
               return true;
            }
         }
      }
   }

   private boolean planClimb(MinecraftClient mc, AutoSchematicBuilderModule.Target t, int layer) {
      int most = Math.min(12, this.scaffoldCount(mc));
      if (most == 0) {
         return false;
      } else {
         ClientWorld world = mc.world;
         int tx = t.pos().getX();
         int tz = t.pos().getZ();
         int[] top = new int[1];
         List<BlockPos> route = Pathfinder.find(world, playerFeet(mc.player), n -> {
            for (int h : new int[]{layer - 1, layer}) {
               if (n.getY() < h && h - n.getY() <= most) {
                  boolean clear = true;

                  for (int y = n.getY(); y <= h + 2 && clear; y++) {
                     BlockPos cell = new BlockPos(n.getX(), y, n.getZ());
                     clear = Pathfinder.passable(world, cell) && !this.byPos.containsKey(cell);
                  }

                  if (clear) {
                     for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
                        for (int sy = Math.max(h, layer); sy <= Math.min(h + 1, layer + 1); sy++) {
                           BlockPos s = new BlockPos(n.getX() + d.getOffsetX(), sy, n.getZ() + d.getOffsetZ());
                           if (Pathfinder.standable(world, s) && this.onBuild(world, s)) {
                              top[0] = h;
                              return true;
                           }
                        }
                     }
                  }
               }
            }

            return false;
         }, n -> Math.abs(n.getX() - tx) + Math.abs(n.getZ() - tz), this.byPos.keySet(), 2500);
         if (route == null) {
            return false;
         } else {
            this.attempts.merge(t.pos(), 1, Integer::sum);
            this.beginWalk(t, route, true, top[0]);
            this.towerFor = t;
            return true;
         }
      }
   }

   private Placement.Option selfOption(MinecraftClient mc, AutoSchematicBuilderModule.Target t) {
      for (Placement.Option o : this.options(mc, t)) {
         if (!o.sneak() && o.side() == Direction.UP && o.neighbour().equals(t.pos().down())) {
            for (int q = 0; q < 4; q++) {
               if ((o.looks() & 1 << q * 3 + 1) != 0) {
                  return o;
               }
            }
         }
      }

      return null;
   }

   private boolean startSelfPillar(MinecraftClient mc, AutoSchematicBuilderModule.Target t) {
      if(layerByLayer.get()&&t.pos().getY()>activeLayer)return false;
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      if (p.isOnGround() && Pathfinder.passable(world, t.pos().up(2))) {
         Placement.Option o = this.selfOption(mc, t);
         if (o == null) {
            return false;
         } else if (!(Math.abs(p.getX() - (t.pos().getX() + 0.5)) > 0.24) && !(Math.abs(p.getZ() - (t.pos().getZ() + 0.5)) > 0.24)) {
            float from = p.getYaw();
            float yaw = from;
            int q = (int)Math.floor(HumanLook.wrap(from) / 90.0F + 0.5F) & 3;
            if ((o.looks() & 1 << q * 3 + 1) == 0) {
               float bestTurn = Float.MAX_VALUE;

               for (int k = 0; k < 4; k++) {
                  if ((o.looks() & 1 << k * 3 + 1) != 0) {
                     float want = k * 90.0F + (this.rng.nextFloat() - 0.5F) * 30.0F;
                     float turn = Math.abs(HumanLook.wrap(want - from));
                     if (turn < bestTurn) {
                        bestTurn = turn;
                        yaw = from + HumanLook.wrap(want - from);
                     }
                  }
               }
            }

            this.selfFor = t;
            this.selfYaw = yaw;
            this.selfFails = 0;
            this.towerPitch = Float.NaN;
            this.jumpFromY = Integer.MIN_VALUE;
            this.attempts.merge(t.pos(), 1, Integer::sum);
            this.phase = AutoSchematicBuilderModule.Phase.TOWER_UP;
            return true;
         } else {
            this.beginWalk(t, List.of(t.pos()), false, 0);
            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean blocksBody(ClientWorld world, AutoSchematicBuilderModule.Target t) {
      VoxelShape shape = t.state().getCollisionShape(world, t.pos());
      return !shape.isEmpty() && shape.getMax(Axis.Y) > 0.2;
   }

   private boolean outsideBox(BlockPos c) {
      return this.boxMin == null
         || c.getX() < this.boxMin.getX()
         || c.getX() > this.boxMax.getX()
         || c.getZ() < this.boxMin.getZ()
         || c.getZ() > this.boxMax.getZ();
   }

   private static boolean pass(ClientWorld world, BlockPos c, BlockPos solid, Set<BlockPos> air) {
      return c.equals(solid) ? false : air.contains(c) || Pathfinder.passable(world, c);
   }

   private static boolean stand(ClientWorld world, BlockPos c, BlockPos solid, Set<BlockPos> air) {
      BlockPos below = c.down();
      return pass(world, c, solid, air) && pass(world, c.up(), solid, air)
         ? below.equals(solid) || !air.contains(below) && Pathfinder.solid(world, below, world.getBlockState(below))
         : false;
   }

   private boolean canEscape(ClientWorld world, BlockPos feet, int layer, BlockPos solid, Set<BlockPos> air) {
      ArrayDeque<BlockPos> todo = new ArrayDeque<>();
      Set<Long> seen = new HashSet<>();
      todo.add(feet);
      seen.add(feet.asLong());

      while (!todo.isEmpty()) {
         if (seen.size() >= 300) {
            return true;
         }

         BlockPos c = todo.poll();
         if (c.getY() >= layer || this.outsideBox(c)) {
            return true;
         }

         boolean head = pass(world, c.up(2), solid, air);

         for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
            BlockPos n = c.offset(d);
            BlockPos next = null;
            if (stand(world, n, solid, air)) {
               next = n;
            } else if (head && stand(world, n.up(), solid, air)) {
               next = n.up();
            } else if (pass(world, n, solid, air) && pass(world, n.up(), solid, air)) {
               for (int k = 1; k <= 3; k++) {
                  BlockPos m = n.down(k);
                  if (stand(world, m, solid, air)) {
                     next = m;
                     break;
                  }

                  if (!pass(world, m, solid, air)) {
                     break;
                  }
               }
            }

            if (next != null && seen.add(next.asLong())) {
               todo.add(next);
            }
         }
      }

      return false;
   }

   private boolean escape(MinecraftClient mc, BlockPos feet, int layer) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      AutoSchematicBuilderModule.Target own = this.byPos.get(feet);
      if (own != null
         && !placed(world, own)
         && world.getBlockState(feet).isReplaceable()
         && (creative(mc) || this.inInventory.contains(own.item()))
         && this.startSelfPillar(mc, own)) {
         this.waitReason = "";
         return true;
      } else {
         int blocks = this.scaffold.get() ? Math.min(12, this.scaffoldCount(mc)) : 0;
         if (blocks > 0) {
            for (int h = feet.getY() + 1; h <= feet.getY() + blocks; h++) {
               BlockPos below = new BlockPos(feet.getX(), h - 1, feet.getZ());
               if (this.byPos.containsKey(below) || !Pathfinder.passable(world, below) && h - 1 > feet.getY()) {
                  break;
               }

               BlockPos at = new BlockPos(feet.getX(), h, feet.getZ());
               if (!Pathfinder.passable(world, at) || !Pathfinder.passable(world, at.up())) {
                  break;
               }

               boolean head = Pathfinder.passable(world, at.up(2));
               boolean out = false;

               for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
                  BlockPos n = at.offset(d);
                  BlockPos step = Pathfinder.standable(world, n) ? n : (head && Pathfinder.standable(world, n.up()) ? n.up() : null);
                  if (step != null && this.canEscape(world, step, layer, null, Set.of())) {
                     out = true;
                     break;
                  }
               }

               if (out) {
                  this.selfFor = null;
                  this.towerFor = null;
                  this.towerGoalY = h;
                  this.escapeTower = true;
                  this.towerPitch = Float.NaN;
                  this.jumpFromY = Integer.MIN_VALUE;
                  this.waitReason = "";
                  this.phase = AutoSchematicBuilderModule.Phase.TOWER_UP;
                  return true;
               }
            }
         }

         List<BlockPos> bestDig = null;
         double bestCost = Double.MAX_VALUE;

         for (Direction dx : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
            BlockPos n = feet.offset(dx);
            List<List<BlockPos>> ways = new ArrayList<>();
            if (Pathfinder.solid(world, n, world.getBlockState(n))) {
               ways.add(List.of(feet.up(2), n.up(), n.up(2)));
            }

            if (Pathfinder.solid(world, n.down(), world.getBlockState(n.down()))) {
               ways.add(List.of(n.up(), n));
            }

            for (List<BlockPos> way : ways) {
               List<BlockPos> clear = new ArrayList<>();
               double cost = 0.0;
               boolean ok = true;

               for (BlockPos c : way) {
                  if (!Pathfinder.passable(world, c)) {
                     BlockState s = world.getBlockState(c);
                     float hard = s.getHardness(world, c);
                     if (hard < 0.0F || hard > 10.0F || !s.getFluidState().isEmpty()) {
                        ok = false;
                        break;
                     }

                     clear.add(c);
                     float speed = s.calcBlockBreakingDelta(p, world, c);
                     cost += 1.0 + (speed > 0.0F ? 1.0 / speed : 1000.0) / 20.0;
                  }
               }

               if (ok && !clear.isEmpty() && !(cost >= bestCost) && this.canEscape(world, feet, layer, null, new HashSet<>(clear))) {
                  bestCost = cost;
                  bestDig = clear;
               }
            }
         }

         if (bestDig == null) {
            return false;
         } else {
            this.digQueue.clear();
            this.digQueue.addAll(bestDig);
            this.digTicks = 0;
            this.waitReason = "";
            this.phase = AutoSchematicBuilderModule.Phase.DIG;
            return true;
         }
      }
   }

   private void dig(MinecraftClient mc, long now, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      Vec3d eye = p.getEyePos();
      if (this.digQueue.removeIf(cx -> Pathfinder.passable(world, cx))) {
         this.lastProgressMs = now;
      }

      BlockPos next = null;
      Vec3d face = null;

      for (BlockPos c : this.digQueue) {
         if (c.equals(this.breaking)) {
            next = c;
            face = visibleFace(world, p, eye, c);
            break;
         }

         Vec3d f = visibleFace(world, p, eye, c);
         if (f != null && next == null) {
            next = c;
            face = f;
         }
      }

      if (next != null && face != null && ++this.digTicks <= 900) {
         if (this.digEye == null || !next.equals(this.digAt) || this.digEye.distanceTo(eye) > 0.15) {
            this.digAngles = Placement.angles(eye, face);
            this.digEye = eye;
            this.digAt = next;
         }

         this.look.lookAt(p, this.digAngles[0], this.digAngles[1]);
         this.releaseKeys(mc);
         this.mine(mc, p, next, resting);
      } else {
         if (this.breaking != null) {
            BotDig.stop(mc);
         }

         this.breaking = null;
         this.digQueue.clear();
         this.releaseKeys(mc);
         this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      }
   }

   private static Vec3d visibleFace(ClientWorld world, ClientPlayerEntity p, Vec3d eye, BlockPos pos) {
      Vec3d c = Vec3d.ofCenter(pos);
      Vec3d best = null;
      double bestD = Double.MAX_VALUE;

      for (Direction d : Direction.values()) {
         Vec3d f = c.add(d.getOffsetX() * 0.5, d.getOffsetY() * 0.5, d.getOffsetZ() * 0.5);
         Vec3d to = f.subtract(eye);
         if (!(to.x * d.getOffsetX() + to.y * d.getOffsetY() + to.z * d.getOffsetZ() >= -0.05)) {
            Vec3d dir = to.normalize();
            BlockHitResult r = world.raycast(new RaycastContext(eye, f.add(dir.multiply(0.1)), ShapeType.OUTLINE, FluidHandling.NONE, p));
            if (r.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK && r.getBlockPos().equals(pos)) {
               double dist = to.length();
               if (dist < bestD && dist < 4.2) {
                  bestD = dist;
                  best = f;
               }
            }
         }
      }

      return best;
   }

   private static boolean nearLedge(ClientWorld world, ClientPlayerEntity p, int floorY) {
      double x = p.getX();
      double z = p.getZ();

      for (double dx : new double[]{-0.75, 0.0, 0.75}) {
         for (double dz : new double[]{-0.75, 0.0, 0.75}) {
            if (dx != 0.0 || dz != 0.0) {
               BlockPos n = new BlockPos((int)Math.floor(x + dx), floorY, (int)Math.floor(z + dz));
               if (Pathfinder.passable(world, n) && Pathfinder.passable(world, n.down())) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static boolean nearDrop(ClientWorld world, BlockPos feet) {
      for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
         BlockPos n = feet.offset(d);
         if (Pathfinder.passable(world, n) && Pathfinder.passable(world, n.down()) && Pathfinder.passable(world, n.down(2))) {
            return true;
         }
      }

      return false;
   }

   private void auditCompletion(ClientWorld world){
      if(targets.isEmpty())return;
      for(int i=0;i<Math.min(512,previewTargets.size());i++){
         if(visualAuditCursor>=previewTargets.size())visualAuditCursor=0;
         Target visual=previewTargets.get(visualAuditCursor++);
         if(!byPos.containsKey(visual.pos()))schematicMesh.placed(visual.pos(),world.getBlockState(visual.pos()).getBlock()==visual.state().getBlock());
      }
      if(lastLayerMode!=layerByLayer.get()){lastLayerMode=layerByLayer.get();candidateStart=0;layerScan=0;layerScannedDone=0;layerIncomplete=false;layerStableSince=0;activeLayer=layers.firstKey();}
      long deadline=System.nanoTime()+2_000_000L;int count=0;
      while(auditCursor<targets.size()&&count++<2048){
         Target t=targets.get(auditCursor++);boolean done=completeTarget(world,t);schematicMesh.placed(t.pos(),done);
         if(done)auditDone++;else auditLowest=Math.min(auditLowest,t.pos().getY());
         if((count&63)==0&&System.nanoTime()>deadline)break;
      }
      if(auditCursor==targets.size()){
         long now=System.currentTimeMillis();
         if(auditDone==targets.size()){
            if(completeSince==0)completeSince=now;
            completionVerified=now-completeSince>=confirmMs(MinecraftClient.getInstance());
         }else{
            completionVerified=false;completeSince=0;
            if(activeLayer==Integer.MAX_VALUE||auditLowest<activeLayer){activeLayer=auditLowest;layerScan=0;layerScannedDone=0;layerIncomplete=false;layerStableSince=0;candidateStart=0;}
         }
         auditCursor=0;auditDone=0;auditLowest=Integer.MAX_VALUE;
      }
   }
   private long layerStableSince;
   private int layerDone,layerScannedDone;
   private boolean completeTarget(ClientWorld world,Target t){return placed(world,t)&&(!fixFacing.get()||!misoriented(world,t))&&(!adjustable.contains(t.pos())||clicksToFix(t.state(),world.getBlockState(t.pos()))==0);}
   private List<Target> activeTargets(){return layerByLayer.get()?layers.getOrDefault(activeLayer,List.of()):targets;}
   private void advanceLayer(ClientWorld world){
      if(!layerByLayer.get())return;
      List<Target> work=activeTargets();if(work.isEmpty())return;
      long deadline=System.nanoTime()+1_500_000L;int examined=0;
      while(layerScan<work.size()&&examined++<1024){
         Target t=work.get(layerScan++);if(!completeTarget(world,t))layerIncomplete=true;else layerScannedDone++;
         if(System.nanoTime()>deadline)break;
      }
      if(layerScan==work.size()){
         layerDone=layerScannedDone;
         if(layerIncomplete)layerStableSince=0;
         else if(layerStableSince==0)layerStableSince=System.currentTimeMillis();
         else if(System.currentTimeMillis()-layerStableSince>=confirmMs(MinecraftClient.getInstance())){
            Integer next=layers.higherKey(activeLayer);activeLayer=next==null?Integer.MAX_VALUE:next;
            candidateStart=0;layerStableSince=0;layerDone=0;supportsAt=0;stallSince=0;
            if(next==null){refreshCursor=0;refreshDone=0;refreshNeed.clear();refreshNames.clear();}
         }
         layerScan=0;layerIncomplete=false;layerScannedDone=0;
      }
   }
   public String layerStatus(){
      if(!preparationStatus().isEmpty())return preparationStatus();
      if(layers.isEmpty())return "Choose a schematic";
      if(!layerByLayer.get())return "Adaptive build  -  "+placedCount+"/"+targets.size();
      if(activeLayer==Integer.MAX_VALUE)return "Verifying all blocks";
      int index=layers.headMap(activeLayer,false).size()+1;
      return "Layer "+index+"/"+layers.size()+"  -  "+layerDone+"/"+activeTargets().size();
   }
   private int currentLayer(MinecraftClient mc,long now,boolean free){return activeLayer;}

   private boolean hasAbove(ClientWorld world, int layer) {
      return layers.higherKey(layer)!=null;
   }

   private boolean hasSupportBelow(AutoSchematicBuilderModule.Target t, long now) {
      for (AutoSchematicBuilderModule.Target s : this.supports) {
         if (s.pos().getX() == t.pos().getX() && s.pos().getZ() == t.pos().getZ() && s.pos().getY() < t.pos().getY()) {
            Long until = this.skipUntil.get(s.pos());
            if (until == null || until <= now) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean tooManyAttempts(AutoSchematicBuilderModule.Target t, long now) {
      if (this.attempts.getOrDefault(t.pos(), 0) < 4) {
         return false;
      } else {
         this.attempts.remove(t.pos());
         this.optionCache.remove(t.pos());
         this.skipUntil.put(t.pos(), now + 1500L);
         return true;
      }
   }

   private List<Placement.Option> options(MinecraftClient mc, AutoSchematicBuilderModule.Target t) {
      ClientWorld world = mc.world;
      int sig = 0;

      for (Direction d : Direction.values()) {
         sig <<= 1;
         if (!world.getBlockState(t.pos().offset(d)).isReplaceable()) {
            sig |= 1;
         }
      }

      AutoSchematicBuilderModule.Cached c = this.optionCache.get(t.pos());
      if (c != null && c.signature() == sig) {
         return c.options();
      } else {
         List<Placement.Option> opts = Placement.options(mc.player, world, t.pos(), t.state(), new ItemStack(t.item(), 1));
         this.optionCache.put(t.pos(), new AutoSchematicBuilderModule.Cached(sig, opts));
         return opts;
      }
   }

   private boolean planWalk(MinecraftClient mc, AutoSchematicBuilderModule.Target t, List<Placement.Option> opts) {
      ClientWorld world = mc.world;
      boolean body = blocksBody(world, t);
      int layer = this.workLayer;
      double reach = this.reach.getFloat() - 0.25;
      Vec3d c = Vec3d.ofCenter(t.pos());
      Predicate<BlockPos> ok = n -> {
         if (!n.equals(t.pos()) && !n.up().equals(t.pos()) && !n.up(2).equals(t.pos()) && !n.up(3).equals(t.pos())) {
            Vec3d eye = new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5);
            if (eye.distanceTo(c) > reach + 0.9) {
               return false;
            } else {
               return pick(opts, world, t.pos(), eye, reach) == null ? false : !body || this.canEscape(world, n, layer, t.pos(), Set.of());
            }
         } else {
            return false;
         }
      };
      List<BlockPos> route = Pathfinder.find(
         world,
         playerFeet(mc.player),
         ok,
         n -> Math.max(0.0, Math.sqrt(c.squaredDistanceTo(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5)) - reach),
         this.byPos.keySet(),
         2500
      );
      if (route == null) {
         return false;
      } else {
         List<BlockPos> var18 = this.betterSpot(mc, t, route, ok, t.pos().getY() - 3, t.pos().getY() + 1, this.byPos.keySet());
         boolean moved = var18 != route;
         ClientPlayerEntity p = mc.player;
         BlockPos last = (BlockPos)var18.get(var18.size() - 1);
         double off = Math.hypot(last.getX() + 0.5 - p.getX(), last.getZ() + 0.5 - p.getZ());
         if (var18.size() == 1 && off < 0.2) {
            return false;
         } else {
            this.attempts.merge(t.pos(), 1, Integer::sum);
            this.beginWalk(t, var18, false, 0);
            this.toBestSpot = moved;
            return true;
         }
      }
   }

   private List<BlockPos> betterSpot(
      MinecraftClient mc, AutoSchematicBuilderModule.Target t, List<BlockPos> route, Predicate<BlockPos> ok, int yMin, int yMax, Set<BlockPos> avoid
   ) {
      ClientWorld world = mc.world;
      double reach = this.reach.getFloat() - 0.25;
      List<AutoSchematicBuilderModule.Target> others = new ArrayList<>(this.openNow);
      others.sort(Comparator.comparingDouble(o -> o.pos().getSquaredDistance(t.pos())));
      if (others.size() > 24) {
         others = others.subList(0, 24);
      }

      if (others.size() < 3) {
         return route;
      } else {
         BlockPos found = route.get(route.size() - 1);
         BlockPos best = found;
         int bestCov = this.coverage(mc, found, others, reach);
         double bestOff = 0.0;
         int tx = t.pos().getX();
         int tz = t.pos().getZ();
         long deadline = System.nanoTime() + 4000000L;

         label70:
         for (int y = yMin; y <= yMax; y++) {
            for (int dx = -4; dx <= 4; dx++) {
               for (int dz = -4; dz <= 4; dz++) {
                  if (System.nanoTime() > deadline) {
                     break label70;
                  }

                  BlockPos n = new BlockPos(tx + dx, y, tz + dz);
                  if (!n.equals(found) && Pathfinder.standable(world, n) && ok.test(n)) {
                     int cov = this.coverage(mc, n, others, reach);
                     double off = Math.sqrt(n.getSquaredDistance(found));
                     if (cov > bestCov + 1 || cov == bestCov && best != found && off < bestOff) {
                        best = n;
                        bestCov = cov;
                        bestOff = off;
                     }
                  }
               }
            }
         }

         if (best.equals(found)) {
            return route;
         } else {
            BlockPos goal = best;
            List<BlockPos> better = Pathfinder.find(
               world, playerFeet(mc.player), nx -> nx.equals(goal), nx -> Math.sqrt(nx.getSquaredDistance(goal)), avoid, 2500
            );
            return better != null ? better : route;
         }
      }
   }

   private int coverage(MinecraftClient mc, BlockPos n, List<AutoSchematicBuilderModule.Target> blocks, double reach) {
      ClientWorld world = mc.world;
      Vec3d eye = new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5);
      int count = 0;

      for (AutoSchematicBuilderModule.Target o : blocks) {
         BlockPos op = o.pos();
         if (!op.equals(n)
            && !op.equals(n.up())
            && !(eye.distanceTo(Vec3d.ofCenter(op)) > reach + 0.9)
            && pick(this.options(mc, o), world, op, eye, reach) != null) {
            count++;
         }
      }

      return count;
   }

   private boolean planTower(MinecraftClient mc, AutoSchematicBuilderModule.Target t, List<Placement.Option> opts) {
      int most = Math.min(12, this.scaffoldCount(mc));
      if (most == 0) {
         if (!this.warnedScaffold) {
            message(mc, "Some blocks are too high to reach. Carry some dirt or cobblestone so I can build up to them.");
         }

         this.warnedScaffold = true;
         return false;
      } else {
         double reach = this.reach.getFloat() - 0.25;
         ClientWorld world = mc.world;
         List<AutoSchematicBuilderModule.TowerSpot> spots = this.towerSpots(mc, t, opts, reach, most);

         for (int i = 0; i < Math.min(4, spots.size()); i++) {
            AutoSchematicBuilderModule.TowerSpot s = spots.get(i);
            List<BlockPos> route = Pathfinder.find(
               world, playerFeet(mc.player), n -> n.equals(s.ground()), n -> Math.sqrt(n.getSquaredDistance(s.ground())), this.byPos.keySet(), 2500
            );
            if (route != null) {
               this.attempts.merge(t.pos(), 1, Integer::sum);
               this.beginWalk(t, route, true, s.top());
               this.towerFor = t;
               return true;
            }
         }

         return false;
      }
   }

   private List<AutoSchematicBuilderModule.TowerSpot> towerSpots(
      MinecraftClient mc, AutoSchematicBuilderModule.Target t, List<Placement.Option> opts, double reach, int most
   ) {
      ClientWorld world = mc.world;
      ClientPlayerEntity p = mc.player;
      int tx = t.pos().getX();
      int ty = t.pos().getY();
      int tz = t.pos().getZ();
      List<AutoSchematicBuilderModule.Target> others = new ArrayList<>(this.openNow);
      others.sort(Comparator.comparingDouble(ox -> ox.pos().getSquaredDistance(t.pos())));
      if (others.size() > 24) {
         others = others.subList(0, 24);
      }

      List<AutoSchematicBuilderModule.TowerSpot> out = new ArrayList<>();
      long deadline = System.nanoTime() + 4000000L;

      label110:
      for (int dx = -3; dx <= 3; dx++) {
         for (int dz = -3; dz <= 3; dz++) {
            if (System.nanoTime() > deadline) {
               break label110;
            }

            if (Math.max(Math.abs(dx), Math.abs(dz)) >= 1) {
               int x = tx + dx;
               int z = tz + dz;
               BlockPos ground = null;

               for (int y = ty - 1; y >= ty - 1 - most; y--) {
                  BlockPos c = new BlockPos(x, y, z);
                  if (Pathfinder.standable(world, c)) {
                     ground = c;
                     break;
                  }
               }

               if (ground != null) {
                  for (int top : new int[]{ty - 1, ty, ty - 2}) {
                     int height = top - ground.getY();
                     if (height >= 1 && height <= most) {
                        boolean clear = true;
                        boolean inBuild = false;

                        for (int yx = ground.getY(); yx <= top + 1 && clear; yx++) {
                           BlockPos c = new BlockPos(x, yx, z);
                           clear = Pathfinder.passable(world, c);
                           inBuild |= this.byPos.containsKey(c);
                        }

                        if (clear) {
                           Vec3d eye = new Vec3d(x + 0.5, top + 1.62, z + 0.5);
                           if (pick(opts, world, t.pos(), eye, reach) != null) {
                              int covers = 0;

                              for (AutoSchematicBuilderModule.Target o : others) {
                                 BlockPos op = o.pos();
                                 if ((op.getX() != x || op.getZ() != z || op.getY() > top + 1) && pick(this.options(mc, o), world, op, eye, reach) != null) {
                                    covers++;
                                 }
                              }

                              double far = Math.sqrt(
                                 Math.pow(p.getX() - (x + 0.5), 2.0) + Math.pow(p.getY() - ground.getY(), 2.0) + Math.pow(p.getZ() - (z + 0.5), 2.0)
                              );
                              double score = covers * 10.0 - height - far * 0.15 - (inBuild ? 25.0 : 0.0);
                              out.add(new AutoSchematicBuilderModule.TowerSpot(ground, top, score, inBuild));
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      out.sort(Comparator.comparingDouble(s -> -s.score()));
      out.removeIf(AutoSchematicBuilderModule.TowerSpot::inBuild);
      return out;
   }

   private List<BlockPos> towerRoute(MinecraftClient mc, AutoSchematicBuilderModule.Target t, List<Placement.Option> opts, double reach, int[] topOut, int most) {
      ClientWorld world = mc.world;
      int tx = t.pos().getX();
      int ty = t.pos().getY();
      int tz = t.pos().getZ();
      Vec3d c = Vec3d.ofCenter(t.pos());
      return Pathfinder.find(world, playerFeet(mc.player), n -> {
         int dx = Math.abs(n.getX() - tx);
         int dz = Math.abs(n.getZ() - tz);
         if (Math.max(dx, dz) >= 1 && Math.max(dx, dz) <= 3) {
            for (int topFeet : new int[]{ty - 1, ty, ty - 2}) {
               if (n.getY() < topFeet && topFeet - n.getY() <= most) {
                  Vec3d eye = new Vec3d(n.getX() + 0.5, topFeet + 1.62, n.getZ() + 0.5);
                  if (!(eye.distanceTo(c) > reach + 0.9)) {
                     boolean clear = true;

                     for (int y = n.getY(); y <= topFeet + 1 && clear; y++) {
                        clear = Pathfinder.passable(world, new BlockPos(n.getX(), y, n.getZ()));
                     }

                     if (clear && pick(opts, world, t.pos(), eye, reach) != null) {
                        topOut[0] = topFeet;
                        return true;
                     }
                  }
               }
            }

            return false;
         } else {
            return false;
         }
      }, n -> Math.abs(n.getX() - tx) + Math.abs(n.getZ() - tz) + (this.byPos.containsKey(n) ? 2.0 : 0.0), this.byPos.keySet(), 2500);
   }

   private void beginWalk(AutoSchematicBuilderModule.Target t, List<BlockPos> route, boolean tower, int goalY) {
      if (this.onTower && route.size() > 1) {
         this.supportPlaced.addAll(this.scaffoldBlocks);
         this.scaffoldBlocks.clear();
                  this.onTower = false;
         this.escapeTower = false;
         this.towerFor = null;
      }

      this.walkTarget = t;
      this.path = route;
      this.toBestSpot = false;
      this.pathIndex = route.size() > 1 ? 1 : 0;
      this.precise = false;
      this.towerAfterWalk = tower;
      this.bridgeAfterWalk = false;
      this.towerGoalY = goalY;
      this.topWalk = false;
      this.selfFor = null;
      this.bestDist = Double.MAX_VALUE;
      this.noProgress = 0;
      this.jumpFromY = Integer.MIN_VALUE;
      this.phase = AutoSchematicBuilderModule.Phase.WALK;
   }

   private static BlockPos playerFeet(ClientPlayerEntity p) {
      return new BlockPos((int)Math.floor(p.getX()), (int)Math.floor(p.getY() + 0.2), (int)Math.floor(p.getZ()));
   }

   private void walk(MinecraftClient mc, long now) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      if (this.path != null && this.walkTarget != null && !placed(world, this.walkTarget)) {
         if (!this.towerAfterWalk
            && !this.toBestSpot
            && !"cherryblossom:remove".equals(this.walkTarget.id())
            && this.tickCounter % 3 == 0
            && (!this.topWalk || this.onTopAt(world, playerFeet(p), this.topLayer))) {
            List<Placement.Option> opts = this.options(mc, this.walkTarget);
            if (!opts.isEmpty()
               && !intersectsPlayer(p, this.walkTarget.pos())
               && p.isOnGround()
               && pick(opts, world, this.walkTarget.pos(), standingEye(p), this.reach.getFloat() - 0.15) != null) {
               this.arrive(mc);
               return;
            }
         }

         while (this.pathIndex < this.path.size() - 1) {
            BlockPos n = this.path.get(this.pathIndex);
            double dx = n.getX() + 0.5 - p.getX();
            double dz = n.getZ() + 0.5 - p.getZ();
            if (!(dx * dx + dz * dz < 0.3) || !(Math.abs(p.getY() - n.getY()) < 1.2)) {
               break;
            }

            this.pathIndex++;
         }

         BlockPos n = this.path.get(this.pathIndex);
         int floorY = (int)Math.floor(p.getY() + 0.2);
         boolean last = this.pathIndex == this.path.size() - 1;
         double ndx = n.getX() + 0.5 - p.getX();
         double ndz = n.getZ() + 0.5 - p.getZ();
         double toNode = Math.sqrt(ndx * ndx + ndz * ndz);
         Vec3d vel = p.getVelocity();
         double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
         if (last && toNode < 0.22 && Math.abs(p.getY() - n.getY()) < 0.6 && speed < 0.08) {
            this.arrive(mc);
         } else {
            BlockPos aimAt = n;
            if (!last && n.getY() == floorY) {
               for (int i = this.pathIndex + 1; i < Math.min(this.path.size(), this.pathIndex + 4); i++) {
                  BlockPos c = this.path.get(i);
                  if (c.getY() != floorY || !straightWalk(mc.world, p, c)) {
                     break;
                  }

                  aimAt = c;
               }
            }

            double dx = aimAt.getX() + 0.5 - p.getX();
            double dz = aimAt.getZ() + 0.5 - p.getZ();
            float toward = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            boolean close = Math.hypot(dx, dz) < 0.9 || last && toNode < 0.9;
            float yaw = close ? p.getYaw() : toward;
            float pitchAhead = 13.0F + 2.5F * (float)Math.sin(this.tickCounter * 0.045) + (n.getY() < floorY ? 8.0F : (n.getY() > floorY ? -4.0F : 0.0F));
            this.look.steer(p, yaw, pitchAhead);
            float err = Math.abs(HumanLook.wrap(toward - p.getYaw()));
            BlockPos feetCell = new BlockPos((int)Math.floor(p.getX()), floorY, (int)Math.floor(p.getZ()));
            boolean onTheBuild = this.onBuild(world, feetCell) || this.onTower;
            boolean back = false;
            boolean left = false;
            boolean right = false;
            boolean forward;
            if (close) {
               boolean[] k = shuffleKeys(p, ndx, ndz);
               boolean moving = toNode > (last ? 0.15 : 0.05);
               forward = moving && k[0];
               back = moving && k[1];
               left = moving && k[2];
               right = moving && k[3];
            } else {
               forward = err < (onTheBuild ? 25.0F : (last ? 30.0F : 70.0F));
            }

            boolean jump = n.getY() > floorY && p.isOnGround() && toNode < 1.6 && (close || err < 40.0F);
            boolean careful = last && toNode < 1.1;
            boolean edge = p.isOnGround() && (nearDrop(world, feetCell) || onTheBuild && nearLedge(world, p, floorY));
            boolean sneak = (careful || edge) && !jump && n.getY() >= floorY;
            int stepsLeft = this.path.size() - this.pathIndex;
            boolean flatAhead = true;

            for (int i = this.pathIndex; i < Math.min(this.path.size(), this.pathIndex + 4); i++) {
               if (this.path.get(i).getY() != floorY) {
                  flatAhead = false;
               }
            }

            p.setSprinting(forward && !close && !careful && !edge && !onTheBuild && stepsLeft > 3 && err < 20.0F && flatAhead);
            this.setKeys(mc, forward, back, left, right, jump, sneak);
            BlockPos end = this.path.get(this.path.size() - 1);
            double toEnd = Math.sqrt(
               Math.pow(end.getX() + 0.5 - p.getX(), 2.0) + Math.pow(end.getZ() + 0.5 - p.getZ(), 2.0) + Math.pow(end.getY() - p.getY(), 2.0)
            );
            if (toEnd < this.bestDist - 0.3) {
               this.bestDist = toEnd;
               this.noProgress = 0;
            } else if (++this.noProgress > 40) {
               this.releaseKeys(mc);
               this.path = null;
               this.phase = AutoSchematicBuilderModule.Phase.IDLE;
               if (++this.replans > 2) {
                  this.skipUntil.put(this.walkTarget.pos(), now + 6000L);
                  this.replans = 0;
               }
            }
         }
      } else {
         this.arrive(mc);
      }
   }

   private static boolean straightWalk(ClientWorld world, ClientPlayerEntity p, BlockPos c) {
      double sx = p.getX();
      double sz = p.getZ();
      double ex = c.getX() + 0.5;
      double ez = c.getZ() + 0.5;
      double len = Math.hypot(ex - sx, ez - sz);
      if (len < 0.001) {
         return true;
      } else {
         double nx = -(ez - sz) / len * 0.32;
         double nz = (ex - sx) / len * 0.32;
         int steps = (int)Math.ceil(len / 0.25);

         for (int i = 1; i <= steps; i++) {
            double f = (double)i / steps;
            double x = sx + (ex - sx) * f;
            double z = sz + (ez - sz) * f;

            for (int side = -1; side <= 1; side++) {
               BlockPos cell = new BlockPos((int)Math.floor(x + nx * side), c.getY(), (int)Math.floor(z + nz * side));
               if (!Pathfinder.standable(world, cell)) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   private void arrive(MinecraftClient mc) {
      this.releaseKeys(mc);
      mc.player.setSprinting(false);
      this.path = null;
      this.replans = 0;
      this.phase = this.towerAfterWalk
         ? AutoSchematicBuilderModule.Phase.TOWER_UP
         : (this.bridgeAfterWalk && this.bridgeFor != null ? AutoSchematicBuilderModule.Phase.BRIDGE : AutoSchematicBuilderModule.Phase.IDLE);
      this.bridgeTicks = 0;
   }

   private void startAim(AutoSchematicBuilderModule.Target t, Placement.Choice c, boolean adjust) {
      if(layerByLayer.get()&&!SUPPORT.equals(t.id())&&!REMOVE.equals(t.id())&&t.pos().getY()>activeLayer)return;
      this.dwell = this.human.get()?1 + this.rng.nextInt(2):1;
      this.blockedTicks = 0;
      this.aim = t;
      this.adjusting = adjust;
      this.choice = c;
      this.alignedTicks = 0;
      this.aimTicks = 0;
      this.sneakTicks = 0;
      this.phase = AutoSchematicBuilderModule.Phase.AIM;
      if (!adjust) {
         this.attempts.merge(t.pos(), 1, Integer::sum);
      }
   }

   private void aimTick(MinecraftClient mc, long now, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      Vec3d eye = p.getEyePos();
      AutoSchematicBuilderModule.Target t = this.aim;
      double reach = this.reach.getFloat();
      boolean valid = t != null
         && (
            this.adjusting
               ? placed(world, t) && clicksToFix(t.state(), world.getBlockState(t.pos())) > 0
               : !placed(world, t) && world.getBlockState(t.pos()).isReplaceable()
         );
      if (valid && ++this.aimTicks <= 60) {
         if (this.choice == null || !stillClickable(world, this.choice, eye, reach + 0.3)) {
            this.choice = this.adjusting ? adjustChoice(world, t.pos(), eye, reach) : Placement.choose(this.options(mc, t), world, t.pos(), eye, reach);
            if (this.choice != null && !faceVisible(world, p, eye, this.choice, this.adjusting ? t.pos() : this.choice.option().neighbour())) {
               this.choice = null;
            }
         }

         if (this.choice == null) {
            if (this.aimTicks > 8) {
               this.skipUntil.put(t.pos(), now + 3000L);
               this.endAim(mc);
            }
         } else if (this.adjusting || this.ensureItem(mc, t.item())) {
            boolean sneak = !this.adjusting && this.choice.option().sneak();
            if (sneak) {
               this.sneakHold = 16;
            }

            this.setKeys(mc, false, false, false, sneak || this.sneakHold > 0);
            this.sneakTicks = sneak ? this.sneakTicks + 1 : 0;
            if (this.choice != this.aimFor || this.aimEye == null || this.aimEye.distanceTo(eye) > 0.15) {
               this.aimAngles = Placement.angles(eye, this.choice.hit());
               this.aimEye = eye;
               this.aimFor = this.choice;
            }

            this.look.lookAt(p, this.aimAngles[0], this.aimAngles[1]);
            this.alignedTicks = resting ? this.alignedTicks + 1 : 0;
            if (this.alignedTicks >= this.dwell && this.cooldown <= 0 && this.switchDelay <= 0 && (!sneak || this.sneakTicks >= 3) && serverSees(p)) {
               Placement.Option o = this.choice.option();
               if (this.adjusting || !this.unconfirmed.containsKey(o.neighbour())) {
                  BlockHitResult aimed = crosshair(p, this.reach.getFloat(), this.adjusting ? t.pos() : o.neighbour(), o.side());
                  if (aimed == null) {
                     this.alignedTicks = 0;
                     if (++this.blockedTicks > 10) {
                        this.blockedTicks = 0;
                        this.choice = null;
                        if (this.aimTicks > 30) {
                           this.skipUntil.put(t.pos(), now + 6000L);
                           this.endAim(mc);
                        }
                     }
                  } else {
                     this.blockedTicks = 0;
                     if(t.state().getBlock() instanceof net.minecraft.block.AbstractSignBlock){this.pendingSign=t.pos();this.pendingSignUntil=now+3000;}
                     ActionResult result = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, aimed);
                     p.swingHand(Hand.MAIN_HAND);
                     this.lastClickTick = this.tickCounter;
                     this.lastProgressMs = now;
                     if (!result.isAccepted()) {
                        this.skipUntil.put(t.pos(), now + 6000L);
                     } else {
                        this.attempts.remove(t.pos());
                        if ("cherryblossom:support".equals(t.id())) {
                           this.supportPlaced.add(t.pos());
                        } else if (!this.adjusting && clicksToFix(t.state(), t.state().getBlock().getDefaultState()) > 0) {
                           this.toAdjust.add(t.pos());
                        }

                        if (!"cherryblossom:support".equals(t.id()) && !this.adjusting) {
                           this.placeTimes.addLast(System.currentTimeMillis());

                           while (this.placeTimes.size() > 30) {
                              this.placeTimes.pollFirst();
                           }
                        }
                     }

                     this.cooldown = Math.max(1, (int)Math.round(this.delay.getFloat() + this.rng.nextGaussian() * 0.8)) + this.slowdown;
                     if (this.human.get() && ++this.sincePause >= this.nextPauseAt) {
                        this.sincePause = 0;
                        this.nextPauseAt = 30 + this.rng.nextInt(30);
                        this.pause = 8 + this.rng.nextInt(18);
                        List<AutoSchematicBuilderModule.Target> near = new ArrayList<>();

                        for (AutoSchematicBuilderModule.Target nt : this.targets) {
                           Vec3d gc = Vec3d.ofCenter(nt.pos());
                           if (!(eye.distanceTo(gc) >= 6.0)
                              && world.raycast(new RaycastContext(eye, gc, ShapeType.OUTLINE, FluidHandling.NONE, p)).getType()
                                 == net.minecraft.util.hit.HitResult.Type.MISS) {
                              near.add(nt);
                           }
                        }

                        if (!near.isEmpty()) {
                           float[] g = Placement.angles(eye, Vec3d.ofCenter(near.get(this.rng.nextInt(near.size())).pos()));
                           if (Math.abs(HumanLook.wrap(g[0] - p.getYaw())) < 50.0F) {
                              this.look.lookAt(p, g[0], g[1]);
                           }
                        }
                     }

                     this.endAim(mc);
                  }
               }
            }
         }
      } else {
         if (t != null && valid) {
            this.skipUntil.put(t.pos(), now + 6000L);
         }

         this.endAim(mc);
      }
   }

   private static Placement.Choice pick(List<Placement.Option> opts, ClientWorld world, BlockPos pos, Vec3d standingEye, double reach) {
      Placement.Choice c = Placement.choose(opts, world, pos, standingEye, reach);
      return c != null && c.option().sneak() ? Placement.choose(opts, world, pos, standingEye.add(0.0, -0.35, 0.0), reach) : c;
   }

   private static Vec3d standingEye(ClientPlayerEntity p) {
      return new Vec3d(p.getX(), p.getY() + 1.62, p.getZ());
   }

   private static boolean stillClickable(ClientWorld world, Placement.Choice c, Vec3d eye, double reach) {
      Vec3d h = c.hit();
      Direction d = c.option().side();
      double ex = eye.x - h.x;
      double ey = eye.y - h.y;
      double ez = eye.z - h.z;
      if (!(ex * ex + ey * ey + ez * ez > reach * reach) && !(ex * d.getOffsetX() + ey * d.getOffsetY() + ez * d.getOffsetZ() <= 0.05)) {
         return (c.option().looks() & 1 << Placement.lookClass(-ex, -ey, -ez)) == 0
            ? false
            : world.getBlockState(c.option().neighbour()).getBlock() != Blocks.AIR
               && Placement.clearLine(world, eye, h.x, h.y, h.z, c.option().neighbour().offset(d), c.option().neighbour());
      } else {
         return false;
      }
   }

   private void endAim(MinecraftClient mc) {
      this.aim = null;
      this.choice = null;
      this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      this.releaseKeysKeepSneak(mc);
   }

   private static BlockHitResult crosshair(ClientPlayerEntity p, double reach, BlockPos pos, Direction side) {
      HitResult r = p.raycast(reach, 1.0F, false);
      return r instanceof BlockHitResult bh
            && r.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK
            && bh.getBlockPos().equals(pos)
            && bh.getSide() == side
         ? bh
         : null;
   }

   private static boolean faceVisible(ClientWorld world, ClientPlayerEntity p, Vec3d eye, Placement.Choice c, BlockPos clickedPos) {
      Vec3d h = c.hit();
      Vec3d dir = h.subtract(eye).normalize();
      BlockHitResult r = world.raycast(new RaycastContext(eye, h.add(dir.multiply(0.08)), ShapeType.OUTLINE, FluidHandling.NONE, p));
      return r.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK && r.getBlockPos().equals(clickedPos) && r.getSide() == c.option().side();
   }

   private boolean aboveHead(ClientPlayerEntity p, BlockPos pos) {
      if (this.onTower) {
         return false;
      } else {
         BlockPos feet = playerFeet(p);
         return pos.getX() == feet.getX() && pos.getZ() == feet.getZ() && pos.getY() >= feet.getY() + 2 && pos.getY() <= feet.getY() + 3;
      }
   }

   private static boolean serverSees(ClientPlayerEntity p) {
      SchematicPlayerAccessor a = (SchematicPlayerAccessor)p;
      return Math.abs(HumanLook.wrap(p.getYaw() - a.cherryblossom$sentYaw())) < 0.5F && Math.abs(p.getPitch() - a.cherryblossom$sentPitch()) < 0.5F;
   }

   private void releaseKeysKeepSneak(MinecraftClient mc) {
      if (this.sneakHold > 0) {
         this.sneakHold--;
         this.setKeys(mc, false, false, false, true);
      } else {
         this.releaseKeys(mc);
      }
   }

   private boolean ensureItem(MinecraftClient mc, Item item) {
      ClientPlayerEntity p = mc.player;
      PlayerInventory inv = p.getInventory();

      for (int i = 0; i < 9; i++) {
         ItemStack s = inv.getStack(i);
         if (s.getItem() == item && !s.isEmpty()) {
            if (inv.getSelectedSlot() != i) {
               inv.setSelectedSlot(i);
               this.switchDelay = 2 + this.rng.nextInt(2);
               return false;
            }

            return this.switchDelay == 0;
         }
      }

      int hotbar = this.freeHotbarSlot(mc, inv);
      if (this.fromInventory.get() || creative(mc)) {
         for (int ix = 9; ix < 36; ix++) {
            if (inv.getStack(ix).getItem() == item && !inv.getStack(ix).isEmpty()) {
               Vec3d v = p.getVelocity();
               if (v.x * v.x + v.z * v.z > 1.0E-4) {
                  return false;
               }

               mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, ix, hotbar, SlotActionType.SWAP, p);
               inv.setSelectedSlot(hotbar);
               this.switchDelay = 3 + this.rng.nextInt(3);
               return false;
            }
         }
      }

      if (creative(mc)) {
         ItemStack stack = new ItemStack(item, item.getMaxCount());
         inv.setStack(hotbar, stack);
         mc.interactionManager.clickCreativeStack(stack, 36 + hotbar);
         inv.setSelectedSlot(hotbar);
         this.switchDelay = 3 + this.rng.nextInt(2);
      }

      return false;
   }

   private int freeHotbarSlot(MinecraftClient mc, PlayerInventory inv) {
      Set<Item> needed = new HashSet<>();

      for (AutoSchematicBuilderModule.Target t : this.targets) {
         needed.add(t.item());
      }

      for (AutoSchematicBuilderModule.Target t : this.supports) {
         needed.add(t.item());
      }

      for (String name : SCAFFOLD) {
         Block b = Schematic.block("minecraft:" + name);
         if (b != null) {
            needed.add(b.asItem());
         }
      }

      for (int i = 0; i < 9; i++) {
         if (inv.getStack(i).isEmpty()) {
            return i;
         }
      }

      for (int ix = 0; ix < 9; ix++) {
         if (!needed.contains(inv.getStack(ix).getItem())) {
            return ix;
         }
      }

      Set<Item> soon = new HashSet<>();
      ClientWorld world = mc.world;

      for (AutoSchematicBuilderModule.Target t : this.targets) {
         if (!placed(world, t)) {
            soon.add(t.item());
         }
      }

      for (int ixx = 0; ixx < 9; ixx++) {
         if (!soon.contains(inv.getStack(ixx).getItem()) && ixx != inv.getSelectedSlot()) {
            return ixx;
         }
      }

      return inv.getSelectedSlot();
   }

   private static int clicksToFix(BlockState want, BlockState have) {
      if (want.getBlock() != have.getBlock()) {
         return 0;
      } else {
         Map<String, String> w = Placement.props(want, false);
         Map<String, String> h = Placement.props(have, false);
         String id = Pathfinder.id(want.getBlock());

         try {
            if (w.containsKey("delay") && id.contains("repeater")) {
               return Math.floorMod(Integer.parseInt(w.get("delay")) - Integer.parseInt(h.get("delay")), 4);
            }

            if (w.containsKey("note") && id.equals("note_block")) {
               return Math.floorMod(Integer.parseInt(w.get("note")) - Integer.parseInt(h.get("note")), 25);
            }
         } catch (RuntimeException var6) {
            return 0;
         }

         if (id.equals("comparator") && !w.get("mode").equals(h.get("mode"))) {
            return 1;
         } else if (id.equals("daylight_detector") && !w.get("inverted").equals(h.get("inverted"))) {
            return 1;
         } else if (id.equals("lever") && !w.get("powered").equals(h.get("powered"))) {
            return 1;
         } else {
            boolean opens = (id.contains("door") || id.contains("gate")) && !id.contains("iron");
            return opens && w.containsKey("open") && !w.get("open").equals(h.get("open")) ? 1 : 0;
         }
      }
   }

   private static Placement.Choice adjustChoice(ClientWorld world, BlockPos pos, Vec3d eye, double reach) {
      Placement.Choice best = null;
      double bestD = reach * reach;
      double top = thinTop(world.getBlockState(pos));

      for (Direction d : Direction.values()) {
         if (!(top < 1.0) || d.getOffsetY() == 1) {
            double hx = pos.getX() + 0.5 + d.getOffsetX() * 0.5;
            double hy = d.getOffsetY() == 1 ? pos.getY() + top : pos.getY() + 0.5 + d.getOffsetY() * 0.5;
            double hz = pos.getZ() + 0.5 + d.getOffsetZ() * 0.5;
            double ex = eye.x - hx;
            double ey = eye.y - hy;
            double ez = eye.z - hz;
            double distSq = ex * ex + ey * ey + ez * ez;
            if (!(distSq > bestD)
               && !(ex * d.getOffsetX() + ey * d.getOffsetY() + ez * d.getOffsetZ() <= 0.05)
               && Placement.clearLine(world, eye, hx, hy, hz, pos, pos)) {
               best = new Placement.Choice(new Placement.Option(pos, d, 0.0, 0.0, 0.0, 4095, false), new Vec3d(hx, hy, hz));
               bestD = distSq;
            }
         }
      }

      return best;
   }

   private static double thinTop(BlockState s) {
      String id = Pathfinder.id(s.getBlock());
      if (id.contains("repeater") || id.contains("comparator")) {
         return 0.125;
      } else {
         return id.contains("daylight") ? 0.375 : 1.0;
      }
   }

   private static Vec3d adjustHit(Vec3d eye, float yaw, float pitch, BlockPos pos, Direction side, Vec3d aimed) {
      double yr = Math.toRadians(yaw);
      double pr = Math.toRadians(pitch);
      double lx = -Math.sin(yr) * Math.cos(pr);
      double ly = -Math.sin(pr);
      double lz = Math.cos(yr) * Math.cos(pr);
      double nx = side.getOffsetX();
      double ny = side.getOffsetY();
      double nz = side.getOffsetZ();
      double denom = lx * nx + ly * ny + lz * nz;
      if (denom > -1.0E-6) {
         return null;
      } else {
         double t = ((aimed.x - eye.x) * nx + (aimed.y - eye.y) * ny + (aimed.z - eye.z) * nz) / denom;
         double hx = eye.x + lx * t;
         double hy = eye.y + ly * t;
         double hz = eye.z + lz * t;
         return !(Math.abs(hx - aimed.x) > 0.45) && !(Math.abs(hy - aimed.y) > 0.45) && !(Math.abs(hz - aimed.z) > 0.45) ? new Vec3d(hx, hy, hz) : null;
      }
   }

   private List<AutoSchematicBuilderModule.Spare> scaffoldChoices(MinecraftClient mc) {
      List<AutoSchematicBuilderModule.Spare> out = new ArrayList<>();
      if (creative(mc)) {
         Block dirt = Schematic.block("minecraft:dirt");
         if (dirt != null) {
            out.add(new AutoSchematicBuilderModule.Spare(dirt.asItem(), 2304, 0.0));
         }

         return out;
      } else {
         ClientWorld world = mc.world;
         PlayerInventory inv = mc.player.getInventory();
         Map<Item, Integer> left = new HashMap<>();

         for (AutoSchematicBuilderModule.Need n : this.needs) {
            left.put(n.item(), n.need());
         }

         for (Entry<Item, Integer> e : inventoryCounts(mc).entrySet()) {
            int spare = e.getValue() - left.getOrDefault(e.getKey(), 0);
            if (spare >= 1) {
               Block b = Block.getBlockFromItem(e.getKey());
               if (b != null && b != Blocks.AIR) {
                  BlockState s = b.getDefaultState();
                  int listed = -1;

                  for (int i = 0; i < SCAFFOLD.length && listed < 0; i++) {
                     if (Schematic.block("minecraft:" + SCAFFOLD[i]) == b) {
                        listed = i;
                     }
                  }

                  if (listed >= 0
                     || b.getStateManager().getProperties().isEmpty()
                        && !(b instanceof FallingBlock)
                        && !Placement.interactive(s)
                        && s.isFullCube(world, BlockPos.ORIGIN)) {
                     float hard = s.getHardness(world, BlockPos.ORIGIN);
                     if (!(hard < 0.0F) && !(hard > 3.0F)) {
                        boolean slow = s.isToolRequired() && !hasToolFor(inv, s);
                        if (!slow || spare >= 4) {
                           out.add(new AutoSchematicBuilderModule.Spare(e.getKey(), spare, (slow ? 1000.0 : 0.0) + (listed >= 0 ? listed : 100.0 + hard)));
                        }
                     }
                  }
               }
            }
         }

         out.sort(Comparator.comparingDouble(AutoSchematicBuilderModule.Spare::rank));
         return out;
      }
   }

   private Item scaffoldItem(MinecraftClient mc) {
      List<AutoSchematicBuilderModule.Spare> l = this.scaffoldChoices(mc);
      return l.isEmpty() ? null : l.get(0).item();
   }

   private int scaffoldCount(MinecraftClient mc) {
      int n = 0;

      for (AutoSchematicBuilderModule.Spare s : this.scaffoldChoices(mc)) {
         n += s.count();
      }

      return n;
   }

   private static boolean hasToolFor(PlayerInventory inv, BlockState s) {
      for (int i = 0; i < 9; i++) {
         if (inv.getStack(i).isSuitableFor(s)) {
            return true;
         }
      }

      return false;
   }

   private void towerUp(MinecraftClient mc, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      AutoSchematicBuilderModule.Target self = this.selfFor;
      Item item = self != null ? self.item() : this.scaffoldItem(mc);
      int feetY = (int)Math.floor(p.getY() + 0.01);
      int goalY = self != null ? self.pos().getY() + 1 : this.towerGoalY;
      long nowMs = System.currentTimeMillis();
      if (this.towerSince == 0L) {
         this.towerSince = nowMs;
      }

      if (nowMs - this.towerSince > 5000L && this.towerRetries < 2 && self == null && p.isOnGround()) {
         this.towerRetries++;
         this.towerSince = nowMs;
         this.jumpFromY = Integer.MIN_VALUE;
      } else if (nowMs - this.towerSince > 5000L) {
         if (self != null) {
            this.skipUntil.put(self.pos(), nowMs + 6000L);
         } else if (this.boxMin != null) {
            this.topFailLayer = this.workLayer;
         }

         this.waitReason = "Couldn't build up here, trying another way";
         this.endTower(mc, false);
      } else if (item != null && goalY - feetY <= 12) {
         if (self != null && p.isOnGround() && this.jumpFromY == Integer.MIN_VALUE) {
            boolean on = (int)Math.floor(p.getX()) == self.pos().getX() && (int)Math.floor(p.getZ()) == self.pos().getZ();
            if (placed(world, self) || !on || feetY != self.pos().getY() || !world.getBlockState(self.pos()).isReplaceable()) {
               this.endTower(mc, false);
               return;
            }
         }

         if (self == null && feetY >= goalY && p.isOnGround()) {
            this.endTower(mc, true);
         } else {
            if (Float.isNaN(this.towerPitch)) {
               this.towerPitch = 85.5F + this.rng.nextFloat() * 2.5F;
            }

            this.look.lookAt(p, self != null ? this.selfYaw : p.getYaw(), this.towerPitch);
            if (this.ensureItem(mc, item)) {
               if (!p.isOnGround() || this.jumpFromY != Integer.MIN_VALUE) {
                  this.setKeys(mc, false, false, false, false);
                  if (this.jumpFromY != Integer.MIN_VALUE) {
                     BlockPos spot = new BlockPos((int)Math.floor(p.getX()), this.jumpFromY, (int)Math.floor(p.getZ()));
                     if (p.getY() >= this.jumpFromY + 1.0 && world.getBlockState(spot).isReplaceable() && (self == null || spot.equals(self.pos()))) {
                        BlockPos below = spot.down();
                        BlockHitResult aimed = crosshair(p, this.reach.getFloat(), below, Direction.UP);
                        if (aimed == null || self != null && !serverSees(p)) {
                           return;
                        }

                        ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, aimed);
                        p.swingHand(Hand.MAIN_HAND);
                        this.lastClickTick = this.tickCounter;
                        if (r.isAccepted()) {
                           this.lastProgressMs = System.currentTimeMillis();
                           this.towerSince = nowMs;
                           this.towerRetries = 0;
                           if (self == null) {
                              this.scaffoldBlocks.add(spot);
                           } else {
                              this.attempts.remove(self.pos());
                              if (clicksToFix(self.state(), self.state().getBlock().getDefaultState()) > 0) {
                                 this.toAdjust.add(self.pos());
                              }

                              this.placeTimes.addLast(System.currentTimeMillis());

                              while (this.placeTimes.size() > 30) {
                                 this.placeTimes.pollFirst();
                              }
                           }
                        }

                        this.jumpFromY = Integer.MIN_VALUE;
                     } else if (p.isOnGround() && p.getY() < this.jumpFromY + 0.5 && p.getVelocity().y <= 0.0) {
                        this.jumpFromY = Integer.MIN_VALUE;
                        if (self != null && ++this.selfFails > 3) {
                           this.skipUntil.put(self.pos(), System.currentTimeMillis() + 6000L);
                           this.endTower(mc, false);
                        }
                     }
                  }
               } else if (self == null && this.byPos.containsKey(new BlockPos((int)Math.floor(p.getX()), feetY, (int)Math.floor(p.getZ())))) {
                  this.topFailLayer = this.workLayer;
                  this.topFailUntil = nowMs + 6000L;
                  this.waitReason = "Not putting scaffold inside the build";
                  this.endTower(mc, false);
               } else if (!(Math.abs(p.getPitch() - this.towerPitch) > 3.0F)) {
                  if (self == null || resting && serverSees(p)) {
                     this.jumpFromY = feetY;
                     this.setKeys(mc, false, false, true, false);
                  }
               }
            }
         }
      } else {
         this.endTower(mc, false);
      }
   }

   private void endTower(MinecraftClient mc, boolean onPillar) {
      this.towerPitch = Float.NaN;
      this.jumpFromY = Integer.MIN_VALUE;
      this.towerSince = 0L;
      this.towerRetries = 0;
      ClientPlayerEntity p = mc.player;
      if (onPillar
         || p != null && this.scaffoldBlocks.contains(new BlockPos((int)Math.floor(p.getX()), (int)Math.floor(p.getY() + 0.01) - 1, (int)Math.floor(p.getZ())))
         )
       {
         this.onTower = true;
      }

      this.selfFor = null;
      this.releaseKeys(mc);
      this.phase = AutoSchematicBuilderModule.Phase.IDLE;
   }

   private boolean startSupply(MinecraftClient mc) {
      if (this.pullFromChest.get() && this.supplyPos != null && mc.world != null && isContainer(mc.world, this.supplyPos) && !creative(mc)) {
         this.releaseKeys(mc);
         this.phase = AutoSchematicBuilderModule.Phase.SUPPLY;
         this.supplyState = 0;
         this.supplyStart = System.currentTimeMillis();
         this.supplyPath = null;
         this.lastSupplyMs = this.supplyStart;
         return true;
      } else {
         return false;
      }
   }

   private static boolean isContainer(ClientWorld world, BlockPos pos) {
      return world != null && world.getBlockEntity(pos) instanceof Inventory;
   }

   private Set<Item> requiredItems() {
      Set<Item> items = new HashSet<>();

      for (AutoSchematicBuilderModule.Target t : this.targets) {
         if (!"cherryblossom:support".equals(t.id())) {
            items.add(t.item());
         }
      }

      return items;
   }

   private void supply(MinecraftClient mc, long now, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      boolean screenOpen = mc.currentScreen instanceof HandledScreen;
      if (this.supplyPos != null && isContainer(world, this.supplyPos) && now - this.supplyStart <= 25000L) {
         Vec3d eye = p.getEyePos();
         Vec3d face = visibleFace(world, p, eye, this.supplyPos);
         double dist = eye.distanceTo(Vec3d.ofCenter(this.supplyPos));
         if (this.supplyState == 0) {
            if (face != null && dist <= this.reach.getFloat()) {
               this.releaseKeys(mc);
               this.supplyState = 1;
               this.supplyWait = 0;
            } else if (!this.walk.get() || !this.walkSupply(mc, p, world, this.supplyPos)) {
               message(mc, "Can't get to the supply chest.");
               this.releaseKeys(mc);
               this.phase = AutoSchematicBuilderModule.Phase.IDLE;
            }
         } else if (this.supplyState == 1) {
            this.releaseKeys(mc);
            if (face == null) {
               this.supplyState = 0;
            } else {
               float[] a = Placement.angles(eye, face);
               this.look.lookAt(p, a[0], a[1]);
               if (screenOpen) {
                  this.supplyState = 2;
                  this.supplyWait = 6;
                  this.supplyStart = now;
                  this.supplyTries.clear();
                  this.pendingSlot = -1;
                  this.supplyTaken = 0;
               } else if (resting && serverSees(p)) {
                  if (this.supplyWait > 0) {
                     this.supplyWait--;
                  } else {
                     HitResult r = p.raycast(this.reach.getFloat(), 1.0F, false);
                     if (r instanceof BlockHitResult bh
                        && r.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK
                        && bh.getBlockPos().equals(this.supplyPos)) {
                        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, bh);
                        p.swingHand(Hand.MAIN_HAND);
                        this.supplyWait = 12;
                     }
                  }
               }
            }
         } else if (!screenOpen) {
            if (this.supplyWait > 0) {
               this.supplyWait--;
            } else {
               this.supplyState = 1;
            }
         } else if (this.supplyWait > 0) {
            this.supplyWait--;
         } else {
            Vec3d v = p.getVelocity();
            if (!(v.x * v.x + v.z * v.z > 4.0E-4)) {
               AutoSchematicBuilderModule.Take r = this.takeNeeded(mc, p);
               if (r == AutoSchematicBuilderModule.Take.TOOK) {
                  this.supplyWait = 4 + this.rng.nextInt(3);
                  this.lastProgressMs = now;
               } else {
                  closeScreen(mc, p);
                  if (r == AutoSchematicBuilderModule.Take.FULL) {
                     message(mc, "Inventory's full, took " + this.supplyTaken + (this.supplyTaken == 1 ? " stack" : " stacks") + " from the chest.");
                  } else {
                     message(mc, "Took " + this.supplyTaken + (this.supplyTaken == 1 ? " stack" : " stacks") + " from the chest.");
                  }

                  this.phase = AutoSchematicBuilderModule.Phase.IDLE;
               }
            }
         }
      } else {
         if (screenOpen) {
            closeScreen(mc, p);
         }

         if (this.supplyPos != null && now - this.supplyStart > 25000L) {
            message(mc, "Couldn't finish at the chest; building with what I have.");
         }

         this.releaseKeys(mc);
         this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      }
   }

   private AutoSchematicBuilderModule.Take takeNeeded(MinecraftClient mc, ClientPlayerEntity p) {
      if (!(mc.currentScreen instanceof HandledScreen<?> hs)) {
         return AutoSchematicBuilderModule.Take.DONE;
      } else {
         ScreenHandler var12 = hs.getScreenHandler();
         PlayerInventory pinv = p.getInventory();
         if (this.pendingSlot >= 0 && this.pendingSlot < var12.slots.size()) {
            ItemStack now = var12.getSlot(this.pendingSlot).getStack();
            boolean moved = now.isEmpty() || now.getItem() != this.pendingItem || now.getCount() < this.pendingCount;
            if (moved) {
               this.supplyTaken++;
            } else {
               this.supplyTries.merge(this.pendingSlot, 1, Integer::sum);
            }

            this.pendingSlot = -1;
         }

         Set<Item> need = this.takeAll.get() ? null : this.requiredItems();
         boolean blockedByRoom = false;
         int n = var12.slots.size();

         for (int i = 0; i < n; i++) {
            Slot slot = var12.getSlot(i);
            if (slot.inventory != pinv) {
               ItemStack st = slot.getStack();
               if (!st.isEmpty() && (need == null || need.contains(st.getItem())) && this.supplyTries.getOrDefault(i, 0) < 4) {
                  if (pinv.getEmptySlot() >= 0 || pinv.getOccupiedSlotWithRoomForStack(st) >= 0) {
                     this.pendingSlot = i;
                     this.pendingItem = st.getItem();
                     this.pendingCount = st.getCount();
                     mc.interactionManager.clickSlot(var12.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                     return AutoSchematicBuilderModule.Take.TOOK;
                  }

                  blockedByRoom = true;
               }
            }
         }

         return blockedByRoom ? AutoSchematicBuilderModule.Take.FULL : AutoSchematicBuilderModule.Take.DONE;
      }
   }

   private static void closeScreen(MinecraftClient mc, ClientPlayerEntity p) {
      try {
         Method m = PlayerEntity.class.getDeclaredMethod("method_7346");
         m.setAccessible(true);
         m.invoke(p);
      } catch (Throwable var3) {
         mc.setScreen(null);
      }
   }

   private boolean walkSupply(MinecraftClient mc, ClientPlayerEntity p, ClientWorld world, BlockPos chest) {
      long now = System.currentTimeMillis();
      BlockPos feet = playerFeet(p);
      double reach = this.reach.getFloat() - 0.6;
      Vec3d gc = Vec3d.ofCenter(chest);
      if (this.supplyPath == null || this.supplyIndex >= this.supplyPath.size() || now - this.supplyPathAt > 2500L) {
         this.supplyPath = Pathfinder.find(
            world,
            feet,
            n -> !n.equals(chest)
               && !n.up().equals(chest)
               && new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5).distanceTo(gc) <= reach
               && Placement.clearLine(world, new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5), gc.x, gc.y, gc.z, chest, chest),
            n -> Math.sqrt(n.getSquaredDistance(chest)),
            Set.of(),
            7000
         );
         this.supplyIndex = 1;
         this.supplyPathAt = now;
         if (this.supplyPath == null || this.supplyPath.size() < 2) {
            return false;
         }
      }

      while (this.supplyIndex < this.supplyPath.size() && nearCell(p, this.supplyPath.get(this.supplyIndex))) {
         this.supplyIndex++;
      }

      if (this.supplyIndex >= this.supplyPath.size()) {
         return false;
      } else {
         BlockPos next = this.supplyPath.get(this.supplyIndex);
         double dx = next.getX() + 0.5 - p.getX();
         double dz = next.getZ() + 0.5 - p.getZ();
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         this.look.steer(p, yaw, 10.0F);
         this.setKeys(mc, true, false, next.getY() > feet.getY(), false);
         return true;
      }
   }

   private static boolean nearCell(ClientPlayerEntity p, BlockPos c) {
      double dx = c.getX() + 0.5 - p.getX();
      double dz = c.getZ() + 0.5 - p.getZ();
      return dx * dx + dz * dz < 0.36 && Math.abs(c.getY() - (int)Math.floor(p.getY() + 0.01)) <= 1;
   }

   private void towerDown(MinecraftClient mc, boolean resting) {
      ClientPlayerEntity p = mc.player;
      ClientWorld world = mc.world;
      BlockPos below = new BlockPos((int)Math.floor(p.getX()), (int)Math.floor(p.getY() + 0.01) - 1, (int)Math.floor(p.getZ()));
      if (!this.scaffoldBlocks.contains(below)) {
         if (p.isOnGround()) {
                     this.onTower = false;
            if (this.towerFor != null && !placed(world, this.towerFor)) {
               this.skipUntil.put(this.towerFor.pos(), System.currentTimeMillis() + 5000L);
            }

            this.towerFor = null;
            if (this.breaking != null) {
               BotDig.stop(mc);
            }

            this.breaking = null;
            if (!this.scaffoldBlocks.isEmpty() && this.scaffoldBlocks.stream().noneMatch(s -> s.getX() == below.getX() && s.getZ() == below.getZ())) {
               this.supportPlaced.addAll(this.scaffoldBlocks);
               this.scaffoldBlocks.clear();
            }

            this.phase = AutoSchematicBuilderModule.Phase.IDLE;
         }
      } else {
         this.releaseKeys(mc);
         if (world.getBlockState(below).isAir()) {
            this.scaffoldBlocks.remove(below);
            this.breaking = null;
         } else {
            Vec3d eye = p.getEyePos();
            float[] want = Placement.angles(eye, new Vec3d(below.getX() + 0.5, below.getY() + 1.0, below.getZ() + 0.5));
            this.look.lookAt(p, want[0], Math.min(89.5F, want[1]));
            this.mineAligned = Math.max(this.mineAligned, 2);
            this.mine(mc, p, below, resting);
         }
      }
   }

   private void setKeys(MinecraftClient mc, boolean forward, boolean back, boolean jump, boolean sneak) {
      this.setKeys(mc, forward, back, false, false, jump, sneak);
   }

   private void setKeys(MinecraftClient mc, boolean forward, boolean back, boolean left, boolean right, boolean jump, boolean sneak) {
      GameOptions o = mc.options;
      o.forwardKey.setPressed(forward);
      o.backKey.setPressed(back);
      o.leftKey.setPressed(left);
      o.rightKey.setPressed(right);
      o.jumpKey.setPressed(jump);
      o.sneakKey.setPressed(sneak);
      this.holdingKeys = true;
   }

   private static boolean[] shuffleKeys(ClientPlayerEntity p, double dx, double dz) {
      double len = Math.hypot(dx, dz);
      if (len < 0.08) {
         return new boolean[4];
      } else {
         double yaw = Math.toRadians(p.getYaw());
         double sin = Math.sin(yaw);
         double cos = Math.cos(yaw);
         double f = (-dx * sin + dz * cos) / len;
         double s = (dx * cos + dz * sin) / len;
         return new boolean[]{f > 0.38, f < -0.38, s > 0.38, s < -0.38};
      }
   }

   private void releaseKeys(MinecraftClient mc) {
      if (this.holdingKeys && mc.options != null) {
         GameOptions o = mc.options;
         o.forwardKey.setPressed(false);
         o.backKey.setPressed(false);
         o.leftKey.setPressed(false);
         o.rightKey.setPressed(false);
         o.jumpKey.setPressed(false);
         o.sneakKey.setPressed(false);
         if (mc.player != null) {
            mc.player.setSprinting(false);
         }

         this.holdingKeys = false;
      }
   }

   private void stopActing(MinecraftClient mc) {
      creativeRoute=List.of();creativeTarget=null;
      if(ownedCreativeFlight&&mc.player!=null){mc.player.setVelocity(Vec3d.ZERO);mc.player.getAbilities().flying=false;mc.player.sendAbilitiesUpdate();}ownedCreativeFlight=false;
      this.releaseKeys(mc);
      this.bridgeFor = null;
      if (this.breaking != null && mc.interactionManager != null) {
         BotDig.stop(mc);
      }

      this.breaking = null;
      this.aim = null;
      this.path = null;
      this.selfFor = null;
      this.jumpFromY = Integer.MIN_VALUE;
      this.towerPitch = Float.NaN;
      this.phase = AutoSchematicBuilderModule.Phase.IDLE;
      this.look.reset();
   }

   private static boolean intersectsPlayer(ClientPlayerEntity p, BlockPos pos) {
      return p.getBoundingBox().intersects(new Box(pos));
   }

   public double[] previewCenter() {
      return this.boxMin == null
         ? new double[]{this.anchor.getX(), this.anchor.getY(), this.anchor.getZ()}
         : new double[]{
            (this.boxMin.getX() + this.boxMax.getX() + 1) / 2.0,
            (this.boxMin.getY() + this.boxMax.getY() + 1) / 2.0,
            (this.boxMin.getZ() + this.boxMax.getZ() + 1) / 2.0
         };
   }

   public double previewRadius() {
      if (this.boxMin == null) {
         return 4.0;
      } else {
         int dx = this.boxMax.getX() - this.boxMin.getX();
         int dy = this.boxMax.getY() - this.boxMin.getY();
         int dz = this.boxMax.getZ() - this.boxMin.getZ();
         return Math.sqrt(dx * dx + dy * dy + dz * dz) / 2.0 + 1.0;
      }
   }

   public String[] previewInfo() {
      int short_ = 0;

      for (AutoSchematicBuilderModule.Need n : this.needs) {
         short_ += Math.max(0, n.need() - n.have());
      }

      return new String[]{
         "§b" + (this.schematic == null ? "" : this.schematic.name),
         "§7"
            + (this.schematic == null ? 0 : this.schematic.sizeX)
            + " x "
            + (this.schematic == null ? 0 : this.schematic.sizeY)
            + " x "
            + (this.schematic == null ? 0 : this.schematic.sizeZ)
            + "  §7|  §f"
            + this.placedCount
            + "/"
            + this.targets.size()
            + " §7placed",
         "§7Rotation §f" + this.rotation.get() + "§7, offset §f" + this.offsetX.getInt() + " " + this.offsetY.getInt() + " " + this.offsetZ.getInt(),
         short_ == 0 ? "§aYou have everything it needs." : "§cShort of " + short_ + " blocks §7(see the Materials HUD)",
         this.temporaryNeed() > 0
            ? "§7+ "
               + this.temporaryNeed()
               + " temporary blocks (dirt, cobble...)"
               + (this.tempHave >= this.temporaryNeed() ? " §a✓" : " §6- you have " + this.tempHave)
            : ""
      };
   }

   private void render(WorldRenderContext context) {
      if (this.isEnabled() && !this.targets.isEmpty()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         ClientWorld world = mc.world;
         if (world != null) {
            Matrix4f m = Esp3D.matrix(context);
            VertexConsumer lines = Esp3D.lines(context);
            VertexConsumer quads = Esp3D.quads(context);
            Vec3d cam = Esp3D.cameraPos();
            if (SchematicPreviewScreen.isOpen()) {
               MatrixStack ms = context.matrices();
               VertexConsumerProvider buffers = context.consumers();
               BlockRenderManager blocks = mc.getBlockRenderManager();
               int drawn = 0;

               if(previewTargets.size()>2048)schematicMesh.draw(ms,cam,true);
               for (AutoSchematicBuilderModule.Target t : this.previewTargets) {
                  if(previewTargets.size()>2048)break;

                  ms.push();
                  ms.translate((float)(t.pos().getX() - cam.x), (float)(t.pos().getY() - cam.y), (float)(t.pos().getZ() - cam.z));
                  blocks.renderBlockAsEntity(t.state(), ms, buffers, 15728880, 655360);
                  ms.pop();
               }
            } else if (this.ghost.get()) {
               if(ghostStyle.is("All"))schematicMesh.draw(context.matrices(),cam,false);
               this.renderGhosts(context, world, m, cam);
            }

            if (this.boxMin != null && !SchematicPreviewScreen.isOpen()) {
               EspBoxRenderer.outline(
                  Esp3D.softLines(context),
                  m,
                  this.boxMin.getX(),
                  this.boxMin.getY(),
                  this.boxMin.getZ(),
                  this.boxMax.getX() + 1.0,
                  this.boxMax.getY() + 1.0,
                  this.boxMax.getZ() + 1.0,
                  Colors.withAlpha(-1, 0.22F),
                  1.2F
               );
            } else if (this.boxMin != null) {
               EspBoxRenderer.outline(
                  lines,
                  m,
                  this.boxMin.getX(),
                  this.boxMin.getY(),
                  this.boxMin.getZ(),
                  this.boxMax.getX() + 1.0,
                  this.boxMax.getY() + 1.0,
                  this.boxMax.getZ() + 1.0,
                  Colors.withAlpha(-1, 0.35F),
                  1.5F
               );
            }
         }
      }
   }

   private static double[][] shapeEdges(ClientWorld world, BlockPos pos, BlockState s) {
      double[][] cached = SHAPES.get(s);
      if (cached != null) {
         return cached;
      } else {
         List<double[]> e = new ArrayList<>();

         try {
            VoxelShape shape = s.getOutlineShape(world, pos);
            if (shape != null && !shape.isEmpty()) {
               shape.forEachEdge((x1, y1, z1, x2, y2, z2) -> e.add(new double[]{x1, y1, z1, x2, y2, z2}));
            }
         } catch (RuntimeException var16) {
         }

         double[][] out = e.isEmpty() ? CUBE : e.toArray(new double[0][]);
         boolean full = out.length == 12;

         for (double[] seg : out) {
            for (double v : seg) {
               if (v != 0.0 && v != 1.0) {
                  full = false;
               }
            }
         }

         FULL.put(s, full);
         SHAPES.put(s, out);
         return out;
      }
   }

   private static int blockColor(ClientWorld world, BlockPos pos, BlockState s) {
      Integer cached = COLORS.get(s);
      if (cached != null) {
         return cached;
      } else {
         int rgb = 11843776;

         try {
            int map = s.getMapColor(world, pos).color;
            if (map != 0) {
               rgb = map;
            }
         } catch (RuntimeException var7) {
         }

         float[] hsb = Color.RGBtoHSB(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, null);
         hsb[1] = Math.min(1.0F, hsb[1] * 1.2F);
         hsb[2] = Math.max(0.6F, Math.min(1.0F, hsb[2] * 1.15F));
         int out = 0xFF000000 | Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]) & 16777215;
         COLORS.put(s, out);
         return out;
      }
   }

   private static boolean isFull(ClientWorld world, BlockPos pos, BlockState s) {
      shapeEdges(world, pos, s);
      return Boolean.TRUE.equals(FULL.get(s));
   }

   private boolean buried(ClientWorld world, BlockPos pos) {
      for (Direction d : Direction.values()) {
         BlockPos nb = pos.offset(d);
         if (this.missing.containsKey(nb)) {
            AutoSchematicBuilderModule.Target nt = this.byPos.get(nb);
            if (nt == null || !isFull(world, nb, nt.state())) {
               return false;
            }
         } else {
            BlockState ns = world.getBlockState(nb);
            if (ns.isReplaceable() || !Placement.faceSolid(world, nb, ns, d.getOpposite())) {
               return false;
            }
         }
      }

      return true;
   }

   private static void drawShape(VertexConsumer buf, Matrix4f m, double[][] shape, BlockPos pos, double scale, int color, float width) {
      double cx = pos.getX() + 0.5;
      double cy = pos.getY() + 0.5;
      double cz = pos.getZ() + 0.5;

      for (double[] s : shape) {
         EspBoxRenderer.tracer(
            buf,
            m,
            cx + (s[0] - 0.5) * scale,
            cy + (s[1] - 0.5) * scale,
            cz + (s[2] - 0.5) * scale,
            cx + (s[3] - 0.5) * scale,
            cy + (s[4] - 0.5) * scale,
            cz + (s[5] - 0.5) * scale,
            color,
            width
         );
      }
   }

   private static void flashFaces(VertexConsumer fills, Matrix4f m, BlockPos pos, double grow, int color) {
      double x1 = pos.getX() - grow;
      double y1 = pos.getY() - grow;
      double z1 = pos.getZ() - grow;
      double x2 = pos.getX() + 1.0 + grow;
      double y2 = pos.getY() + 1.0 + grow;
      double z2 = pos.getZ() + 1.0 + grow;
      face(fills, m, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, color);
      face(fills, m, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, color);
      face(fills, m, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, color);
      face(fills, m, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, color);
      face(fills, m, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, color);
      face(fills, m, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, color);
   }

   private void renderGhosts(WorldRenderContext context, ClientWorld world, Matrix4f m, Vec3d cam) {
      VertexConsumer fills = Esp3D.soft(context);
      VertexConsumer edges = Esp3D.softLines(context);
      long now = System.currentTimeMillis();
      float pulse = 0.5F + 0.5F * (float)Math.sin(now / 220.0);
      BlockPos aimPos = this.aim != null && this.phase == AutoSchematicBuilderModule.Phase.AIM ? this.aim.pos() : null;
      double k = 0.972;
      int drawn = 0;
      int models = 0;
      MinecraftClient mc = MinecraftClient.getInstance();
      BlockRenderManager blocks = mc.getBlockRenderManager();
      BlockColors colors = mc.getBlockColors();
      MatrixStack ms = context.matrices();
      VertexConsumer vc = context.consumers().getBuffer(TexturedRenderLayers.getBlockTranslucentCull());

      long ghostDeadline=System.nanoTime()+2_500_000L;
      for (Entry<BlockPos, Integer> e : this.missing.entrySet()) {
         if (drawn >= 1200 || System.nanoTime()>ghostDeadline) {
            break;
         }

         BlockPos pos = e.getKey();
         AutoSchematicBuilderModule.Target t = this.byPos.get(pos);
         if (t != null) {
            double x = pos.getX();
            double y = pos.getY();
            double z = pos.getZ();
            double dx = x + 0.5 - cam.x;
            double dy = y + 0.5 - cam.y;
            double dz = z + 0.5 - cam.z;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (!(d2 > 3136.0) && (!(Math.abs(dx) < 0.62) || !(Math.abs(dy) < 0.62) || !(Math.abs(dz) < 0.62))) {
               double[][] shape = shapeEdges(world, pos, t.state());
               boolean full = isFull(world, pos, t.state());
               if (!full || !this.buried(world, pos)) {
                  drawn++;
                  int kind = e.getValue();
                  boolean current = pos.equals(aimPos);
                  float fade = (float)Math.max(0.25, Math.min(1.0, 1.0 - (Math.sqrt(d2) - 28.0) / 28.0));
                  boolean near = d2 <= 484.0 && models < 160;
                  List<BlockModelPart> parts = kind != 2 && near ? modelParts(blocks, t.state()) : List.of();
                  if (!parts.isEmpty()) {
                     models++;
                     float a = (current ? 0.55F + 0.25F * pulse : 0.42F) * fade;
                     float gb = kind == 1 ? 0.55F : 1.0F;
                     this.drawGhostModel(vc, ms, cam, world, pos, t.state(), parts, 1.0F, gb, gb, a, colors);
                     if (current) {
                        drawShape(edges, m, shape, pos, 1.004, Colors.withAlpha(-1, 0.6F + 0.3F * pulse), 2.2F);
                     }
                  } else {
                     int base = blockColor(world, pos, t.state());
                     int color = kind == 1 ? Ui.lerp(base, -489871, 0.55F) : (kind == 2 ? Ui.lerp(base, -290244, 0.55F) : base);
                     drawShape(edges, m, shape, pos, k, Colors.withAlpha(color, (current ? 0.8F + 0.2F * pulse : 0.8F) * fade), current ? 2.6F : 1.5F);
                     if (full) {
                        double x1 = x + 0.014;
                        double y1 = y + 0.014;
                        double z1 = z + 0.014;
                        double x2 = x + 0.986;
                        double y2 = y + 0.986;
                        double z2 = z + 0.986;
                        int fill = Colors.withAlpha(color, (current ? 0.14F + 0.12F * pulse : 0.05F) * fade);
                        int facing = (cam.y < y1 ? 1 : 0)
                           | (cam.y > y2 ? 2 : 0)
                           | (cam.z < z1 ? 4 : 0)
                           | (cam.z > z2 ? 8 : 0)
                           | (cam.x < x1 ? 16 : 0)
                           | (cam.x > x2 ? 32 : 0);
                        if ((facing & 1) != 0) {
                           face(fills, m, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, fill);
                        }

                        if ((facing & 2) != 0) {
                           face(fills, m, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, fill);
                        }

                        if ((facing & 4) != 0) {
                           face(fills, m, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, fill);
                        }

                        if ((facing & 8) != 0) {
                           face(fills, m, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, fill);
                        }

                        if ((facing & 16) != 0) {
                           face(fills, m, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, fill);
                        }

                        if ((facing & 32) != 0) {
                           face(fills, m, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, fill);
                        }
                     }
                  }
               }
            }
         }
      }

      for (Entry<BlockPos, Long> e : this.placedAt.entrySet()) {
         float t = (float)(now - e.getValue()) / 900.0F;
         if (!(t < 0.0F) && !(t >= 1.0F)) {
            BlockPos pos = e.getKey();
            AutoSchematicBuilderModule.Target tg = this.byPos.get(pos);
            BlockState st = tg != null ? tg.state() : world.getBlockState(pos);
            double[][] shape = shapeEdges(world, pos, st);
            float ease = 1.0F - (float)Math.pow(1.0F - t, 3.0);
            drawShape(edges, m, shape, pos, 1.0 + 0.2 * ease, Colors.withAlpha(-11870592, 0.9F * (1.0F - t)), 2.4F);
            float hold = t < 0.3F ? 1.0F : 1.0F - (t - 0.3F) / 0.7F;
            drawShape(edges, m, shape, pos, 1.006, Colors.withAlpha(Ui.lerp(-11870592, -1, 0.35F), hold), 2.0F);
            if (isFull(world, pos, st)) {
               flashFaces(fills, m, pos, 0.006, Colors.withAlpha(-11870592, 0.32F * (1.0F - t) * (1.0F - t)));
            }
         }
      }

      for (Entry<BlockPos, Long> ex : this.rejectedAt.entrySet()) {
         float t = (float)(now - ex.getValue()) / 700.0F;
         if (!(t < 0.0F) && !(t >= 1.0F)) {
            BlockPos pos = ex.getKey();
            AutoSchematicBuilderModule.Target tg = this.byPos.get(pos);
            if (tg != null) {
               double[][] shape = shapeEdges(world, pos, tg.state());
               float ease = 1.0F - (float)Math.pow(1.0F - t, 3.0);
               drawShape(edges, m, shape, pos, 1.16 - 0.16 * ease, Colors.withAlpha(-489871, 0.95F * (1.0F - t)), 2.6F);
            }
         }
      }

      if (this.path != null && this.phase == AutoSchematicBuilderModule.Phase.WALK) {
         for (int i = Math.max(1, this.pathIndex); i < this.path.size(); i++) {
            BlockPos a = this.path.get(i - 1);
            BlockPos b = this.path.get(i);
            EspBoxRenderer.tracer(
               edges,
               m,
               a.getX() + 0.5,
               a.getY() + 0.08,
               a.getZ() + 0.5,
               b.getX() + 0.5,
               b.getY() + 0.08,
               b.getZ() + 0.5,
               Colors.withAlpha(-14560274, 0.6F),
               2.0F
            );
         }
      }
   }

   private static List<BlockModelPart> modelParts(BlockRenderManager blocks, BlockState s) {
      Object probe = blocks.getModel(Blocks.STONE.getDefaultState());
      if (probe != modelsProbe) {
         MODEL_PARTS.clear();
         modelsProbe = probe;
      }

      List<BlockModelPart> parts = MODEL_PARTS.get(s);
      if (parts == null) {
         parts = List.of();

         try {
            if (s.getRenderType() == BlockRenderType.MODEL) {
               GHOST_RANDOM.setSeed(42L);
               parts = List.copyOf(blocks.getModel(s).getParts(GHOST_RANDOM));
            }
         } catch (RuntimeException var5) {
         }

         MODEL_PARTS.put(s, parts);
      }

      return parts;
   }

   private boolean ghostFaceHidden(ClientWorld world, BlockPos pos, Direction d) {
      BlockPos nb = pos.offset(d);
      if (this.missing.containsKey(nb)) {
         AutoSchematicBuilderModule.Target nt = this.byPos.get(nb);
         return nt != null && this.missing.get(nb) != 2 && isFull(world, nb, nt.state());
      } else {
         BlockState ns = world.getBlockState(nb);
         return !ns.isReplaceable() && Placement.faceSolid(world, nb, ns, d.getOpposite());
      }
   }

   private void drawGhostModel(
      VertexConsumer vc,
      MatrixStack ms,
      Vec3d cam,
      ClientWorld world,
      BlockPos pos,
      BlockState s,
      List<BlockModelPart> parts,
      float r,
      float g,
      float b,
      float a,
      BlockColors colors
   ) {
      ms.push();
      ms.translate((float)(pos.getX() - cam.x), (float)(pos.getY() - cam.y), (float)(pos.getZ() - cam.z));
      net.minecraft.client.util.math.MatrixStack.Entry entry = ms.peek();

      for (BlockModelPart part : parts) {
         for (int i = 0; i <= 6; i++) {
            Direction d = i < 6 ? Direction.values()[i] : null;
            if (d == null || !this.ghostFaceHidden(world, pos, d)) {
               for (BakedQuad q : part.getQuads(d)) {
                  float qr = r;
                  float qg = g;
                  float qb = b;
                  if (q.tintIndex() != -1) {
                     int c = colors.getColor(s, world, pos, q.tintIndex());
                     if (c != -1) {
                        qr = r * ((c >> 16 & 0xFF) / 255.0F);
                        qg = g * ((c >> 8 & 0xFF) / 255.0F);
                        qb = b * ((c & 0xFF) / 255.0F);
                     }
                  }

                  vc.quad(entry, q, qr, qg, qb, a, 15728880, 655360);
               }
            }
         }
      }

      ms.pop();
   }

   private static void face(
      VertexConsumer buf,
      Matrix4f m,
      double ax,
      double ay,
      double az,
      double bx,
      double by,
      double bz,
      double cx,
      double cy,
      double cz,
      double dx,
      double dy,
      double dz,
      int color
   ) {
      buf.vertex(m, (float)ax, (float)ay, (float)az).color(color);
      buf.vertex(m, (float)bx, (float)by, (float)bz).color(color);
      buf.vertex(m, (float)cx, (float)cy, (float)cz).color(color);
      buf.vertex(m, (float)dx, (float)dy, (float)dz).color(color);
   }

   private void renderHud(DrawContext ctx, RenderTickCounter tickCounter) {
      if(!cherryblossom.integration.TrialAccess.allowed())return;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.isEnabled() && this.hud.get() && this.schematic != null && mc.player != null && !mc.options.hudHidden) {
         HudStyle.frame();
         this.renderCelebration(ctx);
         boolean free = creative(mc);
         float pad = 7.0F;
         float rowH = 18.0F;
         float headH = 30.0F;
         List<AutoSchematicBuilderModule.Need> all = this.needs;
         AutoSchematicBuilderModule.Need temp = this.temporaryRow();
         if (temp != null) {
            all = new ArrayList<>(all);
            all.add(temp);
         }

         int maxScroll = Math.max(0, all.size() - 8);
         this.hudScroll = Math.max(0.0F, Math.min((float)maxScroll, this.hudScroll));
         float scroll = HudStyle.anim("schem:scroll", this.hudScroll, 16.0F);
         MutableText title = Ui.bold("Schematic");
         String progress = this.layerStatus();
         String status=this.buildStatus();
         String sub = !this.building.get() ? "Paused - K to resume" : Character.toUpperCase(status.charAt(0)) + status.substring(1);
         if (this.placedCount < this.targets.size() && (this.building.get() || this.placeTimes.size() >= 5)) {
            sub = sub + "  ·  ~" + duration(this.secondsLeft()) + " left";
         }

         float contentW = Math.max(150.0F, Ui.width(Ui.t(sub)) * 0.85F + 10.0F);
           contentW=Math.max(contentW,Ui.width(title)+Ui.width(Ui.t(progress))*.85f+32);

         for (AutoSchematicBuilderModule.Need n : all) {
            contentW = Math.max(contentW, 22.0F + Ui.width(Ui.t(n.name())) * 0.85F + 52.0F);
         }

         float w = HudStyle.anim("schem:w", contentW + pad * 2.0F, 14.0F);
         int shown = all.isEmpty() ? 1 : Math.min(8, all.size());
         boolean scrolls = all.size() > 8;
         float h = HudStyle.anim("schem:h", headH + shown * rowH + pad + (scrolls ? 11.0F : 0.0F), 14.0F);
         float sw = ctx.getScaledWindowWidth();
         float sh = ctx.getScaledWindowHeight();
         float x = HudStyle.clamp(this.hudX.getFloat() / 100.0F * (sw - w), w, sw);
         float y = HudStyle.clamp(this.hudY.getFloat() / 100.0F * (sh - h), h, sh);
           float unit=(float)mc.getWindow().getScaleFactor();
           float[] moved=HudDragging.place("schematic",x*unit,y*unit,w*unit,h*unit,
              (px,py)->{this.hudX.setValue(px/unit/Math.max(1,sw-w)*100);this.hudY.setValue(py/unit/Math.max(1,sh-h)*100);});
           x=moved[0]/unit;y=moved[1]/unit;
         this.bounds[0] = x;
         this.bounds[1] = y;
         this.bounds[2] = w;
         this.bounds[3] = h;
         HudStyle.panel(ctx, x, y, w, h, 7.0F, 0.6F);
         Icons.draw(ctx, Icons.Type.CUBE, x + pad, y + pad - 1.0F, 10.0F, HudStyle.accent());
         Ui.text(ctx, title, x + pad + 14.0F, y + pad, 1.0F, -1447444);
         Ui.text(ctx, Ui.t(progress), x + w - pad - Ui.width(Ui.t(progress)) * 0.85F, y + pad + 1.0F, 0.85F, -6644573);
         Ui.text(ctx, Ui.t(sub), x + pad, y + pad + 12.0F, 0.85F, this.building.get() ? -11870592 : -6644573);
         Ui.hLine(ctx, x + pad, x + w - pad, y + headH - 2.0F, 520093695);
         float top = y + headH;
         if (all.isEmpty()) {
            Icons.draw(ctx, Icons.Type.CHECK, x + pad, top + 4.0F, 8.0F, -11870592);
            Ui.text(ctx, Ui.t("Nothing left to place"), x + pad + 12.0F, top + 4.0F, 0.85F, -6644573);
         } else {
            float listH = shown * rowH;
            ctx.enableScissor((int)x, (int)top, (int)Math.ceil(x + w), (int)Math.ceil(top + listH));
            int first = Math.max(0, (int)Math.floor(scroll));

            for (int i = first; i < Math.min(all.size(), first + 8 + 1); i++) {
               AutoSchematicBuilderModule.Need n = all.get(i);
               float ry = top + (i - scroll) * rowH;
               ctx.drawItem(new ItemStack(n.item(), 1), (int)(x + pad), (int)ry);
               Ui.text(ctx, Ui.t(n.name()), x + pad + 20.0F, ry + 4.0F, 0.85F, n == temp ? -6644573 : -1447444);
               String count = free ? "free" : Math.min(n.have(), n.need()) + "/" + n.need();
               int color = !free && n.have() < n.need() ? -489871 : -11870592;
               float cxr = x + w - pad - (scrolls ? 5.0F : 0.0F) - Ui.width(Ui.t(count)) * 0.85F;
               Ui.text(ctx, Ui.t(count), cxr, ry + 4.0F, 0.85F, color);
               Long got = n == temp ? null : this.checkedAt.get(n.item());
               if (!free && got != null) {
                  float a = Math.min(1.0F, (float)(System.currentTimeMillis() - got) / 260.0F);
                  float pop = a < 1.0F ? (float)(1.0 + 0.35 * Math.sin(a * Math.PI)) * a : 1.0F;
                  float r = 4.6F * pop;
                  float ccx = cxr - 8.0F;
                  float ccy = ry + 8.0F;
                  Gfx.circle(ctx, ccx, ccy, r, Colors.withAlpha(-11870592, 0.22F));
                  Icons.draw(ctx, Icons.Type.CHECK, ccx - 3.5F * pop, ccy - 3.5F * pop, 7.0F * pop, -11870592);
               }
            }

            ctx.disableScissor();
            if (scrolls) {
               float trackX = x + w - pad + 2.0F;
               float thumbH = Math.max(10.0F, listH * 8.0F / all.size());
               float thumbY = top + (listH - thumbH) * (scroll / Math.max(1, maxScroll));
               Ui.round(ctx, trackX, top, 2.0F, listH, 1.0F, 285212671);
               Ui.round(ctx, trackX, thumbY, 2.0F, thumbH, 1.0F, HudStyle.accent());
               String hint = first + 1 + "-" + Math.min(all.size(), first + 8) + " of " + all.size() + "  |  scroll in chat";
               Ui.text(ctx, Ui.t(hint), x + pad, top + listH + 2.0F, 0.7F, -6644573);
            }
         }
      } else {
         this.bounds[2] = 0.0F;
      }
   }

   private void renderCelebration(DrawContext ctx) {
      long age = System.currentTimeMillis() - this.celebrateAt;
      if (this.celebrateAt != 0L && age <= 4200L) {
         float sw = ctx.getScaledWindowWidth();
         float in = Math.min(1.0F, (float)age / 380.0F);
         float out = age > 3600L ? (float)(age - 3600L) / 600.0F : 0.0F;
         float e = 1.0F - (float)Math.pow(1.0F - in, 3.0);
         float pop = in < 1.0F ? 0.82F + 0.18F * e + 0.06F * (float)Math.sin(in * Math.PI) : 1.0F;
         float alpha = e * (1.0F - out);
         if (!(alpha <= 0.01F)) {
            int left = Math.max(0, this.targets.size() - this.placedCount);
            String title = "You've got all the blocks!";
            String sub = left + " blocks to place  ·  about " + duration(this.secondsLeft()) + (this.building.get() ? "" : "  ·  press K to build");
            float ts = 1.35F * pop;
            float ss = 0.85F * pop;
            float w = Math.max(Ui.width(Ui.bold(title)) * ts, Ui.width(Ui.t(sub)) * ss) + 70.0F * pop;
            float h = 48.0F * pop;
            float x = (sw - w) / 2.0F;
            float y = 34.0F + (1.0F - e) * -12.0F;
            float prev = Gfx.alpha;
            Gfx.alpha = prev * alpha;
            float cx = x + 26.0F * pop;
            float cy = y + h / 2.0F;

            for (int i = 0; i < 2; i++) {
               float t = (float)((age + i * 450L) % 1400L) / 1400.0F;
               if (age <= 2800L || !(t < 0.2F)) {
                  Ui.outline(
                     ctx,
                     cx - (11.0F + 22.0F * t) * pop,
                     cy - (11.0F + 22.0F * t) * pop,
                     (22.0F + 44.0F * t) * pop,
                     (22.0F + 44.0F * t) * pop,
                     (11.0F + 22.0F * t) * pop,
                     Colors.withAlpha(-11870592, 0.5F * (1.0F - t))
                  );
               }
            }

            HudStyle.panel(ctx, x, y, w, h, 12.0F * pop, 0.85F);
            Ui.outline(ctx, x, y, w, h, 12.0F * pop, Colors.withAlpha(-11870592, 0.45F));
            Gfx.circle(ctx, cx, cy, 13.0F * pop, Colors.withAlpha(-11870592, 0.22F));
            Gfx.circle(ctx, cx, cy, 10.0F * pop, -11870592);
            Icons.draw(ctx, Icons.Type.CHECK, cx - 6.5F * pop, cy - 6.5F * pop, 13.0F * pop, -16049648);
            float tx = x + 48.0F * pop;
            Ui.text(ctx, Ui.bold(title), tx, y + 10.0F * pop, ts, -1);
            Ui.text(ctx, Ui.t(sub), tx, y + 28.0F * pop, ss, -6644573);
            Gfx.alpha = prev;
         }
      }
   }

   @Override
   public String widgetName() {
      return "Schematic";
   }

   @Override
   public boolean widgetVisible() {
      return this.isEnabled() && this.hud.get() && this.bounds[2] > 0.0F;
   }

   @Override
   public float[] widgetBounds() {
      return this.bounds;
   }

   @Override
   public void widgetMoveTo(float x, float y, float sw, float sh) {
      float w = this.bounds[2];
      float h = this.bounds[3];
      this.hudX.setValue(Math.max(0.0F, Math.min(100.0F, x / Math.max(1.0F, sw - w) * 100.0F)));
      this.hudY.setValue(Math.max(0.0F, Math.min(100.0F, y / Math.max(1.0F, sh - h) * 100.0F)));
   }

   @Override
   public void widgetScale(float amount) {
      if (amount != 0.0F) {
         this.hudScroll = Math.max(
            0.0F, Math.min((float)Math.max(0, this.needs.size() + (this.temporaryRow() == null ? 0 : 1) - 8), this.hudScroll - Math.signum(amount))
         );
      }
   }

   @Override
   public boolean widgetClick(double mx, double my) {
      if (!(mx < this.bounds[0]) && !(my < this.bounds[1]) && !(mx > this.bounds[0] + this.bounds[2]) && !(my > this.bounds[1] + this.bounds[3])) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player == null) {
            return false;
         } else if (!creative(mc)) {
            this.printMaterials(mc);
            return true;
         } else {
            PlayerInventory inv = mc.player.getInventory();
            int given = 0;

            for (AutoSchematicBuilderModule.Need n : this.needs) {
               int left = n.need() - n.have();

               for (int slot = 9; slot < 36 && left > 0; slot++) {
                  if (inv.getStack(slot).isEmpty()) {
                     int count = Math.min(64, left);
                     ItemStack stack = new ItemStack(n.item(), count);
                     inv.setStack(slot, stack);
                     mc.interactionManager.clickCreativeStack(stack, slot);
                     left -= count;
                     given++;
                  }
               }
            }

            message(mc, given > 0 ? "Gave you what the build needs." : "No free inventory space to put blocks in.");
            return true;
         }
      } else {
         return false;
      }
   }

   private static void message(MinecraftClient mc, String text) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("§d[CherryBlossom] §f" + text), false);
      }
   }

   private static void line(MinecraftClient mc, String text) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("  " + text), false);
      }
   }

   private record Cached(int signature, List<Placement.Option> options) {
   }

   public record Need(Item item, String name, int have, int need) {
   }

   private static enum Phase {
      IDLE,
      WALK,
      AIM,
      TOWER_UP,
      TOWER_DOWN,
      CLEAN,
      DIG,
      SUPPLY,
      BRIDGE;
   }

   private record Ready(AutoSchematicBuilderModule.Target t, Placement.Choice c, double score) {
   }

   private record Spare(Item item, int count, double rank) {
   }

   private record Step(BlockPos pos, double cost, int blocks) {
   }

   private static enum Take {
      TOOK,
      FULL,
      DONE;
   }

   private record Target(BlockPos pos, BlockState state, Item item, String id) {
   }

   private record TowerSpot(BlockPos ground, int top, double score, boolean inBuild) {
   }
}
