package cherryblossom.feature;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.Render2DEvent;
import cherryblossom.event.events.TickEvent;
import cherryblossom.feature.StaffListPanel.StaffMember;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.NewFeature;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.Window;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;

public final class StaffListModule extends Module implements NewFeature {
   private final BooleanSetting showEmpty = new BooleanSetting("Show When Empty", true);
   private final BooleanSetting avatars = new BooleanSetting("Head Avatars", true);
   private final BooleanSetting notify = new BooleanSetting("Chat Notifications", false);
   private final BooleanSetting sound = new BooleanSetting("Alert Sound", false);
   private final NumberSetting posX = new NumberSetting("Position X", 0.0, 2560.0, 25.0, 1.0);
   private final NumberSetting posY = new NumberSetting("Position Y", 0.0, 1440.0, 140.0, 1.0);
   private final NumberSetting scale = new NumberSetting("Scale", 0.5, 2.5, 1.0, 0.05);
   private final NumberSetting width = new NumberSetting("Width", 140.0, 450.0, 210.0, 5.0);
   private final NumberSetting opacity = new NumberSetting("Opacity", 0.0, 1.0, 0.62, 0.05);
   private final StaffListPanel panel = new StaffListPanel();
   private Map<String, StaffMember> staff = Map.of();
   private Object world;
   private int ticks;
   private boolean initialized;
   private long lastRender;

   public StaffListModule() {
      super("Staff List", "Shows staff from player names and scoreboard ranks.", -1, Category.DONUT);
      addSettings(showEmpty, avatars, notify, sound, posX, posY, scale, width, opacity);
   }

   public void onEnable() {
      clear();
   }

   public void onDisable() {
      clear();
   }

   private void clear() {
      staff = Map.of();
      panel.reset();
      world = null;
      ticks = 0;
      initialized = false;
      lastRender = 0L;
   }

   private static String text(Text value) {
      return value == null ? "" : value.getString();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.world == null || mc.player == null || mc.getNetworkHandler() == null) {
         if (world != null) {
            clear();
         }
         return;
      }
      if (world != mc.world) {
         clear();
         world = mc.world;
      }
      if (ticks++ % 5 != 0) {
         return;
      }

      Map<String, StaffMember> found = new TreeMap<>();
      for (PlayerListEntry player : mc.getNetworkHandler().getPlayerList()) {
         if (player.getProfile() == null) {
            continue;
         }
         String name = player.getProfile().name();
         if (name == null || name.isEmpty()) {
            continue;
         }
         Team team = player.getScoreboardTeam();
         String display = text(player.getDisplayName());
         String teamName = team == null ? "" : team.getName();
         String prefix = team == null ? "" : text(team.getPrefix());
         String suffix = team == null ? "" : text(team.getSuffix());
         if (StaffClassifier.isStaff(name, display, teamName, prefix, suffix)) {
            found.put(name.toLowerCase(Locale.ROOT), new StaffMember(name, player.getProfile().id()));
         }
      }
      for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
         String name = player.getGameProfile().name();
         if (name != null && StaffClassifier.knownName(name)) {
            found.putIfAbsent(name.toLowerCase(Locale.ROOT), new StaffMember(name, player.getUuid()));
         }
      }

      if (initialized) {
         boolean joined = false;
         for (Map.Entry<String, StaffMember> entry : found.entrySet()) {
            if (!staff.containsKey(entry.getKey())) {
               joined = true;
               if (notify.getValue()) {
                  message(entry.getValue().name() + " is now online.");
               }
            }
         }
         if (joined && sound.getValue()) {
            UiAudio.play(UiAudio.Cue.CONFIRM);
         }
         if (notify.getValue()) {
            for (Map.Entry<String, StaffMember> entry : staff.entrySet()) {
               if (!found.containsKey(entry.getKey())) {
                  message(entry.getValue().name() + " left or vanished.");
               }
            }
         }
      }
      initialized = true;
      if (!found.equals(staff)) {
         staff = found;
         panel.setMembers(List.copyOf(found.values()));
      }
   }

   private void message(String value) {
      if (mc.inGameHud != null) {
         mc.inGameHud.getChatHud().addMessage(
            Text.literal("CherryBlossom · Staff List  ").append(Text.literal(value)));
      }
   }

   @EventListener
   public void onRender(Render2DEvent event) {
      if (mc.world == null || mc.player == null || mc.options.hudHidden || event.context == null) {
         return;
      }
      Window window = mc.getWindow();
      long now = System.nanoTime();
      float delta = lastRender == 0L ? 0.016F : Math.min(0.1F, (float)(now - lastRender) / 1.0E9F);
      lastRender = now;

      float panelScale = Math.max(0.45F, window.getFramebufferHeight() / 1080.0F)
         * scale.getFloatValue();
      float panelWidth = Math.min(width.getFloatValue() * panelScale,
         Math.max(1, window.getFramebufferWidth() - 16));
      float x = Math.max(8.0F, Math.min(posX.getFloatValue() * panelScale,
         window.getFramebufferWidth() - panelWidth - 8.0F));
      float y = Math.max(8.0F, Math.min(posY.getFloatValue() * panelScale,
         window.getFramebufferHeight() - 108.0F * panelScale));
      float displayScale = window.getScaleFactor();
      float[] moved=HudDragging.place("staff",x,y,panelWidth,Math.max(84,54+staff.size()*30)*panelScale,
         (px,py)->{posX.getValue(px/panelScale);posY.getValue(py/panelScale);});
      x=moved[0];y=moved[1];

      Matrix3x2fStack matrices = event.context.getMatrices();
      matrices.pushMatrix();
      matrices.scale(1.0F / displayScale, 1.0F / displayScale);
      try {
         panel.render(new MinecraftUiRenderer(event.context, displayScale), x, y,
            panelWidth, panelScale, opacity.getFloatValue(), delta,
            true,
            showEmpty.getValue() || mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen, avatars.getValue(), window.getFramebufferHeight(),
            (member, headX, headY, size, alpha) ->
               drawHead(event.context, member, headX, headY, size, alpha));
      } finally {
         matrices.popMatrix();
      }
   }

   private void drawHead(DrawContext context, StaffMember member,
                         float x, float y, float size, float alpha) {
      PlayerListEntry player = mc.getNetworkHandler() == null
         ? null : mc.getNetworkHandler().getPlayerListEntry(member.uuid());
      if (player == null) {
         new MinecraftUiRenderer(context, mc.getWindow().getScaleFactor())
            .icon(UiIcon.USER, x, y, size, UiRenderer.white(alpha * 0.5F));
         return;
      }
      PlayerSkinDrawer.draw(context, player.getSkinTextures(), Math.round(x), Math.round(y),
         Math.max(1, Math.round(size)), UiRenderer.white(alpha));
   }
}
