package cherryblossom.feature;

public final class SpotifyHudRenderer {
    private SpotifyHudRenderer(){}
    public static String time(long millis){long seconds=Math.max(0,millis)/1000;return seconds/60+":"+String.format(java.util.Locale.ROOT,"%02d",seconds%60);}
    public static void draw(UiRenderer r,float x,float y,float u,float opacity,SpotifyNowPlaying.Track track){
        float w=310*u,h=132*u;
        r.shadow(x,y,w,h,14*u,12*u,UiRenderer.argb(.25f,0,0,0));
        r.round(x,y,w,h,14*u,CherryHudPalette.glass(opacity));
        r.outline(x,y,w,h,14*u,Math.max(1,u),CherryHudPalette.accent(.22f));
        r.text("SPOTIFY",x+12*u,y+10*u,10*u,1,CherryHudPalette.accent(1));
        String status=track.present()?(track.playing()?"PLAYING":"PAUSED"):"NOT PLAYING";
        r.textRight(status,x+w-12*u,y+10*u,9*u,0,UiRenderer.white(.55f));
        r.round(x+12*u,y+29*u,40*u,40*u,9*u,CherryHudPalette.accent(.13f));
        // A small musical note keeps the panel consistent with the client artwork.
        r.round(x+31*u,y+38*u,3*u,20*u,1.5f*u,CherryHudPalette.accent(.95f));
        r.round(x+31*u,y+38*u,9*u,3*u,1.5f*u,CherryHudPalette.accent(.95f));
        r.circle(x+28*u,y+58*u,5*u,CherryHudPalette.accent(.95f));
        if(track.present()&&track.artwork()!=null)r.texture(track.artwork(),x+12*u,y+29*u,40*u,40*u,0xFFFFFFFF);
        String title=track.present()?track.title():"Nothing playing";
        String artist=track.present()?track.artist():switch(track.status()){
            case "unsupported"->"Spotify HUD needs Windows";
            case "needs_client_id"->"Add client_id to spotify-api.json";
            case "needs_login"->"Open the login link from chat";
            case "unavailable"->"Waiting for Spotify";
            default->"Open Spotify and play a song";
        };
        r.pushClip(x+64*u,y+28*u,w-77*u,43*u);
        r.text(fit(r,title,14*u,1,w-77*u),x+64*u,y+30*u,14*u,1,UiRenderer.white(.97f));
        r.text(fit(r,artist,11*u,0,w-77*u),x+64*u,y+51*u,11*u,0,UiRenderer.white(.65f));
        r.popClip();
        long position=track.present()?track.positionAt(System.nanoTime()):0;
        float progress=track.durationMs()>0?Math.max(0,Math.min(1,(float)position/track.durationMs())):0;
        r.text(time(position),x+12*u,y+81*u,9*u,0,UiRenderer.white(.65f));
        r.textRight(time(track.durationMs()),x+w-12*u,y+81*u,9*u,0,UiRenderer.white(.65f));
        r.round(x+53*u,y+85*u,w-106*u,3*u,1.5f*u,UiRenderer.white(.13f));
        if(progress>0)r.round(x+53*u,y+85*u,(w-106*u)*progress,3*u,1.5f*u,CherryHudPalette.accent(.9f));
        int icon=UiRenderer.white(track.present()?.95f:.25f);
        for(int i=0;i<3;i++)r.circle(x+(111+i*44)*u,y+111*u,14*u,CherryHudPalette.accent(track.present()?(i==1?.24f:.1f):.05f));
        triangle(r,x+112*u,y+111*u,5*u,false,icon);r.round(x+105*u,y+106*u,2*u,10*u,.5f*u,icon);
        if(track.playing()){
            r.round(x+150*u,y+106*u,3*u,10*u,.5f*u,icon);r.round(x+157*u,y+106*u,3*u,10*u,.5f*u,icon);
        }else triangle(r,x+155*u,y+111*u,5*u,true,icon);
        triangle(r,x+198*u,y+111*u,5*u,true,icon);r.round(x+204*u,y+106*u,2*u,10*u,.5f*u,icon);
    }
    private static void triangle(UiRenderer r,float x,float y,float size,boolean right,int color){
        int steps=Math.max(4,Math.round(size*2));
        for(int i=0;i<steps;i++){float t=(i+.5f)/steps;float half=size*(right?1-t:t);r.round(x-size+i*2*size/steps,y-half,2*size/steps+.2f,2*half,0,color);}
    }
    /** Coordinates are in the unscaled 310 x 132 card. */
    public static SpotifyNowPlaying.Control controlAt(double x,double y){
        if(y<97||y>125)return null;
        if(x>=97&&x<=125)return SpotifyNowPlaying.Control.PREVIOUS;
        if(x>=141&&x<=169)return SpotifyNowPlaying.Control.TOGGLE;
        if(x>=185&&x<=213)return SpotifyNowPlaying.Control.NEXT;
        return null;
    }
    private static String fit(UiRenderer r,String text,float size,int weight,float max){
        if(r.textWidth(text,size,weight)<=max)return text;
        while(!text.isEmpty()&&r.textWidth(text+"…",size,weight)>max)text=text.substring(0,text.offsetByCodePoints(text.length(),-1));
        return text+"…";
    }
}
