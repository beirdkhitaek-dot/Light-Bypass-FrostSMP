package cherryblossom.feature;

/** HUD branding stays pink even when an existing CherryBlossom config selects Black. */
public final class CherryHudPalette {
    private CherryHudPalette() {}
    private static int color(float alpha,int rgb) {
        return Math.round(Math.max(0,Math.min(1,alpha))*255)<<24 | rgb;
    }
    public static int accent(float alpha) {return UiPalette.accent(alpha);}
    public static int glass(float alpha) {return UiPalette.glass(alpha);}
    public static int logoTop(float alpha) {return UiPalette.logoTop(alpha);}
    public static int logoBottom(float alpha) {return UiPalette.logoBottom(alpha);}
}
