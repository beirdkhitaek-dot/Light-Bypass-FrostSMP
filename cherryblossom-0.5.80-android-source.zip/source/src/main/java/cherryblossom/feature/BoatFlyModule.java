package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.NumberSetting;
import net.minecraft.entity.vehicle.AbstractBoatEntity;
import net.minecraft.util.math.Vec3d;

/** Controls only the local player's driven boat, at the boat's physics step. */
public final class BoatFlyModule extends Module {
    private static BoatFlyModule instance;
    private final NumberSetting speed=new NumberSetting("Speed",.5,20,6,.5);
    private final NumberSetting verticalSpeed=new NumberSetting("Vertical Speed",.5,10,3,.5);
    private AbstractBoatEntity controlled;

    public BoatFlyModule(){
        super("Boat Fly","Fly your boat: movement keys steer, Jump rises, Sprint descends; release to hover.",-1,Category.DONUT);
        addSettings(speed,verticalSpeed);instance=this;
    }
    public static boolean controls(AbstractBoatEntity boat){
        var m=instance;
        return m!=null&&m.isEnabled()&&m.mc.world!=null&&boat.getEntityWorld()==m.mc.world
            &&m.mc.player!=null&&m.mc.player.getVehicle()==boat&&boat.getControllingPassenger()==m.mc.player;
    }
    public static boolean move(AbstractBoatEntity boat){
        if(!controls(boat))return false;
        var m=instance;m.controlled=boat;
        if(m.mc.currentScreen!=null||cherryblossom.integration.CherryGui.capturesInput()){
            boat.setVelocity(Vec3d.ZERO);boat.setPaddlesMoving(false,false);return true;
        }
        var keys=m.mc.options;
        double forward=(keys.forwardKey.isPressed()?1:0)-(keys.backKey.isPressed()?1:0);
        double sideways=(keys.rightKey.isPressed()?1:0)-(keys.leftKey.isPressed()?1:0);
        double length=Math.hypot(forward,sideways);
        if(length>0){forward/=length;sideways/=length;}
        double yaw=Math.toRadians(m.mc.player.getYaw()),speed=m.speed.getValue()/20;
        double vertical=((keys.jumpKey.isPressed()?1:0)-(keys.sprintKey.isPressed()?1:0))*m.verticalSpeed.getValue()/20;
        boat.setYaw(m.mc.player.getYaw());
        boat.setVelocity((-Math.sin(yaw)*forward+Math.cos(yaw)*sideways)*speed,vertical,
            (Math.cos(yaw)*forward+Math.sin(yaw)*sideways)*speed);
        boat.fallDistance=0;
        boat.setPaddlesMoving(length>0,length>0);
        return true;
    }
    @EventListener public void onTick(TickEvent event){
        if(controlled!=null&&(mc.world!=controlled.getEntityWorld()||mc.player==null||mc.player.getVehicle()!=controlled))release();
    }
    private void release(){if(controlled!=null){controlled.setVelocity(Vec3d.ZERO);controlled.setPaddlesMoving(false,false);controlled=null;}}
    @Override public void onDisable(){release();}
}
