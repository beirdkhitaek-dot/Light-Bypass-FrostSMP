package cherryblossom.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import cherryblossom.CherryBlossom;
import cherryblossom.module.setting.StorageBlocksSetting;
import cherryblossom.utils.RenderUtils;
import cherryblossom.utils.TextRenderer;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.Click;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

public final class ColorListEditorScreen extends Screen {
   private static final int WIDTH = 580;
   private static final int HEIGHT = 460;
   private static final int COLUMNS = 11;
   private static final int CELL = 42;
   private final StorageBlocksSetting setting;
   private final Map<String, ColorListEditorScreen.ColorEntry> original = new LinkedHashMap<>();
   private String search = "";
   private boolean selectedOnly;
   private int scrollRow;

   public ColorListEditorScreen(StorageBlocksSetting var1) {
      super(Text.empty());
      this.setting = var1;

      for (StorageBlocksSetting.Entry var3 : var1.entries()) {
         this.original.put(var3.id(), new ColorListEditorScreen.ColorEntry(var3.enabled(), var3.color()));
      }
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
      RenderUtils.setContext(var1);
      RenderUtils.unscaledProjection();
      int var5 = physical((double)var2);
      int var6 = physical((double)var3);
      int var7 = MinecraftClient.getInstance().getWindow().getWidth();
      int var8 = MinecraftClient.getInstance().getWindow().getHeight();
      var1.fill(0, 0, var7, var8, new Color(0, 0, 0, 70).getRGB());
      int var9 = (var7 - 580) / 2;
      int var10 = (var8 - 460) / 2;
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(30, 30, 35, 246), (double)var9, (double)var10, (double)(var9 + 580), (double)(var10 + 460), 8.0, 8.0, 8.0, 8.0, 20.0
      );
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(40, 40, 45), (double)var9, (double)var10, (double)(var9 + 580), (double)(var10 + 34), 8.0, 8.0, 0.0, 0.0, 20.0
      );
      boolean var11 = this.setting.isPickerOnly();
      TextRenderer.drawCenteredString(
         var11
            ? this.setting.getName().toString().toUpperCase(Locale.ROOT) + " (" + this.setting.selectedCount() + " SELECTED)"
            : "BLOCK COLORS: " + this.setting.getName().toString().toUpperCase(Locale.ROOT) + " (" + this.setting.selectedCount() + " BLOCKS)",
         var1,
         var9 + 290,
         var10 + 9,
         Color.WHITE.getRGB()
      );
      int var12 = var10 + 42;
      this.button(var1, var9 + 20, var12, 150, 30, var11 ? "ALL ITEMS" : "ALL BLOCKS", !this.selectedOnly, new Color(120, 190, 255));
      this.button(var1, var9 + 180, var12, 150, 30, "SELECTED (" + this.setting.selectedCount() + ")", this.selectedOnly, new Color(120, 190, 255));
      int var13 = var10 + 82;
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(),
         new Color(18, 18, 23),
         (double)(var9 + 20),
         (double)var13,
         (double)(var9 + 580 - 20),
         (double)(var13 + 31),
         5.0,
         5.0,
         5.0,
         5.0,
         20.0
      );
      String var14 = System.currentTimeMillis() % 1000L > 500L ? "|" : "";
      TextRenderer.drawString(this.search.isEmpty() ? "SEARCH..." : this.search + var14, var1, var9 + 30, var13 + 8, new Color(145, 145, 155).getRGB());
      int var15 = var9 + 20;
      int var16 = var10 + 124;
      short var17 = 270;
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(), new Color(20, 20, 25), (double)var15, (double)var16, (double)(var9 + 580 - 20), (double)(var16 + var17), 5.0, 5.0, 5.0, 5.0, 20.0
      );
      List var18 = this.visibleEntries();
      int var19 = Math.min(this.scrollRow * 11, Math.max(0, var18.size() - 1));
      int var20 = Math.min(var18.size(), var19 + 66);

      for (int var21 = var19; var21 < var20; var21++) {
         StorageBlocksSetting.Entry var22 = (StorageBlocksSetting.Entry)var18.get(var21);
         int var23 = var21 - var19;
         int var24 = var15 + 6 + var23 % 11 * 42;
         int var25 = var16 + 6 + var23 / 11 * 42;
         Color var26 = var22.enabled() ? new Color(var22.color().getRed(), var22.color().getGreen(), var22.color().getBlue(), 85) : new Color(35, 35, 40);
         RenderUtils.renderRoundedQuad(
            var1.getMatrices(), var26, (double)var24, (double)var25, (double)(var24 + 36), (double)(var25 + 36), 4.0, 4.0, 4.0, 4.0, 20.0
         );
         if (var22.enabled()) {
            RenderUtils.renderRoundedOutline(
               var1, var22.color(), (double)var24, (double)var25, (double)(var24 + 36), (double)(var25 + 36), 4.0, 4.0, 4.0, 4.0, 1.5, 20.0
            );
         }

         RenderUtils.drawItem(var1, new ItemStack(var22.item()), var24 + 2, var25 + 2, 32.0F, 0);
         var1.fill(var24 + 27, var25 + 3, var24 + 33, var25 + 9, var22.color().getRGB());
         if (inside((double)var5, (double)var6, var24, var25, 36, 36)) {
            RenderUtils.renderRoundedOutline(
               var1, new Color(255, 255, 255, 210), (double)var24, (double)var25, (double)(var24 + 36), (double)(var25 + 36), 4.0, 4.0, 4.0, 4.0, 1.0, 20.0
            );
            TextRenderer.drawCenteredString(var22.displayName().toUpperCase(Locale.ROOT), var1, var9 + 290, var10 + 460 - 82, new Color(220, 220, 225).getRGB());
         }
      }

      int var27 = var10 + 460 - 42;
      this.button(var1, var9 + 580 - 100, var27, 80, 30, "SAVE", true, new Color(90, 220, 135));
      this.button(var1, var9 + 580 - 210, var27, 100, 30, "CANCEL", false, new Color(255, 105, 105));
      this.button(var1, var9 + 580 - 320, var27, 100, 30, "CLEAR ALL", false, Color.WHITE);
      RenderUtils.scaledProjection();
   }

   private void button(DrawContext var1, int var2, int var3, int var4, int var5, String var6, boolean var7, Color var8) {
      RenderUtils.renderRoundedQuad(
         var1.getMatrices(),
         var7 ? new Color(75, 125, 185) : new Color(38, 38, 44),
         (double)var2,
         (double)var3,
         (double)(var2 + var4),
         (double)(var3 + var5),
         5.0,
         5.0,
         5.0,
         5.0,
         20.0
      );
      TextRenderer.drawCenteredString(var6, var1, var2 + var4 / 2, var3 + 8, var8.getRGB());
   }

   private List<StorageBlocksSetting.Entry> visibleEntries() {
      ArrayList var1 = new ArrayList();
      String var2 = this.search.toLowerCase(Locale.ROOT);

      for (StorageBlocksSetting.Entry var4 : this.setting.entries()) {
         if ((!this.selectedOnly || var4.enabled()) && (var2.isEmpty() || var4.displayName().toLowerCase(Locale.ROOT).contains(var2))) {
            var1.add(var4);
         }
      }

      return var1;
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      int var6 = physical(var1);
      int var7 = physical(var3);
      int var8 = MinecraftClient.getInstance().getWindow().getWidth();
      int var9 = MinecraftClient.getInstance().getWindow().getHeight();
      int var10 = (var8 - 580) / 2;
      int var11 = (var9 - 460) / 2;
      if (inside((double)var6, (double)var7, var10 + 20, var11 + 42, 150, 30)) {
         this.selectedOnly = false;
         return true;
      } else if (inside((double)var6, (double)var7, var10 + 180, var11 + 42, 150, 30)) {
         this.selectedOnly = true;
         return true;
      } else {
         int var12 = var10 + 20;
         int var13 = var11 + 124;
         List var14 = this.visibleEntries();
         int var15 = Math.min(this.scrollRow * 11, Math.max(0, var14.size() - 1));
         int var16 = Math.min(var14.size(), var15 + 66);

         for (int var17 = var15; var17 < var16; var17++) {
            int var18 = var17 - var15;
            int var19 = var12 + 6 + var18 % 11 * 42;
            int var20 = var13 + 6 + var18 / 11 * 42;
            if (inside((double)var6, (double)var7, var19, var20, 36, 36)) {
               StorageBlocksSetting.Entry var21 = (StorageBlocksSetting.Entry)var14.get(var17);
               if (var5 != 0 && (var5 != 1 || !this.setting.isPickerOnly())) {
                  if (var5 == 1) {
                     MinecraftClient.getInstance().setScreen(new StorageColorPickerScreen(this, var21));
                  }
               } else {
                  var21.toggle();
               }

               return true;
            }
         }

         int var22 = var11 + 460 - 42;
         if (inside((double)var6, (double)var7, var10 + 580 - 100, var22, 80, 30)) {
            CherryBlossom.INSTANCE.getSettingsManager().saveNow();
            this.returnToGui();
            return true;
         } else if (inside((double)var6, (double)var7, var10 + 580 - 210, var22, 100, 30)) {
            this.restore();
            this.returnToGui();
            return true;
         } else if (inside((double)var6, (double)var7, var10 + 580 - 320, var22, 100, 30)) {
            this.setting.clear();
            return true;
         } else {
            return false;
         }
      }
   }

   public boolean mouseScrolled(double var1, double var3, double var5, double var7) {
      List var9 = this.visibleEntries();
      int var10 = Math.max(0, (var9.size() + 11 - 1) / 11 - 6);
      this.scrollRow = Math.max(0, Math.min(var10, this.scrollRow - (int)Math.signum(var7)));
      return true;
   }

   public boolean keyPressed(int var1, int var2, int var3) {
      if (var1 == 256) {
         this.restore();
         this.returnToGui();
         return true;
      } else if (var1 == 259 && !this.search.isEmpty()) {
         this.search = this.search.substring(0, this.search.length() - 1);
         this.scrollRow = 0;
         return true;
      } else {
         return false;
      }
   }

   public boolean charTyped(char var1, int var2) {
      if (!Character.isISOControl(var1) && this.search.length() < 28) {
         this.search = this.search + var1;
         this.scrollRow = 0;
      }

      return true;
   }

   public boolean mouseClicked(Click var1, boolean var2) {
      return this.mouseClicked(var1.x(), var1.y(), var1.button());
   }

   public boolean keyPressed(KeyInput var1) {
      return this.keyPressed(var1.key(), var1.scancode(), var1.modifiers());
   }

   public boolean charTyped(CharInput var1) {
      return var1.isValidChar() && this.charTyped((char)var1.codepoint(), var1.modifiers());
   }

   public void renderBackground(DrawContext var1, int var2, int var3, float var4) {
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public boolean shouldPause() {
      return false;
   }

   private void restore() {
      for (StorageBlocksSetting.Entry var2 : this.setting.entries()) {
         ColorListEditorScreen.ColorEntry var3 = this.original.get(var2.id());
         if (var3 != null) {
            var2.setEnabled(var3.enabled);
            var2.setColor(var3.color);
         }
      }
   }

   private void returnToGui() {
      MinecraftClient.getInstance().setScreen(CherryBlossom.INSTANCE.GUI);
   }

   private static int physical(double var0) {
      return (int)Math.round(var0 * (double)MinecraftClient.getInstance().getWindow().getScaleFactor());
   }

   private static boolean inside(double var0, double var2, int var4, int var5, int var6, int var7) {
      return var0 >= (double)var4 && var0 <= (double)(var4 + var6) && var2 >= (double)var5 && var2 <= (double)(var5 + var7);
   }

   private static record ColorEntry(boolean enabled, Color color) {
   }
}
