package cherryblossom.feature;

import cherryblossom.CherryBlossom;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.utils.EncryptedString;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

public final class AutoMineModule extends Module {
   private final BooleanSetting lockView;
   private final NumberSetting pitch;
   private final NumberSetting yaw;

   public AutoMineModule() {
      super(
         EncryptedString.of("Auto Mine"),
         EncryptedString.of("Module that allows players to automatically mine"),
         -1,
         Category.MISC
      );
      this.lockView = new BooleanSetting(EncryptedString.of("Lock View"), true);
      this.pitch = new NumberSetting(EncryptedString.of("Pitch"), -180.0, 180.0, 0.0, 0.1);
      this.yaw = new NumberSetting(EncryptedString.of("Yaw"), -180.0, 180.0, 0.0, 0.1);
      this.addSettings(this.lockView, this.pitch, this.yaw);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.currentScreen != null) {
         return;
      }
      AutoEatModule autoEat = (AutoEatModule)CherryBlossom.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoEatModule.class);
      if (autoEat.isEnabled() && autoEat.shouldEat()) {
         return;
      }
      this.processMiningAction();
      if (this.lockView.getValue()) {
         float currentYaw = this.mc.player.getYaw();
         float currentPitch = this.mc.player.getPitch();
         float targetYaw = this.yaw.getFloatValue();
         float targetPitch = this.pitch.getFloatValue();
         if (currentYaw - targetYaw != 0.0F || currentPitch - targetPitch != 0.0F) {
            this.mc.player.setYaw(targetYaw);
            this.mc.player.setPitch(targetPitch);
         }
      }
   }

   private void processMiningAction() {
      if (this.mc.player.isUsingItem()) {
         return;
      }
      HitResult target = this.mc.crosshairTarget;
      if (target != null && target.getType() == HitResult.Type.BLOCK) {
         BlockHitResult blockTarget = (BlockHitResult)target;
         BlockPos position = blockTarget.getBlockPos();
         if (!this.mc.world.getBlockState(position).isAir()
            && this.mc.interactionManager.updateBlockBreakingProgress(position, blockTarget.getSide())) {
            this.mc.player.swingHand(Hand.MAIN_HAND);
         }
         return;
      }
      this.mc.interactionManager.cancelBlockBreaking();
   }
}
