package cherryblossom.feature;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Builder;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.ShapeIndexBuffer;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import cherryblossom.mixin.RenderPipelinesAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Vector3f;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
final class GpuQuadMesh {
   static final RenderPipeline GLOW = pipeline("sky_glow", BlendFunction.LIGHTNING);
   static final RenderPipeline PAINT = pipeline("sky_paint", null);
   private static final int VERTEX_SIZE = VertexFormats.POSITION_COLOR.getVertexSize();
   private final String label;
   private final RenderPipeline pipeline;
   private final int maxQuads;
   private BufferAllocator bytes;
   private GpuBuffer buffer;
   private int indexCount;
   private boolean built;

   GpuQuadMesh(String var1, RenderPipeline var2, int var3) {
      this.label = var1;
      this.pipeline = var2;
      this.maxQuads = var3;
   }

   private static RenderPipeline pipeline(String var0, BlendFunction var1) {
      Snippet[] var10000 = new Snippet[1];
      var10000[0] = RenderPipelinesAccessor.cherryblossom$getTransformsSnippet();
      Builder var2 = RenderPipeline.builder(var10000)
         .withLocation(Identifier.of("cherryblossom", "pipeline/" + var0))
         .withVertexShader("core/position_color")
         .withFragmentShader("core/position_color")
         .withDepthWrite(false)
         .withCull(false)
         .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS);
      if (var1 == null) {
         return var2.withoutBlend().build();
      }
      return var2.withBlend(var1).build();
   }

   BufferBuilder begin() {
      if (this.bytes == null) {
         this.bytes = new BufferAllocator(this.maxQuads * (4) * VERTEX_SIZE);
      }

      return new BufferBuilder(this.bytes, DrawMode.QUADS, VertexFormats.POSITION_COLOR);
   }

   void upload(BufferBuilder builder) {
      this.built = true;
      BuiltBuffer mesh = builder.endNullable();
      if (mesh == null) {
         this.indexCount = 0;
         return;
      }
      try (mesh) {
         if (this.buffer == null) {
            this.buffer = RenderSystem.getDevice().createBuffer(
               () -> this.label, 40, (long)this.maxQuads * 4L * VERTEX_SIZE);
         }
         RenderSystem.getDevice().createCommandEncoder().writeToBuffer(
            this.buffer.slice(0L, mesh.getBuffer().remaining()), mesh.getBuffer());
         this.indexCount = mesh.getDrawParameters().indexCount();
      }
   }

   boolean isBuilt() {
      return this.built;
   }

   void draw(MatrixStack matrices, float alpha) {
      if (this.indexCount != 0 && !(alpha <= 0.002F)) {
         ShapeIndexBuffer indices = RenderSystem.getSequentialBuffer(DrawMode.QUADS);
         Matrix4fStack modelView;
         (modelView = RenderSystem.getModelViewStack()).pushMatrix();

         try {
            modelView.mul(matrices.peek().getPositionMatrix());
            GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
               .write(modelView, new Vector4f(1.0F, 1.0F, 1.0F, alpha), new Vector3f(), new Matrix4f());
            Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();
            RenderPass pass = RenderSystem.getDevice()
               .createCommandEncoder()
               .createRenderPass(
                  () -> this.label, framebuffer.getColorAttachmentView(), OptionalInt.empty(), framebuffer.getDepthAttachmentView(), OptionalDouble.empty()
               );

            try {
               pass.setPipeline(this.pipeline);
               RenderSystem.bindDefaultUniforms(pass);
               pass.setUniform("DynamicTransforms", transforms);
               pass.setVertexBuffer(0, this.buffer);
               pass.setIndexBuffer(indices.getIndexBuffer(this.indexCount), indices.getIndexType());
               pass.drawIndexed(0, 0, this.indexCount, 1);
            } catch (Throwable var15) {
               if (pass != null) {
                  try {
                     pass.close();
                  } catch (Throwable var14) {
                     var15.addSuppressed(var14);
                  }
               }

               throw var15;
            }

            if (pass != null) {
               pass.close();
            }
         } finally {
            modelView.popMatrix();
         }
      }
   }

   void close() {
      if (this.buffer != null) {
         this.buffer.close();
      }

      if (this.bytes != null) {
         this.bytes.close();
      }

      this.buffer = null;
      this.bytes = null;
      this.indexCount = 0;
      this.built = false;
   }

   static void vertex(BufferBuilder var0, float var1, float var2, float var3, int var4) {
      var0.vertex(var1, var2, var3).color(var4);
   }

}
