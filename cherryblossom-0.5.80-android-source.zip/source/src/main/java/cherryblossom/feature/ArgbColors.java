package cherryblossom.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ArgbColors {
   public static final int WHITE = 0xFFFFFFFF;
   public static final int BLACK = 0xFF000000;
   public static final int CLEAR = 0;

   private ArgbColors() {
   }

   public static int rgb(int red, int green, int blue) {
      return BLACK | clamp(red) << 16 | clamp(green) << 8 | clamp(blue);
   }

   public static int argb(int alpha, int red, int green, int blue) {
      return clamp(alpha) << 24 | clamp(red) << 16 | clamp(green) << 8 | clamp(blue);
   }

   public static int hex(String value) {
      String digits = value.startsWith("#") ? value.substring(1) : value;
      long parsed = Long.parseLong(digits, 16);
      return digits.length() <= 6 ? (int)(0xFF000000L | parsed) : (int)parsed;
   }

   public static int hsv(float hue, float saturation, float value) {
      float sector = ((hue % 360.0F + 360.0F) % 360.0F) / 60.0F;
      float chroma = value * saturation;
      float secondary = chroma * (1.0F - Math.abs(sector % 2.0F - 1.0F));
      float red;
      float green;
      float blue;
      if (sector < 1.0F) {
         red = chroma;
         green = secondary;
         blue = 0.0F;
      } else if (sector < 2.0F) {
         red = secondary;
         green = chroma;
         blue = 0.0F;
      } else if (sector < 3.0F) {
         red = 0.0F;
         green = chroma;
         blue = secondary;
      } else if (sector < 4.0F) {
         red = 0.0F;
         green = secondary;
         blue = chroma;
      } else if (sector < 5.0F) {
         red = secondary;
         green = 0.0F;
         blue = chroma;
      } else {
         red = chroma;
         green = 0.0F;
         blue = secondary;
      }
      float minimum = value - chroma;
      return rgb(
         Math.round((red + minimum) * 255.0F),
         Math.round((green + minimum) * 255.0F),
         Math.round((blue + minimum) * 255.0F)
      );
   }

   public static int mix(int first, int second, float weight) {
      float inverse = 1.0F - weight;
      return argb(
         Math.round(alpha(first) * inverse + alpha(second) * weight),
         Math.round(red(first) * inverse + red(second) * weight),
         Math.round(green(first) * inverse + green(second) * weight),
         Math.round(blue(first) * inverse + blue(second) * weight)
      );
   }

   public static int shade(int color, float factor) {
      if (factor <= 1.0F) {
         return argb(
            alpha(color),
            Math.round(red(color) * factor),
            Math.round(green(color) * factor),
            Math.round(blue(color) * factor)
         );
      }
      float brighten = Math.min(1.0F, factor - 1.0F);
      return argb(
         alpha(color),
         Math.round(red(color) + (255 - red(color)) * brighten),
         Math.round(green(color) + (255 - green(color)) * brighten),
         Math.round(blue(color) + (255 - blue(color)) * brighten)
      );
   }

   public static int withAlpha(int color, float alpha) {
      return clamp(Math.round(alpha * 255.0F)) << 24 | color & 0xFFFFFF;
   }

   public static int alpha(int color) {
      return color >>> 24;
   }

   public static int red(int color) {
      return color >> 16 & 0xFF;
   }

   public static int green(int color) {
      return color >> 8 & 0xFF;
   }

   public static int blue(int color) {
      return color & 0xFF;
   }

   static int clamp(int value) {
      return value < 0 ? 0 : Math.min(value, 255);
   }
}
