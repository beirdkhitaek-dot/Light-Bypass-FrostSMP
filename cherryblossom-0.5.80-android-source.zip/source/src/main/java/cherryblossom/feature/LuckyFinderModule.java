package cherryblossom.feature;

import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.Heightmap.Type;
import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.Render3DEvent;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.NewFeature;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.utils.BytecodeException;
import cherryblossom.utils.EncryptedString;
import cherryblossom.utils.RenderUtils;
import cherryblossom.utils.RenderVisibility;
import cherryblossom.utils.RenderUtils.ColoredBox;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.render.Camera;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.ChunkPos;

public final class LuckyFinderModule extends Module implements NewFeature {
   private static final int PLATE_SIZE = 48;
   private static final double PLATE_THICKNESS = 0.15;
   private static final SoundEvent FLAG_SOUND;
   private final BooleanSetting notifications;
   private final BooleanSetting sound;
   private final NumberSetting volume;
   private final NumberSetting alpha;
   private final RetryDeadline timer;
   private final Map<Long, LuckyFinderModule.ChunkMarker> flags;
   private final ArrayList<ColoredBox> geometry;
   private final ArrayList<ColoredBox> visibleGeometry;
   private ClientWorld trackedWorld;
   private String flagWorldKey;
   private boolean geometryDirty;
   private int cachedAlpha;
   private int lastChunkX;
   private int lastChunkZ;
   private int lastViewDistance;

   public LuckyFinderModule() {
      super(EncryptedString.of("Lucky Finder"), EncryptedString.of("Follow your luck."), -1, Category.DONUT);
      this.notifications = new BooleanSetting(EncryptedString.of("Notifications"), true);
      this.sound = new BooleanSetting(EncryptedString.of("Sound"), true);
      this.volume = new NumberSetting(EncryptedString.of("Sound Volume"), 0.0, 100.0, 35.0, 1.0);
      this.alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 75.0, 1.0);
      this.timer = new RetryDeadline();
      this.flags = new LinkedHashMap<>();
      this.geometry = new ArrayList<>();
      this.visibleGeometry = new ArrayList<>();
      this.cachedAlpha = -1;
      this.lastViewDistance = -1;
      this.addSettings(this.notifications, this.sound, this.volume, this.alpha);
   }

   public void onEnable() {
      this.reset();
      if (this.mc.world != null && this.mc.player != null) {
         this.timer.arm(System.nanoTime(), ThreadLocalRandom.current());
      }

      super.onEnable();
   }

   public void onDisable() {
      this.reset();
      super.onDisable();
   }

   private void reset() {
      this.timer.clear();
      this.clearVisuals();
      this.trackedWorld = null;
      this.flagWorldKey = null;
   }

   private void clearVisuals() {
      this.flags.clear();
      this.geometry.clear();
      this.visibleGeometry.clear();
      this.cachedAlpha = -1;
      this.lastViewDistance = -1;
      this.geometryDirty = true;
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.world == null || this.mc.player == null) {
         this.trackedWorld = null;
         return;
      }

      if (this.trackedWorld != this.mc.world) {
         String currentWorldKey = this.worldKey();
         if (!currentWorldKey.equals(this.flagWorldKey)) {
            this.clearVisuals();
            this.flagWorldKey = currentWorldKey;
         }
         this.trackedWorld = this.mc.world;
         this.lastViewDistance = -1;
      }

      this.pruneFlags();
      long now = System.nanoTime();
      if (!this.timer.isArmed()) {
         this.timer.arm(now, ThreadLocalRandom.current());
         return;
      }
      if (!this.timer.due(now)) {
         return;
      }
      if (this.tryFlag()) {
         this.timer.arm(now, ThreadLocalRandom.current());
      } else {
         this.timer.retry(now);
      }
   }

   private String worldKey() {
      String location;
      ServerInfo server = this.mc.getCurrentServerEntry();
      if (server != null) {
         location = "server:" + server.address.toLowerCase(Locale.ROOT);
      } else if (this.mc.getServer() == null) {
         location = "session:" + System.identityHashCode(this.mc.world);
      } else {
         IntegratedServer integrated = this.mc.getServer();
         location = "local:" + integrated.getSavePath(WorldSavePath.ROOT).toAbsolutePath().normalize();
      }
      return location + "|" + this.mc.world.getRegistryKey().getValue();
   }

   private void pruneFlags() {
      if (this.flags.isEmpty()) {
         return;
      }

      ChunkPos playerChunk = this.mc.player.getChunkPos();
      if (!this.mc.world.isChunkLoaded(playerChunk.x, playerChunk.z)) {
         return;
      }

      int viewDistance = this.mc.options.getClampedViewDistance();
      if (this.lastChunkX == playerChunk.x
         && this.lastChunkZ == playerChunk.z
         && this.lastViewDistance == viewDistance) {
         return;
      }

      this.lastChunkX = playerChunk.x;
      this.lastChunkZ = playerChunk.z;
      this.lastViewDistance = viewDistance;
      boolean removed = this.flags.values().removeIf(marker ->
         Math.abs((long) marker.cx - playerChunk.x) > viewDistance
            || Math.abs((long) marker.cz - playerChunk.z) > viewDistance
      );
      if (removed) {
         this.geometryDirty = true;
      }
   }

   private boolean tryFlag() {
      ChunkPos playerChunk = this.mc.player.getChunkPos();
      int radius = Math.max(0, Math.min(8, this.mc.options.getClampedViewDistance() - 2));
      ThreadLocalRandom random = ThreadLocalRandom.current();

      for (int attempt = 0; attempt < 32; attempt++) {
         int chunkX = playerChunk.x + random.nextInt(-radius, radius + 1);
         int chunkZ = playerChunk.z + random.nextInt(-radius, radius + 1);
         long key = ChunkPos.toLong(chunkX, chunkZ);
         if (attempt < 24 && this.flags.containsKey(key)) {
            continue;
         }

         int surfaceY = this.highestSurface(chunkX, chunkZ);
         if (surfaceY == Integer.MIN_VALUE) {
            continue;
         }

         this.flags.put(key, new ChunkMarker(chunkX, chunkZ, surfaceY + 1.002));
         this.geometryDirty = true;
         int centerX = (chunkX << 4) + 8;
         int centerZ = (chunkZ << 4) + 8;
         if (this.notifications.getValue()) {
            this.mc.getToastManager().add(new LuckyFinderToast(centerX, centerZ));
         }
         if (this.sound.getValue() && this.volume.getValue() > 0.0) {
            this.mc.getSoundManager().play(
               PositionedSoundInstance.ui(FLAG_SOUND, 1.0F, this.volume.getFloatValue() / 100.0F)
            );
         }
         return true;
      }
      return false;
   }

   private int highestSurface(int chunkX, int chunkZ) {
      for (int offsetX = -1; offsetX <= 1; offsetX++) {
         for (int offsetZ = -1; offsetZ <= 1; offsetZ++) {
            if (!this.mc.world.isChunkLoaded(chunkX + offsetX, chunkZ + offsetZ)) {
               return Integer.MIN_VALUE;
            }
         }
      }

      int highest = Integer.MIN_VALUE;
      for (int offsetX = -1; offsetX <= 1; offsetX++) {
         for (int offsetZ = -1; offsetZ <= 1; offsetZ++) {
            WorldChunk chunk = this.mc.world.getChunk(chunkX + offsetX, chunkZ + offsetZ);
            for (int localX = 0; localX < 16; localX++) {
               for (int localZ = 0; localZ < 16; localZ++) {
                  highest = Math.max(highest, chunk.sampleHeightmap(Type.WORLD_SURFACE, localX, localZ));
               }
            }
         }
      }

      return highest < this.mc.world.getBottomY() ? Integer.MIN_VALUE : highest;
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (this.mc.player == null || this.trackedWorld != this.mc.world || this.flags.isEmpty()) {
         return;
      }

      int alpha = this.alpha.getIntValue();
      if (alpha <= 0) {
         return;
      }

      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }

      if (this.geometryDirty || this.cachedAlpha != alpha) {
         this.geometry.clear();
         Color color = new Color(0, 255, 70, alpha);
         for (ChunkMarker marker : this.flags.values()) {
            double centerX = marker.cx * 16.0 + 8.0;
            double centerZ = marker.cz * 16.0 + 8.0;
            this.geometry.add(new ColoredBox(
               centerX - PLATE_SIZE / 2.0, marker.y, centerZ - PLATE_SIZE / 2.0,
               centerX + PLATE_SIZE / 2.0, marker.y + PLATE_THICKNESS, centerZ + PLATE_SIZE / 2.0, color
            ));
         }
         this.geometryDirty = false;
         this.cachedAlpha = alpha;
      }

      this.visibleGeometry.clear();
      double playerX = this.mc.player.getX();
      double playerZ = this.mc.player.getZ();
      double maximumDistance = this.mc.options.getClampedViewDistance() * 16.0 + 24.0;
      for (ColoredBox box : this.geometry) {
         double centerX = (box.x1() + box.x2()) / 2.0;
         double centerZ = (box.z1() + box.z2()) / 2.0;
         if (Math.abs(centerX - playerX) > maximumDistance || Math.abs(centerZ - playerZ) > maximumDistance) {
            continue;
         }
         if (RenderVisibility.box(box.x1(), box.y1(), box.z1(), box.x2(), box.y2(), box.z2())) {
            this.visibleGeometry.add(box);
         }
      }

      if (this.visibleGeometry.isEmpty()) {
         return;
      }

      MatrixStack matrices = event.matrixStack;
      matrices.push();
      try {
         RenderUtils.applyCameraTransform(matrices, camera);
         RenderUtils.renderFilledBoxes(matrices, this.visibleGeometry);
      } catch (Throwable error) {
         matrices.pop();
         throw BytecodeException.unchecked(error);
      }
      matrices.pop();
   }

   static {
      FLAG_SOUND = SoundEvent.of(Identifier.of("cherryblossom", "lucky_flag"));
   }

   private record ChunkMarker(int cx, int cz, double y) {
   }
}
