package cherryblossom.feature;

import cherryblossom.event.events.Render3DEvent;
import cherryblossom.mixin.RenderPipelinesAccessor;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

/** Cached curved typography and ring geometry; one bounded upload/draw per frame. */
final class JumpCircleRenderer {
    private static final List<Quad> SHAPE=shape();
    private static final RenderPipeline PIPELINE=RenderPipeline.builder(RenderPipelinesAccessor.cherryblossom$getTransformsSnippet())
        .withLocation(Identifier.of("cherryblossom","pipeline/jump_circles"))
        .withVertexShader("core/position_color").withFragmentShader("core/position_color")
        .withBlend(BlendFunction.TRANSLUCENT).withCull(false).withDepthWrite(false)
        .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
        .withVertexFormat(VertexFormats.POSITION_COLOR,DrawMode.QUADS).build();
    private final GpuQuadMesh mesh=new GpuQuadMesh("CherryBlossom jump circles",PIPELINE,SHAPE.size()*8);
    void render(Render3DEvent event,List<JumpCirclesModule.Circle> circles,double now,boolean rotate){
        var camera=MinecraftClient.getInstance().gameRenderer.getCamera();
        var origin=camera.getCameraPos();
        BufferBuilder buffer=mesh.begin();
        for(var circle:circles){
            double age=Math.max(0,now-circle.born())/circle.lifetime();
            if(age>=1||circle.position().squaredDistanceTo(origin)>4096)continue;
            double scale=circle.radius()*(.35+.65*(1-Math.pow(1-age,3)));
            double angle=rotate?age*.65:0,cs=Math.cos(angle),sn=Math.sin(angle);
            float alpha=(float)(Math.min(1,age*10)*Math.pow(1-age,1.3));
            int color=UiPalette.accent(alpha);
            for(Quad quad:SHAPE){
                int tint=(color&0xFFFFFF)|Math.round((color>>>24)*quad.alpha)<<24;
                for(int i=0;i<4;i++){
                    double x=quad.x[i]*scale,z=quad.z[i]*scale;
                    buffer.vertex((float)(circle.position().x-origin.x+x*cs-z*sn),
                        (float)(circle.position().y-origin.y),(float)(circle.position().z-origin.z+x*sn+z*cs)).color(tint);
                }
            }
        }
        mesh.upload(buffer);
        var matrices=event.matrixStack;matrices.push();
        try {
            matrices.multiply(new org.joml.Quaternionf(camera.getRotation()).conjugate());
            mesh.draw(matrices,1);
        }finally{matrices.pop();}
    }
    void close(){mesh.close();}
    private static List<Quad> shape(){
        List<Quad> quads=new ArrayList<>();
        for(double radius:new double[]{.68,1})for(int i=0;i<192;i++){
            double a=i*Math.PI*2/192,b=(i+1)*Math.PI*2/192;
            quads.add(polar(a,b,radius-.006,radius+.006,1));
            quads.add(polar(a,b,radius-.021,radius+.021,.13f));
        }
        BufferedImage text=new BufferedImage(260,36,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=text.createGraphics();g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,25));g.setColor(Color.WHITE);
        int width=g.getFontMetrics().stringWidth("CherryBlossom");g.drawString("CherryBlossom",0,27);g.dispose();
        for(int repeat=0;repeat<4;repeat++)for(int y=0;y<34;y++)for(int x=0;x<width;){
            if((text.getRGB(x,y)>>>24)==0){x++;continue;}
            int start=x;while(x<width&&(text.getRGB(x,y)>>>24)!=0)x++;
            double base=repeat*Math.PI/2,arc=Math.PI*.45;
            quads.add(polar(base+start/(double)width*arc,base+x/(double)width*arc,
                .94-(y+1)*.006,.94-y*.006,1));
        }
        return List.copyOf(quads);
    }
    private static Quad polar(double a,double b,double inner,double outer,float alpha){
        return new Quad(new double[]{-Math.sin(a)*inner,-Math.sin(b)*inner,-Math.sin(b)*outer,-Math.sin(a)*outer},
            new double[]{Math.cos(a)*inner,Math.cos(b)*inner,Math.cos(b)*outer,Math.cos(a)*outer},alpha);
    }
    private record Quad(double[] x,double[] z,float alpha){}
}
