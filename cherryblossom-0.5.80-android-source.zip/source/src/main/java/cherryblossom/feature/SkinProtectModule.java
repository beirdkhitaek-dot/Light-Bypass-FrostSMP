package cherryblossom.feature;

import com.mojang.authlib.GameProfile;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.Setting;
import cherryblossom.module.setting.StringSetting;
import cherryblossom.utils.EncryptedString;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.SkinTextures;


public final class SkinProtectModule extends Module {
   private static final long CONSTANT_0332 = TimeUnit.MILLISECONDS.toNanos(350L);
   private static final long CONSTANT_0103 = TimeUnit.SECONDS.toNanos(30L);
   private final StringSetting skinName = new StringSetting(
         "Skin Name",
         ""
      )
      .setDescription(
         EncryptedString.of(
            "Minecraft username to use for the skin and cape. Blank uses the default skin"
         )
      );
   private final BooleanSetting protectEverybody = new BooleanSetting(
         EncryptedString.of("Protect Everybody"),
         false
      )
      .setDescription(
         EncryptedString.of(
            "Show the selected skin and cape on every player instead of only yourself"
         )
      );
   private volatile SkinTextures selectedTextures = DefaultSkinHelper.getSteve();
   private String requestedKey = "";
   private String requestedName = "";
   private CompletableFuture<Optional<SkinTextures>> pendingLookup;
   private long nextLookupNanos;
   private int lookupVersion;

   public SkinProtectModule() {
      super(
         EncryptedString.of("Skin Protect"),
         EncryptedString.of(
            "Locally replaces player skins, capes and elytra textures"
         ),
         -1,
         Category.MISC
      );
      Setting[] var10001 = new Setting[2];
      var10001[0] = this.skinName;
      var10001[1] = this.protectEverybody;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      this.clearResolution();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.clearResolution();
      super.onDisable();
   }

   private void clearResolution() {
      this.lookupVersion += 1;
      this.pendingLookup = null;
      this.selectedTextures = DefaultSkinHelper.getSteve();
      this.requestedKey = "";
      this.requestedName = "";
      this.nextLookupNanos = 0L;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      long var2 = System.nanoTime();
      String var4 = this.skinName.getValue() == null
         ? ""
         : this.skinName.getValue().trim();
      String var5 = var4.toLowerCase(Locale.ROOT);
      if (!var5.equals(this.requestedKey)) {
         this.requestedKey = var5;
         this.requestedName = var4;
         this.lookupVersion += 1;
         this.pendingLookup = null;
         this.selectedTextures = DefaultSkinHelper.getSteve();
         this.nextLookupNanos = var2 + CONSTANT_0332;
      }

      if (this.pendingLookup == null
         && var2 >= this.nextLookupNanos
         && this.requestedName.matches("[A-Za-z0-9_]{3,16}")) {
         this.resolveTextures(this.requestedName);
      }
   }

   private void resolveTextures(String var1) {
      int var2 = this.lookupVersion;
      GameProfile var3 = null;
      if (this.mc.getNetworkHandler() != null) {
         PlayerListEntry var4 = this.mc.getNetworkHandler().getPlayerListEntry(var1);
         if (var4 != null) {
            var3 = var4.getProfile();
         }
      }

       CompletableFuture<Optional<GameProfile>> var5 = var3 == null
         ? CompletableFuture.supplyAsync(() -> this.mc.getApiServices().profileResolver().getProfileByName(var1))
         : CompletableFuture.completedFuture(Optional.of(var3));
       CompletableFuture<Optional<SkinTextures>> var6 = var5.thenCompose(
          var1x -> var1x.map(
                   var1xx -> CompletableFuture.supplyAsync(() -> this.mc.getSkinProvider().fetchSkinTextures(var1xx)).thenCompose(var0 -> var0)
               )
               .orElseGet(() -> CompletableFuture.completedFuture(Optional.empty()))
      );
      this.pendingLookup = var6;
      var6.whenComplete((var2x, var3x) -> this.mc.execute(() -> {
            if (var2 == this.lookupVersion && this.isEnabled()) {
               this.pendingLookup = null;
               if (var3x == null && var2x != null && var2x.isPresent()) {
                  this.selectedTextures = (SkinTextures)var2x.get();
                  this.nextLookupNanos = 9223372036854775807L;
               } else {
                  this.selectedTextures = DefaultSkinHelper.getSteve();
                  this.nextLookupNanos = System.nanoTime() + CONSTANT_0103;
               }
            }
         }));
   }

   public SkinTextures replacementFor(UUID var1, String var2, SkinTextures var3) {
      if (!this.isEnabled()) {
         return var3;
      } else {
         return !this.protectEverybody.getValue() && !this.isOwnPlayer(var1, var2) ? var3 : this.selectedTextures;
      }
   }

   private boolean isOwnPlayer(UUID var1, String var2) {
      UUID var3 = this.mc.getSession().getUuidOrNull();
      return ((!((var3 == null || !var3.equals(var1)) && (var2 == null || !var2.equalsIgnoreCase(this.mc.getSession().getUsername())))));
   }
}
