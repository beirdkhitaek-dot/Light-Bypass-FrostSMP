package cherryblossom.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface CharacterRenderStateAccess {
   WornCharacterModel cherryblossom$character();

   void cherryblossom$setCharacter(WornCharacterModel var1);

   float cherryblossom$seat();

   void cherryblossom$setSeat(float var1);
}
