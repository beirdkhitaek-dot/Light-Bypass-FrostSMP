package cherryblossom.feature;
import java.util.List;
public final class Character3dHelper {
    private static final List<CharacterDefinition> DESIGNS=List.of(
        BakedCharacterAsset.builtIn("cj","CJ","/assets/cherryblossom/characters/cj.anc"),
        BakedCharacterAsset.builtIn("neighbor","Neighbor","/assets/cherryblossom/characters/neighbor.anc"));
    public static List<CharacterDefinition> all(){return DESIGNS;}
    static boolean refresh(){return false;}
    static List<String> names(){return DESIGNS.stream().map(CharacterDefinition::name).toList();}
    static CharacterDefinition byName(String name){return DESIGNS.stream().filter(d->d.name().equals(name)).findFirst().orElse(DESIGNS.getFirst());}
}