package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.*;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Local Minecraft input feedback; it does not monitor other applications or record text. */
public final class CreamyKeysModule extends Module {
    private final ChoiceSetting sound=new ChoiceSetting("Sound","Creamy",List.of("Creamy","Marble","Thock","Muted"));
    private final ChoiceSetting keys=new ChoiceSetting("Keys","All Keys",List.of("All Keys","Movement Only"));
    private final NumberSetting volume=new NumberSetting("Volume",0,100,40,1),pitch=new NumberSetting("Pitch",.6,1.6,1,.01),variation=new NumberSetting("Pitch Variation",0,25,5,1);
    private final BooleanSetting releases=new BooleanSetting("Release Sounds",true),chat=new BooleanSetting("While Chatting",true),menus=new BooleanSetting("In Menus",false),mouse=new BooleanSetting("Mouse Clicks",false);
    private final NumberSetting releaseVolume=new NumberSetting("Release Volume",0,100,45,1),spaceTone=new NumberSetting("Spacebar Tone",.6,1.4,.82,.01),spaceVolume=new NumberSetting("Spacebar Volume",20,150,110,1),mouseVolume=new NumberSetting("Mouse Volume",0,100,45,1);
    private final Set<Integer> held=new HashSet<>();
    public CreamyKeysModule(){super("Creamy Keys","Soft mechanical keyboard feedback with independent sound, tone and release controls.",-1,Category.MISC);addSettings(sound,keys,volume,pitch,variation,releases,releaseVolume,spaceTone,spaceVolume,chat,menus,mouse,mouseVolume);}
    private boolean accepts(){return isEnabled()&&mc.isWindowFocused()&&(mc.currentScreen==null?mc.world!=null:mc.currentScreen instanceof ChatScreen?chat.getValue():menus.getValue());}
    private boolean movement(int code){var input=new KeyInput(code,0,0);var o=mc.options;return o.forwardKey.matchesKey(input)||o.backKey.matchesKey(input)||o.leftKey.matchesKey(input)||o.rightKey.matchesKey(input)||o.jumpKey.matchesKey(input)||o.sneakKey.matchesKey(input)||o.sprintKey.matchesKey(input);}
    @EventListener public void key(KeyEvent event){
        if(event.mode==0){boolean was=held.remove(event.key);if(was&&accepts()&&releases.getValue())play(event.key,true,releaseVolume.getValue()/100);return;}
        if(event.mode!=1||!accepts()||event.key<32||event.key>GLFW.GLFW_KEY_LAST||keys.getMode().equals("Movement Only")&&!movement(event.key)||!held.add(event.key))return;
        play(event.key,false,1);
    }
    @EventListener public void mouse(MouseButtonEvent event){if(event.actions==1&&event.button>=0&&event.button<=1&&mouse.getValue()&&accepts()&&!event.isCancelled())play(-1,false,mouseVolume.getValue()/100);}
    private void play(int key,boolean release,double gain){
        double jitter=variation.getValue()/100,random=jitter==0?1:1+ThreadLocalRandom.current().nextDouble(-jitter,jitter);
        float tone=(float)Math.max(.5,Math.min(2,pitch.getValue()*random*(key==GLFW.GLFW_KEY_SPACE?spaceTone.getValue():1)));
        float loudness=(float)Math.min(.65,volume.getValue()/100*.6*gain*(key==GLFW.GLFW_KEY_SPACE?spaceVolume.getValue()/100:1));
        if(loudness<=0)return;
        var id=Identifier.of("cherryblossom","keys."+sound.getMode().toLowerCase(Locale.ROOT)+"."+(release?"release":"press"));
        mc.getSoundManager().play(PositionedSoundInstance.ui(SoundEvent.of(id),tone,loudness));
    }
    @EventListener public void tick(TickEvent event){if(!mc.isWindowFocused())held.clear();}
    @Override public void onEnable(){held.clear();}
    @Override public void onDisable(){held.clear();}
}
