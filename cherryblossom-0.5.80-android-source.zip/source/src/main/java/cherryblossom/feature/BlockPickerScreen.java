package cherryblossom.feature;

import cherryblossom.CherryBlossom;
import cherryblossom.integration.TrialAccess;
import cherryblossom.module.setting.StorageBlocksSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.*;

/** Virtualized native item gallery over the same palette used by Block ESP. */
public final class BlockPickerScreen extends Screen {
    private final StorageBlocksSetting blocks;
    private final Screen parent;
    private final boolean returnToGui;
    private final List<StorageBlocksSetting.Entry> entries;
    private List<StorageBlocksSetting.Entry> filtered;
    private TextFieldWidget search;
    private String query="";
    private boolean selectedOnly, changed;
    private double scroll;
    private int left,top,panelWidth,panelHeight,gridTop,gridBottom,columns,cellWidth;
    private static final int CELL_H=54,GAP=5;

    public BlockPickerScreen(StorageBlocksSetting blocks,Screen parent,boolean returnToGui) {
        super(Text.literal("Block ESP · Choose blocks"));
        this.blocks=blocks;this.parent=parent;this.returnToGui=returnToGui;
        entries=blocks.entries().stream().sorted(Comparator.comparing(StorageBlocksSetting.Entry::displayName)).toList();
        filtered=entries;
    }
    public static void open(StorageBlocksSetting blocks) {
        var mc=MinecraftClient.getInstance();
        mc.execute(()->{
            if(!TrialAccess.allowed())return;
            boolean back=cherryblossom.integration.CherryGui.capturesInput();Screen previous=mc.currentScreen;
            if(back){
                try{var type=Class.forName("dev.cherryblossom.client.CherryBlossomController");type.getMethod("forceOff").invoke(type.getMethod("get").invoke(null));}
                catch(ReflectiveOperationException error){throw new IllegalStateException("Could not open block picker",error);}
            }
            mc.setScreen(new BlockPickerScreen(blocks,previous,back));
        });
    }
    @Override protected void init() {
        panelWidth=Math.min(740,Math.max(180,width-24));panelHeight=Math.min(490,Math.max(150,height-24));
        left=(width-panelWidth)/2;top=(height-panelHeight)/2;
        gridTop=top+91;gridBottom=top+panelHeight-43;
        columns=Math.max(1,(panelWidth-36)/60);cellWidth=(panelWidth-36)/columns;
        search=new TextFieldWidget(textRenderer,left+19,top+56,panelWidth-38,22,Text.literal("Search blocks"));
        search.setDrawsBackground(false);search.setMaxLength(160);search.setPlaceholder(Text.literal("Search by block name or ID...").withColor(0xB9AAB6));
        search.setEditableColor(0xFFF4EAF1);
        search.setText(query);search.setChangedListener(this::filter);addDrawableChild(search);
        clampScroll();releaseCursor();
    }
    private static void releaseCursor(){cherryblossom.schematic.SchematicScreenBridge.releaseCursor();}
    public void filter(String value) {
        query=value;String find=value.trim().toLowerCase(Locale.ROOT);
        filtered=entries.stream().filter(e->(!selectedOnly||e.enabled())&&(find.isEmpty()||e.displayName().toLowerCase(Locale.ROOT).contains(find)||e.id().contains(find))).toList();
        scroll=0;
    }
    public List<StorageBlocksSetting.Entry> visibleEntries(){return List.copyOf(filtered);}
    public void selectedOnly(boolean enabled){selectedOnly=enabled;filter(query);}
    public boolean toggleBlock(String id){
        if(!TrialAccess.allowed())return false;
        var entry=blocks.get(id);if(entry==null)return false;
        entry.toggle();changed=true;if(selectedOnly)filter(query);return true;
    }
    public int highlightColor(){return UiPalette.accent(1);}
    public double scrollPosition(){return scroll;}
    private int maxScroll(){return Math.max(0,((filtered.size()+columns-1)/columns)*CELL_H-(gridBottom-gridTop));}
    private void clampScroll(){scroll=Math.max(0,Math.min(scroll,maxScroll()));}
    @Override public boolean shouldPause(){return false;}
    @Override public void renderBackground(DrawContext c,int x,int y,float delta){}
    @Override public void render(DrawContext c,int mx,int my,float delta) {
        releaseCursor();clampScroll();int accent=highlightColor();
        c.fill(0,0,width,height,0xC5100C12);
        round(c,left-1,top-1,panelWidth+2,panelHeight+2,13,alpha(accent,100));
        round(c,left,top,panelWidth,panelHeight,12,0xF5201922);
        c.drawText(textRenderer,"Choose blocks",left+18,top+17,0xFFF6EDF3,false);
        String count=blocks.selectedCount()+" selected";
        c.drawText(textRenderer,count,left+panelWidth-20-textRenderer.getWidth(count),top+18,accent,false);
        c.drawText(textRenderer,"Click an icon to toggle Block ESP for that block",left+18,top+35,0xFFB9AAB6,false);
        round(c,left+13,top+51,panelWidth-26,30,7,0xFF302633);
        super.render(c,mx,my,delta);
        StorageBlocksSetting.Entry hovered=null;
        c.enableScissor(left+13,gridTop,left+panelWidth-13,gridBottom);
        int first=Math.max(0,(int)(scroll/CELL_H)*columns),last=Math.min(filtered.size(),((int)(scroll/CELL_H)+(gridBottom-gridTop)/CELL_H+2)*columns);
        for(int i=first;i<last;i++){
            var entry=filtered.get(i);int x=left+18+(i%columns)*cellWidth,y=gridTop+(i/columns)*CELL_H-(int)scroll;
            int w=cellWidth-GAP,h=CELL_H-GAP;boolean hover=mx>=x&&mx<x+w&&my>=y&&my<y+h&&my>=gridTop&&my<gridBottom;
            if(hover)hovered=entry;
            round(c,x,y,w,h,7,entry.enabled()?alpha(accent,255):hover?0xFF463849:0xFF2B232E);
            if(entry.enabled())round(c,x+1,y+1,w-2,h-2,6,blend(accent,0xFF201922,.72f));
            var stack=entry.item()==Items.AIR?ItemStack.EMPTY:new ItemStack(entry.item());
            if(!stack.isEmpty()) {
                var matrices=c.getMatrices();matrices.pushMatrix();matrices.translate(x+(w-24)/2f,y+5);matrices.scale(1.5f,1.5f);c.drawItem(stack,0,0);matrices.popMatrix();
            } else {
                var block=Registries.BLOCK.get(Identifier.of(entry.id()));
                var sprite=client.getBlockRenderManager().getModels().getModelParticleSprite(block.getDefaultState());
                c.drawSpriteStretched(RenderPipelines.GUI_TEXTURED,sprite,x+(w-22)/2,y+6,22,22);
            }
            String name=textRenderer.trimToWidth(entry.displayName(),w-6);
            c.drawCenteredTextWithShadow(textRenderer,name,x+w/2,y+34,entry.enabled()?0xFFFFFFFF:0xFFCFC2CD);
            if(entry.enabled())c.fill(x+w-8,y+4,x+w-4,y+8,accent);
        }
        if(filtered.isEmpty())c.drawCenteredTextWithShadow(textRenderer,"No matching blocks",left+panelWidth/2,gridTop+20,0xFFB9AAB6);
        c.disableScissor();
        if(maxScroll()>0){int area=gridBottom-gridTop,thumb=Math.max(16,area*area/(area+maxScroll())),y=gridTop+(int)(scroll/maxScroll()*(area-thumb));round(c,left+panelWidth-9,y,3,thumb,1,alpha(accent,180));}
        int by=top+panelHeight-32;
        button(c,"All blocks",left+16,by,80,selectedOnly?0xFF302633:blend(accent,0xFF201922,.5f),mx,my);
        button(c,"Selected only",left+101,by,91,selectedOnly?blend(accent,0xFF201922,.5f):0xFF302633,mx,my);
        button(c,"Done",left+panelWidth-77,by,60,blend(accent,0xFF201922,.38f),mx,my);
        if(hovered!=null)c.drawTooltip(textRenderer,List.of(Text.literal(hovered.displayName()),Text.literal(hovered.id()).withColor(0xB9AAB6),Text.literal(hovered.enabled()?"Selected · click to remove":"Click to select").withColor(accent&0xFFFFFF)),mx,my);
    }
    private void button(DrawContext c,String label,int x,int y,int w,int color,int mx,int my){round(c,x,y,w,22,6,inside(mx,my,x,y,w,22)?blend(color,0xFFFFFFFF,.1f):color);c.drawCenteredTextWithShadow(textRenderer,label,x+w/2,y+7,0xFFF4EBF2);}
    @Override public boolean mouseClicked(Click click,boolean doubled){
        if(click.button()!=0)return super.mouseClicked(click,doubled);
        double x=click.x(),y=click.y();int by=top+panelHeight-32;
        if(inside(x,y,left+16,by,80,22)){selectedOnly(false);return true;}
        if(inside(x,y,left+101,by,91,22)){selectedOnly(true);return true;}
        if(inside(x,y,left+panelWidth-77,by,60,22)){close();return true;}
        if(inside(x,y,left+18,gridTop,panelWidth-36,gridBottom-gridTop)) {
            int column=(int)(x-left-18)/cellWidth,row=(int)(y-gridTop+scroll)/CELL_H,index=row*columns+column;
            if(column<columns&&index<filtered.size()&&(x-left-18)%cellWidth<cellWidth-GAP&&(y-gridTop+scroll)%CELL_H<CELL_H-GAP)toggleBlock(filtered.get(index).id());
            setFocused(null);return true;
        }
        return super.mouseClicked(click,doubled);
    }
    @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){
        if(inside(x,y,left,gridTop,panelWidth,gridBottom-gridTop)){scroll-=vertical*CELL_H;clampScroll();return true;}return super.mouseScrolled(x,y,horizontal,vertical);
    }
    @Override public boolean keyPressed(KeyInput key){
        if(key.key()==256){close();return true;}
        if(!search.isFocused()&&(key.key()==266||key.key()==267||key.key()==268||key.key()==269)){
            if(key.key()==268)scroll=0;else if(key.key()==269)scroll=maxScroll();else scroll+=(key.key()==266?-1:1)*(gridBottom-gridTop);clampScroll();return true;
        }
        return super.keyPressed(key);
    }
    @Override public void close(){
        if(client==null)return;client.setScreen(parent);
        if(returnToGui&&parent==null&&TrialAccess.allowed())cherryblossom.integration.CherryGui.toggle();
    }
    @Override public void removed(){
        if(changed){CherryBlossom.INSTANCE.getSettingsManager().saveNow();cherryblossom.integration.CherryGui.saveSettings();changed=false;}
        super.removed();
    }
    private static boolean inside(double x,double y,int l,int t,int w,int h){return x>=l&&x<l+w&&y>=t&&y<t+h;}
    private static int alpha(int color,int a){return color&0xFFFFFF|a<<24;}
    private static int blend(int a,int b,float t){int r=Math.round((a>>16&255)*(1-t)+(b>>16&255)*t),g=Math.round((a>>8&255)*(1-t)+(b>>8&255)*t),v=Math.round((a&255)*(1-t)+(b&255)*t);return 0xFF000000|r<<16|g<<8|v;}
    private static void round(DrawContext c,int x,int y,int w,int h,int r,int color){
        r=Math.min(r,Math.min(w,h)/2);c.fill(x+r,y,x+w-r,y+h,color);c.fill(x,y+r,x+w,y+h-r,color);
        for(int dy=0;dy<r;dy++){int dx=(int)Math.ceil(r-Math.sqrt(r*r-(r-dy-.5)*(r-dy-.5)));c.fill(x+dx,y+dy,x+w-dx,y+dy+1,color);c.fill(x+dx,y+h-dy-1,x+w-dx,y+h-dy,color);}
    }
}
