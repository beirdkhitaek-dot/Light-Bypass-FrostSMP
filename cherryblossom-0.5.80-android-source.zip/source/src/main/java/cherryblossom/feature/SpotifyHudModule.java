package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.MouseButtonEvent;
import cherryblossom.event.events.Render2DEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.*;
import cherryblossom.utils.EncryptedString;
import net.minecraft.client.gui.screen.ChatScreen;

public final class SpotifyHudModule extends Module {
    private final BooleanSetting hideWhenIdle=new BooleanSetting(EncryptedString.of("Hide When Idle"),false);
    private final NumberSetting scale=new NumberSetting(EncryptedString.of("HUD Scale"),60,160,100,5);
    private final NumberSetting opacity=new NumberSetting(EncryptedString.of("Opacity"),.1,1,.72,.05);
    private final NumberSetting x=new NumberSetting(EncryptedString.of("X Position"),0,100,2,.1);
    private final NumberSetting y=new NumberSetting(EncryptedString.of("Y Position"),0,100,72,.1);
    private final SpotifyNowPlaying player=SpotifyMedia.shared();
    private boolean dragging;
    private float left,top,width,height;
    private double grabX,grabY;
    public SpotifyHudModule(){
        super(EncryptedString.of("Spotify HUD"),EncryptedString.of("Spotify artwork and playback controls; open chat to click or drag"),-1,Category.CLIENT);
        addSettings(new Setting[]{hideWhenIdle,scale,opacity,x,y});
    }
    @Override public void onEnable(){SpotifyMedia.acquire(this);}
    @Override public void onDisable(){dragging=false;SpotifyMedia.release(this);}
    public void shutdown(){SpotifyMedia.release(this);}
    @EventListener public void render(Render2DEvent event){
        if(mc.options.hudHidden||mc.world==null)return;
        SpotifyNowPlaying.Track track=player.current();boolean editing=mc.currentScreen instanceof ChatScreen;
        if(hideWhenIdle.getValue()&&!track.present()&&!editing)return;
        var window=mc.getWindow();float sw=window.getFramebufferWidth(),sh=window.getFramebufferHeight();
        float u=Math.max(.5f,sh/1080f*(float)(scale.getValue()/100));u=Math.min(u,Math.min(sw/330,sh/152));
        width=310*u;height=132*u;
        if(!editing)dragging=false;
        if(dragging){
            double mx=mc.mouse.getX()*sw/Math.max(1,window.getWidth()),my=mc.mouse.getY()*sh/Math.max(1,window.getHeight());
            x.getValue((mx-grabX)/Math.max(1,sw-width)*100);y.getValue((my-grabY)/Math.max(1,sh-height)*100);
        }
        left=(float)(Math.max(0,sw-width)*x.getValue()/100);top=(float)(Math.max(0,sh-height)*y.getValue()/100);
        float guiScale=(float)window.getScaleFactor();event.context.getMatrices().pushMatrix();event.context.getMatrices().scale(1/guiScale,1/guiScale);
        try{SpotifyHudRenderer.draw(new MinecraftUiRenderer(event.context,guiScale),left,top,u,(float)opacity.getValue(),track);
        }finally{event.context.getMatrices().popMatrix();}
    }
    @EventListener public void mouse(MouseButtonEvent event){
        if(event.isCancelled())return;
        if(event.button!=0)return;
        if(event.actions==0){if(dragging){dragging=false;cherryblossom.integration.CherryGui.saveSettings();}return;}
        if(event.actions!=1||!(mc.currentScreen instanceof ChatScreen)||mc.world==null||mc.options.hudHidden||width<=0)return;
        var window=mc.getWindow();double mx=mc.mouse.getX()*window.getFramebufferWidth()/Math.max(1,window.getWidth());
        double my=mc.mouse.getY()*window.getFramebufferHeight()/Math.max(1,window.getHeight());
        if(mx>=left&&mx<=left+width&&my>=top&&my<=top+height){
            event.cancel();
            var control=SpotifyHudRenderer.controlAt((mx-left)/(width/310),(my-top)/(width/310));
            if(control!=null){player.control(control);return;}
            dragging=true;grabX=mx-left;grabY=my-top;
        }
    }
}
