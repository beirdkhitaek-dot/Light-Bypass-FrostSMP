package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.*;
import java.util.List;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class WorldLyricsModule extends Module {
    private static WorldLyricsModule instance;
    private final NumberSetting distance=new NumberSetting("Distance",.8,8,2.5,.1),height=new NumberSetting("Vertical Offset",-1.5,1.5,-.45,.05),horizontal=new NumberSetting("Horizontal Offset",-1.5,1.5,0,.05),scale=new NumberSetting("Text Scale",50,160,85,5),opacity=new NumberSetting("Opacity",.1,1,1,.05),timing=new NumberSetting("Timing Offset (ms)",-5000,5000,0,50);
    private final BooleanSetting nextLine=new BooleanSetting("Next Line",true),song=new BooleanSetting("Song Details",true),background=new BooleanSetting("Glass Background",false),throughWalls=new BooleanSetting("Through Walls",false),hidePaused=new BooleanSetting("Hide When Paused",false),status=new BooleanSetting("Show Status Messages",true);
    private LyricsSource source;
    public record Display(String title,String artist,String line,String next,String status,boolean playing){}
    public WorldLyricsModule(){super("World Lyrics","Synced Spotify lyrics floating in front of you. Uses LRCLIB when timed lyrics are available.",-1,Category.RENDER);addSettings(distance,height,horizontal,scale,opacity,timing,nextLine,song,background,throughWalls,hidePaused,status);instance=this;}
    @Override public void onEnable(){source=new LyricsSource();SpotifyMedia.acquire(this);}
    @Override public void onDisable(){SpotifyMedia.release(this);if(source!=null){source.close();source=null;}try{Class.forName("dev.cherryblossom.client.render.WorldLyricsRenderer").getMethod("release").invoke(null);}catch(ReflectiveOperationException ignored){}}
    @EventListener public void tick(TickEvent event){if(isEnabled()&&source!=null)source.update(SpotifyMedia.shared().current());}
    public Display display(){
        var track=SpotifyMedia.shared().current();if(!track.present()||source==null)return new Display("","","","","",false);
        var current=source.current();var timeline=current.lyrics();int index=timeline.indexAt(Math.max(0,track.positionAt(System.nanoTime())+(long)timing.getValue()));List<SyncedLyrics.Line> lines=timeline.lines();
        String text=index>=0?lines.get(index).text():"",next=index+1<lines.size()?lines.get(index+1).text():"";
        return new Display(track.title(),track.artist(),text,next,current.status(),track.playing());
    }
    public double distance(){return distance.getValue();}public double height(){return height.getValue();}public double horizontal(){return horizontal.getValue();}public float textScale(){return (float)scale.getValue()/100;}public float opacity(){return (float)opacity.getValue();}
    public boolean nextLine(){return nextLine.getValue();}public boolean songDetails(){return song.getValue();}public boolean background(){return background.getValue();}public boolean throughWalls(){return throughWalls.getValue();}public boolean hidePaused(){return hidePaused.getValue();}public boolean statusMessages(){return status.getValue();}
    public static void renderWorld(Matrix4f view,Matrix4f projection){
        var m=instance;if(m==null||!m.isEnabled()||m.mc.world==null||m.mc.options.hudHidden)return;
        var camera=m.mc.gameRenderer.getCamera();var rotation=camera.getRotation();Vector3f forward=new Vector3f(0,0,-1).rotate(rotation),right=new Vector3f(1,0,0).rotate(rotation),up=new Vector3f(0,1,0).rotate(rotation);
        try{Class.forName("dev.cherryblossom.client.render.WorldLyricsRenderer").getMethod("render",WorldLyricsModule.class,Matrix4f.class,Matrix4f.class,Vector3f.class,Vector3f.class,Vector3f.class).invoke(null,m,view,projection,forward,right,up);}catch(ReflectiveOperationException error){throw new IllegalStateException("World Lyrics renderer failed",error);}
    }
}
