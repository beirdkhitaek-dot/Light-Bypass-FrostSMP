package cherryblossom.feature;

import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.NumberSetting;

/** Changes the camera's base FOV without writing Minecraft's saved video setting. */
public final class CustomFovModule extends Module {
    private static CustomFovModule instance;
    private final NumberSetting fov = new NumberSetting("FOV",30,150,90,1)
        .getValue("Camera field of view in degrees. Sprinting, zoom and underwater effects still apply.");

    public CustomFovModule(){
        super("Custom FOV","Choose your camera field of view while enabled.",-1,Category.RENDER);
        addSetting(fov);instance=this;
    }
    public static boolean active(){return instance!=null&&instance.isEnabled();}
    public static int baseFov(int vanilla){
        if(!active())return vanilla;
        double value=instance.fov.getValue();
        return Double.isFinite(value)?(int)Math.round(Math.max(30,Math.min(150,value))):vanilla;
    }
}
