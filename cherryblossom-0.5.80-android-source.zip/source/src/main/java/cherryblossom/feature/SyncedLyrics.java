package cherryblossom.feature;

import java.util.*;
import java.util.regex.*;

/** Line-timed LRC only: plain lyrics are never presented as accurately synchronized. */
public final class SyncedLyrics {
    public record Line(long timeMs,String text){}
    private static final Pattern TIME=Pattern.compile("\\[(\\d{1,4}):([0-5]\\d)(?:[.:](\\d{1,3}))?]");
    private static final Pattern OFFSET=Pattern.compile("(?i)\\[offset:([+-]?\\d+)]");
    private final List<Line> lines;
    public SyncedLyrics(List<Line> lines){this.lines=List.copyOf(lines);}
    public List<Line> lines(){return lines;}
    public static SyncedLyrics parse(String lrc){
        if(lrc==null||lrc.length()>200_000)return new SyncedLyrics(List.of());
        long offset=0;var om=OFFSET.matcher(lrc);if(om.find())try{offset=Math.max(-60_000,Math.min(60_000,Long.parseLong(om.group(1))));}catch(NumberFormatException ignored){}
        TreeMap<Long,String> values=new TreeMap<>();
        for(String raw:lrc.split("\\R")){
            var matcher=TIME.matcher(raw);List<Long> times=new ArrayList<>();int end=0;
            while(matcher.find()){long ms=Long.parseLong(matcher.group(1))*60_000L+Long.parseLong(matcher.group(2))*1000;String fraction=matcher.group(3);if(fraction!=null)ms+=Integer.parseInt((fraction+"00").substring(0,3));times.add(Math.max(0,ms+offset));end=matcher.end();}
            if(times.isEmpty())continue;String text=raw.substring(end).replaceAll("[\\p{Cc}\\p{Cf}]","").strip();if(text.length()>320)text=text.substring(0,320);
            for(long time:times){if(values.size()>=4000)break;values.merge(time,text,(a,b)->a.isBlank()?b:a);}
        }
        return new SyncedLyrics(values.entrySet().stream().map(e->new Line(e.getKey(),e.getValue())).toList());
    }
    public int indexAt(long position){int low=0,high=lines.size()-1,result=-1;while(low<=high){int mid=(low+high)>>>1;if(lines.get(mid).timeMs()<=position){result=mid;low=mid+1;}else high=mid-1;}return result;}
}
