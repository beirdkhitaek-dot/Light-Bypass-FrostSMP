package cherryblossom.feature;

import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.NumberSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;

public final class HandPositionModule extends Module {
    private static HandPositionModule instance;
    private final NumberSetting mainX=offset("Main Hand X","Right / left");
    private final NumberSetting mainY=offset("Main Hand Y","Up / down");
    private final NumberSetting mainZ=offset("Main Hand Z","Closer / farther");
    private final NumberSetting offX=offset("Off Hand X","Right / left");
    private final NumberSetting offY=offset("Off Hand Y","Up / down");
    private final NumberSetting offZ=offset("Off Hand Z","Closer / farther");

    public HandPositionModule(){
        super("Hand Position","Move your main and off hand independently in first person.",-1,Category.RENDER);
        addSettings(mainX,mainY,mainZ,offX,offY,offZ);instance=this;
    }
    private static NumberSetting offset(String name,String description){return new NumberSetting(name,-1,1,0,.01).getValue(description+" in camera space. Zero is the normal position.");}
    public static boolean active(){return instance!=null&&instance.isEnabled();}
    public static void apply(MatrixStack matrices,Hand hand){
        if(!active())return;
        var m=instance;boolean main=hand==Hand.MAIN_HAND;
        matrices.translate((main?m.mainX:m.offX).getValue(),(main?m.mainY:m.offY).getValue(),(main?m.mainZ:m.offZ).getValue());
    }
}
