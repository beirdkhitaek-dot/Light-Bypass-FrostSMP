package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.module.setting.BindSetting;
import cherryblossom.module.setting.Setting;
import cherryblossom.utils.InventoryUtil;
import cherryblossom.utils.EncryptedString;
import cherryblossom.utils.KeyUtils;
import cherryblossom.utils.BlockUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.BlockHitResult;

public final class DoubleAnchorModule extends Module {
   private final BindSetting activateKey = new BindSetting(
         EncryptedString.of("Activate Key"),
         71,
         false
      )
      .setDescription(
         EncryptedString.of("Key that starts double anchoring")
      );
   private final NumberSetting switchDelay = new NumberSetting(
      EncryptedString.of("Switch Delay"),
      0.0,
      20.0,
      0.0,
      1.0
   );
   private final NumberSetting totemSlot = new NumberSetting(
      EncryptedString.of("Totem Slot"),
      1.0,
      9.0,
      1.0,
      1.0
   );
   private int delayCounter = 0;
   private int step = 0;
   private boolean isAnchoring = false;

   public DoubleAnchorModule() {
      super(
         EncryptedString.of("Double Anchor"),
         EncryptedString.of("Automatically Places 2 anchors"),
         -1,
         Category.COMBAT
      );
      Setting[] var10001 = new Setting[3];
      var10001[0] = this.switchDelay;
      var10001[1] = this.totemSlot;
      var10001[2] = this.activateKey;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.currentScreen == null
         && this.mc.player != null
         && this.hasRequiredItems()
         && (this.isAnchoring || this.checkActivationKey())) {
         HitResult var2 = this.mc.crosshairTarget;
         if (!(this.mc.crosshairTarget instanceof BlockHitResult)
            || BlockUtil.isBlockAtPosition(((BlockHitResult)var2).getBlockPos(), Blocks.AIR)) {
            this.isAnchoring = false;
            this.resetState();
         } else if (this.delayCounter < this.switchDelay.getIntValue()) {
            this.delayCounter += 1;
         } else {
            if (this.step == 0) {
               InventoryUtil.swap(Items.RESPAWN_ANCHOR);
            } else if (this.step == (1)) {
               BlockUtil.interactWithBlock((BlockHitResult)var2, true);
            } else if (this.step == (2)) {
               InventoryUtil.swap(Items.GLOWSTONE);
            } else if (this.step == (3)) {
               BlockUtil.interactWithBlock((BlockHitResult)var2, true);
            } else if (this.step == (4)) {
               InventoryUtil.swap(Items.RESPAWN_ANCHOR);
            } else if (this.step == (5)) {
               BlockUtil.interactWithBlock((BlockHitResult)var2, true);
               BlockUtil.interactWithBlock((BlockHitResult)var2, true);
            } else if (this.step == (6)) {
               InventoryUtil.swap(Items.GLOWSTONE);
            } else if (this.step == (7)) {
               BlockUtil.interactWithBlock((BlockHitResult)var2, true);
            } else if (this.step == (8)) {
               InventoryUtil.swap(this.totemSlot.getIntValue() - (1));
            } else if (this.step == (9)) {
               BlockUtil.interactWithBlock((BlockHitResult)var2, true);
            } else if (this.step == (10)) {
               this.isAnchoring = false;
               this.step = 0;
               this.resetState();
               return;
            }

            this.step += 1;
         }
      }
   }

   private boolean hasRequiredItems() {
      int var1 = 0;
      int var2 = 0;

      for (int var3 = 0; var3 < (9); var3++) {
         ItemStack var4 = this.mc.player.getInventory().getStack(var3);
         if (var4.getItem().equals(Items.RESPAWN_ANCHOR)) {
            var1 = 1;
         }

         if (var4.getItem().equals(Items.GLOWSTONE)) {
            var2 = 1;
         }
      }

      return ((var1 != 0 && var2 != 0));
   }

   private boolean checkActivationKey() {
      int var1 = this.activateKey.getValue();
      if (var1 != (-1) && KeyUtils.isKeyPressed(var1)) {
         return this.isAnchoring = true;
      } else {
         this.resetState();
         return false;
      }
   }

   private void resetState() {
      this.delayCounter = 0;
   }

   public boolean isAnchoringActive() {
      return this.isAnchoring;
   }
}
