package cherryblossom.feature;

import java.util.ArrayList;
import java.util.List;
import cherryblossom.mixin.SakuraParticleFactoryAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Small, bounded ambient cherry-leaf particles using vanilla flutter and collision. */
final class SakuraPetals {
    private final List<Particle> active = new ArrayList<>();
    private ClientWorld world;
    private int ticks;

    void tick(boolean enabled) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled || mc.world != world) clear();
        world = mc.world;
        if (!enabled || world == null || mc.player == null || mc.isPaused()
                || world.getRegistryKey() != World.OVERWORLD) return;
        active.removeIf(p -> !p.isAlive());
        if (++ticks % 2 != 0 || active.size() >= 100) return;
        var camera = mc.gameRenderer.getCamera().getCameraPos();
        var random = world.random;
        double x = camera.x + (random.nextDouble() - .5) * 24;
        double y = camera.y + 3 + random.nextDouble() * 7;
        double z = camera.z + (random.nextDouble() - .5) * 24;
        if (!world.isSkyVisible(BlockPos.ofFloored(x, y, z))) return;
        // This explicitly enabled ambient effect has its own toggle and cap.
        // Create only our leaves directly, preserving normal game particle settings.
        Particle petal = ((SakuraParticleFactoryAccessor)mc.particleManager)
                .cherry$createPetal(ParticleTypes.CHERRY_LEAVES, x, y, z, 0, 0, 0);
        if (petal != null) {
            petal.scale(.7f);mc.particleManager.addParticle(petal);active.add(petal);
        }
    }

    void clear() {
        for (Particle petal : active) petal.markDead();
        active.clear();world = null;ticks = 0;
    }
}
