package cherryblossom.feature;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class CharacterRig {
   float scale = 1.0F;
   int outlineColor = -14017512;
   float outline = 0.2F;
   float occlusion = 0.55F;
   float flat;
   boolean firstPersonArms = true;
   final CharacterPartBuilder[] bones = new CharacterPartBuilder[CharacterBone.values().length];
   final List<CharacterPartBuilder> extras = new ArrayList<>();

   public CharacterRig scale(float value) {
      if (value <= 0.05F || value >= 8.0F) {
         throw new IllegalArgumentException("scale must be between 0.05 and 8");
      }
      scale = value;
      return this;
   }

   public CharacterRig outline(int color, float thickness) {
      outlineColor = color;
      outline = Math.max(0.0F, thickness);
      return this;
   }

   public CharacterRig occlusion(float value) {
      occlusion = Math.max(0.0F, Math.min(1.0F, value));
      return this;
   }

   public CharacterRig flatLight(float value) {
      flat = Math.max(0.0F, Math.min(1.0F, value));
      return this;
   }

   public CharacterRig firstPersonArms(boolean enabled) {
      firstPersonArms = enabled;
      return this;
   }

   public CharacterPartBuilder part(CharacterBone bone) {
      CharacterPartBuilder builder = bones[bone.ordinal()];
      if (builder == null) {
         builder = new CharacterPartBuilder(bone.name(), bone, null, false);
         bones[bone.ordinal()] = builder;
      }
      return builder;
   }

   public CharacterPartBuilder extra(String name, CharacterBone bone) {
      return extra(name, part(bone));
   }

   public CharacterPartBuilder extra(String name, CharacterPartBuilder parent) {
      if (name == null || name.isEmpty()) {
         throw new IllegalArgumentException("extra needs a name");
      }
      for (CharacterPartBuilder existing : extras) {
         if (existing.name.equals(name)) {
            throw new IllegalArgumentException("duplicate extra name: " + name);
         }
      }
      for (CharacterBone bone : CharacterBone.values()) {
         if (bone.name().equals(name)) {
            throw new IllegalArgumentException("extra name clashes with a bone: " + name);
         }
      }
      CharacterPartBuilder extra = new CharacterPartBuilder(name, parent.bone, parent, true);
      extras.add(extra);
      return extra;
   }

   public float scale() {
      return scale;
   }
}
