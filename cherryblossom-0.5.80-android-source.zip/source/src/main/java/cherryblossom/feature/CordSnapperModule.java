package cherryblossom.feature;

import java.util.concurrent.CompletableFuture;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.BindSetting;
import cherryblossom.module.setting.ModeSetting;
import cherryblossom.module.setting.StringSetting;
import cherryblossom.utils.EncryptedString;
import cherryblossom.utils.KeyUtils;
import cherryblossom.utils.embed.DiscordWebhook;
import cherryblossom.utils.embed.TelegramNotifier;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

public final class CordSnapperModule extends Module {
   private final BindSetting activateKey;
   private final ModeSetting<Delivery> delivery;
   private final StringSetting webhookUrl;
   private final StringSetting telegramToken;
   private final StringSetting telegramChatId;
   private boolean wasPressed;

   public CordSnapperModule() {
      super(
         EncryptedString.of("Cord Snapper"),
         EncryptedString.of("Sends your current coordinates to Discord or Telegram"),
         -1,
         Category.MISC
      );
      activateKey = new BindSetting(EncryptedString.of("Activate Key"), -1, false);
      delivery = new ModeSetting<>(EncryptedString.of("Delivery"), Delivery.Discord, Delivery.class);
      webhookUrl = new StringSetting(EncryptedString.of("Discord Webhook"), "");
      telegramToken = new StringSetting(EncryptedString.of("Telegram Bot Token"), "");
      telegramChatId = new StringSetting(EncryptedString.of("Telegram Chat ID"), "");
      addSettings(activateKey, delivery, webhookUrl, telegramToken, telegramChatId);
   }

   @Override
   public void onEnable() {
      wasPressed = false;
      super.onEnable();
   }

   @Override
   public void onDisable() {
      wasPressed = false;
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.player == null || mc.world == null || activateKey.getValue() < 0) {
         return;
      }
      boolean pressed = KeyUtils.isKeyPressed(activateKey.getValue());
      if (pressed && !wasPressed) {
         sendCoordinates();
      }
      wasPressed = pressed;
   }

   private void sendCoordinates() {
      BlockPos position = mc.player.getBlockPos();
      String dimension = mc.world.getRegistryKey().getValue().toString();
      String message = "CherryBlossom coordinates\nDimension: " + dimension
         + "\nX: " + position.getX() + " Y: " + position.getY() + " Z: " + position.getZ();
      Delivery destination = delivery.isMode(Delivery.Telegram) ? Delivery.Telegram : Delivery.Discord;
      String discordUrl = webhookUrl.getValue();
      String botToken = telegramToken.getValue();
      String chatId = telegramChatId.getValue();

      CompletableFuture.runAsync(() -> {
         try {
            if (destination == Delivery.Telegram) {
               TelegramNotifier.send(botToken, chatId, message);
            } else {
               DiscordWebhook webhook = new DiscordWebhook(discordUrl);
               webhook.a(message);
               webhook.execute();
            }
            showStatus("§aCord Snapper: coordinates sent to " + destination + ".");
         } catch (Throwable error) {
            System.err.println("CherryBlossom Cord Snapper: " + error.getMessage());
            showStatus("§cCord Snapper failed: " + safeMessage(error));
         }
      });
   }

   private void showStatus(String message) {
      mc.execute(() -> {
         if (mc.player != null) {
            mc.player.sendMessage(Text.literal(message), false);
         }
      });
   }

   private static String safeMessage(Throwable error) {
      String message = error.getMessage();
      if (message == null || message.isBlank()) {
         return error.getClass().getSimpleName();
      }
      return message.length() > 160 ? message.substring(0, 160) + "…" : message;
   }

   private enum Delivery {
      Discord,
      Telegram
   }
}
