package cherryblossom.feature;

import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.NewFeature;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.ModeSetting;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.module.setting.ButtonSetting;
import cherryblossom.module.setting.StringSetting;
import cherryblossom.utils.EncryptedString;
import cherryblossom.itemfx.ItemFx;

public final class CustomTotemModule extends Module implements NewFeature {
   public static final ModeSetting<TotemDesign> design = new ModeSetting<>(
      EncryptedString.of("Design"), TotemDesign.Spooky, TotemDesign.class
   ).setDescription(EncryptedString.of("Built-in designs or your own imported PNG"));
   public static final BooleanSetting animations = new BooleanSetting(
      EncryptedString.of("Animations"), true
   ).setDescription(EncryptedString.of("Floating, swaying cloth, flowing chrome and drips"));
   public static final BooleanSetting particles = new BooleanSetting(
      EncryptedString.of("Particles"), true
   ).setDescription(EncryptedString.of("Orbiting glow, embers, runes, smoke and glints around the totem"));
   public static final NumberSetting glow = new NumberSetting(
      EncryptedString.of("Glow Strength"), 0.0, 100.0, 75.0, 1.0
   ).getValue(EncryptedString.of("How bright the glowing parts and their bloom are"));
   public static final BooleanSetting popEffects = new BooleanSetting(
      EncryptedString.of("Pop Effects"), true
   ).setDescription(EncryptedString.of("The design's own burst when a totem pops (replaces the green particles)"));

   private static CustomTotemModule instance;
   public static final StringSetting imagePath = new StringSetting(EncryptedString.of("PNG File"), "")
      .setDescription(EncryptedString.of("Choose a PNG, or paste its full file path and use Import PNG Path"));

   public CustomTotemModule() {
      super(EncryptedString.of("Custom Totem"),
         EncryptedString.of("Built-in animated totems or import your own PNG image"),
         -1, Category.RENDER);
      addSettings(design,
         new ButtonSetting(EncryptedString.of("Choose PNG..."), cherryblossom.itemfx.ImportedTotem::browse),
         imagePath,
         new ButtonSetting(EncryptedString.of("Import PNG Path"), () -> cherryblossom.itemfx.ImportedTotem.importAsync(imagePath.getValue())),
         animations, particles, glow, popEffects);
      instance = this;
   }

   public static boolean active() {
      return instance != null && instance.isEnabled();
   }

   public static int designIndex() {
      return design.getModeIndex();
   }

   public static boolean chromeActive() {
      return active() && (designIndex() == 1 || designIndex() == 3) && animations.getValue();
   }

   @Override
   public void onDisable() {
      super.onDisable();
      ItemFx.moduleOff();
   }

   public enum TotemDesign {
      Spooky,
      Chrome_Liquid,
      Spooky_3D,
      Chrome_Liquid_3D,
      Imported_PNG,
      IShowSpeed,
      Totem_Cat_Meme,
      Hello_Kitty,
      Animated_Axolotl,
      Totem_of_Autism,
      Glowing_3D_Totem,
      Teddy_Totems,
      Cat_Biting_Wire,
      camman18;
      @Override public String toString() {return ordinal()>=5?cherryblossom.itemfx.TotemAssets.entries().get(ordinal()-5).name():name().replace('_',' ');}
   }
}
