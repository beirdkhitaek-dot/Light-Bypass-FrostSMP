package cherryblossom.feature;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.BooleanSupplier;
import cherryblossom.mixin.BlockOverlayInteractionAccessor;
import cherryblossom.mixin.CherryBlossomGameRendererAccessor;
import cherryblossom.module.ext.ClientModule;
import cherryblossom.module.ext.EventHandler;
import cherryblossom.module.ext.ModuleCategory;
import cherryblossom.module.ext.event.Render3DEvent;
import cherryblossom.module.ext.setting.BooleanSetting;
import cherryblossom.module.ext.setting.ColorSetting;
import cherryblossom.module.ext.setting.ModeSetting;
import cherryblossom.module.ext.setting.NumberSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.enums.ChestType;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.util.shape.VoxelShapes.BoxConsumer;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

@Environment(EnvType.CLIENT)
public final class BlockOverlayModule extends ClientModule {
   private static final String BOTH = "Both";
   private static final String OUTLINE = "Outline";
   private static final String FILL = "Fill";
   private static final String GRADIENT = "Gradient";
   private static final String SOLID = "Solid";
   private static final String RAINBOW = "Rainbow";
   private static final float FADE_IN = 0.12F;
   private static final float FADE_OUT = 0.2F;
   private static final double SNAP_DISTANCE = 6.0;
   private static final float FLOW_SPEED = 0.35F;
   private static final double SEGMENT = 0.125;
   private static final double FILL_INFLATE = 0.002;
   private static final double LINE_LIFT = 0.004;
   private static final double GLOW_LIFT = 0.002;
   private final ModeSetting style;
   private final ModeSetting colorMode;
   private final ColorSetting color;
   private final ColorSetting secondColor;
   private final BooleanSetting flow;
   private final NumberSetting fillOpacity;
   private final NumberSetting width;
   private final BooleanSetting glow;
   private final BooleanSetting smooth;
   private final NumberSetting smoothSpeed;
   private final BooleanSetting miningProgress;
   private final BooleanSetting faceOnly;
   private final BooleanSetting seeThrough;
   private ClientWorld level;
   private BlockPos pos;
   private BlockState state;
   private BlockPos partner;
   private BlockState partnerState;
   private final List<double[]> edges;
   private List<Box> boxes;
   private Box localBounds;
   private Box goal;
   private Box box;
   private Direction face;
   private Box faceBox;
   private float presence;
   private float progress;
   private long lastFrame;
   private Vec3d eye;
   private double time;
   private float fade;
   private double ax;
   private double bx;
   private double ay;
   private double by;
   private double az;
   private double bz;

   public BlockOverlayModule() {
      super(
         "block-overlay",
         "Block Overlay",
         "A smooth, animated outline and fill on the block you look at.",
         ModuleCategory.VISUALS
      );
      String var10002 = "style";
      String var10005 = "Style";
      String var10006 = "Both";
      String[] var10007 = new String[3];
      var10007[0] = "Both";
      var10007[1] = "Outline";
      var10007[2] = "Fill";
      this.style = this.addSetting(var10002, new ModeSetting(var10005, var10006, var10007));
      var10002 = "color-mode";
      var10005 = "Color Mode";
      var10006 = "Gradient";
      var10007 = new String[3];
      var10007[0] = "Gradient";
      var10007[1] = "Solid";
      var10007[2] = "Rainbow";
      this.colorMode = this.addSetting(var10002, new ModeSetting(var10005, var10006, var10007));
      this.color = this.addSetting(
         "color",
         new ColorSetting("Color", -871878)
      );
      this.secondColor = this.addSetting(
         "second-color",
         new ColorSetting("Second Color", -6480)
      );
      this.flow = this.addSetting(
         "flow",
         new BooleanSetting("Flow", true)
      );
      this.fillOpacity = this.addSetting(
         "fill-opacity",
         new NumberSetting(
               "Fill Opacity",
               20.0F,
               2.0F,
               60.0F
            )
            .step(1.0F)
      );
      this.width = this.addSetting(
         "width",
         new NumberSetting(
               "Width",
               2.0F,
               1.0F,
               5.0F
            )
            .step(0.5F)
      );
      this.glow = this.addSetting(
         "glow",
         new BooleanSetting("Glow", true)
      );
      this.smooth = this.addSetting(
         "smooth",
         new BooleanSetting("Smooth", true)
      );
      this.smoothSpeed = this.addSetting(
         "smooth-speed",
         new NumberSetting(
               "Smooth Speed",
               16.0F,
               4.0F,
               40.0F
            )
            .step(1.0F)
      );
      this.miningProgress = this.addSetting(
         "mining-progress",
         new BooleanSetting(
            "Mining Progress", true
         )
      );
      this.faceOnly = this.addSetting(
         "face-only",
         new BooleanSetting("Face Only", false)
      );
      this.seeThrough = this.addSetting(
         "see-through",
         new BooleanSetting("See Through", false)
      );
      this.edges = new ArrayList<>();
      this.boxes = List.of();
      this.secondColor
         .visibleWhen(() -> this.colorMode.is("Gradient"));
      this.flow
         .visibleWhen(
            () -> ((!this.colorMode.is("Solid")
                  ? 1
                  : 0) != 0)
         );
      this.fillOpacity
         .visibleWhen(
            () -> ((!this.style.is("Outline")
                  ? 1
                  : 0) != 0)
         );
      this.width
         .visibleWhen(
            () -> ((!this.style.is("Fill")
                  ? 1
                  : 0) != 0)
         );
      this.glow
         .visibleWhen(
            () -> ((!this.style.is("Fill")
                  ? 1
                  : 0) != 0)
         );
      this.smoothSpeed.visibleWhen(this.smooth::get);
   }

   public void onDisable() {
      this.reset();
   }

   @EventHandler
   public void onRender3D(Render3DEvent var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.world != null && var2.player != null) {
         if (var2.world != this.level) {
            this.reset();
            this.level = var2.world;
         }

         long var3 = System.nanoTime();
         float var5 = this.lastFrame == (0L)
            ? 0.0F
            : Math.min(
               (float)(var3 - this.lastFrame) / 1000000000.0F, 0.10000000149011612F
            );
         this.lastFrame = var3;
         BlockHitResult var6 = target(var2);
         if (var6 != null && this.adopt(var2, var6)) {
            if (this.box != null
               && !(this.presence < 0.019999999552965164F)
               && this.smooth.get()
               && !(
                  this.box.getCenter().distanceTo(this.goal.getCenter())
                     > 6.0
               )) {
               this.box = lerp(
                  this.box,
                  this.goal,
                  1.0F - (float)Math.exp((double)(-this.smoothSpeed.get() * var5))
               );
            } else {
               this.box = this.goal;
            }

            this.presence = Math.min(
               1.0F, this.presence + var5 / 0.11999999731779099F
            );
         } else {
            var6 = null;
            this.presence = Math.max(
               0.0F, this.presence - var5 / 0.20000000298023224F
            );
            if (this.presence == 0.0F) {
               this.reset();
               this.level = var2.world;
               return;
            }
         }

         if (this.box != null) {
            this.updateProgress(var2, var5, ((var6 != null)));
            this.eye = var2.gameRenderer.getCamera().getCameraPos();
            this.time = (double)(var3 % (3600000000000L))
               / 1000000000.0;
            this.draw();
         }
      } else {
         this.reset();
      }
   }

   private static BlockHitResult target(MinecraftClient var0) {
      if (!(var0.crosshairTarget instanceof BlockHitResult var1) || var1.getType() != Type.BLOCK || var1.isInsideBlock()) {
         return null;
      }

      if (!((CherryBlossomGameRendererAccessor)var0.gameRenderer).cherryblossom$shouldRenderBlockOutline()) {
         return null;
      } else {
         BlockPos var3 = var1.getBlockPos();
         return !var0.world.getBlockState(var3).isAir() && var0.world.getWorldBorder().contains(var3) ? var1 : null;
      }
   }

   private boolean adopt(MinecraftClient var1, BlockHitResult var2) {
      ClientWorld var3 = var1.world;
      BlockPos var4 = var2.getBlockPos();
      BlockPos var5 = partner(var3, var4, var3.getBlockState(var4));
      BlockPos var6 = var5 != null && var5.compareTo(var4) < 0 ? var5 : var4;
      BlockPos var7 = var5 == null ? null : (var6.equals(var4) ? var5 : var4);
      BlockState var8 = var3.getBlockState(var6);
      BlockState var9 = var7 == null ? null : var3.getBlockState(var7);
      if (!var6.equals(this.pos) || var8 != this.state || var9 != this.partnerState) {
         Entity var10 = var1.getCameraEntity();
         ShapeContext var11 = var10 == null ? ShapeContext.absent() : ShapeContext.of(var10);
         VoxelShape var12 = var8.getOutlineShape(var3, var6, var11);
         if (var7 != null) {
            var12 = VoxelShapes.union(var12, var9.getOutlineShape(var3, var7, var11).offset(var7.subtract(var6)));
         }

         var12 = var12.simplify();
         if (var12.isEmpty()) {
            return false;
         }

         if (!var6.equals(this.pos)) {
            this.progress = 0.0F;
         }

         this.pos = var6;
         this.state = var8;
         this.partner = var7;
         this.partnerState = var9;
         this.edges.clear();
         var12.forEachEdge((var1x, var3x, var5x, var7x, var9x, var11x) -> {
            double[] var10001 = new double[6];
            var10001[0] = var1x;
            var10001[1] = var3x;
            var10001[2] = var5x;
            var10001[3] = var7x;
            var10001[4] = var9x;
            var10001[5] = var11x;
            this.edges.add(var10001);
         });
         this.boxes = var12.getBoundingBoxes();
         this.localBounds = var12.getBoundingBox();
         this.goal = this.localBounds.offset(var6);
      }

      this.face = var2.getSide();
      this.faceBox = this.boxOnFace(
         var2.getPos()
            .subtract(
               (double)this.pos.getX(),
               (double)this.pos.getY(),
               (double)this.pos.getZ()
            )
      );
      return true;
   }

   private static BlockPos partner(ClientWorld var0, BlockPos var1, BlockState var2) {
      BlockPos var3 = null;
      if (var2.contains(Properties.DOUBLE_BLOCK_HALF)) {
         var3 = var2.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER ? var1.up() : var1.down();
      } else if (var2.getBlock() instanceof BedBlock) {
         var3 = var1.offset(BedBlock.getOppositePartDirection(var2));
      } else if (var2.getBlock() instanceof ChestBlock && var2.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
         var3 = ChestBlock.getPosInFrontOf(var1, var2);
      }

      return var3 != null && var0.getBlockState(var3).isOf(var2.getBlock()) ? var3 : null;
   }

   private Box boxOnFace(Vec3d var1) {
      double var2 = 0.001;

      for (Box var5 : this.boxes) {
         int var6 = switch (this.face) {
            case EAST-> Math.abs(var1.x - var5.maxX) < var2 ? 1 : 0;
            case WEST-> Math.abs(var1.x - var5.minX) < var2 ? 1 : 0;
            case UP-> Math.abs(var1.y - var5.maxY) < var2 ? 1 : 0;
            case DOWN-> Math.abs(var1.y - var5.minY) < var2 ? 1 : 0;
            case SOUTH-> Math.abs(var1.z - var5.maxZ) < var2 ? 1 : 0;
            case NORTH-> Math.abs(var1.z - var5.minZ) < var2 ? 1 : 0;
            default -> throw new MatchException(null, null);
         };
         if (var6 != 0 && var5.expand(var2).contains(var1)) {
            return var5;
         }
      }

      return this.localBounds;
   }

   private void updateProgress(MinecraftClient var1, float var2, boolean var3) {
      float var4 = 0.0F;
      ClientPlayerInteractionManager var5 = var1.interactionManager;
      if (var3 && this.miningProgress.get() && var5 != null && var5.isBreakingBlock()) {
         BlockOverlayInteractionAccessor var6 = (BlockOverlayInteractionAccessor)var5;
         BlockPos var7 = var6.cherryblossom$blockOverlayDestroyPos();
         if (var7 != null && (var7.equals(this.pos) || var7.equals(this.partner))) {
            var4 = MathHelper.clamp(
               var6.cherryblossom$blockOverlayDestroyProgress(), 0.0F, 1.0F
            );
         }
      }

      this.progress = this.progress
         + (var4 - this.progress)
            * (1.0F - (float)Math.exp((double)(-18.0F * var2)));
   }

   private void reset() {
      this.level = null;
      this.pos = null;
      this.state = null;
      this.partner = null;
      this.partnerState = null;
      this.edges.clear();
      this.boxes = List.of();
      this.localBounds = null;
      this.goal = null;
      this.box = null;
      this.face = null;
      this.faceBox = null;
      this.presence = 0.0F;
      this.progress = 0.0F;
      this.lastFrame = 0L;
   }

   private void draw() {
      this.fade = this.presence
         * this.presence
         * (3.0F - 2.0F * this.presence);
      double var1 = 0.94
         + 0.06 * (double)this.fade;
      double[] var3 = axis(
         this.box.minX,
         this.box.maxX,
         this.goal.minX,
         this.goal.maxX,
         (double)this.pos.getX() - this.goal.minX,
         var1
      );
      double[] var4 = axis(
         this.box.minY,
         this.box.maxY,
         this.goal.minY,
         this.goal.maxY,
         (double)this.pos.getY() - this.goal.minY,
         var1
      );
      double[] var5 = axis(
         this.box.minZ,
         this.box.maxZ,
         this.goal.minZ,
         this.goal.maxZ,
         (double)this.pos.getZ() - this.goal.minZ,
         var1
      );
      this.ax = var3[0];
      this.bx = var3[1];
      this.ay = var4[0];
      this.by = var4[1];
      this.az = var5[0];
      this.bz = var5[1];
      int var6 = !this.style.is("Fill") ? 1 : 0;
      int var7 = !this.style.is("Outline")
         ? 1
         : 0;
      float var8 = this.fillOpacity.get() / 100.0F;
      if (var7 != 0) {
         if (this.faceOnly.get()) {
            this.faceFill(
               this.faceBox, this.face, var8, 0.002
            );
         } else {
            for (Box var10 : this.boxes) {
               this.boxFill(var10, var8, 0.002);
            }
         }
      }

      if (this.progress > 0.009999999776482582F) {
         this.progressFill(
            Math.min(
               0.44999998807907104F,
               var8 * 1.399999976158142F + 0.1599999964237213F
            )
         );
      }

      if (var6 != 0) {
         this.outline(
            this.faceOnly.get()
               ? faceEdges(this.faceBox, this.face)
               : this.edges
         );
      }
   }

   private static double[] axis(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = var6 - var4;
      double var14 = var12 > 1e-06
         ? (var2 - var0) / var12
         : 1.0;
      double var16 = (var0 + var2) * 0.5;
      double var18 = var16 * (1.0 - var10) + (var0 + var8 * var14) * var10;
      double[] var10000 = new double[2];
      var10000[0] = var18;
      var10000[1] = var14 * var10;
      return var10000;
   }

   private Vec3d world(double var1, double var3, double var5) {
      return new Vec3d(
         this.ax + this.bx * var1,
         this.ay + this.by * var3,
         this.az + this.bz * var5
      );
   }

   private void outline(List<double[]> var1) {
      int var2 = !this.colorMode.is("Solid")
         ? 1
         : 0;
      ArrayList var3 = new ArrayList(var1.size() * (4));
      ArrayList var4 = new ArrayList(var1.size() * (4));

      for (double[] var6 : var1) {
         double var7 = Math.sqrt(
            sq(var6[3] - var6[0])
               + sq(var6[4] - var6[1])
               + sq(var6[5] - var6[2])
         );
         int var9 = var2 != 0
            ? MathHelper.clamp(
               (int)Math.ceil(var7 / 0.125), 1, 16
            )
            : 1;

         for (int var10 = 0; var10 < var9; var10++) {
            double var11 = (double)var10 / (double)var9;
            double var13 = (double)(var10 + (1)) / (double)var9;
            double var15 = (var11 + var13) * 0.5;
            double[] var10001 = new double[6];
            var10001[0] = MathHelper.lerp(var11, var6[0], var6[3]);
            var10001[1] = MathHelper.lerp(var11, var6[1], var6[4]);
            var10001[2] = MathHelper.lerp(var11, var6[2], var6[5]);
            var10001[3] = MathHelper.lerp(var13, var6[0], var6[3]);
            var10001[4] = MathHelper.lerp(var13, var6[1], var6[4]);
            var10001[5] = MathHelper.lerp(var13, var6[2], var6[5]);
            var3.add(var10001);
            var4.add(
               this.colorAt(
                  MathHelper.lerp(var15, var6[0], var6[3]),
                  MathHelper.lerp(var15, var6[1], var6[4]),
                  MathHelper.lerp(var15, var6[2], var6[5])
               )
            );
         }
      }

      float var17 = this.width.get();
      if (this.glow.get()) {
         for (int var18 = 0; var18 < var3.size(); var18++) {
            double[] var20 = (double[])var3.get(var18);
            int var8 = (Integer)var4.get(var18);
            this.line(
               var20,
               ColorHelper.scaleAlpha(var8, 0.3400000035762787F * this.fade),
               var17 + 3.0F,
               0.002
            );
            this.line(
               var20,
               ColorHelper.scaleAlpha(var8, 0.12999999523162842F * this.fade),
               var17 + 8.0F,
               0.002
            );
         }
      }

      for (int var19 = 0; var19 < var3.size(); var19++) {
         this.line(
            (double[])var3.get(var19),
            ColorHelper.scaleAlpha((Integer)var4.get(var19), this.fade),
            var17,
            0.004
         );
      }
   }

   private void line(double[] var1, int var2, float var3, double var4) {
      VisibilityConfigurable var6 = GizmoDrawing.line(
         this.lift(
            this.world(var1[0], var1[1], var1[2]), var4
         ),
         this.lift(
            this.world(var1[3], var1[4], var1[5]), var4
         ),
         var2,
         var3
      );
      if (this.seeThrough.get()) {
         var6.ignoreOcclusion();
      }
   }

   private Vec3d lift(Vec3d var1, double var2) {
      Vec3d var4 = this.eye.subtract(var1);
      double var5 = var4.length();
      return var5 < 1e-06 ? var1 : var1.add(var4.multiply(var2 / var5));
   }

   private void boxFill(Box var1, float var2, double var3) {
      Direction[] var5 = Direction.values();
      int var6 = var5.length;

      for (int var7 = 0; var7 < var6; var7++) {
         Direction var8 = var5[var7];
         this.faceFill(var1, var8, var2, var3);
      }
   }

   private void faceFill(Box var1, Direction var2, float var3, double var4) {
      Vec3d var6 = this.world(var1.minX, var1.minY, var1.minZ).subtract(var4, var4, var4);
      Vec3d var7 = this.world(var1.maxX, var1.maxY, var1.maxZ).add(var4, var4, var4);
      Vec3d var8 = faceCentre(var1, var2);
      int var9 = this.colorAt(var8.x, var8.y, var8.z);
      int var10 = MathHelper.clamp(
               Math.round(var3 * this.fade * 255.0F), 0, 255
            )
            << (24)
         | var9 & (16777215);
      VisibilityConfigurable var11 = GizmoDrawing.face(var6, var7, var2, DrawStyle.filled(var10));
      if (this.seeThrough.get()) {
         var11.ignoreOcclusion();
      }
   }

   private void progressFill(float var1) {
      double var2 = 0.004;
      if (this.faceOnly.get()) {
         Box var4 = this.faceBox;
         Box var5 = this.face.getAxis() == Axis.Y
            ? var4.contract(
               var4.getLengthX()
                  * (double)(1.0F - this.progress)
                  * 0.5,
               0.0,
               var4.getLengthZ()
                  * (double)(1.0F - this.progress)
                  * 0.5
            )
            : new Box(
               var4.minX,
               var4.minY,
               var4.minZ,
               var4.maxX,
               var4.minY + var4.getLengthY() * (double)this.progress,
               var4.maxZ
            );
         this.faceFill(var5, this.face, var1, var2);
      } else {
         double var8 = this.localBounds.minY + this.localBounds.getLengthY() * (double)this.progress;

         for (Box var7 : this.boxes) {
            if (!(var7.minY >= var8)) {
               this.boxFill(
                  new Box(var7.minX, var7.minY, var7.minZ, var7.maxX, Math.min(var7.maxY, var8), var7.maxZ),
                  var1,
                  var2
               );
            }
         }
      }
   }

   private int colorAt(double var1, double var3, double var5) {
      int var7 = this.color.argb();
      if (this.colorMode.is("Solid")) {
         return var7;
      } else {
         double var8 = (
               norm(var1, this.localBounds.minX, this.localBounds.maxX)
                  + norm(var3, this.localBounds.minY, this.localBounds.maxY)
                  + norm(var5, this.localBounds.minZ, this.localBounds.maxZ)
            )
            / 3.0;
         double var10 = this.flow.get()
            ? this.time * 0.3499999940395355
            : 0.0;
         if (this.colorMode.is("Rainbow")) {
            double var14 = var8 * 0.5 - var10;
            return var7 & (-16777216)
               | MathHelper.hsvToRgb(
                     (float)(var14 - Math.floor(var14)), 0.6499999761581421F, 1.0F
                  )
                  & (16777215);
         } else {
            double var12 = this.flow.get()
               ? 0.5
                  - 0.5
                     * Math.cos(6.283185307179586 * (var8 - var10))
               : var8;
            return ColorHelper.lerp((float)var12, var7, this.secondColor.argb());
         }
      }
   }

   private static double norm(double var0, double var2, double var4) {
      return var4 - var2 < 1e-06
         ? 0.5
         : (var0 - var2) / (var4 - var2);
   }

   private static Vec3d faceCentre(Box var0, Direction var1) {
      Vec3d var2 = var0.getCenter();

      return switch (var1) {
         case EAST-> new Vec3d(var0.maxX, var2.y, var2.z);
         case WEST-> new Vec3d(var0.minX, var2.y, var2.z);
         case UP-> new Vec3d(var2.x, var0.maxY, var2.z);
         case DOWN-> new Vec3d(var2.x, var0.minY, var2.z);
         case SOUTH-> new Vec3d(var2.x, var2.y, var0.maxZ);
         case NORTH-> new Vec3d(var2.x, var2.y, var0.minZ);
         default -> throw new MatchException(null, null);
      };
   }

   private static List<double[]> faceEdges(Box var0, Direction var1) {
      double[][] var10000;
      switch (var1.getAxis()) {
         case X:
            double var8 = var1 == Direction.EAST ? var0.maxX : var0.minX;
            var10000 = new double[4][];
            int var17 = 0;
            double[] var28 = new double[3];
            var28[0] = var8;
            var28[1] = var0.minY;
            var28[2] = var0.minZ;
            var10000[var17] = var28;
            var17 = 1;
            var28 = new double[3];
            var28[0] = var8;
            var28[1] = var0.maxY;
            var28[2] = var0.minZ;
            var10000[var17] = var28;
            var17 = 2;
            var28 = new double[3];
            var28[0] = var8;
            var28[1] = var0.maxY;
            var28[2] = var0.maxZ;
            var10000[var17] = var28;
            var17 = 3;
            var28 = new double[3];
            var28[0] = var8;
            var28[1] = var0.minY;
            var28[2] = var0.maxZ;
            var10000[var17] = var28;
            break;
         case Y:
            double var7 = var1 == Direction.UP ? var0.maxY : var0.minY;
            var10000 = new double[4][];
            int var13 = 0;
            double[] var24 = new double[3];
            var24[0] = var0.minX;
            var24[1] = var7;
            var24[2] = var0.minZ;
            var10000[var13] = var24;
            var13 = 1;
            var24 = new double[3];
            var24[0] = var0.maxX;
            var24[1] = var7;
            var24[2] = var0.minZ;
            var10000[var13] = var24;
            var13 = 2;
            var24 = new double[3];
            var24[0] = var0.maxX;
            var24[1] = var7;
            var24[2] = var0.maxZ;
            var10000[var13] = var24;
            var13 = 3;
            var24 = new double[3];
            var24[0] = var0.minX;
            var24[1] = var7;
            var24[2] = var0.maxZ;
            var10000[var13] = var24;
            break;
         case Z:
            double var3 = var1 == Direction.SOUTH ? var0.maxZ : var0.minZ;
            var10000 = new double[4][];
            int var10002 = 0;
            double[] var10003 = new double[3];
            var10003[0] = var0.minX;
            var10003[1] = var0.minY;
            var10003[2] = var3;
            var10000[var10002] = var10003;
            var10002 = 1;
            var10003 = new double[3];
            var10003[0] = var0.maxX;
            var10003[1] = var0.minY;
            var10003[2] = var3;
            var10000[var10002] = var10003;
            var10002 = 2;
            var10003 = new double[3];
            var10003[0] = var0.maxX;
            var10003[1] = var0.maxY;
            var10003[2] = var3;
            var10000[var10002] = var10003;
            var10002 = 3;
            var10003 = new double[3];
            var10003[0] = var0.minX;
            var10003[1] = var0.maxY;
            var10003[2] = var3;
            var10000[var10002] = var10003;
            break;
         default:
            throw new MatchException(null, null);
      }

      double[][] var2 = var10000;
      ArrayList var9 = new ArrayList(4);

      for (int var4 = 0; var4 < (4); var4++) {
         double[] var5 = var2[var4];
         double[] var6 = var2[(var4 + (1)) % (4)];
         double[] var10001 = new double[6];
         var10001[0] = var5[0];
         var10001[1] = var5[1];
         var10001[2] = var5[2];
         var10001[3] = var6[0];
         var10001[4] = var6[1];
         var10001[5] = var6[2];
         var9.add(var10001);
      }

      return var9;
   }

   private static Box lerp(Box var0, Box var1, float var2) {
      return new Box(
         MathHelper.lerp((double)var2, var0.minX, var1.minX),
         MathHelper.lerp((double)var2, var0.minY, var1.minY),
         MathHelper.lerp((double)var2, var0.minZ, var1.minZ),
         MathHelper.lerp((double)var2, var0.maxX, var1.maxX),
         MathHelper.lerp((double)var2, var0.maxY, var1.maxY),
         MathHelper.lerp((double)var2, var0.maxZ, var1.maxZ)
      );
   }

   private static double sq(double var0) {
      return var0 * var0;
   }
}
