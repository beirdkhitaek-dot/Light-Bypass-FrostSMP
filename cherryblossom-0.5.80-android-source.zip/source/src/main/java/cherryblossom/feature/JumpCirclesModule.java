package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.event.events.Render3DEvent;
import cherryblossom.module.Module;
import cherryblossom.module.Category;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.module.setting.BooleanSetting;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayDeque;
import java.util.List;

/** Local cosmetic effect: one two-ring seal for each grounded takeoff. */
public final class JumpCirclesModule extends Module {
    private final NumberSetting radius=new NumberSetting("Radius",.8,3,1.5,.1);
    private final NumberSetting duration=new NumberSetting("Duration",.4,3,1.4,.1);
    private final BooleanSetting rotate=new BooleanSetting("Rotate",true);
    private final ArrayDeque<Circle> circles=new ArrayDeque<>();
    private ClientWorld world;
    private Object player;
    private boolean grounded;
    private Vec3d lastPosition;
    private JumpCircleRenderer renderer;
    public JumpCirclesModule(){
        super("JumpCircles","Two expanding rings with CherryBlossom lettering when you jump.",-1,Category.RENDER);
        addSettings(radius,duration,rotate);
    }
    @Override public void onEnable(){reset();}
    @Override public void onDisable(){reset();if(renderer!=null){renderer.close();renderer=null;}}
    private void reset(){circles.clear();world=null;player=null;lastPosition=null;grounded=false;}
    @EventListener public void onTick(TickEvent event){
        if(mc.world==null||mc.player==null){reset();return;}
        if(world!=mc.world||player!=mc.player){
            reset();world=mc.world;player=mc.player;
            grounded=mc.player.isOnGround();lastPosition=mc.player.getEntityPos();return;
        }
        long now=world.getTime();
        circles.removeIf(c->now-c.born>=c.lifetime);
        boolean onGround=mc.player.isOnGround();
        if(grounded&&!onGround&&mc.player.getVelocity().y>.08&&!mc.player.getAbilities().flying
            &&!mc.player.isGliding()&&!mc.player.isTouchingWater()&&!mc.player.isClimbing()
            &&lastPosition!=null&&lastPosition.squaredDistanceTo(mc.player.getEntityPos())<4){
            if(circles.size()>=8)circles.removeFirst();
            circles.addLast(new Circle(lastPosition.add(0,.035,0),now,duration.getValue()*20,radius.getValue()));
        }
        grounded=onGround;lastPosition=mc.player.getEntityPos();
    }
    @EventListener public void onRender(Render3DEvent event){
        if(world==null||world!=mc.world||player!=mc.player||circles.isEmpty())return;
        if(renderer==null)renderer=new JumpCircleRenderer();
        renderer.render(event,List.copyOf(circles),world.getTime()+event.tickDelta,rotate.getValue());
    }
    record Circle(Vec3d position,long born,double lifetime,double radius){}
}
