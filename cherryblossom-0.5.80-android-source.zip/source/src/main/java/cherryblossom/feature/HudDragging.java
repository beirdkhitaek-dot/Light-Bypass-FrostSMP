package cherryblossom.feature;

import java.util.*;
import java.util.function.BiConsumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import cherryblossom.integration.TrialAccess;

/** Shared hit testing in framebuffer pixels for the additional HUD panels. */
public final class HudDragging {
    private record Area(float x,float y,float w,float h,long seen,BiConsumer<Float,Float> move) {}
    private static final Map<String,Area> areas=new LinkedHashMap<>();
    private static String grabbed;
    private static float dx,dy;
    private HudDragging(){}
    private static boolean editing(){var mc=MinecraftClient.getInstance();return TrialAccess.allowed()&&mc.world!=null&&!mc.options.hudHidden&&mc.currentScreen instanceof ChatScreen;}
    private static double mx(){var mc=MinecraftClient.getInstance();return mc.mouse.getX()*mc.getWindow().getFramebufferWidth()/Math.max(1,mc.getWindow().getWidth());}
    private static double my(){var mc=MinecraftClient.getInstance();return mc.mouse.getY()*mc.getWindow().getFramebufferHeight()/Math.max(1,mc.getWindow().getHeight());}
    public static float[] place(String id,float x,float y,float w,float h,BiConsumer<Float,Float> move){
        if(!editing()){finish();areas.clear();return new float[]{x,y};}
        var window=MinecraftClient.getInstance().getWindow();
        if(id.equals(grabbed)){
            x=(float)Math.max(0,Math.min(window.getFramebufferWidth()-w,mx()-dx));
            y=(float)Math.max(0,Math.min(window.getFramebufferHeight()-h,my()-dy));
            move.accept(x,y);
        }
        areas.put(id,new Area(x,y,w,h,System.nanoTime(),move));
        return new float[]{x,y};
    }
    public static boolean button(int button,int action){
        if(button!=0)return false;
        if(action==0){boolean used=grabbed!=null;finish();return used;}
        if(action!=1||!editing())return false;
        double x=mx(),y=my();long now=System.nanoTime();
        var entries=new ArrayList<>(areas.entrySet());Collections.reverse(entries);
        for(var e:entries){var a=e.getValue();if(now-a.seen<250_000_000L&&x>=a.x&&x<=a.x+a.w&&y>=a.y&&y<=a.y+a.h){grabbed=e.getKey();dx=(float)x-a.x;dy=(float)y-a.y;return true;}}
        return false;
    }
    private static void finish(){if(grabbed!=null){grabbed=null;cherryblossom.integration.CherryGui.saveSettings();}}
}
