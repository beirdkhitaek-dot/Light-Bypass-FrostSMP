package cherryblossom.feature;
import java.util.*;
/** One Windows media session shared by HUD controls and world lyrics. */
public final class SpotifyMedia {
    private static final SpotifyNowPlaying PLAYER=new SpotifyNowPlaying();
    private static final Set<Object> USERS=Collections.newSetFromMap(new IdentityHashMap<>());
    private SpotifyMedia(){}
    public static SpotifyNowPlaying shared(){return PLAYER;}
    public static synchronized void acquire(Object user){if(USERS.add(user)&&USERS.size()==1)PLAYER.start();}
    public static synchronized void release(Object user){if(USERS.remove(user)&&USERS.isEmpty())PLAYER.close();}
}
