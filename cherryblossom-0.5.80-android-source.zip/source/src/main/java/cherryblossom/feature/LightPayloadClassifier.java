package cherryblossom.feature;

import java.util.BitSet;
import java.util.List;
import net.minecraft.network.packet.s2c.play.LightData;

public final class LightPayloadClassifier {
   private static final int NIBBLES_PER_SECTION = 2048;

   private LightPayloadClassifier() {}

   public static SkyLightPattern classifyPayload(byte[] data) {
      if (data == null || data.length != NIBBLES_PER_SECTION) {
         return SkyLightPattern.UNKNOWN;
      }
      boolean allZero = true;
      boolean allFull = true;
      for (byte value : data) {
         if (value != 0) {
            allZero = false;
         }
         if (value != -1) {
            allFull = false;
         }
         if (!allZero && !allFull) {
            return SkyLightPattern.NORMAL;
         }
      }
      return allZero ? SkyLightPattern.ZEROED_PRESENT : SkyLightPattern.UNIFORM_MAX;
   }

   public static void apply(LightData data, ChunkLightSnapshot snapshot, long stamp) {
      applyTrack(data.getInitedBlock(), data.getUninitedBlock(), data.getBlockNibbles(),
         snapshot.block, snapshot.blockUpdated, stamp);
      applyTrack(data.getInitedSky(), data.getUninitedSky(), data.getSkyNibbles(),
         snapshot.sky, snapshot.skyUpdated, stamp);
   }

   private static void applyTrack(BitSet initialized, BitSet uninitialized, List<byte[]> payloads,
                                  SkyLightPattern[] output, long[] updated, long stamp) {
      int payloadIndex = 0;
      for (int section = 0; section < output.length; section++) {
         if (initialized.get(section)) {
            byte[] payload = payloadIndex < payloads.size() ? payloads.get(payloadIndex) : null;
            payloadIndex++;
            output[section] = classifyPayload(payload);
            updated[section] = stamp;
         } else if (uninitialized.get(section)) {
            output[section] = SkyLightPattern.EMPTY_MASK;
            updated[section] = stamp;
         }
      }
   }
}
