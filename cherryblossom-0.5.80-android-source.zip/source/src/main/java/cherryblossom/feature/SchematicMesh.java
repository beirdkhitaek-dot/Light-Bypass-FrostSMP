package cherryblossom.feature;

import cherryblossom.mixin.RenderPipelinesAccessor;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EmptyBlockView;

/** Whole-schematic surface geometry, prepared off-thread and uploaded in bounded sections. */
final class SchematicMesh implements AutoCloseable {
    record Cell(int local,int faces,int color){}
    record Part(BlockPos origin,List<Cell> cells,int faces){}
    record Data(List<Part> parts,int blocks){}
    private static final RenderPipeline PIPELINE=RenderPipeline.builder(RenderPipelinesAccessor.cherryblossom$getTransformsSnippet())
        .withLocation(Identifier.of("cherryblossom","pipeline/schematic_cached"))
        .withVertexShader("core/position_color").withFragmentShader("core/position_color")
        .withBlend(BlendFunction.TRANSLUCENT).withCull(false).withDepthWrite(false)
        .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
        .withVertexFormat(VertexFormats.POSITION_COLOR,DrawMode.QUADS).build();
    private static final Direction[] DIRECTIONS=Direction.values();
    private static final class Section {
        final Part part;final BitSet placed=new BitSet(4096);
        GpuQuadMesh full,remaining;boolean dirty;long updated;
        Section(Part part){this.part=part;}
    }
    private final List<Section> sections=new ArrayList<>();
    private final Map<Long,Section> bySection=new HashMap<>();
    private int blocks,uploadCursor;
    static Data prepare(Map<BlockPos,BlockState> states){
        Map<Long,List<Cell>> grouped=new LinkedHashMap<>();Map<Long,BlockPos> origins=new HashMap<>();
        Map<BlockState,Integer> colors=new HashMap<>();Map<BlockState,Boolean> fullCubes=new HashMap<>();int checked=0;
        for(var entry:states.entrySet()){
            if((++checked&1023)==0&&Thread.currentThread().isInterrupted())throw new java.util.concurrent.CancellationException();
            BlockPos pos=entry.getKey();int mask=0;
            for(int face=0;face<DIRECTIONS.length;face++){BlockState neighbor=states.get(pos.offset(DIRECTIONS[face]));if(neighbor==null||!fullCubes.computeIfAbsent(neighbor,state->state.isFullCube(EmptyBlockView.INSTANCE,BlockPos.ORIGIN)))mask|=1<<face;}
            // Partial models need their own surface even if surrounded by schematic cells.
            if(!entry.getValue().isFullCube(EmptyBlockView.INSTANCE,BlockPos.ORIGIN))mask=63;
            int color=colors.computeIfAbsent(entry.getValue(),state->{int rgb=state.getMapColor(EmptyBlockView.INSTANCE,BlockPos.ORIGIN).color;return 0xFF000000|(rgb==0?0xF0A7C6:rgb);});
            long section=key(pos);origins.putIfAbsent(section,new BlockPos(pos.getX()&~15,pos.getY()&~15,pos.getZ()&~15));
            grouped.computeIfAbsent(section,k->new ArrayList<>()).add(new Cell(local(pos),mask,color));
        }
        List<Part> parts=new ArrayList<>();for(var entry:grouped.entrySet()){
            int faces=entry.getValue().stream().mapToInt(c->Integer.bitCount(c.faces())).sum();
            parts.add(new Part(origins.get(entry.getKey()),List.copyOf(entry.getValue()),faces));
        }
        return new Data(List.copyOf(parts),states.size());
    }
    void install(Data data){close();blocks=data.blocks();for(Part part:data.parts()){Section section=new Section(part);sections.add(section);bySection.put(key(part.origin()),section);}}
    int blockCount(){return blocks;}
    int uploaded(boolean full){return (int)sections.stream().filter(s->full?s.full!=null:s.remaining!=null).count();}
    int sectionCount(){return sections.size();}
    void placed(BlockPos pos,boolean placed){Section section=bySection.get(key(pos));if(section==null)return;int local=local(pos);if(section.placed.get(local)!=placed){section.placed.set(local,placed);section.dirty=true;for(Direction d:DIRECTIONS){Section neighbor=bySection.get(key(pos.offset(d)));if(neighbor!=null)neighbor.dirty=true;}}}
    private static int local(BlockPos pos){return (pos.getX()&15)|((pos.getY()&15)<<4)|((pos.getZ()&15)<<8);}
    private static long key(BlockPos pos){return BlockPos.asLong(pos.getX()>>4,pos.getY()>>4,pos.getZ()>>4);}
    void draw(MatrixStack matrices,Vec3d camera,boolean full){
        if(sections.isEmpty())return;
        long now=System.nanoTime(),deadline=now+2_000_000L;int uploaded=0;
        int start=uploadCursor;
        for(int i=0;i<sections.size();i++){
            int index=(start+i)%sections.size();Section section=sections.get(index);
            boolean needed=full?section.full==null:section.remaining==null||section.dirty&&now-section.updated>200_000_000L;
            if(needed){build(section,full);uploaded++;uploadCursor=(index+1)%sections.size();if(uploaded>=2||System.nanoTime()>deadline)break;}
        }
        // Every uploaded section can draw; there is no block-count or distance cutoff.
        for(Section section:sections){GpuQuadMesh mesh=full?section.full:section.remaining;if(mesh==null)continue;
            matrices.push();try{matrices.translate(section.part.origin().getX()-camera.x,section.part.origin().getY()-camera.y,section.part.origin().getZ()-camera.z);mesh.draw(matrices,full?.92f:.38f);}finally{matrices.pop();}
        }
    }
    private void build(Section section,boolean full){
        GpuQuadMesh old=full?section.full:section.remaining;if(old!=null)old.close();
        GpuQuadMesh mesh=new GpuQuadMesh("CherryBlossom schematic section",PIPELINE,Math.max(1,full?section.part.faces():section.part.cells().size()*6));
        BufferBuilder out=mesh.begin();
        for(Cell cell:section.part.cells()){
            if(!full&&section.placed.get(cell.local()))continue;
            float x=cell.local()&15,y=(cell.local()>>4)&15,z=(cell.local()>>8)&15;
            int mask=cell.faces();
            if(!full)for(int face=0;face<DIRECTIONS.length;face++){
                BlockPos neighbor=section.part.origin().add((int)x,(int)y,(int)z).offset(DIRECTIONS[face]);Section other=bySection.get(key(neighbor));
                if(other!=null&&other.placed.get(local(neighbor)))mask|=1<<face;
            }
            for(int face=0;face<DIRECTIONS.length;face++)if((mask&(1<<face))!=0)face(out,x,y,z,DIRECTIONS[face],cell.color());
        }
        mesh.upload(out);if(full)section.full=mesh;else{section.remaining=mesh;section.dirty=false;section.updated=System.nanoTime();}
    }
    private static void quad(BufferBuilder out,int color,float... v){for(int i=0;i<12;i+=3)out.vertex(v[i],v[i+1],v[i+2]).color(color);}
    private static void face(BufferBuilder out,float x,float y,float z,Direction side,int color){
        float s=side==Direction.UP?1:side==Direction.DOWN?.55f:side.getAxis()==Direction.Axis.X?.75f:.88f;
        int rgb=0xFF000000|Math.round((color>>16&255)*s)<<16|Math.round((color>>8&255)*s)<<8|Math.round((color&255)*s);
        float a=x+.004f,b=y+.004f,c=z+.004f,d=x+.996f,e=y+.996f,f=z+.996f;
        switch(side){
            case DOWN->quad(out,rgb,a,b,c,d,b,c,d,b,f,a,b,f);
            case UP->quad(out,rgb,a,e,c,a,e,f,d,e,f,d,e,c);
            case NORTH->quad(out,rgb,a,b,c,a,e,c,d,e,c,d,b,c);
            case SOUTH->quad(out,rgb,a,b,f,d,b,f,d,e,f,a,e,f);
            case WEST->quad(out,rgb,a,b,c,a,b,f,a,e,f,a,e,c);
            case EAST->quad(out,rgb,d,b,c,d,e,c,d,e,f,d,b,f);
        }
    }
    @Override public void close(){for(Section section:sections){if(section.full!=null)section.full.close();if(section.remaining!=null)section.remaining.close();}sections.clear();bySection.clear();blocks=0;uploadCursor=0;}
}
