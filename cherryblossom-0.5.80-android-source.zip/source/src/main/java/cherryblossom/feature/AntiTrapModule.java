package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.TickEvent;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.Box;

public final class AntiTrapModule extends Module {
   public AntiTrapModule() {
      super(
         EncryptedString.of("Anti Trap"),
         EncryptedString.of("Clears nearby armor stands and chest minecarts blocking your movement"),
         -1,
         Category.DONUT
      );
   }

   @Override
   public void onEnable() {
      this.clearBlockingEntities();
      super.onEnable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      this.clearBlockingEntities();
   }

   private void clearBlockingEntities() {
      ClientPlayerEntity player = this.mc.player;
      ClientWorld world = this.mc.world;
      if (player == null || world == null) {
         return;
      }

      Box nearby = player.getBoundingBox().expand(0.35);
      for (Entity entity : world.getOtherEntities(player, nearby,
         candidate -> isTrapEntity(candidate) && candidate.getBoundingBox().intersects(nearby))) {
         if (!entity.isRemoved()) {
            entity.remove(Entity.RemovalReason.DISCARDED);
         }
      }
   }

   private static boolean isTrapEntity(Entity entity) {
      return entity != null && (entity.getType() == EntityType.ARMOR_STAND
         || entity.getType() == EntityType.CHEST_MINECART);
   }
}
