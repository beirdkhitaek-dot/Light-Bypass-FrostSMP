package cherryblossom.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;

@Environment(EnvType.CLIENT)
final class AuroraMeshRenderer {
   private static final float RADIUS = 100.0F;
   private static final int COLUMNS = 64;
   private static final int ROWS = 6;
   private static final float[][] CURTAINS;
   private final GpuQuadMesh mesh;
   private final float[] x;
   private final float[] y;
   private final float[] z;
   private final int[] color;

   AuroraMeshRenderer() {
      this.mesh = new GpuQuadMesh(
         "CherryBlossom aurora",
         GpuQuadMesh.GLOW,
         CURTAINS.length * (64) * (6)
      );
      this.x = new float[455];
      this.y = new float[this.x.length];
      this.z = new float[this.x.length];
      this.color = new int[this.x.length];
   }

   void render(MatrixStack var1, float var2, float var3, int var4, int var5) {
      BufferBuilder var6 = this.mesh.begin();

      for (int var7 = 0; var7 < CURTAINS.length; var7++) {
         this.curtain(var6, CURTAINS[var7], var7, var3, var4, var5);
      }

      this.mesh.upload(var6);
      this.mesh.draw(var1, var2);
   }

   private void curtain(BufferBuilder var1, float[] var2, int var3, float var4, int var5, int var6) {
      float var7 = var2[0];
      float var8 = var2[1];
      float var9 = var2[2];
      float var10 = var2[3];

      for (int var11 = 0; var11 <= (64); var11++) {
         float var12 = (float)var11 / 64.0F;
         float var13 = var7
            + (var12 - 0.5F) * var9
            + 3.0F
               * wave(var12 * 2.0999999046325684F + var4 * 0.05000000074505806F + (float)var3);
         float var14 = var8
            + 5.0F * MathHelper.sin((double)(3.1415927410125732F * var12))
            + 3.0F
               * wave(
                  var12 * 3.700000047683716F
                     - var4 * 0.07000000029802322F
                     + (float)var3 * 2.0F
               );
         float var15 = smoothstep(var12 / 0.25F)
            * smoothstep((1.0F - var12) / 0.25F);
         float var16 = var15
            * (
               0.550000011920929F
                  + 0.44999998807907104F
                     * wave01(
                        var12 * 5.300000190734863F
                           + var4 * 0.10999999940395355F
                           + (float)var3 * 1.2999999523162842F
                     )
            );
         float var17 = 0.7200000286102295F
            + 0.2800000011920929F
               * wave01(var12 * 23.0F + var4 * 0.3499999940395355F + (float)var3);
         float var18 = var10
            * (
               0.800000011920929F
                  + 0.3499999940395355F
                     * wave01(
                        var12 * 4.099999904632568F
                           + var4 * 0.05999999865889549F
                           + (float)var3 * 3.0F
                     )
            );
         float var19 = MathHelper.cos((double)(var13 * 0.01745329238474369F));
         float var20 = MathHelper.sin((double)(var13 * 0.01745329238474369F));

         for (int var21 = 0; var21 <= (6); var21++) {
            float var22 = (float)var21 / 6.0F;
            float var23 = (var14 + var22 * var18) * 0.01745329238474369F;
            float var24 = MathHelper.cos((double)var23);
            int var25 = var11 * (7) + var21;
            this.x[var25] = 100.0F * var24 * var20;
            this.y[var25] = 100.0F * MathHelper.sin((double)var23);
            this.z[var25] = -100.0F * var24 * var19;
            float var26 = var22 < 0.11999999731779099F
               ? smoothstep(var22 / 0.11999999731779099F)
               : (float)Math.pow(
                  (double)(
                     1.0F
                        - (var22 - 0.11999999731779099F) / 0.8799999952316284F
                  ),
                  1.5
               );
            float var27 = MathHelper.clamp(
               var16 * var17 * var26 * 0.800000011920929F,
               0.0F,
               1.0F
            );
            int var28 = ColorHelper.lerp((float)Math.pow((double)var22, 0.7), var5, var6)
               & (16777215);
            this.color[var25] = Math.round(var27 * 255.0F) << (24) | var28;
         }
      }

      for (int var29 = 0; var29 < (64); var29++) {
         for (int var30 = 0; var30 < (6); var30++) {
            int var31 = var29 * (7) + var30;
            int var32 = (var29 + (1)) * (7) + var30;
            this.vertex(var1, var31);
            this.vertex(var1, var32);
            this.vertex(var1, var32 + (1));
            this.vertex(var1, var31 + (1));
         }
      }
   }

   private void vertex(BufferBuilder var1, int var2) {
      GpuQuadMesh.vertex(var1, this.x[var2], this.y[var2], this.z[var2], this.color[var2]);
   }

   static float wave(float var0) {
      return 0.5F * MathHelper.sin((double)var0)
         + 0.30000001192092896F
            * MathHelper.sin((double)(var0 * 2.130000114440918F + 1.2999999523162842F))
         + 0.20000000298023224F
            * MathHelper.sin((double)(var0 * 4.369999885559082F + 2.9000000953674316F));
   }

   static float wave01(float var0) {
      return 0.5F + 0.5F * wave(var0);
   }

   static float smoothstep(float var0) {
      var0 = MathHelper.clamp(var0, 0.0F, 1.0F);
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   void close() {
      this.mesh.close();
   }

   static {
      float[][] var10000 = new float[3][];
      int var10002 = 0;
      float[] var10003 = new float[4];
      var10003[0] = -40.0F;
      var10003[1] = 22.0F;
      var10003[2] = 78.0F;
      var10003[3] = 18.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[4];
      var10003[0] = 6.0F;
      var10003[1] = 28.0F;
      var10003[2] = 100.0F;
      var10003[3] = 23.0F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[4];
      var10003[0] = 54.0F;
      var10003[1] = 20.0F;
      var10003[2] = 70.0F;
      var10003[3] = 16.0F;
      var10000[var10002] = var10003;
      CURTAINS = var10000;
   }
}
