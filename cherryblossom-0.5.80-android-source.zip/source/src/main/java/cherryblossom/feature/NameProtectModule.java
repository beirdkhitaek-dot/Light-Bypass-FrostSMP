package cherryblossom.feature;

import cherryblossom.CherryBlossom;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.ModuleManager;
import cherryblossom.module.setting.StringSetting;
import cherryblossom.utils.EncryptedString;

public class NameProtectModule extends Module {
   private final StringSetting fakeName;

   public NameProtectModule() {
      super(
         EncryptedString.of("Name Protect"),
         EncryptedString.of("Replaces your name with given one."),
         -1,
         Category.MISC
      );
      this.fakeName = new StringSetting("Fake Name", "Player");
      this.addSettings(this.fakeName);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   public String getFakeName() {
      String value = this.fakeName.getValue();
      return value != null && !value.isBlank() ? value.trim() : "Player";
   }

   public static String displayName(String original) {
      if (original == null || original.isEmpty()) {
         return "";
      }
      CherryBlossom client = CherryBlossom.INSTANCE;
      if (client == null) {
         return original;
      }
      ModuleManager modules = client.getModuleManager();
      if (modules == null) {
         return original;
      }
      NameProtectModule nameProtect = (NameProtectModule)modules.getModuleByClass(NameProtectModule.class);
      return nameProtect != null && nameProtect.isEnabled() ? nameProtect.getFakeName() : original;
   }
}
