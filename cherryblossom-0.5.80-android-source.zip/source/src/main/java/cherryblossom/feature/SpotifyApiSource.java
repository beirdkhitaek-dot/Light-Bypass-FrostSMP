package cherryblossom.feature;

import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Base64;
import java.util.function.Consumer;

/**
 * Spotify Web API now-playing source for platforms without a Windows media session (Android/Zalith, Linux, macOS).
 * Uses the OAuth PKCE flow, so no client secret is needed. Only Spotify's own endpoints are contacted.
 *
 * Setup: create an app at developer.spotify.com, add the redirect URI {@link #REDIRECT}, and put its Client ID in
 * config/cherryblossom/spotify/spotify-api.json as {"client_id":"..."}.
 */
public final class SpotifyApiSource implements AutoCloseable {
    public static final int PORT=8888;
    public static final String REDIRECT="http://127.0.0.1:"+PORT+"/callback";
    private static final String SCOPES="user-read-playback-state user-modify-playback-state user-read-currently-playing";
    private static final HttpClient HTTP=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NEVER).build();
    private static final SecureRandom RANDOM=new SecureRandom();

    /** One poll result. status: ready, idle, needs_client_id, needs_login, unavailable. */
    public record Snapshot(String status,String title,String artist,boolean playing,long positionMs,long durationMs,String artUrl){
        static Snapshot of(String status){return new Snapshot(status,"","",false,0,0,"");}
    }

    private final Path config;
    private final Consumer<String> userMessage;
    private String clientId="",refreshToken="",accessToken="";
    private long accessExpiresAt,backoffUntil;
    private volatile boolean authRunning,closed;
    private volatile ServerSocket authServer;
    private String artUrl="";
    private byte[] artBytes;

    public SpotifyApiSource(Path configFile,Consumer<String> userMessage){this.config=configFile;this.userMessage=userMessage;load();}

    // ---- config ----
    private void load(){
        try{
            if(!Files.exists(config)){
                Files.createDirectories(config.getParent());
                Files.writeString(config,"{\n  \"client_id\": \"\"\n}\n",StandardCharsets.UTF_8);return;
            }
            if(Files.size(config)>16384)return;
            JsonObject o=JsonParser.parseString(Files.readString(config)).getAsJsonObject();
            clientId=str(o,"client_id").trim();refreshToken=str(o,"refresh_token").trim();
        }catch(Exception ignored){}
    }
    private void save(){
        try{
            JsonObject o=new JsonObject();o.addProperty("client_id",clientId);if(!refreshToken.isEmpty())o.addProperty("refresh_token",refreshToken);
            Path temp=Files.createTempFile(config.getParent(),"spotify-",".tmp");
            try{
                Files.writeString(temp,new GsonBuilder().setPrettyPrinting().create().toJson(o),StandardCharsets.UTF_8);
                File f=temp.toFile();f.setReadable(false,false);f.setReadable(true,true);f.setWritable(false,false);f.setWritable(true,true);
                try{Files.move(temp,config,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,config,StandardCopyOption.REPLACE_EXISTING);}
            }finally{Files.deleteIfExists(temp);}
        }catch(IOException ignored){}
    }
    private static String str(JsonObject o,String k){return o.has(k)&&!o.get(k).isJsonNull()?o.get(k).getAsString():"";}

    // ---- polling ----
    public Snapshot poll(){
        try{
            if(System.currentTimeMillis()<backoffUntil)return Snapshot.of("unavailable");
            if(clientId.isEmpty()){load();if(clientId.isEmpty())return Snapshot.of("needs_client_id");}
            if(refreshToken.isEmpty()){startAuth();return Snapshot.of("needs_login");}
            if(!ensureToken())return refreshToken.isEmpty()?Snapshot.of("needs_login"):Snapshot.of("unavailable");
            HttpResponse<String> r=api("GET","/v1/me/player/currently-playing?additional_types=episode");
            if(r.statusCode()==401){accessToken="";if(!ensureToken())return Snapshot.of("unavailable");r=api("GET","/v1/me/player/currently-playing?additional_types=episode");}
            if(r.statusCode()==429){backoffUntil=System.currentTimeMillis()+retryAfter(r);return Snapshot.of("unavailable");}
            if(r.statusCode()==204||r.body().isBlank())return Snapshot.of("idle");
            if(r.statusCode()!=200)return Snapshot.of("unavailable");
            JsonObject o=JsonParser.parseString(r.body()).getAsJsonObject();
            if(!o.has("item")||o.get("item").isJsonNull())return Snapshot.of("idle");
            JsonObject item=o.getAsJsonObject("item");
            String artist="";
            if(item.has("artists")&&item.get("artists").isJsonArray()){
                StringBuilder sb=new StringBuilder();
                for(JsonElement a:item.getAsJsonArray("artists")){if(sb.length()>0)sb.append(", ");sb.append(str(a.getAsJsonObject(),"name"));}
                artist=sb.toString();
            }else if(item.has("show")&&item.get("show").isJsonObject())artist=str(item.getAsJsonObject("show"),"name");
            String art="";
            JsonObject album=item.has("album")&&item.get("album").isJsonObject()?item.getAsJsonObject("album"):item.has("images")?item:null;
            if(album!=null&&album.has("images")&&album.get("images").isJsonArray()&&album.getAsJsonArray("images").size()>0){
                // prefer the smallest image that is still >= 128px
                long best=Long.MAX_VALUE;
                for(JsonElement e:album.getAsJsonArray("images")){
                    JsonObject im=e.getAsJsonObject();long w=im.has("width")&&!im.get("width").isJsonNull()?im.get("width").getAsLong():0;
                    if(w>=128&&w<best){best=w;art=str(im,"url");}
                }
                if(art.isEmpty())art=str(album.getAsJsonArray("images").get(0).getAsJsonObject(),"url");
            }
            return new Snapshot("ready",clean(str(item,"name")),clean(artist),o.has("is_playing")&&o.get("is_playing").getAsBoolean(),
                o.has("progress_ms")&&!o.get("progress_ms").isJsonNull()?o.get("progress_ms").getAsLong():0,
                item.has("duration_ms")?item.get("duration_ms").getAsLong():0,art);
        }catch(Exception e){return Snapshot.of("unavailable");}
    }
    private static String clean(String s){s=s.replaceAll("[\\p{Cntrl}]"," ").trim();return s.substring(0,Math.min(256,s.length()));}
    private static long retryAfter(HttpResponse<?> r){
        try{return Math.max(1,Math.min(120,Long.parseLong(r.headers().firstValue("Retry-After").orElse("5"))))*1000;}catch(NumberFormatException e){return 5000;}
    }

    /** Cover art as base64 (same format the Windows helper emits), cached per URL. Only Spotify's CDN is contacted. */
    public String artworkBase64(String url){
        try{
            if(url.isEmpty())return "";
            if(!url.equals(artUrl)){
                URI uri=URI.create(url);String host=uri.getHost()==null?"":uri.getHost().toLowerCase();
                if(!"https".equals(uri.getScheme())||!(host.endsWith(".scdn.co")||host.endsWith(".spotifycdn.com")))return "";
                HttpResponse<InputStream> r=HTTP.send(HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(10)).GET().build(),HttpResponse.BodyHandlers.ofInputStream());
                try(InputStream in=r.body()){
                    byte[] b=in.readNBytes(2_000_001);
                    artUrl=url;artBytes=r.statusCode()==200&&b.length<=2_000_000?b:null;
                }
            }
            return artBytes==null?"":Base64.getEncoder().encodeToString(artBytes);
        }catch(Exception e){return "";}
    }

    // ---- controls ----
    public void send(String command){
        try{
            if(!ensureToken())return;
            String method,path;
            switch(command){
                case "play"->{method="PUT";path="/v1/me/player/play";}
                case "pause"->{method="PUT";path="/v1/me/player/pause";}
                case "next"->{method="POST";path="/v1/me/player/next";}
                case "previous"->{method="POST";path="/v1/me/player/previous";}
                default->{return;}
            }
            HttpResponse<String> r=api(method,path);
            if(r.statusCode()==401){accessToken="";if(ensureToken())api(method,path);}
        }catch(Exception ignored){}
    }

    // ---- HTTP / tokens ----
    private HttpResponse<String> api(String method,String path)throws Exception{
        HttpRequest.Builder b=HttpRequest.newBuilder(URI.create("https://api.spotify.com"+path)).timeout(Duration.ofSeconds(10)).header("Authorization","Bearer "+accessToken);
        b.method(method,HttpRequest.BodyPublishers.noBody());
        return HTTP.send(b.build(),HttpResponse.BodyHandlers.ofString());
    }
    private boolean ensureToken()throws Exception{
        if(!accessToken.isEmpty()&&System.currentTimeMillis()<accessExpiresAt-30_000)return true;
        if(refreshToken.isEmpty()||clientId.isEmpty())return false;
        JsonObject o=tokenRequest("grant_type=refresh_token&refresh_token="+enc(refreshToken)+"&client_id="+enc(clientId));
        if(o==null)return false;
        if(o.has("error")){
            if("invalid_grant".equals(str(o,"error"))){refreshToken="";save();} // revoked: log in again
            return false;
        }
        applyToken(o);return !accessToken.isEmpty();
    }
    private void applyToken(JsonObject o){
        accessToken=str(o,"access_token");
        accessExpiresAt=System.currentTimeMillis()+(o.has("expires_in")?o.get("expires_in").getAsLong():3600)*1000;
        String rt=str(o,"refresh_token");if(!rt.isEmpty()&&!rt.equals(refreshToken)){refreshToken=rt;save();}
    }
    private static JsonObject tokenRequest(String form)throws Exception{
        HttpResponse<String> r=HTTP.send(HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token")).timeout(Duration.ofSeconds(10))
            .header("Content-Type","application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(form)).build(),HttpResponse.BodyHandlers.ofString());
        if(r.statusCode()>=500||r.statusCode()==429)return null;
        return JsonParser.parseString(r.body()).getAsJsonObject();
    }
    private static String enc(String s){return URLEncoder.encode(s,StandardCharsets.UTF_8);}

    // ---- one-time PKCE login via a loopback listener on this device ----
    private synchronized void startAuth(){
        if(authRunning||closed)return;
        authRunning=true;
        String verifier=random(64),state=random(24);
        String challenge;
        try{challenge=Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));}
        catch(Exception e){authRunning=false;return;}
        String url="https://accounts.spotify.com/authorize?response_type=code&client_id="+enc(clientId)+"&redirect_uri="+enc(REDIRECT)
            +"&scope="+enc(SCOPES)+"&state="+state+"&code_challenge_method=S256&code_challenge="+challenge;
        Thread t=new Thread(()->{
            try(ServerSocket server=new ServerSocket(PORT,1,InetAddress.getByAddress(new byte[]{127,0,0,1}))){
                authServer=server;server.setSoTimeout(1000);
                userMessage.accept(url);
                long end=System.currentTimeMillis()+5*60_000L;
                while(!closed&&System.currentTimeMillis()<end){
                    Socket s;try{s=server.accept();}catch(SocketTimeoutException e){continue;}
                    try(s){if(handle(s,state,verifier))break;}catch(Exception ignored){}
                }
            }catch(IOException e){userMessage.accept("Spotify login could not start (port "+PORT+" busy?)");}
            finally{authServer=null;authRunning=false;}
        },"CherryBlossom Spotify login");
        t.setDaemon(true);t.start();
    }
    private boolean handle(Socket s,String state,String verifier)throws Exception{
        s.setSoTimeout(5000);
        BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.US_ASCII));
        String line=in.readLine();if(line==null||line.length()>4096)return false;
        String[] parts=line.split(" ");
        if(parts.length<2||!parts[0].equals("GET")||!parts[1].startsWith("/callback"))return reply(s,404,"Not found",false);
        String query=parts[1].contains("?")?parts[1].substring(parts[1].indexOf('?')+1):"";
        String code="",got="",error="";
        for(String kv:query.split("&")){
            int i=kv.indexOf('=');if(i<0)continue;
            String k=kv.substring(0,i),v=URLDecoder.decode(kv.substring(i+1),StandardCharsets.UTF_8);
            if(k.equals("code"))code=v;else if(k.equals("state"))got=v;else if(k.equals("error"))error=v;
        }
        if(!MessageDigest.isEqual(got.getBytes(StandardCharsets.UTF_8),state.getBytes(StandardCharsets.UTF_8)))return reply(s,400,"State mismatch. Try again from Minecraft.",false);
        if(!error.isEmpty()||code.isEmpty())return reply(s,400,"Spotify login was cancelled.",true);
        JsonObject o=tokenRequest("grant_type=authorization_code&code="+enc(code)+"&redirect_uri="+enc(REDIRECT)+"&client_id="+enc(clientId)+"&code_verifier="+enc(verifier));
        if(o==null||o.has("error")||str(o,"refresh_token").isEmpty())return reply(s,400,"Token exchange failed. Check the Client ID and redirect URI.",true);
        applyToken(o);
        userMessage.accept("Spotify connected.");
        return reply(s,200,"Spotify connected. You can return to Minecraft.",true);
    }
    private static boolean reply(Socket s,int code,String text,boolean done)throws IOException{
        byte[] body=("<!doctype html><meta name=viewport content='width=device-width'><body style='font-family:sans-serif;padding:2em'>"+text.replace("<","&lt;")+"</body>").getBytes(StandardCharsets.UTF_8);
        s.getOutputStream().write(("HTTP/1.1 "+code+" X\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: "+body.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
        s.getOutputStream().write(body);s.getOutputStream().flush();return done;
    }
    private static String random(int n){
        String a="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";StringBuilder sb=new StringBuilder();
        for(int i=0;i<n;i++)sb.append(a.charAt(RANDOM.nextInt(a.length())));return sb.toString();
    }

    @Override public void close(){
        closed=true;ServerSocket s=authServer;if(s!=null)try{s.close();}catch(IOException ignored){}
    }
}
