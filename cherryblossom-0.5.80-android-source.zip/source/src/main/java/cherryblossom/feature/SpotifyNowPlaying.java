package cherryblossom.feature;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Locale;
import java.util.concurrent.*;
import net.fabricmc.loader.api.FabricLoader;

/** Windows media-session bridge. File/IPC/image decoding work stays off the render thread. */
public final class SpotifyNowPlaying implements AutoCloseable {
    public record Track(String title,String artist,boolean playing,long positionMs,long durationMs,long receivedNanos,String status,UiTextureData artwork){
        public Track(String title,String artist,boolean playing,long positionMs,long durationMs,long receivedNanos,String status){this(title,artist,playing,positionMs,durationMs,receivedNanos,status,null);}
        public boolean present(){return "ready".equals(status)&&!title.isBlank();}
        public long positionAt(long now){
            long elapsed=playing?Math.max(0,now-receivedNanos)/1_000_000:0;
            long position=positionMs+elapsed;
            return durationMs>0?Math.min(durationMs,position):position;
        }
    }
    private static Track empty(String status){return new Track("","",false,0,0,System.nanoTime(),status);}
    private volatile Track track=empty("idle");
    private record Pending(Track display,long started){}
    private volatile Pending pending;
    private volatile Run run;
    private static final class Run {
        volatile boolean active=true;
        volatile Process process;
        volatile long received=System.nanoTime();
        long retry;
        volatile Path commands;
        volatile SpotifyApiSource api; // non-Windows: Spotify Web API instead of the PowerShell media-session helper
        String artData="";
        UiTextureData artwork;
        final ScheduledExecutorService executor=Executors.newSingleThreadScheduledExecutor(task->{Thread t=new Thread(task,"CherryBlossom Spotify monitor");t.setDaemon(true);return t;});
    }
    public Track current(){
        Track actual=track;Pending request=pending;
        if(request==null)return actual;
        Track display=request.display();
        if(!actual.present()||!actual.title().equals(display.title())||!actual.artist().equals(display.artist())
                ||System.nanoTime()-request.started()>3_000_000_000L
                ||actual.receivedNanos()>request.started()&&actual.playing()==display.playing()){
            if(pending==request)pending=null;
            return actual;
        }
        return new Track(actual.title(),actual.artist(),display.playing(),display.positionMs(),actual.durationMs(),display.receivedNanos(),actual.status(),actual.artwork());
    }
    public enum Control { PREVIOUS, TOGGLE, NEXT }
    public static String commandFor(Control control,Track track){return control==Control.TOGGLE?(track.playing()?"pause":"play"):control.name().toLowerCase(Locale.ROOT);}
    public void control(Control control){
        Run current=run;Track shown=current();if(current==null||!current.active||!shown.present())return;
        String command=commandFor(control,shown);
        long now=System.nanoTime();
        Pending request=control==Control.TOGGLE?new Pending(new Track(shown.title(),shown.artist(),!shown.playing(),shown.positionAt(now),shown.durationMs(),now,shown.status(),shown.artwork()),now):null;
        pending=request;
        try{current.executor.execute(()->{
            SpotifyApiSource api=current.api;
            if(api!=null){if(current.active)api.send(command);return;}
            if(!current.active||current.commands==null){if(pending==request)pending=null;return;}
            try{
                Path temp=Files.createTempFile(current.commands,"pending-",".tmp");
                Files.writeString(temp,command,StandardCharsets.US_ASCII);
                Files.move(temp,current.commands.resolve(String.format(Locale.ROOT,"%020d",System.nanoTime())+".cmd"),StandardCopyOption.ATOMIC_MOVE);
            }catch(IOException ignored){if(pending==request)pending=null;}
        });}catch(RejectedExecutionException ignored){if(pending==request)pending=null;}
    }
    static UiTextureData decodeArtwork(String encoded){
        if(encoded.isEmpty()||encoded.length()>2_800_000)return null;
        try(var input=javax.imageio.ImageIO.createImageInputStream(new ByteArrayInputStream(java.util.Base64.getDecoder().decode(encoded)))){
            var readers=javax.imageio.ImageIO.getImageReaders(input);if(!readers.hasNext())return null;
            var reader=readers.next();try{
                reader.setInput(input);int w=reader.getWidth(0),h=reader.getHeight(0);if(w<1||h<1||w>4096||h>4096)return null;
                var image=reader.read(0);var resized=new java.awt.image.BufferedImage(128,128,java.awt.image.BufferedImage.TYPE_INT_ARGB);
                var g=resized.createGraphics();try{g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);int edge=Math.min(w,h);g.drawImage(image,0,0,128,128,(w-edge)/2,(h-edge)/2,(w+edge)/2,(h+edge)/2,null);}finally{g.dispose();}
                return new UiTextureData("spotify/cover",128,128,resized.getRGB(0,0,128,128,null,0,128));
            }finally{reader.dispose();}
        }catch(Exception ignored){return null;}
    }
    public static Track parse(String json,long now){
        JsonObject value=JsonParser.parseString(json).getAsJsonObject();
        String title=text(value,"title"),artist=text(value,"artist"),status=text(value,"status");
        long duration=number(value,"durationMs"),position=number(value,"positionMs");
        if(duration>0)position=Math.min(position,duration);
        return new Track(title,artist,value.has("playing")&&value.get("playing").getAsBoolean(),position,duration,now,status);
    }
    private static String text(JsonObject object,String key){
        String value=object.has(key)&&!object.get(key).isJsonNull()?object.get(key).getAsString():"";
        value=value.replaceAll("[\\p{Cntrl}]"," ").trim();return value.substring(0,Math.min(256,value.length()));
    }
    private static long number(JsonObject object,String key){return object.has(key)?Math.max(0,Math.min(604_800_000,object.get(key).getAsLong())):0;}
    public synchronized void start(){
        if(run!=null)return;
        if(Boolean.getBoolean("cherryblossom.spotify.disabled"))return;
        if(!System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")){
            Run api=new Run();run=api;
            api.api=new SpotifyApiSource(FabricLoader.getInstance().getConfigDir().resolve("cherryblossom/spotify/spotify-api.json"),SpotifyNowPlaying::tell);
            api.executor.scheduleWithFixedDelay(()->pollApi(api),0,3,TimeUnit.SECONDS);
            return;
        }
        Run current=new Run();run=current;
        current.executor.scheduleWithFixedDelay(()->poll(current),0,2,TimeUnit.SECONDS);
    }
    /** Shows a login link / status line in chat and copies links to the clipboard (there is no browser launcher on Android). */
    private static void tell(String message){
        var mc=net.minecraft.client.MinecraftClient.getInstance();
        mc.execute(()->{
            if(message.startsWith("https://"))mc.keyboard.setClipboard(message);
            if(mc.inGameHud!=null)mc.inGameHud.getChatHud().addMessage(net.minecraft.text.Text.literal("[CherryBlossom] "+(message.startsWith("https://")?"Spotify login link copied to clipboard. Paste it into your browser: "+message:message)));
        });
    }
    private void pollApi(Run current){
        if(!current.active)return;
        SpotifyApiSource source=current.api;if(source==null)return;
        SpotifyApiSource.Snapshot s=source.poll();
        if(!current.active||run!=current)return;
        if(!s.status().equals("ready")){track=empty(s.status());current.received=System.nanoTime();return;}
        String encoded=source.artworkBase64(s.artUrl());
        if(!encoded.equals(current.artData)){current.artData=encoded;current.artwork=decodeArtwork(encoded);}
        long now=System.nanoTime();
        track=new Track(s.title(),s.artist(),s.playing(),s.positionMs(),s.durationMs(),now,"ready",current.artwork);
        current.received=now;
    }
    private void poll(Run current){
        if(!current.active)return;
        Process existing=current.process;
        if(existing!=null&&existing.isAlive()){
            if(System.nanoTime()-current.received>12_000_000_000L){existing.destroyForcibly();track=empty("unavailable");}
            return;
        }
        if(System.currentTimeMillis()<current.retry)return;
        current.retry=System.currentTimeMillis()+15_000;
        try{
            Path script=FabricLoader.getInstance().getConfigDir().resolve("cherryblossom/spotify/session.ps1");
            Files.createDirectories(script.getParent());
            if(current.commands==null)current.commands=Files.createTempDirectory(script.getParent(),"controls-");
            try(InputStream resource=SpotifyNowPlaying.class.getResourceAsStream("/assets/cherryblossom/spotify-session.ps1")){
                if(resource==null)throw new IOException("Spotify helper asset missing");Files.write(script,resource.readAllBytes());
            }
            String systemRoot=System.getenv("SystemRoot");
            String powershell=systemRoot==null?"powershell.exe":Path.of(systemRoot,"System32","WindowsPowerShell","v1.0","powershell.exe").toString();
            Process process=new ProcessBuilder(powershell,"-NoProfile","-NonInteractive","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",script.toString(),"-OwnerPid",Long.toString(ProcessHandle.current().pid()),"-CommandDirectory",current.commands.toString())
                .redirectError(ProcessBuilder.Redirect.DISCARD).start();
            current.process=process;current.received=System.nanoTime();
            if(!current.active){process.destroyForcibly();return;}
            Thread reader=new Thread(()->read(current,process),"CherryBlossom Spotify reader");reader.setDaemon(true);reader.start();
        }catch(Exception e){if(run==current)track=empty("unavailable");}
    }
    private void read(Run current,Process process){
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(process.getInputStream(),StandardCharsets.UTF_8))){
            String line;while(current.active&&(line=reader.readLine())!=null){
                try{
                    Track update=parse(line,System.nanoTime());var json=JsonParser.parseString(line).getAsJsonObject();
                    String encoded=json.has("artwork")?json.get("artwork").getAsString():"";
                    if(!encoded.equals(current.artData)){current.artData=encoded;current.artwork=decodeArtwork(encoded);}
                    update=new Track(update.title(),update.artist(),update.playing(),update.positionMs(),update.durationMs(),update.receivedNanos(),update.status(),current.artwork);
                    if(run==current){track=update;current.received=update.receivedNanos();}
                }catch(RuntimeException ignored){}
            }
        }catch(IOException ignored){}finally{
            process.destroyForcibly();if(current.process==process)current.process=null;
            if(run==current&&current.active)track=empty("unavailable");
        }
    }
    @Override public synchronized void close(){
        pending=null;
        Run old=run;run=null;if(old!=null){old.active=false;if(old.api!=null)old.api.close();old.executor.shutdownNow();Process process=old.process;if(process!=null)process.destroyForcibly();
            // Only this run's small command files; never traverse other config directories.
            if(old.commands!=null)try(var files=Files.list(old.commands)){for(Path file:files.toList())Files.deleteIfExists(file);Files.deleteIfExists(old.commands);}catch(IOException ignored){}
        }
        track=empty("idle");
    }
}
