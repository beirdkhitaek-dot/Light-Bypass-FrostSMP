package cherryblossom.feature;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class HalloweenGhostOverlay {
   private static final int GHOSTS = 7;
   static volatile float worldRoll;
   static volatile float worldPitch;
   private static volatile long shakeAt;
   private final Random rnd = new Random();
   private final List<HalloweenGhostOverlay.GhostSprite> ghosts = new ArrayList<>();
   private final List<HalloweenGhostOverlay.GhostParticle> bats = new ArrayList<>();
   private float batTimer = 5.0F;
   private float sx;
   private float sy;
   private float svx;
   private float svy;
   private float kick;
   private float kickVel;
   private float[] window;

   public static float worldRoll() {
      return System.nanoTime() - shakeAt < 150000000L ? worldRoll : 0.0F;
   }

   public static float worldPitch() {
      return System.nanoTime() - shakeAt < 150000000L ? worldPitch : 0.0F;
   }

   float[] shake(float var1, float var2, float var3, float var4, float var5) {
      float var6 = var4 / 1080.0F * 7.0F * var3;
      float var7 = (float)(Math.sin((double)var5 * 9.7) * 0.6 + Math.sin((double)var5 * 5.3 + 1.1) * 0.4);
      float var8 = (float)(Math.sin((double)var5 * 8.1 + 2.3) * 0.5 + Math.sin((double)var5 * 4.7 + 0.4) * 0.5);
      float var9 = var7 * var2 * var6 * 0.75F;
      float var10 = (var8 * 0.45F + 0.55F) * var2 * var6;
      float var11 = 260.0F;
      float var12 = 2.0F * (float)Math.sqrt((double)var11) * 0.9F;
      int var13 = Math.max(1, (int)Math.ceil((double)(var1 / 0.004F)));
      float var14 = var1 / (float)var13;

      for (int var15 = 0; var15 < var13; var15++) {
         this.svx = this.svx + ((var9 - this.sx) * var11 - this.svx * var12) * var14;
         this.svy = this.svy + ((var10 - this.sy) * var11 - this.svy * var12) * var14;
         this.sx = this.sx + this.svx * var14;
         this.sy = this.sy + this.svy * var14;
         this.kickVel = this.kickVel + ((var2 * var3 - this.kick) * var11 - this.kickVel * var12) * var14;
         this.kick = this.kick + this.kickVel * var14;
      }

      worldRoll = this.sx / Math.max(1.0F, var6) * 0.35F * var3;
      worldPitch = this.kick * 0.28F;
      shakeAt = System.nanoTime();
      return new float[]{this.sx, this.sy};
   }

   void calm() {
      worldRoll = 0.0F;
      worldPitch = 0.0F;
   }

   void background(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float[] var7) {
      this.window = var7;
      if (!(var6 <= 0.003F)) {
         float var8 = Math.max(var2, var3);
         var1.pushAlpha(var6);
         float var9 = var3 * 0.115F;
         float var10 = var2 * 0.83F + (float)Math.sin((double)var4 * 0.05) * var2 * 0.004F;
         float var11 = var3 * 0.17F;
         var1.glow(var10, var11, var9 * 3.4F, UiRenderer.argb(0.055F, 255, 190, 140));
         var1.glow(var10, var11, var9 * 1.5F, UiRenderer.argb(0.1F, 255, 228, 200));
         var1.texture(HalloweenIconAtlas.moon(Math.round(var9)), var10 - var9 / 2.0F, var11 - var9 / 2.0F, var9, var9, UiRenderer.white(0.21F));
         float var12 = var3 * 0.3F;
         float var13 = var2 * 1.25F;
         UiTextureData var14 = HalloweenIconAtlas.mist(512, 128);
         this.mistLayer(var1, var14, var2, var3, var12, var13, var4 * 9.0F, UiRenderer.argb(0.13F, 196, 180, 224));
         this.mistLayer(var1, var14, var2, var3, var12 * 0.75F, var13 * 0.8F, -var4 * 5.5F + var13 * 0.37F, UiRenderer.argb(0.09F, 220, 160, 140));
         float var15 = var3 * 0.26F;
         float var16 = (float)Math.sin((double)var4 * 0.55) * var3 * 0.0018F;
         var1.texture(HalloweenIconAtlas.web(Math.round(var15)), -2.0F + var16, -2.0F, var15, var15, UiRenderer.white(0.068F));
         var1.texture(HalloweenIconAtlas.web(Math.round(var15), true), var2 - var15 + 2.0F - var16, -2.0F, var15, var15, UiRenderer.white(0.058F));
         this.pumpkin(var1, var2 * 0.045F, var3, var3 * 0.13F, var4, 0.0F);
         this.pumpkin(var1, var2 - var2 * 0.075F, var3, var3 * 0.095F, var4, 2.3F);
         this.pumpkin(var1, var2 - var2 * 0.03F - var3 * 0.11F, var3, var3 * 0.065F, var4, 4.1F);
         this.bats(var1, var2, var3, var5, var4);
         this.ghosts(var1, var2, var3, var5, var4, var8);
         var1.popAlpha();
      }
   }

   private void mistLayer(UiRenderer var1, UiTextureData var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      float var9 = var7 % var6;
      if (var9 > 0.0F) {
         var9 -= var6;
      }

      for (float var10 = var9; var10 < var3; var10 += var6) {
         var1.texture(var2, var10, var4 - var5, var6 + 1.0F, var5, var8);
      }
   }

   private void pumpkin(UiRenderer var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = 0.62F + 0.22F * (float)Math.sin((double)var5 * 7.3 + (double)var6) + 0.16F * (float)Math.sin((double)var5 * 13.1 + (double)(var6 * 2.0F));
      float var8 = var3 - var4 * 0.92F;
      var1.glow(var2, var8 + var4 * 0.55F, var4 * 1.6F, UiRenderer.argb(0.07F * var7, 255, 140, 40));
      var1.glow(var2, var8 + var4 * 0.62F, var4 * 0.55F, UiRenderer.argb(0.16F * var7, 255, 196, 90));
      var1.texture(HalloweenIconAtlas.pumpkin(Math.round(var4)), var2 - var4 / 2.0F, var8, var4, var4, UiRenderer.white(0.78F));
   }

   private void bats(UiRenderer var1, float var2, float var3, float var4, float var5) {
      this.batTimer -= var4;
      if (this.batTimer <= 0.0F && this.bats.size() < 2) {
         HalloweenGhostOverlay.GhostParticle var6 = new HalloweenGhostOverlay.GhostParticle();
         var6.dir = this.rnd.nextBoolean() ? 1 : -1;
         var6.x = var6.dir > 0 ? -0.08F : 1.08F;
         var6.y = 0.08F + this.rnd.nextFloat() * 0.22F;
         var6.speed = 0.075F + this.rnd.nextFloat() * 0.05F;
         var6.size = 0.028F + this.rnd.nextFloat() * 0.016F;
         var6.phase = this.rnd.nextFloat() * 10.0F;
         this.bats.add(var6);
         this.batTimer = 7.0F + this.rnd.nextFloat() * 9.0F;
      }

      for (int var14 = this.bats.size() - 1; var14 >= 0; var14--) {
         HalloweenGhostOverlay.GhostParticle var7 = this.bats.get(var14);
         var7.x = var7.x + (float)var7.dir * var7.speed * var4;
         var7.age += var4;
         if (!(var7.x < -0.12F) && !(var7.x > 1.12F)) {
            float var8 = (var7.age * 11.0F + var7.phase) % 3.0F;
            int var9 = (int)var8;
            float var10 = var7.size * var3 * 2.0F;
            float var11 = var10 / 2.0F;
            float var12 = (var7.y + 0.018F * (float)Math.sin((double)(var7.age * 3.1F + var7.phase))) * var3;
            float var13 = Math.min(1.0F, Math.min(var7.x + 0.1F, 1.1F - var7.x) / 0.1F);
            var1.texture(
               HalloweenIconAtlas.bat(Math.round(var10), var9), var7.x * var2 - var10 / 2.0F, var12, var10, var11, UiRenderer.argb(0.42F * var13, 14, 6, 20)
            );
         } else {
            this.bats.remove(var14);
         }
      }
   }

   private void ghosts(UiRenderer var1, float var2, float var3, float var4, float var5, float var6) {
      if (this.ghosts.isEmpty()) {
         for (int var7 = 0; var7 < 7; var7++) {
            HalloweenGhostOverlay.GhostSprite var8 = new HalloweenGhostOverlay.GhostSprite();
            this.respawn(var8);
            var8.age = this.rnd.nextFloat() * var8.life;
            this.ghosts.add(var8);
         }
      }

      int var29 = Math.round(var3 * 0.085F);

      for (HalloweenGhostOverlay.GhostSprite var9 : this.ghosts) {
         var9.age += var4;
         if (var9.age >= var9.life) {
            this.respawn(var9);
         }

         float var10 = var9.age + var9.seed;
         float var11 = var9.drift + 0.018F * (float)Math.sin((double)(var10 * 0.31F)) + 0.01F * (float)Math.sin((double)(var10 * 0.77F + 1.3F));
         float var12 = -0.006F + 0.012F * (float)Math.sin((double)(var10 * 0.23F + 2.1F)) + 0.006F * (float)Math.sin((double)(var10 * 0.61F));
         var9.x = var9.x + var11 * var9.speed * var4;
         var9.y = var9.y + var12 * var9.speed * var4;
         float var13 = UiEasing.out(var9.age / 2.6F);
         float var14 = UiEasing.out((var9.life - var9.age) / 2.8F);
         float var15 = Math.min(var13, var14);
         float var16 = (float)Math.sin((double)(var5 * 1.25F + var9.seed)) * 0.006F;
         float var17 = 1.0F + 0.035F * (float)Math.sin((double)(var5 * 1.9F + var9.seed * 2.0F));
         float var18 = var9.size * var3 * var17;
         float var20 = var18 * 1.25F;
         float var21 = var9.x * var2;
         float var22 = (var9.y + var16) * var3;
         float var23 = var9.alpha * var15 * this.behind(var21, var22, var18);
         if (!(var23 <= 0.002F)) {
            var1.glow(var21, var22, var18 * 1.25F, UiRenderer.argb(0.1F * var23, 200, 170, 255));
            var1.glow(var21, var22 - var18 * 0.1F, var18 * 0.55F, UiRenderer.argb(0.12F * var23, 255, 244, 255));
            float var24 = (var5 * 5.5F + var9.seed * 3.0F) % 8.0F;
            int var25 = (int)var24;
            int var26 = (var25 + 1) % 8;
            float var27 = var24 - (float)var25;
            int var28 = UiEasing.mix(UiRenderer.argb(1.0F, 236, 230, 255), UiRenderer.argb(1.0F, 255, 238, 220), var9.warm);
            var1.texture(
               HalloweenIconAtlas.ghost(var29, var25),
               var21 - var18 / 2.0F,
               var22 - var20 / 2.0F,
               var18,
               var20,
               var28 & 16777215 | Math.round(255.0F * var23 * (1.0F - var27)) << 24
            );
            var1.texture(
               HalloweenIconAtlas.ghost(var29, var26),
               var21 - var18 / 2.0F,
               var22 - var20 / 2.0F,
               var18,
               var20,
               var28 & 16777215 | Math.round(255.0F * var23 * var27) << 24
            );
         }
      }
   }

   private float behind(float var1, float var2, float var3) {
      if (this.window == null) {
         return 1.0F;
      } else {
         float[] var4 = this.window;
         float var5 = Math.max(var4[0] - var1, var1 - (var4[0] + var4[2]));
         float var6 = Math.max(var4[1] - var2, var2 - (var4[1] + var4[3]));
         float var7 = Math.max(var5, var6);
         float var8 = UiEasing.clamp((var7 + var3 * 0.6F) / (var3 * 1.2F), 0.0F, 1.0F);
         var8 = var8 * var8 * (3.0F - 2.0F * var8);
         return 0.28F + 0.72F * var8;
      }
   }

   private void respawn(HalloweenGhostOverlay.GhostSprite var1) {
      var1.x = 0.06F + this.rnd.nextFloat() * 0.88F;
      var1.y = 0.18F + this.rnd.nextFloat() * 0.66F;
      var1.size = 0.045F + this.rnd.nextFloat() * 0.045F;
      var1.speed = 0.6F + this.rnd.nextFloat() * 0.7F;
      var1.drift = (float)(this.rnd.nextBoolean() ? 1 : -1) * (0.004F + this.rnd.nextFloat() * 0.01F);
      var1.seed = this.rnd.nextFloat() * 100.0F;
      var1.life = 13.0F + this.rnd.nextFloat() * 10.0F;
      var1.alpha = 0.18F + this.rnd.nextFloat() * 0.17F;
      var1.warm = this.rnd.nextFloat() * 0.5F;
      var1.age = 0.0F;
   }

   void panelWeb(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, boolean var9) {
      if (!(var8 <= 0.003F)) {
         float var10 = 70.0F * var6;
         var1.pushClip(var2, var3, var4, var5);
         var1.texture(HalloweenIconAtlas.web(Math.round(var10), true), var2 + var4 - var10 - 1.0F, var3 + 1.0F, var10, var10, UiRenderer.white(0.075F * var8));
         var1.popClip();
         if (var9) {
            float var11 = (26.0F + 9.0F * (float)Math.sin((double)(var7 * 0.7F))) * var6;
            float var12 = var2 + var4 - 30.0F * var6;
            float var13 = var3 + 8.0F * var6;
            var1.rect(var12, var13, Math.max(1.0F, var6 * 0.8F), var11, UiRenderer.white(0.1F * var8));
            float var14 = 13.0F * var6;
            var1.texture(
               HalloweenIconAtlas.spider(Math.round(var14)),
               var12 - var14 / 2.0F + 0.5F,
               var13 + var11 - var14 * 0.32F,
               var14,
               var14,
               UiRenderer.argb(0.55F * var8, 18, 10, 24)
            );
         }
      }
   }

   static void lantern(UiRenderer var0, float var1, float var2, float var3, float var4, float var5) {
      if (!(var5 <= 0.003F)) {
         float var6 = 0.7F + 0.3F * (float)Math.sin((double)(var4 * 8.0F)) * (float)Math.sin((double)(var4 * 3.1F + 1.0F));
         var0.glow(var1 + var3 / 2.0F, var2 + var3 * 0.62F, var3 * 1.1F, UiRenderer.argb(0.18F * var5 * var6, 255, 150, 50));
         var0.texture(HalloweenIconAtlas.pumpkin(Math.round(var3)), var1, var2, var3, var3, UiRenderer.white(var5));
      }
   }

   static float newBadge(UiRenderer var0, float var1, float var2, float var3, float var4, float var5) {
      float var6 = var0.textWidth("NEW", var3 * 0.52F, 1);
      float var7 = var6 + var3 * 0.9F;
      float var8 = 0.5F + 0.5F * (float)Math.sin((double)(var4 * 2.6F));
      var0.pushAlpha(var5);
      var0.glow(var1 + var7 / 2.0F, var2 + var3 / 2.0F, var7 * 0.9F, UiRenderer.argb(0.1F + 0.08F * var8, 255, 140, 50));
      var0.roundGradient(var1, var2, var7, var3, var3 / 2.0F, UiRenderer.argb(1.0F, 255, 170, 92), UiRenderer.argb(1.0F, 226, 104, 40));
      var0.outline(var1, var2, var7, var3, var3 / 2.0F, Math.max(1.0F, var3 / 22.0F), UiRenderer.argb(0.35F + 0.25F * var8, 190, 120, 255));
      var0.textCentered("NEW", var1 + var7 / 2.0F, var2 + (var3 - var3 * 0.52F) / 2.0F - var3 * 0.04F, var3 * 0.52F, 1, UiRenderer.argb(1.0F, 30, 14, 10));
      var0.popAlpha();
      return var7;
   }

   private static final class GhostParticle {
      float x;
      float y;
      float speed;
      float size;
      float phase;
      float age;
      int dir;
   }

   private static final class GhostSprite {
      float x;
      float y;
      float size;
      float speed;
      float drift;
      float seed;
      float life;
      float age;
      float alpha;
      float warm;
   }
}
