package cherryblossom.feature;

import java.io.IOException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface UiTextureAtlas {
   UiTextureAtlas.TexturePixels decode(byte[] var1) throws IOException;

   @Environment(EnvType.CLIENT)
   public static record TexturePixels(int width, int height, int[] argb) {
   }
}
