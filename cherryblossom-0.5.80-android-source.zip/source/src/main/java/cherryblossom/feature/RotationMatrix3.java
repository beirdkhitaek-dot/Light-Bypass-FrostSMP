package cherryblossom.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class RotationMatrix3 {
   public static final RotationMatrix3 IDENTITY =
      new RotationMatrix3(1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F);

   public final float m00;
   public final float m01;
   public final float m02;
   public final float m10;
   public final float m11;
   public final float m12;
   public final float m20;
   public final float m21;
   public final float m22;

   public RotationMatrix3(
      float m00, float m01, float m02,
      float m10, float m11, float m12,
      float m20, float m21, float m22
   ) {
      this.m00 = m00;
      this.m01 = m01;
      this.m02 = m02;
      this.m10 = m10;
      this.m11 = m11;
      this.m12 = m12;
      this.m20 = m20;
      this.m21 = m21;
      this.m22 = m22;
   }

   public static RotationMatrix3 euler(float xDegrees, float yDegrees, float zDegrees) {
      return radians(
         (float)Math.toRadians(xDegrees),
         (float)Math.toRadians(yDegrees),
         (float)Math.toRadians(zDegrees)
      );
   }

   public static RotationMatrix3 radians(float xRadians, float yRadians, float zRadians) {
      float cosX = (float)Math.cos(xRadians);
      float sinX = (float)Math.sin(xRadians);
      float cosY = (float)Math.cos(yRadians);
      float sinY = (float)Math.sin(yRadians);
      float cosZ = (float)Math.cos(zRadians);
      float sinZ = (float)Math.sin(zRadians);
      return new RotationMatrix3(
         cosZ * cosY,
         cosZ * sinY * sinX - sinZ * cosX,
         cosZ * sinY * cosX + sinZ * sinX,
         sinZ * cosY,
         sinZ * sinY * sinX + cosZ * cosX,
         sinZ * sinY * cosX - cosZ * sinX,
         sinY,
         cosY * sinX,
         cosY * cosX
      );
   }

   public static RotationMatrix3 about(float axisX, float axisY, float axisZ, float degrees) {
      float length = (float)Math.sqrt(axisX * axisX + axisY * axisY + axisZ * axisZ);
      if (length < 1.0E-8F) {
         return IDENTITY;
      }
      float x = axisX / length;
      float y = axisY / length;
      float z = axisZ / length;
      float radians = (float)Math.toRadians(degrees);
      float cosine = (float)Math.cos(radians);
      float sine = (float)Math.sin(radians);
      float complement = 1.0F - cosine;
      return new RotationMatrix3(
         complement * x * x + cosine,
         complement * x * y - sine * z,
         complement * x * z + sine * y,
         complement * x * y + sine * z,
         complement * y * y + cosine,
         complement * y * z - sine * x,
         complement * x * z - sine * y,
         complement * y * z + sine * x,
         complement * z * z + cosine
      );
   }

   public RotationMatrix3 mul(RotationMatrix3 other) {
      return new RotationMatrix3(
         m00 * other.m00 + m01 * other.m10 + m02 * other.m20,
         m00 * other.m01 + m01 * other.m11 + m02 * other.m21,
         m00 * other.m02 + m01 * other.m12 + m02 * other.m22,
         m10 * other.m00 + m11 * other.m10 + m12 * other.m20,
         m10 * other.m01 + m11 * other.m11 + m12 * other.m21,
         m10 * other.m02 + m11 * other.m12 + m12 * other.m22,
         m20 * other.m00 + m21 * other.m10 + m22 * other.m20,
         m20 * other.m01 + m21 * other.m11 + m22 * other.m21,
         m20 * other.m02 + m21 * other.m12 + m22 * other.m22
      );
   }

   public RotationMatrix3 transpose() {
      return new RotationMatrix3(m00, m10, m20, m01, m11, m21, m02, m12, m22);
   }

   public Vec3 apply(Vec3 vector) {
      return new Vec3(
         x(vector.x(), vector.y(), vector.z()),
         y(vector.x(), vector.y(), vector.z()),
         z(vector.x(), vector.y(), vector.z())
      );
   }

   public float x(float x, float y, float z) {
      return m00 * x + m01 * y + m02 * z;
   }

   public float y(float x, float y, float z) {
      return m10 * x + m11 * y + m12 * z;
   }

   public float z(float x, float y, float z) {
      return m20 * x + m21 * y + m22 * z;
   }
}
