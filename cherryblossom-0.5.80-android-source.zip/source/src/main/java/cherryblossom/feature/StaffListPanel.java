package cherryblossom.feature;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class StaffListPanel {
   private final Map<String, StaffListPanel.AnimatedStaffMember> rows = new LinkedHashMap<>();
   private int count;
   private float visibility;
   private float height;
   private double time;

   public void setMembers(List<StaffListPanel.StaffMember> var1) {
      for (StaffListPanel.AnimatedStaffMember var3 : this.rows.values()) {
         var3.active = false;
      }

      int var7 = 0;

      for (StaffListPanel.StaffMember var4 : var1) {
         String var5 = var4.name().toLowerCase(Locale.ROOT);
         StaffListPanel.AnimatedStaffMember var6 = this.rows.get(var5);
         if (var6 == null) {
            var6 = new StaffListPanel.AnimatedStaffMember(var4, var7);
            this.rows.put(var5, var6);
         }

         var6.member = var4;
         var6.index = var7++;
         var6.active = true;
      }

      this.count = var7;
   }

   public void reset() {
      this.rows.clear();
      this.count = 0;
      this.visibility = this.height = 0.0F;
   }

   public void render(
      UiRenderer var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      boolean var8,
      boolean var9,
      boolean var10,
      int var11,
      StaffListPanel.DrawCallback var12
   ) {
      var7 = Math.max(0.0F, Math.min(0.1F, var7));
      this.time += (double)var7;
      float var13 = 1.0F - (float)Math.exp((double)(-12.0F * var7));
      float var14 = !var8 || this.count == 0 && !var9 ? 0.0F : 1.0F;
      this.visibility = this.visibility + (var14 - this.visibility) * var13;
      int var15 = Math.max(1, (int)(((float)var11 - var3) / var5 - 54.0F) / 30);
      if (this.count > var15) {
         var15 = Math.max(1, (int)(((float)var11 - var3) / var5 - 73.0F) / 30);
      }

      int var16 = Math.min(Math.max(1, this.count), var15);
      float var17 = (float)(44 + var16 * 30 + 10 + (this.count > var15 ? 19 : 0)) * var5;
      if (this.height == 0.0F) {
         this.height = var17;
      }

      this.height = this.height + (var17 - this.height) * var13;
      Iterator var18 = this.rows.values().iterator();

      while (var18.hasNext()) {
         StaffListPanel.AnimatedStaffMember var19 = (StaffListPanel.AnimatedStaffMember)var18.next();
         var19.alpha = var19.alpha + ((var19.active ? 1.0F : 0.0F) - var19.alpha) * var13;
         var19.y = var19.y + ((float)var19.index * 30.0F - var19.y) * var13;
         if (!var19.active && var19.alpha < 0.005F) {
            var18.remove();
         }
      }

      if (!(this.visibility < 0.005F)) {
         float var26 = 16.0F * var5;
         var1.pushAlpha(this.visibility);
         var1.shadow(var2, var3, var4, this.height, var26, 18.0F * var5, UiRenderer.argb(0.3F, 0, 0, 0));
         var1.round(var2, var3, var4, this.height, var26, UiPalette.glass(var6));
         var1.roundGradient(var2, var3, var4, this.height, var26, UiRenderer.white(0.05F), UiRenderer.white(0.0F));
         float var27 = Math.min(var4, this.height) * 0.38F;
         var1.glow(var2 + var4 * (0.5F + 0.08F * (float)Math.sin(this.time * 0.12)), var3 + this.height * 0.5F, var27, UiPalette.light(0.025F * var6));
         var1.outline(var2, var3, var4, this.height, var26, Math.max(1.0F, var5 * 0.8F), UiRenderer.white(0.085F));
         var1.rect(var2 + var26, var3 + Math.max(1.0F, var5), var4 - var26 * 2.0F, Math.max(1.0F, var5 * 0.7F), UiRenderer.white(0.045F));
         var1.icon(UiIcon.USER, var2 + 13.0F * var5, var3 + 13.0F * var5, 16.0F * var5, UiRenderer.white(0.85F));
         var1.text(
            var1.ellipsize("Staff List", var4 - 72.0F * var5, 13.0F * var5, 1),
            var2 + 38.0F * var5,
            var3 + 13.0F * var5,
            13.0F * var5,
            1,
            UiRenderer.white(0.95F)
         );
         var1.textRight(Integer.toString(this.count), var2 + var4 - 14.0F * var5, var3 + 14.0F * var5, 11.0F * var5, 0, UiRenderer.white(0.45F));
         var1.rect(var2 + 12.0F * var5, var3 + 38.0F * var5, var4 - 24.0F * var5, Math.max(1.0F, var5 * 0.8F), UiRenderer.white(0.055F));
         if (this.count == 0 && this.rows.isEmpty()) {
            var1.text("No staff detected", var2 + 14.0F * var5, var3 + 54.0F * var5, 11.5F * var5, 0, UiRenderer.white(0.45F));
         }

         var1.pushClip(var2 + 8.0F * var5, var3 + 44.0F * var5, var4 - 16.0F * var5, Math.max(0.0F, this.height - 51.0F * var5));

         for (StaffListPanel.AnimatedStaffMember var21 : this.rows.values()) {
            float var22 = var3 + 44.0F * var5 + var21.y * var5;
            if (var21.index < var15 && !(var22 > var3 + this.height - 10.0F * var5) && !(var21.alpha < 0.005F)) {
               var1.pushAlpha(var21.alpha);
               float var23 = (1.0F - var21.alpha) * 6.0F * var5;
               float var24 = var2 + 14.0F * var5 + var23;
               if (var10) {
                  var1.round(var24 - 2.0F * var5, var22 + 3.0F * var5, 23.0F * var5, 23.0F * var5, 7.0F * var5, UiRenderer.white(0.035F));
                  var12.draw(var21.member, var24, var22 + 5.0F * var5, 19.0F * var5, var21.alpha * this.visibility);
                  var24 += 29.0F * var5;
               }

               var1.text(
                  var1.ellipsize(var21.member.name(), var2 + var4 - 14.0F * var5 - var24, 12.0F * var5, 0),
                  var24,
                  var22 + 8.0F * var5,
                  12.0F * var5,
                  0,
                  UiRenderer.white(0.9F)
               );
               var1.popAlpha();
            }
         }

         var1.popClip();
         if (this.count > var15) {
            var1.text("+" + (this.count - var15) + " more", var2 + 14.0F * var5, var3 + this.height - 24.0F * var5, 10.0F * var5, 0, UiRenderer.white(0.4F));
         }

         var1.popAlpha();
      }
   }

   @FunctionalInterface
   public interface DrawCallback {
      void draw(StaffListPanel.StaffMember var1, float var2, float var3, float var4, float var5);
   }

   public static record StaffMember(String name, UUID uuid) {
   }

   private static final class AnimatedStaffMember {
      StaffListPanel.StaffMember member;
      boolean active;
      float alpha;
      float y;
      int index;

      AnimatedStaffMember(StaffListPanel.StaffMember var1, int var2) {
         this.member = var1;
         this.index = var2;
         this.y = (float)var2 * 30.0F;
      }
   }
}
