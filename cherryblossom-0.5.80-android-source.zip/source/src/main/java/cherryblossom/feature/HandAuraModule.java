package cherryblossom.feature;

import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.function.BooleanSupplier;
import cherryblossom.module.ext.ClientModule;
import cherryblossom.module.ext.ModuleCategory;
import cherryblossom.module.ext.setting.BooleanSetting;
import cherryblossom.module.ext.setting.ColorSetting;
import cherryblossom.module.ext.setting.ModeSetting;
import cherryblossom.module.ext.setting.NumberSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ColorHelper;


@Environment(EnvType.CLIENT)
public final class HandAuraModule extends ClientModule {
   public static volatile HandAuraModule active;
   private static final String CONSTANT_0002 = "Theme";
   private static final String CONSTANT_0462 = "Manual";
   private static final int CONSTANT_0594 = -1;
   private static final float CONSTANT_0336 = 0.55F;
   private static final long CONSTANT_0480 = 3200000000L;
   private static final long CONSTANT_0291 = 4400000000L;
   private final ModeSetting colorMode;
   private final ColorSetting glowColor;
   private final NumberSetting aura;
   private final NumberSetting reach;
   private final NumberSetting rim;
   private final NumberSetting sheen;
   private final ColorSetting sheenColor;
   private final BooleanSetting breathe;

   public HandAuraModule() {
      super(
         "hand-aura",
         "Hand Aura",
         "Adds a glowing outline to your hand and held item.",
         ModuleCategory.VISUALS
      );
      String var10002 = "color";
      String var10005 = "Color";
      String var10006 = "Theme";
      String[] var10007 = new String[2];
      var10007[0] = "Theme";
      var10007[1] = "Manual";
      this.colorMode = this.addSetting(var10002, new ModeSetting(var10005, var10006, var10007));
      this.glowColor = this.addSetting(
         "glow-color",
         new ColorSetting("Glow Color", -13338378)
      );
      this.aura = this.addSetting(
         "aura",
         new NumberSetting(
               "Aura",
               65.0F,
               0.0F,
               100.0F
            )
            .step(5.0F)
      );
      this.reach = this.addSetting(
         "reach",
         new NumberSetting(
               "Reach",
               8.0F,
               2.0F,
               20.0F
            )
            .step(1.0F)
      );
      this.rim = this.addSetting(
         "rim",
         new NumberSetting(
               "Rim",
               40.0F,
               0.0F,
               100.0F
            )
            .step(5.0F)
      );
      this.sheen = this.addSetting(
         "sheen",
         new NumberSetting(
               "Sheen",
               25.0F,
               0.0F,
               100.0F
            )
            .step(5.0F)
      );
      this.sheenColor = this.addSetting(
         "sheen-color",
         new ColorSetting("Sheen Color", -3153665)
      );
      this.breathe = this.addSetting(
         "breathe",
         new BooleanSetting("Breathe", true)
      );
      this.glowColor.visibleWhen(this::manual);
      this.reach
         .visibleWhen(() -> ((this.aura.get() > 0.0F)));
      this.sheenColor
         .visibleWhen(
            () -> ((this.sheen.get() > 0.0F && this.manual()))
         );
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
      if (RenderSystem.isOnRenderThread()) {
         HandAuraHelper.release();
      } else {
         MinecraftClient.getInstance().execute(HandAuraModule::releaseIfOff);
      }
   }

   private static void releaseIfOff() {
      if (active == null) {
         HandAuraHelper.release();
      }
   }

   public static boolean beginCapture() {
      HandAuraModule var0 = active;
      return ((var0 != null && var0.shows() && HandAuraHelper.begin()));
   }

   public static void endCapture(boolean var0) {
      if (HandAuraHelper.end() && var0) {
         HandAuraModule var1 = active;
         float var2 = Math.max(
            1.0F,
            (float)MinecraftClient.getInstance().getFramebuffer().textureHeight / 1080.0F
         );
         if (var1 == null) {
            HandAuraHelper.compose(
               -1,
               0.0F,
               2.0F,
               0.0F,
               2.0F * var2,
               -1,
               0.0F,
               0.0F
            );
         } else {
            long var3 = System.nanoTime();
            float var5 = (float)(
               (double)(var3 % (4400000000L)) / 4400000000.0
            );
            int var6 = var1.glowArgb();
            HandAuraHelper.compose(
               var6,
               var1.auraStrength(var3),
               var1.reach.get() * var2,
               var1.rim.get() / 100.0F,
               2.0F * var2,
               var1.sheenArgb(var6),
               var1.sheen.get() / 100.0F,
               var5
            );
         }
      }
   }

   private boolean manual() {
      return this.colorMode.is("Manual");
   }

   private int glowArgb() {
      return this.manual() ? this.glowColor.argb() : HandAuraColors.argb();
   }

   private int sheenArgb(int var1) {
      return this.manual()
         ? this.sheenColor.argb()
         : ColorHelper.lerp(0.550000011920929F, var1, -1);
   }

   private boolean shows() {
      return ((!(!(this.aura.get() > 0.0F) && !(this.rim.get() > 0.0F))));
   }

   private float auraStrength(long var1) {
      float var3 = this.aura.get() / 100.0F;
      if (!this.breathe.get()) {
         return var3;
      } else {
         double var4 = (double)(var1 % (3200000000L)) / 3200000000.0;
         float var6 = (float)Math.sin(var4 * 3.141592653589793);
         return var3 * (0.6000000238418579F + 0.4000000059604645F * var6 * var6);
      }
   }
}
