package cherryblossom.feature;

public enum SkyLightPattern {
   NORMAL,
   EMPTY_MASK,
   ZEROED_PRESENT,
   UNIFORM_MAX,
   UNKNOWN;
}
