package cherryblossom.feature;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.*;
import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.*;
import java.util.*;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public final class KeystrokesModule extends Module {
    private final NumberSetting scale=new NumberSetting("HUD Scale",60,180,100,5),opacity=new NumberSetting("Opacity",.1,1,.78,.05),x=new NumberSetting("X Position",0,100,2,.1),y=new NumberSetting("Y Position",0,100,40,.1),radius=new NumberSetting("Corner Radius",2,16,9,1);
    private final ChoiceSetting style=new ChoiceSetting("Style","Glass",List.of("Glass","Minimal","Outline"));
    private final BooleanSetting movement=new BooleanSetting("Movement Keys",true),jump=new BooleanSetting("Spacebar",true),buttons=new BooleanSetting("Mouse Buttons",true),cps=new BooleanSetting("Show CPS",true),labels=new BooleanSetting("Use Bound Key Names",true);
    private final ArrayDeque<Long> left=new ArrayDeque<>(),right=new ArrayDeque<>();
    public KeystrokesModule(){super("Keystrokes","Movement keys and independent left/right clicks per second. Open chat to move it.",-1,Category.CLIENT);addSettings(style,scale,opacity,radius,movement,jump,buttons,cps,labels,x,y);}
    public static int count(ArrayDeque<Long> clicks,long now){while(!clicks.isEmpty()&&now-clicks.peekFirst()>=1_000_000_000L)clicks.removeFirst();return clicks.size();}
    @EventListener public void mouse(MouseButtonEvent event){if(isEnabled()&&event.actions==1&&mc.currentScreen==null&&mc.world!=null&&mc.isWindowFocused()&&!event.isCancelled()&&(event.button==0||event.button==1)){var list=event.button==0?left:right;long now=System.nanoTime();count(list,now);if(list.size()<500)list.addLast(now);}}
    private String name(KeyBinding key,String fallback){String value=key.getBoundKeyLocalizedText().getString().toUpperCase(Locale.ROOT);return labels.getValue()&&value.length()<=3?value:fallback;}
    @EventListener public void render(Render2DEvent event){
        if(!isEnabled()||mc.world==null||mc.options.hudHidden)return;
        var window=mc.getWindow();float sw=window.getFramebufferWidth(),sh=window.getFramebufferHeight(),u=Math.max(.45f,sh/1080f*(float)scale.getValue()/100);
        float w=142*u,h=((movement.getValue()?92:0)+(jump.getValue()?31:0)+(buttons.getValue()?43:0)+10)*u;
        float px=(float)((sw-w)*x.getValue()/100),py=(float)((sh-h)*y.getValue()/100);
        var p=HudDragging.place("keystrokes",px,py,w,h,(nx,ny)->{x.getValue(nx/Math.max(1,sw-w)*100);y.getValue(ny/Math.max(1,sh-h)*100);});px=p[0];py=p[1];
        var matrix=event.context.getMatrices();float gs=(float)window.getScaleFactor();matrix.pushMatrix();matrix.scale(1/gs,1/gs);
        try{var r=new MinecraftUiRenderer(event.context,gs);float cursor=py+5*u,l=px+5*u;boolean live=mc.currentScreen==null&&mc.isWindowFocused();var o=mc.options;
            if(movement.getValue()){
                tile(r,l+45*u,cursor,42*u,40*u,name(o.forwardKey,"W"),null,live&&o.forwardKey.isPressed(),u);
                String[] text={name(o.leftKey,"A"),name(o.backKey,"S"),name(o.rightKey,"D")};boolean[] down={o.leftKey.isPressed(),o.backKey.isPressed(),o.rightKey.isPressed()};
                for(int i=0;i<3;i++)tile(r,l+i*45*u,cursor+44*u,42*u,40*u,text[i],null,live&&down[i],u);cursor+=90*u;
            }
            if(jump.getValue()){tile(r,l,cursor,132*u,25*u,"SPACE",null,live&&o.jumpKey.isPressed(),u);cursor+=31*u;}
            if(buttons.getValue()){long now=System.nanoTime();int a=count(left,now),b=count(right,now);tile(r,l,cursor,64*u,37*u,"LMB",cps.getValue()?a+" CPS":null,live&&GLFW.glfwGetMouseButton(window.getHandle(),0)==GLFW.GLFW_PRESS,u);tile(r,l+68*u,cursor,64*u,37*u,"RMB",cps.getValue()?b+" CPS":null,live&&GLFW.glfwGetMouseButton(window.getHandle(),1)==GLFW.GLFW_PRESS,u);}
        }finally{matrix.popMatrix();}
    }
    private void tile(UiRenderer r,float x,float y,float w,float h,String key,String detail,boolean down,float u){
        boolean outline=style.getMode().equals("Outline"),minimal=style.getMode().equals("Minimal");float corner=(float)radius.getValue()*u;
        if(!minimal)r.shadow(x,y+2*u,w,h,corner,6*u,UiRenderer.argb(.12f,0,0,0));
        r.round(x,y,w,h,corner,down?CherryHudPalette.accent(.3f):minimal?UiRenderer.argb(.26f,20,17,24):outline?UiRenderer.argb(.08f,20,17,24):CherryHudPalette.glass((float)opacity.getValue()));
        r.outline(x,y,w,h,corner,Math.max(.7f,u),CherryHudPalette.accent(down?.9f:outline?.45f:.17f));
        float size=(detail==null?13:11)*u;r.textCentered(key,x+w/2,y+(detail==null?(h-size)/2:7*u),size,1,down?CherryHudPalette.accent(1):UiRenderer.white(.93f));
        if(detail!=null)r.textCentered(detail,x+w/2,y+23*u,8.5f*u,0,UiRenderer.white(.6f));
    }
    @Override public void onDisable(){left.clear();right.clear();}
}
