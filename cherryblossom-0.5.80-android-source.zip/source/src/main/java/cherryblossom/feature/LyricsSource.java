package cherryblossom.feature;

import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/** Bounded, cached LRCLIB requests on a background thread. Only track metadata is sent. */
public final class LyricsSource implements AutoCloseable {
    public record Result(SyncedLyrics lyrics,String status){}
    private record Cached(Result result,long expires){}
    private static final HttpClient HTTP=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NEVER).build();
    private static final Map<String,Cached> CACHE=Collections.synchronizedMap(new LinkedHashMap<>(32,.75f,true));
    private final ExecutorService worker=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"CherryBlossom synced lyrics");t.setDaemon(true);return t;});
    private volatile Result result=new Result(new SyncedLyrics(List.of()),"Open Spotify to show lyrics");
    private volatile long generation;
    private volatile boolean closed;
    private String key="";private Future<?> pending;
    public Result current(){return result;}
    public void update(SpotifyNowPlaying.Track track){
        String next=track.present()?track.title()+"\n"+track.artist()+"\n"+track.durationMs():"";
        if(next.equals(key)||closed)return;key=next;long request=++generation;if(pending!=null)pending.cancel(true);
        if(next.isEmpty()){result=new Result(new SyncedLyrics(List.of()),"Open Spotify to show lyrics");return;}
        Cached found=CACHE.get(next);if(found!=null&&found.expires>System.currentTimeMillis()){result=found.result;return;}
        result=new Result(new SyncedLyrics(List.of()),"Finding synced lyrics...");
        pending=worker.submit(()->{
            Result loaded;try{loaded=fetch(track);}catch(InterruptedException e){Thread.currentThread().interrupt();return;}catch(Exception e){loaded=new Result(new SyncedLyrics(List.of()),"Lyrics are temporarily unavailable");}
            if(closed||request!=generation)return;
            synchronized(CACHE){CACHE.put(next,new Cached(loaded,System.currentTimeMillis()+(loaded.lyrics.lines().isEmpty()?600_000:86_400_000)));while(CACHE.size()>40)CACHE.remove(CACHE.keySet().iterator().next());}
            result=loaded;
        });
    }
    private static String q(String value){return URLEncoder.encode(value,StandardCharsets.UTF_8);}
    private static JsonElement get(String path)throws Exception{
        var req=HttpRequest.newBuilder(URI.create("https://lrclib.net"+path)).timeout(Duration.ofSeconds(10)).header("User-Agent","CherryBlossomClient/0.5.80 (synced lyrics)").header("Accept","application/json").GET().build();
        var response=HTTP.send(req,HttpResponse.BodyHandlers.ofInputStream());byte[] body;try(var in=response.body()){body=in.readNBytes(524289);}if(body.length>524288)throw new IOException("Lyrics response too large");
        if(response.statusCode()==404)return JsonNull.INSTANCE;if(response.statusCode()!=200)throw new IOException("Lyrics provider unavailable");return JsonParser.parseString(new String(body,StandardCharsets.UTF_8));
    }
    public static Result decode(JsonObject object){
        if(object.has("instrumental")&&object.get("instrumental").getAsBoolean())return new Result(new SyncedLyrics(List.of()),"Instrumental");
        String value=object.has("syncedLyrics")&&!object.get("syncedLyrics").isJsonNull()?object.get("syncedLyrics").getAsString():"";var lyrics=SyncedLyrics.parse(value);
        return new Result(lyrics,lyrics.lines().isEmpty()?"No synced lyrics available":"ready");
    }
    private static String normalized(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]","");}
    private static Result fetch(SpotifyNowPlaying.Track track)throws Exception{
        String params="track_name="+q(track.title())+"&artist_name="+q(track.artist());long seconds=Math.round(track.durationMs()/1000d);
        JsonElement exact=get("/api/get?"+params+(seconds>=1&&seconds<=3600?"&duration="+seconds:""));if(exact.isJsonObject())return decode(exact.getAsJsonObject());
        var search=get("/api/search?"+params);if(search.isJsonArray())for(var entry:search.getAsJsonArray()){
            var o=entry.getAsJsonObject();String title=o.has("trackName")?o.get("trackName").getAsString():"",artist=o.has("artistName")?o.get("artistName").getAsString():"";
            if(!normalized(title).equals(normalized(track.title()))||!normalized(artist).equals(normalized(track.artist())))continue;
            if(track.durationMs()>0&&(!o.has("duration")||Math.abs(o.get("duration").getAsDouble()-track.durationMs()/1000d)>3))continue;
            var decoded=decode(o);if(!decoded.lyrics.lines().isEmpty())return decoded;
        }
        return new Result(new SyncedLyrics(List.of()),"No synced lyrics available");
    }
    @Override public void close(){closed=true;generation++;if(pending!=null)pending.cancel(true);worker.shutdownNow();}
}
