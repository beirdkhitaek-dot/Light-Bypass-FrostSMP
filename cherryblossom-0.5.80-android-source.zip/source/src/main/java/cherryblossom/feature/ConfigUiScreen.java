package cherryblossom.feature;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import cherryblossom.CherryBlossom;
import cherryblossom.manager.ConfigLibrary;
import net.minecraft.client.MinecraftClient;

public final class ConfigUiScreen {
   private static final int TEXT = UiRenderer.white(0.96F);
   private static final int SUB = UiRenderer.white(0.55F);
   private final Supplier<ConfigLibrary> library;
   private final Supplier<String> clipboard;
   private final Consumer<String> copy;
   private final List<ConfigUiScreen.ActionButton> hits = new ArrayList<>();
   private final Map<String, Float> hover = new HashMap<>();
   private boolean opened;
   private boolean selectAll;
   private float progress;
   private float unit;
   private float delta;
   private float x;
   private float y;
   private float width;
   private float height;
   private float caret;
   private double mx;
   private double my;
   private ConfigUiScreen.PendingAction dialog = ConfigUiScreen.PendingAction.NONE;
   private String target;
   private String input = "";
   private String status = "";
   private String selection;
   private boolean error;

   public ConfigUiScreen() {
      this(
         () -> CherryBlossom.INSTANCE.getSettingsManager().configs(),
         () -> MinecraftClient.getInstance().keyboard.getClipboard(),
         var0 -> MinecraftClient.getInstance().keyboard.setClipboard(var0)
      );
   }

   public ConfigUiScreen(Supplier<ConfigLibrary> var1, Supplier<String> var2, Consumer<String> var3) {
      this.library = var1;
      this.clipboard = var2;
      this.copy = var3;
   }

   public void open() {
      this.opened = true;
      this.dialog = ConfigUiScreen.PendingAction.NONE;
      this.status = "";
      this.error = false;

      try {
         this.selection = this.library.get().selected();
      } catch (RuntimeException var2) {
         this.fail(var2);
      }

      UiAudio.play(UiAudio.Cue.OPEN);
   }

   public void close() {
      this.opened = false;
      this.dialog = ConfigUiScreen.PendingAction.NONE;
      UiAudio.play(UiAudio.Cue.BACK);
   }

   public boolean active() {
      return this.opened || this.progress > 0.005F;
   }

   public boolean isOpen() {
      return this.opened;
   }

   public float visibility() {
      return this.progress;
   }

   private float d(float var1) {
      return var1 * this.unit;
   }

   private void fail(RuntimeException var1) {
      this.status = var1.getMessage() == null ? "Couldn't complete this action." : var1.getMessage();
      this.error = true;
   }

   private void run(Runnable var1, String var2) {
      try {
         var1.run();
         this.status = var2;
         this.error = false;
         UiAudio.play(UiAudio.Cue.CONFIRM);
      } catch (RuntimeException var4) {
         this.fail(var4);
      }
   }

   public void render(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float var7, double var8, double var10, boolean var12) {
      this.unit = var6;
      this.delta = var7;
      this.mx = var8;
      this.my = var10;
      this.caret += var7;
      this.progress = this.progress + ((this.opened ? 1.0F : 0.0F) - this.progress) * (1.0F - (float)Math.exp((double)(-14.0F * var7)));
      if (this.progress < 0.005F && !this.opened) {
         this.progress = 0.0F;
         this.hits.clear();
      } else {
         this.x = var2;
         this.y = var3;
         this.width = var4;
         this.height = var5;
         this.hits.clear();
         var1.pushAlpha(this.progress);
         float var13 = this.d(6.0F) * (1.0F - UiEasing.out(this.progress));
         this.y += var13;
         boolean var14 = this.opened && var12 && this.progress > 0.6F;

         List var15;
         try {
            var15 = this.library.get().profiles();
         } catch (RuntimeException var27) {
            this.fail(var27);
            var15 = List.of();
         }

         var1.round(this.x + this.d(22.0F), this.y + this.d(18.0F), this.d(44.0F), this.d(44.0F), this.d(14.0F), UiRenderer.white(0.07F));
         var1.outline(
            this.x + this.d(22.0F),
            this.y + this.d(18.0F),
            this.d(44.0F),
            this.d(44.0F),
            this.d(14.0F),
            Math.max(1.0F, this.unit * 0.9F),
            UiRenderer.white(0.09F)
         );
         var1.icon(UiIcon.FOLDER, this.x + this.d(33.5F), this.y + this.d(29.5F), this.d(21.0F), TEXT);
         var1.text("Configs", this.x + this.d(82.0F), this.y + this.d(19.0F), this.d(21.0F), 1, TEXT);
         var1.text(var15.size() + " / 5 saved", this.x + this.d(83.0F), this.y + this.d(45.0F), this.d(12.0F), 0, SUB);
         this.iconButton(
            var1, "close", UiIcon.CLOSE, "Close", this.x + this.width - this.d(54.0F), this.y + this.d(24.0F), this.d(32.0F), var14, this::close
         );
         var1.rect(this.x + this.d(20.0F), this.y + this.d(78.0F), this.width - this.d(40.0F), Math.max(1.0F, this.unit), UiRenderer.white(0.055F));
         boolean var16 = var15.size() >= 5;
         this.button(
            var1,
            "create",
            "Create new",
            UiIcon.PLUS,
            this.x + this.d(22.0F),
            this.y + this.d(94.0F),
            this.d(132.0F),
            this.d(34.0F),
            var14 && !var16,
            true,
            () -> this.begin(ConfigUiScreen.PendingAction.CREATE, null, "")
         );
         this.button(
            var1,
            "paste",
            "Paste config",
            UiIcon.COPY,
            this.x + this.d(164.0F),
            this.y + this.d(94.0F),
            this.d(132.0F),
            this.d(34.0F),
            var14 && !var16,
            false,
            () -> this.run(() -> this.selection = this.library.get().pasteCode(this.clipboard.get()), "Imported. Click Load to apply.")
         );
         this.button(
            var1,
            "reset",
            "Reset all",
            UiIcon.RESET,
            this.x + this.width - this.d(136.0F),
            this.y + this.d(94.0F),
            this.d(114.0F),
            this.d(34.0F),
            var14,
            false,
            () -> this.begin(ConfigUiScreen.PendingAction.RESET, null, "")
         );
         float var17 = this.y + this.d(144.0F);
         float var18 = this.width - this.d(44.0F);
         if (var15.isEmpty()) {
            var1.textCentered("No saved configs", this.x + this.width / 2.0F, this.y + this.d(281.0F), this.d(14.0F), 1, SUB);
            var1.textCentered(
               "Create new or paste a config.", this.x + this.width / 2.0F, this.y + this.d(308.0F), this.d(11.5F), 0, UiRenderer.white(0.34F)
            );
         }

         for (Object var20Raw : var15) {ConfigLibrary.Profile var20 = (ConfigLibrary.Profile)var20Raw;
            String var21 = var20.id();
            boolean var22 = Objects.equals(this.selection, var21);
            float var23 = this.x + this.d(22.0F);
            float var24 = this.d(58.0F);
            float var25 = this.animate("row:" + var21, this.hot(var23, var17, var18, var24) && var14 ? 1.0F : 0.0F);
            var1.round(
               var23,
               var17,
               var18,
               var24,
               this.d(16.0F),
               UiEasing.mix(
                  UiRenderer.white((var22 ? 0.065F : 0.03F) + 0.025F * var25), UiPalette.accent(0.065F + 0.025F * var25), var22 ? 0.25F : 0.0F
               )
            );
            var1.roundGradient(var23, var17, var18, var24, this.d(16.0F), UiRenderer.white(0.025F), UiRenderer.white(0.0F));
            var1.outline(
               var23, var17, var18, var24, this.d(16.0F), Math.max(1.0F, this.unit * 0.9F), UiRenderer.white((var22 ? 0.12F : 0.055F) + 0.05F * var25)
            );
            var1.icon(
               var22 ? UiIcon.CHECK : UiIcon.FOLDER,
               var23 + this.d(15.0F),
               var17 + this.d(17.0F),
               this.d(19.0F),
               var22 ? UiPalette.accent(0.9F) : SUB
            );
            var1.text(
               var1.ellipsize(var20.name(), var18 - this.d(265.0F), this.d(14.0F), 1), var23 + this.d(47.0F), var17 + this.d(10.0F), this.d(14.0F), 1, TEXT
            );
            var1.text(var20.enabledCount() + " enabled", var23 + this.d(47.0F), var17 + this.d(33.0F), this.d(10.5F), 0, SUB);
            if (var14 && this.dialog == ConfigUiScreen.PendingAction.NONE) {
               this.hits.add(new ConfigUiScreen.ActionButton(var23, var17, var18, var24, () -> this.run(() -> {
                     this.library.get().select(var21);
                     this.selection = var21;
                  }, "")));
            }

            float var26 = var23 + var18 - this.d(211.0F);
            this.iconButton(
               var1,
               "rename:" + var21,
               UiIcon.EDIT,
               "Rename",
               var26,
               var17 + this.d(11.0F),
               this.d(32.0F),
               var14,
               () -> this.begin(ConfigUiScreen.PendingAction.RENAME, var21, var20.name())
            );
            this.iconButton(
               var1,
               "copy:" + var21,
               UiIcon.COPY,
               "Copy code",
               var26 + this.d(38.0F),
               var17 + this.d(11.0F),
               this.d(32.0F),
               var14,
               () -> this.run(() -> this.copy.accept(this.library.get().copyCode(var21)), "Code copied.")
            );
            this.iconButton(
               var1,
               "delete:" + var21,
               UiIcon.TRASH,
               "Delete",
               var26 + this.d(76.0F),
               var17 + this.d(11.0F),
               this.d(32.0F),
               var14,
               () -> this.begin(ConfigUiScreen.PendingAction.DELETE, var21, var20.name())
            );
            this.button(
               var1,
               "load:" + var21,
               "Load",
               null,
               var26 + this.d(120.0F),
               var17 + this.d(10.0F),
               this.d(76.0F),
               this.d(35.0F),
               var14,
               var22,
               () -> this.run(() -> {
                     this.library.get().loadConfig(var21);
                     this.selection = var21;
                  }, "Loaded " + var20.name() + ".")
            );
            var17 += this.d(68.0F);
         }

         float var28 = this.y + this.height - this.d(54.0F);
         var1.rect(this.x + this.d(20.0F), var28 - this.d(13.0F), this.width - this.d(40.0F), Math.max(1.0F, this.unit), UiRenderer.white(0.055F));
         this.button(
            var1,
            "save",
            "Save current",
            UiIcon.CHECK,
            this.x + this.d(22.0F),
            var28,
            this.d(145.0F),
            this.d(36.0F),
            var14 && this.selection != null,
            true,
            () -> this.run(() -> this.library.get().saveCurrent(this.selection), "Saved.")
         );
         var1.text(
            var1.ellipsize(this.status, this.width - this.d(210.0F), this.d(10.7F), 0),
            this.x + this.d(185.0F),
            var28 + this.d(11.0F),
            this.d(10.7F),
            0,
            this.error ? UiRenderer.white(0.92F) : SUB
         );
         if (this.dialog != ConfigUiScreen.PendingAction.NONE) {
            this.drawDialog(var1, var14);
         }

         var1.popAlpha();
      }
   }

   private float animate(String var1, float var2) {
      float var3 = this.hover.getOrDefault(var1, 0.0F);
      var3 += (var2 - var3) * (1.0F - (float)Math.exp((double)(-14.0F * this.delta)));
      this.hover.put(var1, var3);
      return var3;
   }

   private boolean hot(float var1, float var2, float var3, float var4) {
      return this.mx >= (double)var1 && this.my >= (double)var2 && this.mx < (double)(var1 + var3) && this.my < (double)(var2 + var4);
   }

   private void button(
      UiRenderer var1,
      String var2,
      String var3,
      UiIcon var4,
      float var5,
      float var6,
      float var7,
      float var8,
      boolean var9,
      boolean var10,
      Runnable var11
   ) {
      boolean var12 = var9 && this.dialog == ConfigUiScreen.PendingAction.NONE && this.hot(var5, var6, var7, var8);
      if (var2.startsWith("dialog:")) {
         var12 = var9 && this.hot(var5, var6, var7, var8);
      }

      float var13 = this.animate(var2, var12 ? 1.0F : 0.0F);
      var1.round(
         var5,
         var6,
         var7,
         var8,
         this.d(12.0F),
         UiEasing.mix(
            UiRenderer.white((var10 && var9 ? 0.07F : 0.035F) + 0.04F * var13), UiPalette.accent(0.09F + 0.04F * var13), var10 && var9 ? 0.25F : 0.0F
         )
      );
      var1.roundGradient(var5, var6, var7, var8, this.d(12.0F), UiRenderer.white(0.025F), UiRenderer.white(0.0F));
      var1.outline(var5, var6, var7, var8, this.d(12.0F), Math.max(1.0F, this.unit * 0.9F), UiRenderer.white(var9 ? 0.08F + 0.075F * var13 : 0.035F));
      int var14 = UiRenderer.white(var9 ? 0.84F + 0.12F * var13 : 0.26F);
      if (var4 != null) {
         var1.icon(var4, var5 + this.d(13.0F), var6 + (var8 - this.d(15.0F)) / 2.0F, this.d(15.0F), var14);
      }

      var1.textCentered(
         var3, var5 + var7 / 2.0F + (var4 == null ? 0.0F : this.d(9.0F)), var6 + (var8 - this.d(11.5F)) / 2.0F - this.d(0.5F), this.d(11.5F), 1, var14
      );
      if (var9 && (this.dialog == ConfigUiScreen.PendingAction.NONE || var2.startsWith("dialog:"))) {
         this.hits.add(new ConfigUiScreen.ActionButton(var5, var6, var7, var8, var11));
      }
   }

   private void iconButton(UiRenderer var1, String var2, UiIcon var3, String var4, float var5, float var6, float var7, boolean var8, Runnable var9) {
      float var10 = this.animate(var2, var8 && this.dialog == ConfigUiScreen.PendingAction.NONE && this.hot(var5, var6, var7, var7) ? 1.0F : 0.0F);
      var1.round(var5, var6, var7, var7, this.d(10.0F), UiRenderer.white(0.02F + 0.075F * var10));
      var1.icon(
         var3,
         var5 + (var7 - this.d(16.0F)) / 2.0F,
         var6 + (var7 - this.d(16.0F)) / 2.0F,
         this.d(16.0F),
         UiRenderer.white(var8 ? 0.55F + 0.4F * var10 : 0.25F)
      );
      if (var10 > 0.35F) {
         float var11 = var1.textWidth(var4, this.d(10.0F), 0) + this.d(16.0F);
         float var12 = var5 + var7 / 2.0F - var11 / 2.0F;
         var1.round(var12, var6 - this.d(29.0F), var11, this.d(24.0F), this.d(8.0F), UiPalette.glass(0.96F));
         var1.textCentered(var4, var5 + var7 / 2.0F, var6 - this.d(23.0F), this.d(10.0F), 0, TEXT);
      }

      if (var8 && this.dialog == ConfigUiScreen.PendingAction.NONE) {
         this.hits.add(new ConfigUiScreen.ActionButton(var5, var6, var7, var7, var9));
      }
   }

   private void begin(ConfigUiScreen.PendingAction var1, String var2, String var3) {
      this.dialog = var1;
      this.target = var2;
      this.input = var3;
      this.selectAll = var1 == ConfigUiScreen.PendingAction.RENAME;
      this.status = "";
      this.error = false;
      this.caret = 0.0F;
      UiAudio.play(UiAudio.Cue.OPEN);
   }

   private void drawDialog(UiRenderer var1, boolean var2) {
      this.hits.clear();
      var1.round(this.x, this.y, this.width, this.height, this.d(22.0F), UiRenderer.argb(0.42F, 5, 6, 9));
      float var3 = this.d(444.0F);
      float var4 = this.d(222.0F);
      float var5 = this.x + (this.width - var3) / 2.0F;
      float var6 = this.y + (this.height - var4) / 2.0F;
      var1.shadow(var5, var6, var3, var4, this.d(20.0F), this.d(30.0F), UiRenderer.argb(0.55F, 0, 0, 0));
      var1.round(var5, var6, var3, var4, this.d(20.0F), UiPalette.glass(0.94F));
      var1.roundGradient(var5, var6, var3, var4, this.d(20.0F), UiRenderer.white(0.05F), UiRenderer.white(0.0F));
      var1.outline(var5, var6, var3, var4, this.d(20.0F), Math.max(1.0F, this.unit * 0.9F), UiRenderer.white(0.1F));
      boolean var7 = this.dialog == ConfigUiScreen.PendingAction.CREATE || this.dialog == ConfigUiScreen.PendingAction.RENAME;

      String var8 = switch (this.dialog) {
         case CREATE -> "New config";
         case RENAME -> "Rename config";
         case DELETE -> "Delete config?";
         default -> "Reset all?";
      };
      var1.text(var8, var5 + this.d(24.0F), var6 + this.d(22.0F), this.d(19.0F), 1, TEXT);
      String var9 = var7
         ? "Name"
         : (this.dialog == ConfigUiScreen.PendingAction.DELETE ? "Remove this saved config." : "Reset modules, settings, binds and layout.");
      var1.text(var1.ellipsize(var9, var3 - this.d(48.0F), this.d(11.0F), 0), var5 + this.d(24.0F), var6 + this.d(54.0F), this.d(11.0F), 0, SUB);
      if (var7) {
         float var10 = var5 + this.d(24.0F);
         float var11 = var6 + this.d(83.0F);
         float var12 = var3 - this.d(48.0F);
         float var13 = this.d(43.0F);
         var1.round(var10, var11, var12, var13, this.d(12.0F), UiRenderer.white(0.055F));
         var1.outline(var10, var11, var12, var13, this.d(12.0F), Math.max(1.0F, this.unit), UiPalette.accent(0.35F));
         if (this.selectAll && !this.input.isEmpty()) {
            var1.round(
               var10 + this.d(12.0F),
               var11 + this.d(10.0F),
               Math.min(var12 - this.d(24.0F), var1.textWidth(this.input, this.d(13.0F), 0)),
               this.d(22.0F),
               this.d(4.0F),
               UiPalette.accent(0.18F)
            );
         }

         var1.pushClip(var10 + this.d(12.0F), var11, var12 - this.d(24.0F), var13);
         float var14 = var1.textWidth(this.input, this.d(13.0F), 0);
         float var15 = Math.max(0.0F, var14 - var12 + this.d(28.0F));
         var1.text(
            this.input.isEmpty() ? "Config name" : this.input,
            var10 + this.d(13.0F) - var15,
            var11 + this.d(13.0F),
            this.d(13.0F),
            0,
            this.input.isEmpty() ? SUB : TEXT
         );
         if (this.caret % 1.2F < 0.6F) {
            var1.rect(var10 + this.d(14.0F) + var14 - var15, var11 + this.d(11.0F), Math.max(1.0F, this.unit), this.d(21.0F), TEXT);
         }

         var1.popClip();
      } else {
         var1.text(
            this.dialog == ConfigUiScreen.PendingAction.DELETE ? this.input : "Your saved configs will remain available.",
            var5 + this.d(24.0F),
            var6 + this.d(99.0F),
            this.d(13.0F),
            1,
            TEXT
         );
      }

      if (this.error) {
         var1.text(var1.ellipsize(this.status, var3 - this.d(48.0F), this.d(10.5F), 0), var5 + this.d(24.0F), var6 + this.d(140.0F), this.d(10.5F), 0, TEXT);
      }

      this.button(var1, "dialog:cancel", "Cancel", null, var5 + this.d(24.0F), var6 + var4 - this.d(55.0F), this.d(116.0F), this.d(34.0F), var2, false, () -> {
         this.dialog = ConfigUiScreen.PendingAction.NONE;
         this.status = "";
         this.error = false;
      });

      String var16 = switch (this.dialog) {
         case CREATE -> "Create";
         case RENAME -> "Rename";
         case DELETE -> "Delete";
         default -> "Reset All";
      };
      this.button(
         var1,
         "dialog:confirm",
         var16,
         null,
         var5 + var3 - this.d(146.0F),
         var6 + var4 - this.d(55.0F),
         this.d(122.0F),
         this.d(34.0F),
         var2,
         true,
         this::confirm
      );
   }

   private void confirm() {
      try {
         switch (this.dialog) {
            case CREATE:
               this.selection = this.library.get().create(this.input);
               this.status = "Config created.";
               break;
            case RENAME:
               this.library.get().rename(this.target, this.input);
               this.status = "Config renamed.";
               break;
            case DELETE:
               this.library.get().delete(this.target);
               this.selection = this.library.get().selected();
               this.status = "Config deleted.";
               break;
            case RESET:
               this.library.get().resetCurrent();
               this.status = "Reset complete.";
               break;
            default:
               return;
         }

         this.dialog = ConfigUiScreen.PendingAction.NONE;
         this.error = false;
         UiAudio.play(UiAudio.Cue.CONFIRM);
      } catch (RuntimeException var2) {
         this.fail(var2);
      }
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      if (!this.active()) {
         return false;
      } else if (this.opened && !(this.progress < 0.6F) && var5 == 0) {
         for (int var6 = this.hits.size() - 1; var6 >= 0; var6--) {
            ConfigUiScreen.ActionButton var7 = this.hits.get(var6);
            if (var1 >= (double)var7.x && var3 >= (double)var7.y && var1 < (double)(var7.x + var7.w) && var3 < (double)(var7.y + var7.h)) {
               var7.action.run();
               return true;
            }
         }

         if (this.dialog == ConfigUiScreen.PendingAction.NONE
            && (!(var1 >= (double)this.x) || !(var3 >= (double)this.y) || !(var1 < (double)(this.x + this.width)) || !(var3 < (double)(this.y + this.height)))) {
            this.close();
         }

         return true;
      } else {
         return true;
      }
   }

   public boolean keyPressed(int var1, int var2) {
      if (!this.active()) {
         return false;
      } else if (var1 == 256) {
         if (this.dialog != ConfigUiScreen.PendingAction.NONE) {
            this.dialog = ConfigUiScreen.PendingAction.NONE;
            this.error = false;
            this.status = "";
         } else {
            this.close();
         }

         return true;
      } else {
         boolean var3 = this.dialog == ConfigUiScreen.PendingAction.CREATE || this.dialog == ConfigUiScreen.PendingAction.RENAME;
         boolean var4 = (var2 & 2) != 0;
         if (var1 != 257 && var1 != 335) {
            if (var3) {
               if (var4 && var1 == 65) {
                  this.selectAll = true;
               } else if (var4 && var1 == 67) {
                  this.copy.accept(this.input);
               } else if (var4 && var1 == 86) {
                  String var5 = this.clipboard.get().replaceAll("[\\p{Cntrl}]", "");
                  this.input = (this.selectAll ? "" : this.input) + var5;
                  this.input = this.input.substring(0, Math.min(32, this.input.length()));
                  this.selectAll = false;
               } else if (var1 == 259 || var1 == 261) {
                  this.input = !this.selectAll && !var4 ? this.input.substring(0, Math.max(0, this.input.length() - 1)) : "";
                  this.selectAll = false;
               }

               this.caret = 0.0F;
            }

            return true;
         } else {
            if (this.dialog != ConfigUiScreen.PendingAction.NONE) {
               this.confirm();
            }

            return true;
         }
      }
   }

   public boolean charTyped(char var1) {
      if (!this.active()) {
         return false;
      } else {
         if (!Character.isISOControl(var1) && (this.dialog == ConfigUiScreen.PendingAction.CREATE || this.dialog == ConfigUiScreen.PendingAction.RENAME)) {
            if (this.selectAll) {
               this.input = "";
            }

            if (this.input.length() < 32) {
               this.input = this.input + var1;
            }

            this.selectAll = false;
            this.caret = 0.0F;
         }

         return true;
      }
   }

   private static enum PendingAction {
      NONE,
      CREATE,
      RENAME,
      DELETE,
      RESET;
   }

   private static record ActionButton(float x, float y, float w, float h, Runnable action) {
   }
}
