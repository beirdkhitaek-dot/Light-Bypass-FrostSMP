package cherryblossom.schematic;
import cherryblossom.CherryBlossom;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
public final class SchematicIntegration{
    public static final SchematicIntegration MANAGER=new SchematicIntegration();
    public static final KeyBinding.Category CATEGORY=KeyBinding.Category.create(Identifier.of("cherryblossom","schematic"));
    public void setEnabled(cherryblossom.module.Module module,boolean enabled){module.toggle(enabled);}
    public void save(){CherryBlossom.INSTANCE.getSettingsManager().saveNow();cherryblossom.integration.CherryGui.saveSettings();}
    public static boolean freecam(){return active(cherryblossom.feature.FreecamModule.class);}
    public static boolean freelook(){return active(cherryblossom.feature.FreelookModule.class);}
    private static boolean active(Class<? extends cherryblossom.module.Module> type){var module=CherryBlossom.INSTANCE.getModuleManager().getModuleByClass(type);return module!=null&&module.isEnabled();}
    public static void closeGui(){
        try{var type=Class.forName("dev.cherryblossom.client.CherryBlossomController");type.getMethod("forceOff").invoke(type.getMethod("get").invoke(null));}
        catch(ReflectiveOperationException error){throw new IllegalStateException("Could not open schematic setup",error);}
    }
}
