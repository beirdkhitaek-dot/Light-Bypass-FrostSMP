package cherryblossom.schematic.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.util.Arrays;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public final class Esp3D {
   private static final Identifier LATE = Identifier.of("cherryblossom", "esp_flush");
   private static final Esp3D.Recorder QUADS = new Esp3D.Recorder();
   private static final Esp3D.Recorder LINES = new Esp3D.Recorder();
   private static final Esp3D.Recorder GLOW = new Esp3D.Recorder();
   private static final Esp3D.Recorder SOFT = new Esp3D.Recorder();
   private static final Esp3D.Recorder SOFT_LINES = new Esp3D.Recorder();
   private static RenderLayer layer;
   private static boolean layerFailed;
   private static RenderLayer softLayer;
   private static boolean softFailed;
   private static Matrix4f camMatrix;
   private static Matrix4f camPose = new Matrix4f();
   private static double camX;
   private static double camY;
   private static double camZ;
   private static Immediate onTop;
   private static boolean onTopBroken;

   public static void init() {
      WorldRenderEvents.AFTER_ENTITIES.addPhaseOrdering(Event.DEFAULT_PHASE, LATE);
      WorldRenderEvents.AFTER_ENTITIES.register(LATE, Esp3D::flushInWorld);
      WorldRenderEvents.END_MAIN.register(Esp3D::flushOnTop);
   }

   public static Matrix4f matrix(WorldRenderContext context) {
      Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
      Matrix4f pose = new Matrix4f(context.matrices().peek().getPositionMatrix());
      Matrix4f m = new Matrix4f(pose).translate((float)(-cam.x), (float)(-cam.y), (float)(-cam.z));
      camPose = pose;
      camMatrix = new Matrix4f(m);
      camX = cam.x;
      camY = cam.y;
      camZ = cam.z;
      return m;
   }

   public static boolean isCameraMatrix(Matrix4fc m) {
      return camMatrix != null && (camMatrix == m || camMatrix.equals(m));
   }

   public static Matrix4f pose() {
      return camPose;
   }

   public static Vec3d cameraPos() {
      return new Vec3d(camX, camY, camZ);
   }

   public static Vec3d tracerStart() {
      Camera camera = MinecraftClient.getInstance().gameRenderer.getCamera();
      return camera.getCameraPos().add(Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.6));
   }

   public static VertexConsumer quads(WorldRenderContext context) {
      return QUADS;
   }

   public static VertexConsumer lines(WorldRenderContext context) {
      return LINES;
   }

   public static VertexConsumer glow(WorldRenderContext context) {
      return GLOW;
   }

   public static VertexConsumer soft(WorldRenderContext context) {
      return SOFT;
   }

   public static VertexConsumer softLines(WorldRenderContext context) {
      return SOFT_LINES;
   }

   private static RenderLayer softLayer() {
      if (softLayer == null && !softFailed) {
         try {
            RenderPipeline pipeline = cherryblossom.mixin.RenderPipelinesAccessor.cherryblossom$register(
               RenderPipeline.builder(cherryblossom.mixin.RenderPipelinesAccessor.cherryblossom$getTransformsSnippet())
                  .withLocation(Identifier.of("cherryblossom", "pipeline/schematic_soft"))
                  .withVertexShader("core/position_color").withFragmentShader("core/position_color")
                  .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                  .withBlend(BlendFunction.TRANSLUCENT)
                  .withCull(false)
                  .withDepthWrite(false)
                  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                  .build()
            );
            softLayer = cherryblossom.mixin.RenderLayerAccessor.cherryblossom$create("cherryblossom_schematic_soft", RenderSetup.builder(pipeline).translucent().build());
         } catch (Throwable var1) {
            softFailed = true;
         }
      }

      return softLayer != null ? softLayer : RenderLayers.lightning();
   }

   private static RenderLayer layer() {
      if (layer == null && !layerFailed) {
         try {
            RenderPipeline pipeline = cherryblossom.mixin.RenderPipelinesAccessor.cherryblossom$register(
               RenderPipeline.builder(cherryblossom.mixin.RenderPipelinesAccessor.cherryblossom$getTransformsSnippet())
                  .withLocation(Identifier.of("cherryblossom", "pipeline/schematic_esp"))
                  .withVertexShader("core/position_color").withFragmentShader("core/position_color")
                  .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                  .withBlend(BlendFunction.TRANSLUCENT)
                  .withCull(false)
                  .withDepthWrite(false)
                  .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                  .build()
            );
            layer = cherryblossom.mixin.RenderLayerAccessor.cherryblossom$create("cherryblossom_schematic_esp", RenderSetup.builder(pipeline).translucent().build());
         } catch (Throwable var1) {
            layerFailed = true;
         }
      }

      return layer != null ? layer : RenderLayers.debugQuads();
   }

   private static void flushInWorld(WorldRenderContext context) {
      try {
         if (SOFT.count > 0 || SOFT_LINES.count > 0) {
            VertexConsumer out = context.consumers().getBuffer(softLayer());
            SOFT.emitQuads(out);
            SOFT_LINES.emitLines(out);
         }

         if (GLOW.count > 0) {
            GLOW.emitQuads(context.consumers().getBuffer(RenderLayers.lightning()));
         }

         if (onTopBroken && (QUADS.count > 0 || LINES.count > 0)) {
            VertexConsumer out = context.consumers().getBuffer(layer());
            QUADS.emitQuads(out);
            LINES.emitLines(out);
            QUADS.count = 0;
            LINES.count = 0;
         }
      } finally {
         GLOW.count = 0;
         SOFT.count = 0;
         SOFT_LINES.count = 0;
      }
   }

   private static void flushOnTop(WorldRenderContext context) {
      if (!onTopBroken) {
         try {
            if (QUADS.count > 0 || LINES.count > 0) {
               if (onTop == null) {
                  onTop = VertexConsumerProvider.immediate(new BufferAllocator(262144));
               }

               VertexConsumer out = onTop.getBuffer(layer());
               QUADS.emitQuads(out);
               LINES.emitLines(out);
               onTop.draw();
            }
         } catch (Throwable var5) {
            onTopBroken = true;
            System.out.println("[CherryBlossom] ESP on-top pass failed, drawing ESP with the world instead: " + var5);
         } finally {
            QUADS.count = 0;
            LINES.count = 0;
         }
      }
   }

   private static final class Recorder implements VertexConsumer {
      float[] pos = new float[3072];
      int[] color = new int[1024];
      float[] width = new float[1024];
      int count;
      private final Vector3f tmp = new Vector3f();
      private final float[] sideA = new float[3];
      private final float[] sideB = new float[3];

      private void grow() {
         int n = this.color.length * 2;
         this.pos = Arrays.copyOf(this.pos, n * 3);
         this.color = Arrays.copyOf(this.color, n);
         this.width = Arrays.copyOf(this.width, n);
      }

      @Override
      public VertexConsumer vertex(Matrix4fc matrix, float x, float y, float z) {
         Vector3f v = Esp3D.isCameraMatrix(matrix)
            ? Esp3D.camPose.transformPosition((float)(x - Esp3D.camX), (float)(y - Esp3D.camY), (float)(z - Esp3D.camZ), this.tmp)
            : matrix.transformPosition(x, y, z, this.tmp);
         return this.vertex(v.x(), v.y(), v.z());
      }

      @Override
      public VertexConsumer vertex(float x, float y, float z) {
         if (this.count == this.color.length) {
            this.grow();
         }

         int i = this.count++;
         this.pos[i * 3] = x;
         this.pos[i * 3 + 1] = y;
         this.pos[i * 3 + 2] = z;
         this.color[i] = -1;
         this.width[i] = 1.5F;
         return this;
      }

      @Override
      public VertexConsumer color(int red, int green, int blue, int alpha) {
         return this.color((alpha & 0xFF) << 24 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF);
      }

      @Override
      public VertexConsumer color(int argb) {
         if (this.count > 0) {
            this.color[this.count - 1] = argb;
         }

         return this;
      }

      @Override
      public VertexConsumer lineWidth(float width) {
         if (this.count > 0) {
            this.width[this.count - 1] = width;
         }

         return this;
      }

      @Override
      public VertexConsumer texture(float u, float v) {
         return this;
      }

      @Override
      public VertexConsumer overlay(int u, int v) {
         return this;
      }

      @Override
      public VertexConsumer light(int u, int v) {
         return this;
      }

      @Override
      public VertexConsumer normal(float x, float y, float z) {
         return this;
      }

      void emitQuads(VertexConsumer out) {
         int n = this.count - this.count % 4;

         for (int i = 0; i < n; i++) {
            out.vertex(this.pos[i * 3], this.pos[i * 3 + 1], this.pos[i * 3 + 2]).color(this.color[i]);
         }
      }

      void emitLines(VertexConsumer out) {
         MinecraftClient mc = MinecraftClient.getInstance();
         Camera cam = mc.gameRenderer.getCamera();
         Vector3fc f = cam.getHorizontalPlane();
         float fx = f.x();
         float fy = f.y();
         float fz = f.z();
         int fbH = Math.max(1, mc.getWindow().getFramebufferHeight());
         double fov = Math.toRadians(mc.options.getFov().getValue().intValue());
         float worldPerPx = (float)(2.0 * Math.tan(fov / 2.0) / fbH);
         float near = 0.06F;

         for (int i = 0; i + 1 < this.count; i += 2) {
            float ax = this.pos[i * 3];
            float ay = this.pos[i * 3 + 1];
            float az = this.pos[i * 3 + 2];
            float bx = this.pos[i * 3 + 3];
            float by = this.pos[i * 3 + 4];
            float bz = this.pos[i * 3 + 5];
            int ca = this.color[i];
            int cb = this.color[i + 1];
            float da = ax * fx + ay * fy + az * fz;
            float db = bx * fx + by * fy + bz * fz;
            if (!(da < near) || !(db < near)) {
               if (da < near || db < near) {
                  float t = (near - da) / (db - da);
                  float cx = ax + (bx - ax) * t;
                  float cy = ay + (by - ay) * t;
                  float cz = az + (bz - az) * t;
                  if (da < near) {
                     ax = cx;
                     ay = cy;
                     az = cz;
                     da = near;
                  } else {
                     bx = cx;
                     by = cy;
                     bz = cz;
                     db = near;
                  }
               }

               float dx = bx - ax;
               float dy = by - ay;
               float dz = bz - az;
               float px = Math.max(0.5F, Math.min(this.width[i], 6.0F)) * 1.15F;
               float[] na = this.sideA;
               float[] nb = this.sideB;
               if (side(dx, dy, dz, ax, ay, az, na) && side(dx, dy, dz, bx, by, bz, nb)) {
                  float ka = da * worldPerPx;
                  float kb = db * worldPerPx;
                  float coreA = px * 0.5F * ka;
                  float coreB = px * 0.5F * kb;
                  float edgeA = coreA + ka * 0.9F;
                  float edgeB = coreB + kb * 0.9F;
                  int clearA = ca & 16777215;
                  int clearB = cb & 16777215;
                  strip(out, ax, ay, az, bx, by, bz, na, nb, -coreA, coreA, -coreB, coreB, ca, ca, cb, cb);
                  strip(out, ax, ay, az, bx, by, bz, na, nb, coreA, edgeA, coreB, edgeB, ca, clearA, cb, clearB);
                  strip(out, ax, ay, az, bx, by, bz, na, nb, -edgeA, -coreA, -edgeB, -coreB, clearA, ca, clearB, cb);
               }
            }
         }
      }

      private static void strip(
         VertexConsumer out,
         float ax,
         float ay,
         float az,
         float bx,
         float by,
         float bz,
         float[] na,
         float[] nb,
         float a0,
         float a1,
         float b0,
         float b1,
         int ca0,
         int ca1,
         int cb0,
         int cb1
      ) {
         out.vertex(ax + na[0] * a0, ay + na[1] * a0, az + na[2] * a0).color(ca0);
         out.vertex(ax + na[0] * a1, ay + na[1] * a1, az + na[2] * a1).color(ca1);
         out.vertex(bx + nb[0] * b1, by + nb[1] * b1, bz + nb[2] * b1).color(cb1);
         out.vertex(bx + nb[0] * b0, by + nb[1] * b0, bz + nb[2] * b0).color(cb0);
      }

      private static boolean side(float dx, float dy, float dz, float px, float py, float pz, float[] out) {
         float cx = dy * pz - dz * py;
         float cy = dz * px - dx * pz;
         float cz = dx * py - dy * px;
         float len = (float)Math.sqrt(cx * cx + cy * cy + cz * cz);
         if (len < 1.0E-7F) {
            return false;
         } else {
            out[0] = cx / len;
            out[1] = cy / len;
            out[2] = cz / len;
            return true;
         }
      }
   }
}
