package cherryblossom.schematic.setting;
public class ModeSetting extends Setting<String>{
    protected final cherryblossom.module.setting.Setting backing;
    private final String[] modes;
    public ModeSetting(String name,String[] modes,String value){this(name,"",modes,value);}
    public ModeSetting(String name,String description,String[] modes,String value){super(name);this.modes=modes.clone();backing=modes.length==0?new cherryblossom.module.setting.StringSetting(name,value):new cherryblossom.module.setting.ChoiceSetting(name,value,java.util.List.of(modes));backing.setDescription(description);}
    public String get(){return getValue();}
    public String getValue(){return backing instanceof cherryblossom.module.setting.StringSetting text?text.getValue():((cherryblossom.module.setting.ChoiceSetting)backing).getMode();}
    public String[] getModes(){return modes.clone();}
    public boolean is(String value){return get().equals(value);}
    public void setValue(String value){if(backing instanceof cherryblossom.module.setting.StringSetting text)text.setValue(value);else if(!((cherryblossom.module.setting.ChoiceSetting)backing).setMode(value))throw new IllegalArgumentException("Invalid "+name());notifyChanged();}
    public cherryblossom.module.setting.Setting cherryblossom(){return backing;}
}
