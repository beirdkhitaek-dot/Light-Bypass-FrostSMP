package cherryblossom.schematic.setting;
public final class SliderSetting extends Setting<Float>{
    private final cherryblossom.module.setting.NumberSetting backing;
    public SliderSetting(String name,float min,float max,float value,float step){this(name,min,max,value,step,"");}
    public SliderSetting(String name,float min,float max,float value,float step,String suffix){super(name);backing=new cherryblossom.module.setting.NumberSetting(name,min,max,value,step);}
    public float getFloat(){return (float)backing.getValue();}
    public int getInt(){return Math.round(getFloat());}
    public Float getValue(){return getFloat();}
    public void setValue(Float value){backing.getValue(value);notifyChanged();}
    public cherryblossom.module.setting.Setting cherryblossom(){return backing;}
}
