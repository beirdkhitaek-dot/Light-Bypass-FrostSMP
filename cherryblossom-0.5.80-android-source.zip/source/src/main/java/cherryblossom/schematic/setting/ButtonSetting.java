package cherryblossom.schematic.setting;
public final class ButtonSetting extends Setting<Boolean>{
    private final cherryblossom.module.setting.ButtonSetting backing;
    public ButtonSetting(String name,String description,Runnable action){super(name);backing=new cherryblossom.module.setting.ButtonSetting(name,action);backing.setDescription(description);}
    public Boolean getValue(){return false;}
    public void setValue(Boolean value){if(value)backing.run();}
    public cherryblossom.module.setting.Setting cherryblossom(){return backing;}
}
