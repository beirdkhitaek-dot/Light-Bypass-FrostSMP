package cherryblossom.schematic.setting;
public final class BooleanSetting extends Setting<Boolean>{
    private final cherryblossom.module.setting.BooleanSetting backing;
    public BooleanSetting(String name,boolean value){super(name);backing=new cherryblossom.module.setting.BooleanSetting(name,value);}
    public boolean get(){return backing.getValue();}
    public Boolean getValue(){return get();}
    public void setValue(Boolean value){backing.setValue(value);notifyChanged();}
    public cherryblossom.module.setting.Setting cherryblossom(){return backing;}
}
