package cherryblossom.schematic.setting;
import java.util.List;
import java.util.function.Supplier;
public final class SchematicFileSetting extends ModeSetting{
    private final Supplier<List<String>> source;
    public SchematicFileSetting(String name,String description,Supplier<List<String>> source){super(name,description,new String[0],"");this.source=source;}
    @Override public String[] getModes(){return source.get().toArray(String[]::new);}
    @Override public String get(){return getValue().isEmpty()?"none":getValue();}
}
