package cherryblossom.schematic.setting;

/** Schematic-only settings bridge backed by CherryBlossom's persisted settings. */
public abstract class Setting<T> extends cherryblossom.module.ext.setting.Setting {
    protected Setting(String name){super(name);}
    public abstract T getValue();
    public abstract void setValue(T value);
    @Override protected Object snapshot(){return getValue();}
}
