package cherryblossom.schematic;

import cherryblossom.feature.AutoSchematicBuilderModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import java.nio.file.*;

/** Cherry's smooth glass UI; no foreign client GUI or assets are loaded. */
public final class SchematicSetupScreen extends Screen {
    private final AutoSchematicBuilderModule module;
    private final Screen parent;
    public SchematicSetupScreen(AutoSchematicBuilderModule module,Screen parent){super(Text.literal("Auto SchematicBuilder"));this.module=module;this.parent=parent instanceof SchematicSetupScreen?null:parent;}
    @Override public boolean shouldPause(){return false;}
    @Override protected void init(){super.init();SchematicScreenBridge.releaseCursor();}
    @Override public void renderBackground(DrawContext context,int mx,int my,float delta){}
    @Override public void render(DrawContext context,int mx,int my,float delta){
        SchematicScreenBridge.releaseCursor();
        if(!SchematicScreenBridge.render(this,module,width,height,mx,my))context.drawCenteredTextWithShadow(textRenderer,"Preparing CherryBlossom UI...",width/2,height/2,0xFFFFA5CA);
    }
    @Override public boolean mouseClicked(Click click,boolean doubled){return click.button()==0&&SchematicScreenBridge.click(this,click.x(),click.y());}
    @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){return SchematicScreenBridge.scroll(this,x,y,vertical);}
    @Override public boolean keyPressed(KeyInput key){
        switch(key.key()){
            case 82->module.rotateQuarter();case 262->module.nudge(1,0,0);case 263->module.nudge(-1,0,0);
            case 264->module.nudge(0,0,1);case 265->module.nudge(0,0,-1);case 266->module.nudge(0,1,0);case 267->module.nudge(0,-1,0);
            case 257,335->{if(module.loadedInfo()!=null){module.setBuildingFromScreen(true);start();}}
            default->{return super.keyPressed(key);}
        }
        return true;
    }
    public void start(){SchematicIntegration.MANAGER.save();MinecraftClient.getInstance().setScreen(null);}
    @Override public void close(){SchematicIntegration.MANAGER.save();MinecraftClient.getInstance().setScreen(parent);}
    @Override public void removed(){SchematicScreenBridge.close(this);super.removed();}
    public void openFolder(){
        try{Path folder=AutoSchematicBuilderModule.folder();Files.createDirectories(folder);net.minecraft.util.Util.getOperatingSystem().open(folder.toFile());}
        catch(Exception error){if(client.player!=null)client.player.sendMessage(Text.literal("Schematics folder: "+AutoSchematicBuilderModule.folder()),false);}
    }
}
