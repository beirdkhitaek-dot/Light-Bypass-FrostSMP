package cherryblossom.schematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public final class BotDig {
   private static volatile long lastNs;

   private BotDig() {
   }

   public static boolean active() {
      return System.nanoTime() - lastNs < 150000000L;
   }

   public static void dig(MinecraftClient mc, BlockPos pos, Direction side) {
      lastNs = System.nanoTime();
      if (mc.interactionManager.updateBlockBreakingProgress(pos, side)) {
         mc.world.spawnBlockBreakingParticle(pos, side);
         mc.player.swingHand(Hand.MAIN_HAND);
      }
   }

   public static void stop(MinecraftClient mc) {
      lastNs = 0L;
      if (mc.interactionManager != null) {
         mc.interactionManager.cancelBlockBreaking();
      }
   }
}
