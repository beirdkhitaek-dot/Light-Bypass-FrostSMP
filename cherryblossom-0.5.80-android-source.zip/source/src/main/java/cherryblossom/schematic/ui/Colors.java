package cherryblossom.schematic.ui;

public final class Colors {
   private Colors() {
   }

   public static int argb(int a, int r, int g, int b) {
      return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
   }

   public static int rgb(int r, int g, int b) {
      return argb(255, r, g, b);
   }

   public static int withAlpha(int color, int alpha) {
      return color & 16777215 | (alpha & 0xFF) << 24;
   }

   public static int withAlpha(int color, float alpha) {
      return withAlpha(color, (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   public static int alpha(int c) {
      return c >>> 24 & 0xFF;
   }

   public static int red(int c) {
      return c >> 16 & 0xFF;
   }

   public static int green(int c) {
      return c >> 8 & 0xFF;
   }

   public static int blue(int c) {
      return c & 0xFF;
   }

   public static int lerp(int a, int b, float t) {
      t = Math.clamp(t, 0.0F, 1.0F);
      return argb(
         (int)(alpha(a) + (alpha(b) - alpha(a)) * t),
         (int)(red(a) + (red(b) - red(a)) * t),
         (int)(green(a) + (green(b) - green(a)) * t),
         (int)(blue(a) + (blue(b) - blue(a)) * t)
      );
   }

   public static int lighten(int c, float t) {
      return lerp(c, withAlpha(16777215, alpha(c)), t);
   }

   public static int darken(int c, float t) {
      return lerp(c, withAlpha(0, alpha(c)), t);
   }

   public static float[] rgbToHsv(int c) {
      float r = red(c) / 255.0F;
      float g = green(c) / 255.0F;
      float b = blue(c) / 255.0F;
      float max = Math.max(r, Math.max(g, b));
      float min = Math.min(r, Math.min(g, b));
      float d = max - min;
      float h;
      if (d == 0.0F) {
         h = 0.0F;
      } else if (max == r) {
         h = 60.0F * ((g - b) / d % 6.0F);
      } else if (max == g) {
         h = 60.0F * ((b - r) / d + 2.0F);
      } else {
         h = 60.0F * ((r - g) / d + 4.0F);
      }

      if (h < 0.0F) {
         h += 360.0F;
      }

      float s = max == 0.0F ? 0.0F : d / max;
      return new float[]{h, s, max};
   }

   public static int hsvToRgb(float h, float s, float v) {
      float c = v * s;
      float x = c * (1.0F - Math.abs(h / 60.0F % 2.0F - 1.0F));
      float m = v - c;
      float r;
      float g;
      float b;
      if (h < 60.0F) {
         r = c;
         g = x;
         b = 0.0F;
      } else if (h < 120.0F) {
         r = x;
         g = c;
         b = 0.0F;
      } else if (h < 180.0F) {
         r = 0.0F;
         g = c;
         b = x;
      } else if (h < 240.0F) {
         r = 0.0F;
         g = x;
         b = c;
      } else if (h < 300.0F) {
         r = x;
         g = 0.0F;
         b = c;
      } else {
         r = c;
         g = 0.0F;
         b = x;
      }

      return rgb(Math.round((r + m) * 255.0F), Math.round((g + m) * 255.0F), Math.round((b + m) * 255.0F));
   }
}
