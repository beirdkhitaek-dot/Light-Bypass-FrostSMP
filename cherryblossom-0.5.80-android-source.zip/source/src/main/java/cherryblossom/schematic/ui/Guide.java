package cherryblossom.schematic.ui;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
public final class Guide{
    public enum Visual{FILE,KEY,CHEST,BUILD,CAMERA,DONE}
    public record Step(Visual visual,String title,String description,String... keys){}
    public static String key(KeyBinding binding){return binding.getBoundKeyLocalizedText().getString();}
    public static void open(String title,Icons.Type icon,List<Step> steps){
        var mc=MinecraftClient.getInstance();Screen parent=mc.currentScreen;cherryblossom.schematic.SchematicIntegration.closeGui();
        mc.setScreen(new Screen(Text.literal(title)){
            protected void init(){addDrawableChild(ButtonWidget.builder(Text.literal("Close"),b->close()).dimensions(width/2-45,height-30,90,20).build());}
            public boolean shouldPause(){return false;}
            public void close(){client.setScreen(parent);}
            public void render(DrawContext c,int mx,int my,float delta){
                HudStyle.frame();Ui.panel(c,8,8,width-16,height-16,10);Ui.centered(c,Ui.bold(title.getString()),width/2,18,1,-1);int y=40;
                for(Step step:steps){c.drawText(textRenderer,step.title(),18,y,HudStyle.accent(),false);y+=12;for(var line:textRenderer.wrapLines(Text.literal(step.description()),width-36)){c.drawText(textRenderer,line,18,y,0xFFE0CDDA,false);y+=10;}y+=8;}
                super.render(c,mx,my,delta);
            }
        });
    }
}
