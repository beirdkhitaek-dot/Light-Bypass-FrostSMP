package cherryblossom.schematic.ui;
public final class UiSounds{
    public static void click(){if(cherryblossom.module.modules.client.CherryBlossom.uiSounds.getValue())net.minecraft.client.MinecraftClient.getInstance().getSoundManager().play(net.minecraft.client.sound.PositionedSoundInstance.ui(net.minecraft.sound.SoundEvents.UI_BUTTON_CLICK.value(),1,(float)(cherryblossom.module.modules.client.CherryBlossom.uiVolume.getValue()/100)));}
}
