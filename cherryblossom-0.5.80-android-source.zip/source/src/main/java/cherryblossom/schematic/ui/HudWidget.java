package cherryblossom.schematic.ui;

public interface HudWidget {
   String widgetName();

   boolean widgetVisible();

   float[] widgetBounds();

   void widgetMoveTo(float var1, float var2, float var3, float var4);

   void widgetScale(float var1);

   default boolean widgetClick(double x, double y) {
      return false;
   }
}
