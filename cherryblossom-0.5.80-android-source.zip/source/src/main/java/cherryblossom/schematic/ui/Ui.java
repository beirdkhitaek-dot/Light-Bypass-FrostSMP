package cherryblossom.schematic.ui;

import cherryblossom.schematic.ui.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.StyleSpriteSource.Font;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

public final class Ui {
   public static int SCREEN_DIM = 939524096;
   public static int PANEL_BG = -938339561;
   public static int PANEL_BORDER = 1090519039;
   public static int DIVIDER = 822083583;
   public static int BUTTON_BG = -1944314590;
   public static int BUTTON_BG_HOVER = -1205195725;
   public static int BUTTON_BORDER = 822083583;
   public static int BUTTON_BORDER_HOVER = 1560281087;
   public static int CARD_BG = -1474815457;
   public static int CARD_BG_HOVER = -1205985241;
   public static int CARD_BG_LOCKED = -2146167528;
   public static int CARD_BORDER = 788529151;
   public static int CARD_BORDER_HOVER = 1358954495;
   public static int CARD_BORDER_ACTIVE = -758132780;
   public static int FIELD_BG = 1879048192;
   public static int BADGE_BG = -534633431;
   public static int TRACK = -13750217;
   public static int CHECK_FILL = -5855572;
   public static int PRIMARY_BG = -1776408;
   public static int PRIMARY_BG_HOVER = -1;
   public static int PRIMARY_TEXT = -15592681;
   public static int ACCENT = -3881782;
   static int PANEL_BASE = -15592681;
   static int CARD_BASE = -15197665;
   public static final int TEXT = -1447444;
   public static final int TEXT_DIM = -6644573;
   public static final int TEXT_FAINT = -10131602;
   public static final int ONLINE = -12595089;
   public static final int ERROR = -1743762;
   public static final int SUCCESS = -10300533;
   private static final Font REGULAR = new Font(Identifier.of("minecraft", "default"));
   private static final Font BOLD = new Font(Identifier.of("minecraft", "default"));

   private Ui() {
   }

   static void applyPalette(int accent, int panel, int card, float panelOpacity, float dim, boolean monochrome) {
      ACCENT = accent;
      PANEL_BASE = panel;
      CARD_BASE = card;
      SCREEN_DIM = Colors.withAlpha(0, dim);
      PANEL_BG = Colors.withAlpha(panel, panelOpacity);
      CARD_BG = Colors.withAlpha(card, 0.66F);
      CARD_BG_HOVER = Colors.withAlpha(Colors.lighten(card, 0.06F), 0.74F);
      CARD_BG_LOCKED = Colors.withAlpha(Colors.darken(card, 0.25F), 0.5F);
      BUTTON_BG = Colors.withAlpha(Colors.lighten(card, 0.02F), 0.55F);
      BUTTON_BG_HOVER = Colors.withAlpha(Colors.lighten(card, 0.09F), 0.74F);
      BADGE_BG = Colors.withAlpha(Colors.lighten(card, 0.04F), 0.9F);
      TRACK = Colors.withAlpha(Colors.lighten(card, 0.1F), 1.0F);
      CARD_BORDER_ACTIVE = Colors.withAlpha(accent, 0.82F);
      CHECK_FILL = accent;
      PRIMARY_BG = monochrome ? -1776408 : accent;
      PRIMARY_BG_HOVER = Colors.lighten(PRIMARY_BG, 0.25F);
   }

   public static TextRenderer font() {
      return MinecraftClient.getInstance().textRenderer;
   }

   public static MutableText t(String s) {
      return Text.literal(s).styled(st -> st.withFont(REGULAR));
   }

   public static MutableText bold(String s) {
      return Text.literal(s).styled(st -> st.withFont(BOLD));
   }

   public static int width(Text t) {
      return font().getWidth(t);
   }

   public static int width(String s) {
      return font().getWidth(t(s));
   }

   public static int width(Text t, float scale) {
      return (int)Math.ceil(font().getWidth(t) * scale);
   }

   public static void text(DrawContext ctx, Text t, float x, float y, int color) {
      text(ctx, t, x, y, 1.0F, color);
   }

   public static void text(DrawContext ctx, String s, float x, float y, int color) {
      text(ctx, t(s), x, y, 1.0F, color);
   }

   public static void text(DrawContext ctx, Text t, float x, float y, float scale, int color) {
      int c = Gfx.fade(color);
      if (c >>> 24 >= 8) {
         float s = Gfx.scale();
         float sx = Math.round(x * s) / s;
         float sy = Math.round(y * s) / s;
         Matrix3x2fStack m = ctx.getMatrices();
         m.pushMatrix();
         m.translate(sx, sy);
         if (scale != 1.0F) {
            m.scale(scale, scale);
         }

         ctx.drawText(font(), t, 0, 0, c, false);
         m.popMatrix();
      }
   }

   public static void centered(DrawContext ctx, Text t, float cx, float y, float scale, int color) {
      text(ctx, t, cx - font().getWidth(t) * scale / 2.0F, y, scale, color);
   }

   public static Text fit(Text t, String raw, boolean bold, int maxWidth, float scale) {
      if (width(t, scale) <= maxWidth) {
         return t;
      } else {
         String s = raw;

         while (!s.isEmpty()) {
            s = s.substring(0, s.length() - 1);
            Text candidate = bold ? bold(s.stripTrailing() + "...") : t(s.stripTrailing() + "...");
            if (width(candidate, scale) <= maxWidth) {
               return candidate;
            }
         }

         return Text.empty();
      }
   }

   public static void round(DrawContext ctx, float x, float y, float w, float h, float radius, int color) {
      Gfx.roundRect(ctx, x, y, w, h, radius, color);
   }

   public static void outline(DrawContext ctx, float x, float y, float w, float h, float radius, int color) {
      Gfx.roundOutline(ctx, x, y, w, h, radius, color);
   }

   public static void panel(DrawContext ctx, float x, float y, float w, float h, float radius) {
      HudStyle.frame();
      round(ctx, x, y, w, h, radius, PANEL_BG);
      outline(ctx, x, y, w, h, radius, PANEL_BORDER);
   }

   public static void button(DrawContext ctx, float x, float y, float w, float h, float radius, boolean hovered, boolean active) {
      button(ctx, x, y, w, h, radius, hovered ? 1.0F : 0.0F, active ? 1.0F : 0.0F);
   }

   public static void button(DrawContext ctx, float x, float y, float w, float h, float radius, float hover, float active) {
      round(ctx, x, y, w, h, radius, lerp(BUTTON_BG, BUTTON_BG_HOVER, Math.max(hover, active)));
      if (w > radius * 2.0F + 2.0F) {
         round(ctx, x + radius, y, w - radius * 2.0F, 1.0F, 0.5F, Colors.withAlpha(16777215, 0.06F + 0.06F * hover));
      }

      outline(ctx, x, y, w, h, radius, lerp(lerp(BUTTON_BORDER, BUTTON_BORDER_HOVER, hover), CARD_BORDER_ACTIVE, active));
   }

   public static void labelButton(DrawContext ctx, float x, float y, float w, float h, Icons.Type icon, String label, float hover, boolean primary) {
      if (primary) {
         round(ctx, x, y, w, h, 6.0F, lerp(PRIMARY_BG, PRIMARY_BG_HOVER, hover));
      } else {
         button(ctx, x, y, w, h, 6.0F, hover, 0.0F);
      }

      int color = primary ? PRIMARY_TEXT : -1447444;
      Text label2 = bold(label);
      float iconSize = icon == null ? 0.0F : 10.0F;
      float contentW = width(label2) + (icon == null ? 0.0F : iconSize + 5.0F);
      float cx = x + (w - contentW) / 2.0F;
      if (icon != null) {
         Icons.draw(ctx, icon, cx, y + (h - iconSize) / 2.0F, iconSize, color);
         cx += iconSize + 5.0F;
      }

      text(ctx, label2, cx, y + (h - 8.0F) / 2.0F, color);
   }

   public static void checkbox(DrawContext ctx, float x, float y, float size, float on, float hover) {
      round(ctx, x, y, size, size, 2.5F, 1073741824);
      int borderAlpha = Math.round((1.0F - on) * lerpAlpha(80, 144, hover));
      outline(ctx, x, y, size, size, 2.5F, borderAlpha << 24 | 16777215);
      if (on > 0.01F) {
         round(ctx, x, y, size, size, 2.5F, Colors.withAlpha(CHECK_FILL, on));
         float tick = size * 0.8F;
         Icons.draw(ctx, Icons.Type.CHECK, x + (size - tick) / 2.0F, y + (size - tick) / 2.0F, tick, Colors.withAlpha(-1, on));
      }
   }

   private static int lerpAlpha(int a, int b, float t) {
      return Math.round(a + (b - a) * t);
   }

   public static void badge(DrawContext ctx, float x, float y, float w, float h, float hover) {
      round(ctx, x, y, w, h, h / 2.0F, BADGE_BG);
      outline(ctx, x, y, w, h, h / 2.0F, lerp(654311423, 1728053247, hover));
   }

   public static void hLine(DrawContext ctx, float x1, float x2, float y, int color) {
      Gfx.hLine(ctx, x1, x2, y, color);
   }

   public static void vLine(DrawContext ctx, float x, float y1, float y2, int color) {
      Gfx.vLine(ctx, x, y1, y2, color);
   }

   public static void tooltip(DrawContext ctx, String label, float x, float y) {
      Text t = t(label);
      int w = width(t) + 12;
      round(ctx, x, y, w, 16.0F, 5.0F, -266724576);
      outline(ctx, x, y, w, 16.0F, 5.0F, 1090519039);
      text(ctx, t, x + 6.0F, y + 4.0F, -1447444);
   }

   public static boolean inside(double mx, double my, float x, float y, float w, float h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   public static float approach(float current, float target, float dt, float speed) {
      float next = current + (target - current) * (1.0F - (float)Math.exp(-speed * dt));
      return Math.abs(target - next) < 0.001F ? target : next;
   }

   public static float easeOut(float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      float inv = 1.0F - t;
      return 1.0F - inv * inv * inv;
   }

   public static int lerp(int a, int b, float t) {
      return Colors.lerp(a, b, t);
   }
}
