package cherryblossom.schematic.ui;
import net.minecraft.client.gui.DrawContext;
public final class Icons{
    public enum Type{CUBE,CLOSE,PAUSE,PLAY,CHECK,FOLDER,MAP_PIN,EYE}
    public static void draw(DrawContext c,Type type,float x,float y,float size,int color){if(type==null)return;String text=switch(type){case CLOSE->"x";case PAUSE->"II";case PLAY->">";case CHECK->"+";case FOLDER->"[ ]";case MAP_PIN->"o";case EYE->"<>";default->"#";};Ui.text(c,Ui.t(text),x,y,size/10,color);}
}
