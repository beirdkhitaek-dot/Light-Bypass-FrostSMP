package cherryblossom.schematic.ui;
import java.awt.Color;
import net.minecraft.client.gui.DrawContext;
public final class Gfx{
    public static float alpha=1;
    public static int fade(int color){return (color&0xFFFFFF)|Math.round((color>>>24)*alpha)<<24;}
    public static float scale(){return (float)net.minecraft.client.MinecraftClient.getInstance().getWindow().getScaleFactor();}
    public static void roundRect(DrawContext c,float x,float y,float w,float h,float radius,int color){cherryblossom.utils.RenderUtils.renderRoundedQuad(c.getMatrices(),new Color(fade(color),true),x,y,x+w,y+h,radius,1);}
    public static void roundOutline(DrawContext c,float x,float y,float w,float h,float radius,int color){cherryblossom.utils.RenderUtils.renderRoundedOutline(c,new Color(fade(color),true),x,y,x+w,y+h,radius,radius,radius,radius,1,1);}
    public static void circle(DrawContext c,float x,float y,float radius,int color){cherryblossom.utils.RenderUtils.renderCircle(c.getMatrices(),new Color(fade(color),true),x,y,radius,40);}
    public static void hLine(DrawContext c,float a,float b,float y,int color){c.fill((int)a,(int)y,(int)b,(int)y+1,fade(color));}
    public static void vLine(DrawContext c,float x,float a,float b,int color){c.fill((int)x,(int)a,(int)x+1,(int)b,fade(color));}
}
