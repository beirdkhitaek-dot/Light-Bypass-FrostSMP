package cherryblossom.schematic.ui;
import java.util.HashMap;
import net.minecraft.client.gui.DrawContext;
public final class HudStyle{
    private static final HashMap<String,Float> values=new HashMap<>();
    public static void frame(){Ui.applyPalette(accent(),0xFF442839,0xFF35202E,.95f,.25f,false);}
    public static int accent(){return cherryblossom.feature.UiPalette.accent(1);}
    public static float anim(String id,float target,float speed){float current=values.getOrDefault(id,target);float next=current+(target-current)*Math.min(1,(float)cherryblossom.utils.RenderUtils.deltaTime()*speed);values.put(id,next);return next;}
    public static float clamp(float position,float size,float screen){return Math.max(2,Math.min(Math.max(2,screen-size-2),position));}
    public static void panel(DrawContext c,float x,float y,float w,float h,float radius,float opacity){frame();Gfx.roundRect(c,x,y,w,h,radius,cherryblossom.feature.UiPalette.glass(opacity));Gfx.roundOutline(c,x,y,w,h,radius,(accent()&0xFFFFFF)|0x55000000);}
}
