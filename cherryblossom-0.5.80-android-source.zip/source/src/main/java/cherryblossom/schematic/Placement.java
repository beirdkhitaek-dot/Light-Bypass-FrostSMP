package cherryblossom.schematic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.shape.VoxelShape;

public final class Placement {
   private static final Set<String> PLACED_PROPS = Set.of(
      "facing", "axis", "half", "type", "hinge", "face", "rotation", "attachment", "hanging", "orientation", "vertical_direction"
   );
   private static final float[] YAWS = new float[]{0.0F, 90.0F, 180.0F, -90.0F};
   private static final float[] PITCHES = new float[]{0.0F, 60.0F, -60.0F};
   public static final int ANY_LOOK = 4095;

   private Placement() {
   }

   public static List<Placement.Option> options(ClientPlayerEntity p, ClientWorld world, BlockPos pos, BlockState target, ItemStack stack) {
      Map<String, String> want = props(target, true);
      boolean careful = !want.isEmpty();
      boolean offsets = want.containsKey("half") || want.containsKey("type") || want.containsKey("hinge");
      List<Placement.Option> out = new ArrayList<>();

      for (Direction d : Direction.values()) {
         BlockPos n = pos.offset(d);
         BlockState ns = world.getBlockState(n);
         Direction side = d.getOpposite();
         if (!ns.isReplaceable() && faceSolid(world, n, ns, side)) {
            boolean sneak = interactive(ns);
            double cx = pos.getX() + 0.5 + d.getOffsetX() * 0.5;
            double cy = pos.getY() + 0.5 + d.getOffsetY() * 0.5;
            double cz = pos.getZ() + 0.5 + d.getOffsetZ() * 0.5;

            for (double[] off : offsets(side, careful && offsets)) {
               if (!careful) {
                  out.add(new Placement.Option(n, side, off[0], off[1], off[2], 4095, sneak,target));
               } else {
                  BlockHitResult hit = new BlockHitResult(new Vec3d(cx + off[0], cy + off[1], cz + off[2]), side, n, false);
                  int looks = 0;

                  for (int y = 0; y < 4; y++) {
                     for (int c = 0; c < 3; c++) {
                        float sampleYaw=YAWS[y];
                        if(want.containsKey("rotation")){
                           sampleYaw=Integer.parseInt(want.get("rotation"))*22.5f-180;
                           if(((int)Math.floor(sampleYaw/90+.5)&3)!=y)continue;
                        }
                        BlockState sim = simulate(p, stack, target, hit, sampleYaw, PITCHES[c]);
                        if (sim != null && sim.getBlock() == target.getBlock() && props(sim, true).equals(want)) {
                           looks |= 1 << y * 3 + c;
                        }
                     }
                  }

                  if (looks != 0) {
                     out.add(new Placement.Option(n, side, off[0], off[1], off[2], looks, sneak,target));
                  }
               }
            }
         }
      }

      return out;
   }

   public static boolean faceSolid(ClientWorld world, BlockPos n, BlockState ns, Direction side) {
      VoxelShape shape = ns.getCollisionShape(world, n);
      if (shape.isEmpty()) {
         return false;
      } else {
         Axis axis = side.getAxis();
         int sign = side.getOffsetX() + side.getOffsetY() + side.getOffsetZ();
         return sign > 0 ? shape.getMax(axis) >= 0.99 : shape.getMin(axis) <= 0.01;
      }
   }

   public static Placement.Choice choose(List<Placement.Option> options, ClientWorld world, BlockPos pos, Vec3d eye, double reach) {
      Placement.Choice best = null;
      double bestD = reach * reach;

      for (Placement.Option o : options) {
         Direction d = o.side();
         double hx = o.neighbour().getX() + 0.5 + d.getOffsetX() * 0.5 + o.ox();
         double hy = o.neighbour().getY() + 0.5 + d.getOffsetY() * 0.5 + o.oy();
         double hz = o.neighbour().getZ() + 0.5 + d.getOffsetZ() * 0.5 + o.oz();
         double ex = eye.x - hx;
         double ey = eye.y - hy;
         double ez = eye.z - hz;
         double distSq = ex * ex + ey * ey + ez * ez;
         if (!(distSq > bestD)
            && !(ex * d.getOffsetX() + ey * d.getOffsetY() + ez * d.getOffsetZ() <= 0.05)
            && (o.looks() & 1 << lookClass(-ex, -ey, -ez)) != 0
            && clearLine(world, eye, hx, hy, hz, pos, o.neighbour())
            && preciseSign(o,eye,new Vec3d(hx,hy,hz))) {
            best = new Placement.Choice(o, new Vec3d(hx, hy, hz));
            bestD = distSq;
         }
      }

      return best;
   }

   public static int lookClass(double dx, double dy, double dz) {
      float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
      int quadrant = (int)Math.floor(yaw / 90.0F + 0.5F) & 3;
      int vertical = Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > Math.abs(dz) ? (dy < 0.0 ? 1 : 2) : 0;
      return quadrant * 3 + vertical;
   }

   private static BlockState simulate(ClientPlayerEntity p, ItemStack stack, BlockState target, BlockHitResult hit, float yaw, float pitch) {
      float oldYaw = p.getYaw();
      float oldPitch = p.getPitch();
      p.setYaw(yaw);
      p.setPitch(pitch);

      Object var9;
      try {
           ItemPlacementContext context=new ItemPlacementContext(p,Hand.MAIN_HAND,stack,hit);
           return stack.getItem() instanceof net.minecraft.item.BlockItem
              ? ((cherryblossom.mixin.SchematicBlockItemAccessor)stack.getItem()).cherry$placementState(context)
              : target.getBlock().getPlacementState(context);
      } catch (RuntimeException var13) {
         var9 = null;
      } finally {
         p.setYaw(oldYaw);
         p.setPitch(oldPitch);
      }

      return (BlockState)var9;
   }
   private static boolean preciseSign(Option option,Vec3d eye,Vec3d hit){
      if(option.target()==null||!(option.target().getBlock() instanceof net.minecraft.block.AbstractSignBlock))return true;
      var p=net.minecraft.client.MinecraftClient.getInstance().player;if(p==null)return false;
      float[] a=angles(eye,hit);BlockState state=simulate(p,new ItemStack(option.target().getBlock().asItem()),option.target(),new BlockHitResult(hit,option.side(),option.neighbour(),false),a[0],a[1]);
      return state!=null&&state.getBlock()==option.target().getBlock()&&props(state,true).equals(props(option.target(),true));
   }

   private static double[][] offsets(Direction side, boolean spread) {
      if (!spread) {
         return new double[][]{{0.0, 0.0, 0.0}};
      } else {
         double s = 0.3;
         if (side.getOffsetY() != 0) {
            return new double[][]{{0.0, 0.0, 0.0}, {s, 0.0, 0.0}, {-s, 0.0, 0.0}, {0.0, 0.0, s}, {0.0, 0.0, -s}};
         } else {
            return side.getOffsetX() != 0
               ? new double[][]{{0.0, 0.0, 0.0}, {0.0, s, 0.0}, {0.0, -s, 0.0}, {0.0, 0.0, s}, {0.0, 0.0, -s}}
               : new double[][]{{0.0, 0.0, 0.0}, {0.0, s, 0.0}, {0.0, -s, 0.0}, {s, 0.0, 0.0}, {-s, 0.0, 0.0}};
         }
      }
   }

   public static Map<String, String> props(BlockState state, boolean placedOnly) {
      Map<String, String> out = new HashMap<>();
      String s = state.toString();
      int open = s.indexOf(91);
      int close = s.lastIndexOf(93);
      if (open >= 0 && close >= open) {
         boolean rail = s.contains("rail}");
         boolean chest = s.contains("chest}");

         for (String pair : s.substring(open + 1, close).split(",")) {
            int eq = pair.indexOf(61);
            if (eq > 0) {
               String k = pair.substring(0, eq);
               String v = pair.substring(eq + 1);
               if (!placedOnly) {
                  out.put(k, v);
               } else if (rail && k.equals("shape")) {
                  if (v.contains("north_south") || v.equals("ascending_north") || v.equals("ascending_south")) {
                     out.put(k, "north_south");
                  } else if (v.contains("east_west") || v.equals("ascending_east") || v.equals("ascending_west")) {
                     out.put(k, "east_west");
                  }
               } else if (PLACED_PROPS.contains(k) && (!chest || !k.equals("type"))) {
                  out.put(k, v);
               }
            }
         }

         return out;
      } else {
         return out;
      }
   }

   public static boolean interactive(BlockState s) {
      if (s.hasBlockEntity()) {
         return true;
      } else {
         String id = Pathfinder.id(s.getBlock());
         return id.contains("door")
            || id.contains("gate")
            || id.contains("button")
            || id.contains("lever")
            || id.contains("bed")
            || id.contains("crafting")
            || id.contains("anvil")
            || id.contains("note_block")
            || id.contains("repeater")
            || id.contains("comparator")
            || id.contains("loom")
            || id.contains("stonecutter")
            || id.contains("grindstone")
            || id.contains("cartography")
            || id.contains("smithing")
            || id.contains("bell")
            || id.contains("cake")
            || id.contains("daylight")
            || id.contains("respawn_anchor")
            || id.contains("enchanting")
            || id.equals("redstone_wire")
            || id.contains("composter")
            || id.contains("cauldron")
            || id.contains("flower_pot")
            || id.contains("candle")
            || id.contains("cave_vines")
            || id.equals("dragon_egg")
            || id.contains("observer")
            || id.contains("redstone_lamp")
            || id.contains("target")
            || id.contains("chiseled_bookshelf")
            || id.contains("copper_bulb")
            || id.contains("pumpkin")
            || id.contains("tnt");
      }
   }

   public static boolean clearLine(ClientWorld world, Vec3d eye, double hx, double hy, double hz, BlockPos target, BlockPos neighbour) {
      double dx = hx - eye.x;
      double dy = hy - eye.y;
      double dz = hz - eye.z;
      int steps = (int)Math.ceil(Math.sqrt(dx * dx + dy * dy + dz * dz) / 0.2);

      for (int i = 1; i < steps; i++) {
         double f = (double)i / steps;
         BlockPos b = new BlockPos((int)Math.floor(eye.x + dx * f), (int)Math.floor(eye.y + dy * f), (int)Math.floor(eye.z + dz * f));
         if (!b.equals(target) && !b.equals(neighbour)) {
            BlockState s = world.getBlockState(b);
            if (!s.isReplaceable() && !s.getCollisionShape(world, b).isEmpty()) {
               return false;
            }
         }
      }

      return true;
   }

   public static Vec3d lookHit(Vec3d eye, float yaw, float pitch, BlockPos neighbour, Direction side) {
      double yr = Math.toRadians(yaw);
      double pr = Math.toRadians(pitch);
      double lx = -Math.sin(yr) * Math.cos(pr);
      double ly = -Math.sin(pr);
      double lz = Math.cos(yr) * Math.cos(pr);
      double nx = side.getOffsetX();
      double ny = side.getOffsetY();
      double nz = side.getOffsetZ();
      double cx = neighbour.getX() + 0.5 + nx * 0.5;
      double cy = neighbour.getY() + 0.5 + ny * 0.5;
      double cz = neighbour.getZ() + 0.5 + nz * 0.5;
      double denom = lx * nx + ly * ny + lz * nz;
      if (denom > -1.0E-6) {
         return null;
      } else {
         double t = ((cx - eye.x) * nx + (cy - eye.y) * ny + (cz - eye.z) * nz) / denom;
         if (t <= 0.0) {
            return null;
         } else {
            double hx = eye.x + lx * t;
            double hy = eye.y + ly * t;
            double hz = eye.z + lz * t;
            double limit = 0.48;
            return (nx != 0.0 || !(Math.abs(hx - cx) > limit)) && (ny != 0.0 || !(Math.abs(hy - cy) > limit)) && (nz != 0.0 || !(Math.abs(hz - cz) > limit))
               ? new Vec3d(hx, hy, hz)
               : null;
         }
      }
   }

   public static float[] angles(Vec3d eye, Vec3d at) {
      double dx = at.x - eye.x;
      double dy = at.y - eye.y;
      double dz = at.z - eye.z;
      return new float[]{(float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0), (float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))))};
   }

   public record Choice(Placement.Option option, Vec3d hit) {
   }

   public record Option(BlockPos neighbour, Direction side, double ox, double oy, double oz, int looks, boolean sneak,BlockState target) {
      public Option(BlockPos neighbour,Direction side,double ox,double oy,double oz,int looks,boolean sneak){this(neighbour,side,ox,oy,oz,looks,sneak,null);}
   }
}
