package cherryblossom.schematic;

import cherryblossom.feature.AutoSchematicBuilderModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class SchematicPreviewScreen extends Screen {
   private static SchematicPreviewScreen open;
   private final AutoSchematicBuilderModule module;
   private final boolean savedCull;
   private float yaw = 35.0F;
   private float pitch = 30.0F;
   private double distance;

   public SchematicPreviewScreen(AutoSchematicBuilderModule module) {
      super(Text.literal("Schematic preview"));
      this.module = module;
      this.distance = Math.max(8.0, module.previewRadius() * 2.4 + 4.0);
      MinecraftClient mc = MinecraftClient.getInstance();
      this.savedCull = mc.chunkCullingEnabled;
      mc.chunkCullingEnabled = false;
      open = this;
   }

   public static boolean isOpen() {
      return open != null;
   }

   public static double[] camera() {
      SchematicPreviewScreen s = open;
      double[] c = s.module.previewCenter();
      double yr = Math.toRadians(s.yaw);
      double pr = Math.toRadians(s.pitch);
      double lx = -Math.sin(yr) * Math.cos(pr);
      double ly = -Math.sin(pr);
      double lz = Math.cos(yr) * Math.cos(pr);
      return new double[]{c[0] - lx * s.distance, c[1] - ly * s.distance, c[2] - lz * s.distance, s.yaw, s.pitch};
   }

   @Override
   public boolean shouldPause() {
      return false;
   }
   @Override protected void init(){super.init();SchematicScreenBridge.releaseCursor();}

   @Override
   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      SchematicScreenBridge.releaseCursor();
      SchematicScreenBridge.preview(this,this.module,this.width,this.height,mouseX,mouseY);
   }

   @Override
   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      this.yaw += (float)offsetX * 0.5F;
      this.pitch = Math.max(-89.0F, Math.min(89.0F, this.pitch + (float)offsetY * 0.5F));
      return true;
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.distance = Math.max(3.0, Math.min(250.0, this.distance * (verticalAmount > 0.0 ? 0.88 : 1.14)));
      return true;
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      switch (input.key()) {
         case 82:
            this.module.rotateQuarter();
            break;
         case 257:
         case 335:
            this.close();
            this.module.startBuilding();
            break;
         case 262:
            this.module.nudge(1, 0, 0);
            break;
         case 263:
            this.module.nudge(-1, 0, 0);
            break;
         case 264:
            this.module.nudge(0, 0, 1);
            break;
         case 265:
            this.module.nudge(0, 0, -1);
            break;
         case 266:
            this.module.nudge(0, 1, 0);
            break;
         case 267:
            this.module.nudge(0, -1, 0);
            break;
         default:
            return super.keyPressed(input);
      }

      return true;
   }

   @Override
   public void removed() {
      MinecraftClient.getInstance().chunkCullingEnabled = this.savedCull;
      if (open == this) {
         open = null;
      }

      SchematicScreenBridge.close(this);
      super.removed();
   }
}
