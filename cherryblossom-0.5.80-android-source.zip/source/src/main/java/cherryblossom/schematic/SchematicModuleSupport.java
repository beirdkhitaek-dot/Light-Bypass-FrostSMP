package cherryblossom.schematic;
public abstract class SchematicModuleSupport extends cherryblossom.module.ext.ClientModule{
    protected SchematicModuleSupport(String name,String category,String description){super("auto-schematicbuilder",name,description,cherryblossom.module.ext.ModuleCategory.DONUT);}
}
