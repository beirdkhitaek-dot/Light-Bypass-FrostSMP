package cherryblossom.schematic;

import cherryblossom.feature.AutoSchematicBuilderModule;
import java.lang.reflect.Method;

/** Keeps the feature runtime independent of the intermediary Cherry GUI renderer. */
public final class SchematicScreenBridge {
    public static boolean isOpen(){var s=net.minecraft.client.MinecraftClient.getInstance().currentScreen;return s instanceof SchematicSetupScreen || s instanceof SchematicPreviewScreen;}
    public static void releaseCursor(){
        var mc=net.minecraft.client.MinecraftClient.getInstance();
        if(mc.mouse.isCursorLocked())mc.mouse.unlockCursor();
        org.lwjgl.glfw.GLFW.glfwSetInputMode(mc.getWindow().getHandle(),org.lwjgl.glfw.GLFW.GLFW_CURSOR,org.lwjgl.glfw.GLFW.GLFW_CURSOR_NORMAL);
    }
    private static Class<?> renderer;
    private static Class<?> renderer()throws ReflectiveOperationException{
        if(renderer==null)renderer=Class.forName("dev.cherryblossom.client.render.SchematicScreenRenderer");return renderer;
    }
    private static Object invoke(String name,Class<?>[] types,Object... args){
        try{return renderer().getMethod(name,types).invoke(null,args);}
        catch(ReflectiveOperationException error){throw new IllegalStateException("Schematic screen could not "+name,error);}
    }
    public static boolean render(Object page,AutoSchematicBuilderModule module,int width,int height,int mx,int my){
        return (Boolean)invoke("render",new Class<?>[]{Object.class,AutoSchematicBuilderModule.class,int.class,int.class,int.class,int.class},page,module,width,height,mx,my);
    }
    public static boolean click(Object page,double x,double y){return (Boolean)invoke("click",new Class<?>[]{Object.class,double.class,double.class},page,x,y);}
    public static boolean scroll(Object page,double x,double y,double amount){return (Boolean)invoke("scroll",new Class<?>[]{Object.class,double.class,double.class,double.class},page,x,y,amount);}
    public static void close(Object page){invoke("closed",new Class<?>[]{Object.class},page);}
    public static void renderLate(){invoke("renderLate",new Class<?>[0]);}
    public static boolean preview(Object page,AutoSchematicBuilderModule module,int width,int height,int mx,int my){
        return (Boolean)invoke("preview",new Class<?>[]{Object.class,AutoSchematicBuilderModule.class,int.class,int.class,int.class,int.class},page,module,width,height,mx,my);
    }
}
