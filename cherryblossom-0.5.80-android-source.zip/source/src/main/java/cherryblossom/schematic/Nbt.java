package cherryblossom.schematic;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Bounded reader for the schematic module's Sponge and Litematica importers. */
final class Nbt {
    private static final int MAX_BYTES=64*1024*1024;
    private final DataInputStream input;
    private int tags;
    private Nbt(DataInputStream input){this.input=input;}
    static Map<String,Object> read(Path file)throws IOException{
        if(Files.size(file)>MAX_BYTES)throw new IOException("Schematic file exceeds 64 MiB.");
        try(var raw=new BufferedInputStream(Files.newInputStream(file))){
            raw.mark(2);boolean gzip=raw.read()==31&&raw.read()==139;raw.reset();
            InputStream decoded=gzip?new GZIPInputStream(raw):raw;
            try(var data=new DataInputStream(new BufferedInputStream(new FilterInputStream(decoded){
                private long left=MAX_BYTES;
                public int read()throws IOException{if(left<=0)throw new IOException("Unpacked schematic exceeds 64 MiB.");int value=super.read();if(value>=0)left--;return value;}
                public int read(byte[] bytes,int off,int len)throws IOException{if(left<=0)throw new IOException("Unpacked schematic exceeds 64 MiB.");int count=super.read(bytes,off,(int)Math.min(left,len));if(count>0)left-=count;return count;}
            }))){
                if(data.readUnsignedByte()!=10)throw new IOException("Not an NBT schematic.");data.readUTF();return new Nbt(data).compound(0);
            }
        }
    }
    private Map<String,Object> compound(int depth)throws IOException{
        if(depth>64)throw new IOException("Schematic NBT is nested too deeply.");
        Map<String,Object> result=new HashMap<>();
        for(int type=input.readUnsignedByte();type!=0;type=input.readUnsignedByte()){
            String name=input.readUTF();result.put(name,tag(type,depth+1));
        }
        return result;
    }
    private int length(int max)throws IOException{int value=input.readInt();if(value<0||value>max)throw new IOException("Invalid schematic NBT array length.");return value;}
    private Object tag(int type,int depth)throws IOException{
        if(depth>64||++tags>1_000_000)throw new IOException("Schematic NBT is too complex.");
        return switch(type){
            case 1->input.readByte();case 2->input.readShort();case 3->input.readInt();case 4->input.readLong();case 5->input.readFloat();case 6->input.readDouble();
            case 7->{byte[] data=new byte[length(MAX_BYTES)];input.readFully(data);yield data;}
            case 8->input.readUTF();
            case 9->{int itemType=input.readUnsignedByte(),count=length(1_000_000);List<Object> list=new ArrayList<>(count);for(int i=0;i<count;i++)list.add(tag(itemType,depth+1));yield list;}
            case 10->compound(depth+1);
            case 11->{int[] data=new int[length(MAX_BYTES/4)];for(int i=0;i<data.length;i++)data[i]=input.readInt();yield data;}
            case 12->{long[] data=new long[length(MAX_BYTES/8)];for(int i=0;i<data.length;i++)data[i]=input.readLong();yield data;}
            default->throw new IOException("Invalid NBT tag type: "+type);
        };
    }
    @SuppressWarnings("unchecked") static Map<String,Object> map(Object value){return value instanceof Map?(Map<String,Object>)value:Map.of();}
    @SuppressWarnings("unchecked") static List<Object> list(Object value){return value instanceof List?(List<Object>)value:List.of();}
    static int num(Object value){return value instanceof Number number?number.intValue():0;}
}