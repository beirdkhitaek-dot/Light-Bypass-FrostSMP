package cherryblossom.schematic;

import net.minecraft.client.network.ClientPlayerEntity;

public final class HumanLook {
   private static final float AIM_TIME = 1.6F;
   private static final float AIM_MAX = 38.0F;
   private static final float STEER_TIME = 3.2F;
   private static final float STEER_MAX = 16.0F;
   private boolean hasGoal;
   private boolean steering;
   private float goalYaw;
   private float goalPitch;
   private float vYaw;
   private float vPitch;
   private float fromYaw = Float.NaN;
   private float fromPitch;
   private float fromVYaw;
   private float fromVPitch;
   private float toYaw;
   private float toPitch;
   private float lastYaw = Float.NaN;
   private float lastPitch = Float.NaN;
   private float dampVel;

   public void lookAt(ClientPlayerEntity p, float yaw, float pitch) {
      this.setGoal(p, yaw, pitch);
      this.steering = false;
   }

   public void steer(ClientPlayerEntity p, float yaw, float pitch) {
      this.setGoal(p, yaw, pitch);
      this.steering = true;
   }

   private void setGoal(ClientPlayerEntity p, float yaw, float pitch) {
      float base = p.getYaw();
      this.goalYaw = base + wrap(yaw - base);
      this.goalPitch = clampPitch(pitch);
      this.hasGoal = true;
   }

   public boolean tick(ClientPlayerEntity p) {
      float y = p.getYaw();
      float pt = p.getPitch();
      if (!Float.isNaN(this.lastYaw) && (Math.abs(y - this.lastYaw) > 2.0F || Math.abs(pt - this.lastPitch) > 2.0F)) {
         this.vYaw = 0.0F;
         this.vPitch = 0.0F;
      }

      this.fromYaw = y;
      this.fromPitch = pt;
      this.fromVYaw = this.vYaw;
      this.fromVPitch = this.vPitch;
      if (!this.hasGoal) {
         this.toYaw = y;
         this.toPitch = pt;
         this.vYaw = 0.0F;
         this.vPitch = 0.0F;
         return false;
      } else {
         float gy = y + wrap(this.goalYaw - y);
         float time = this.steering ? 3.2F : 1.6F;
         float max = this.steering ? 16.0F : 38.0F;
         float ny = this.damp(y, gy, this.vYaw, time, max);
         this.vYaw = this.dampVel;
         float np = this.damp(pt, this.goalPitch, this.vPitch, time, max * 0.7F);
         this.vPitch = this.dampVel;
         if (Math.abs(gy - ny) < 0.05F && Math.abs(this.vYaw) < 0.05F) {
            ny = gy;
            this.vYaw = 0.0F;
         }

         if (Math.abs(this.goalPitch - np) < 0.05F && Math.abs(this.vPitch) < 0.05F) {
            np = this.goalPitch;
            this.vPitch = 0.0F;
         }

         this.set(p, ny, np);
         this.toYaw = ny;
         this.toPitch = clampPitch(np);
         return Math.abs(gy - ny) < 0.6F && Math.abs(this.goalPitch - np) < 0.6F && Math.abs(this.vYaw) < 1.5F && Math.abs(this.vPitch) < 1.5F;
      }
   }

   public float[] view(ClientPlayerEntity p, float partial) {
      if (!Float.isNaN(this.fromYaw) && !(Math.abs(p.getYaw() - this.toYaw) > 0.01F) && !(Math.abs(p.getPitch() - this.toPitch) > 0.01F)) {
         float t = Math.max(0.0F, Math.min(1.0F, partial));
         float t2 = t * t;
         float t3 = t2 * t;
         float h00 = 2.0F * t3 - 3.0F * t2 + 1.0F;
         float h10 = t3 - 2.0F * t2 + t;
         float h01 = -2.0F * t3 + 3.0F * t2;
         float h11 = t3 - t2;
         float yaw = h00 * this.fromYaw + h10 * this.fromVYaw + h01 * this.toYaw + h11 * this.vYaw;
         float pitch = h00 * this.fromPitch + h10 * this.fromVPitch + h01 * this.toPitch + h11 * this.vPitch;
         return new float[]{yaw, clampPitch(pitch)};
      } else {
         return new float[]{p.getYaw(), p.getPitch()};
      }
   }

   private float damp(float cur, float target, float vel, float smoothTime, float maxSpeed) {
      float omega = 2.0F / smoothTime;
      float exp = 1.0F / (1.0F + omega + 0.48F * omega * omega + 0.235F * omega * omega * omega);
      float change = cur - target;
      float maxChange = maxSpeed * smoothTime;
      change = Math.max(-maxChange, Math.min(maxChange, change));
      float temp = vel + omega * change;
      float newVel = (vel - omega * temp) * exp;
      float out = cur - change + (change + temp) * exp;
      if (target - cur > 0.0F == out > target) {
         out = target;
         newVel = 0.0F;
      }

      this.dampVel = newVel;
      return out;
   }

   public boolean overridden(ClientPlayerEntity p) {
      return Float.isNaN(this.lastYaw) ? false : Math.abs(p.getYaw() - this.lastYaw) > 2.0F || Math.abs(p.getPitch() - this.lastPitch) > 2.0F;
   }

   public void reset() {
      this.hasGoal = false;
      this.vYaw = 0.0F;
      this.vPitch = 0.0F;
      this.fromYaw = Float.NaN;
      this.lastYaw = Float.NaN;
      this.lastPitch = Float.NaN;
   }

   private void set(ClientPlayerEntity p, float yaw, float pitch) {
      p.setYaw(yaw);
      p.setPitch(clampPitch(pitch));
      this.lastYaw = p.getYaw();
      this.lastPitch = p.getPitch();
   }

   public void hold(ClientPlayerEntity p) {
      this.lastYaw = p.getYaw();
      this.lastPitch = p.getPitch();
   }

   private static float clampPitch(float pitch) {
      return Math.max(-90.0F, Math.min(90.0F, pitch));
   }

   public static float wrap(float deg) {
      float d = deg % 360.0F;
      if (d >= 180.0F) {
         d -= 360.0F;
      }

      if (d < -180.0F) {
         d += 360.0F;
      }

      return d;
   }
}
