package cherryblossom.module.ext;

public enum Stage {
   PRE,
   POST;
}
