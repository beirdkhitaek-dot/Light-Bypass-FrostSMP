package cherryblossom.module.ext.event;

public final class EventType<E> {
   private final Class<E> type;

   public EventType(Class<E> var1) {
      this.type = var1;
   }

   public void listen(Object owner,java.util.function.Consumer<E> fn){cherryblossom.module.ext.ExtBridge.listenGlobal(type,fn);}
   public Class<E> type() {
      return this.type;
   }
}
