package cherryblossom.module.ext.event;
import net.minecraft.network.packet.Packet;
public final class PacketAppliedEvent {
    public static final EventType<PacketAppliedEvent> TYPE=new EventType<>(PacketAppliedEvent.class);
    public final Packet<?> packet;
    public PacketAppliedEvent(Packet<?> packet){this.packet=packet;}
}
