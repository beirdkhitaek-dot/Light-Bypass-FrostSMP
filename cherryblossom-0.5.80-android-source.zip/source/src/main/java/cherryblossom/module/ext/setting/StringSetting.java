package cherryblossom.module.ext.setting;
public final class StringSetting extends Setting {
    private final cherryblossom.module.setting.StringSetting backing;
    public StringSetting(String name,String value){super(name);backing=new cherryblossom.module.setting.StringSetting(name,value);}
    public StringSetting privateValue(){return this;}
    public String get(){return backing.getValue();}
    public void set(String value){backing.setValue(value);notifyChanged();}
    public String value(){return get();}
    @Override public cherryblossom.module.setting.Setting cherryblossom(){return backing;}
    @Override protected Object snapshot(){return get();}
}
