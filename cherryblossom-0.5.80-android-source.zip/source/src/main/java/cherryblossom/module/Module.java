package cherryblossom.module;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import cherryblossom.CherryBlossom;
import cherryblossom.manager.EventManager;
import cherryblossom.module.setting.Setting;
import net.minecraft.client.MinecraftClient;

public abstract class Module implements Serializable {
   private final List<Setting> settings = new ArrayList<>();
   protected final EventManager EVENT_BUS = CherryBlossom.INSTANCE.getEventBus();
   protected MinecraftClient mc = MinecraftClient.getInstance();
   private CharSequence name;
   private CharSequence description;
   private boolean enabled;
   private int keybind;
   private Category category;
   private final boolean i = false;

   public Module(CharSequence name, CharSequence description, int keybind, Category category) {
      this.name = name;
      this.description = description;
      this.enabled = false;
      this.keybind = keybind;
      this.category = category;
   }

   private transient boolean changingEnabled;
   public void toggle(){toggle(!enabled);}

   public CharSequence getName() {
      return this.name;
   }

   public boolean isEnabled() {
      return cherryblossom.integration.TrialAccess.allowed() && this.enabled;
   }

   public CharSequence getDescription() {
      return this.description;
   }

   public int getKeybind() {
      return this.keybind;
   }

   public Category getCategory() {
      return this.category;
   }

   public void setCategory(Category category) {
      this.category = category;
   }

   public void setName(CharSequence name) {
      this.name = name;
   }

   public void setDescription(CharSequence description) {
      this.description = description;
   }

   public void setKeybind(int keybind) {
      this.keybind = keybind;
   }

   public List<Setting> getSettings() {
      return this.settings;
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void addSetting(Setting setting) {
      this.settings.add(setting);
   }

   public void addSettings(Setting... a) {
      this.settings.addAll(Arrays.asList(a));
   }

   public void toggle(boolean next) {
      if(next&&!cherryblossom.integration.TrialAccess.allowed())return;
      boolean previous=this.enabled;if(previous==next)return;
      changingEnabled=true;
      try{this.enabled=next;if(next)onEnable();else onDisable();}
      finally{changingEnabled=false;}
      if(previous!=this.enabled)cherryblossom.integration.ToggleNotifications.show(this,this.enabled);
   }
   public void setEnabled(boolean next){
      if(next&&!cherryblossom.integration.TrialAccess.allowed())return;
      boolean previous=this.enabled;this.enabled=next;
      if(!changingEnabled&&previous!=next)cherryblossom.integration.ToggleNotifications.show(this,next);
   }
}
