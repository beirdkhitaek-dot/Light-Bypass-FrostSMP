package cherryblossom.module.setting;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.item.Item;

public final class StorageBlocksSetting extends Setting {
   private final List<StorageBlocksSetting.Entry> entries = new ArrayList<>();
   private boolean colorOnly;
   private boolean tracerControls;
   public StorageBlocksSetting withTracers(){tracerControls=true;return this;}
   public boolean hasTracerControls(){return tracerControls;}
   private boolean pickerOnly;

   public StorageBlocksSetting(CharSequence var1) {
      super(var1);
   }

   public StorageBlocksSetting colorOnly() {
      this.colorOnly = true;
      return this;
   }

   public boolean isColorOnly() {
      return this.colorOnly && !this.entries.isEmpty();
   }

   public StorageBlocksSetting pickerOnly() {
      this.pickerOnly = true;
      return this;
   }

   public boolean isPickerOnly() {
      return this.pickerOnly;
   }

   public StorageBlocksSetting add(String var1, String var2, Item var3, boolean var4, Color var5) {
      this.entries.add(new StorageBlocksSetting.Entry(var1, var2, var3, var4, var5));
      return this;
   }

   public List<StorageBlocksSetting.Entry> entries() {
      return Collections.unmodifiableList(this.entries);
   }

   public StorageBlocksSetting.Entry get(String var1) {
      for (StorageBlocksSetting.Entry var3 : this.entries) {
         if (var3.id.equals(var1)) {
            return var3;
         }
      }

      return null;
   }

   public int selectedCount() {
      int var1 = 0;

      for (StorageBlocksSetting.Entry var3 : this.entries) {
         if (var3.enabled) {
            var1++;
         }
      }

      return var1;
   }

   public void clear() {
      for (StorageBlocksSetting.Entry var2 : this.entries) {
         var2.enabled = false;
      }
   }

   public void reset() {
      for (StorageBlocksSetting.Entry var2 : this.entries) {
         var2.reset();
      }
   }

   public static final class Entry {
      private final String id;
      private final String displayName;
      private final Item item;
      private final boolean defaultEnabled;
      private final Color defaultColor;
      private boolean enabled;
      private Color color;
      private boolean tracerEnabled,defaultTracerEnabled;
      private Color tracerColor=Color.WHITE,defaultTracerColor=Color.WHITE;
      public void tracerDefaults(boolean enabled,int argb){tracerEnabled=defaultTracerEnabled=enabled;tracerColor=defaultTracerColor=new Color(argb,true);}
      public boolean tracerEnabled(){return tracerEnabled;}
      public Color tracerColor(){return tracerColor;}
      public void setTracerEnabled(boolean enabled){tracerEnabled=enabled;}
      public void setTracerColor(Color color){tracerColor=color;}

      private Entry(String var1, String var2, Item var3, boolean var4, Color var5) {
         this.id = var1;
         this.displayName = var2;
         this.item = var3;
         this.defaultEnabled = var4;
         this.defaultColor = var5;
         this.enabled = var4;
         this.color = var5;
      }

      public String id() {
         return this.id;
      }

      public String displayName() {
         return this.displayName;
      }

      public Item item() {
         return this.item;
      }

      public boolean enabled() {
         return this.enabled;
      }

      public Color color() {
         return this.color;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public void toggle() {
         this.enabled = !this.enabled;
      }

      public void setColor(Color var1) {
         this.color = new Color(var1.getRGB(),true);
      }

      private void reset() {
         this.enabled = this.defaultEnabled;
         this.color = this.defaultColor;this.tracerEnabled=defaultTracerEnabled;this.tracerColor=defaultTracerColor;
      }
   }
}
