package cherryblossom.module.modules.client;

import cherryblossom.event.EventListener;
import cherryblossom.event.events.PacketReceiveEvent;
import cherryblossom.event.events.TickEvent;

import cherryblossom.module.Category;
import cherryblossom.module.Module;
import cherryblossom.module.setting.BooleanSetting;
import cherryblossom.module.setting.ModeSetting;
import cherryblossom.module.setting.NumberSetting;
import cherryblossom.module.setting.Setting;
import cherryblossom.module.setting.StringSetting;
import cherryblossom.utils.EncryptedString;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import cherryblossom.feature.CherryBlossomClickGuiScreen;
import cherryblossom.feature.UiPalette;

public final class CherryBlossom extends Module {
   public static final ModeSetting<UiPalette> theme = new ModeSetting<>(EncryptedString.of("Theme"), UiPalette.Rose, UiPalette.class)
      .setDescription(EncryptedString.of("Changes the interface, blossom tree and HUD together"));
   public static final BooleanSetting toggleNotifications=new BooleanSetting("Module Toggle Notifications",true);
   public static final BooleanSetting uiSounds = new BooleanSetting(EncryptedString.of("UI Sounds"), true)
      .setDescription(EncryptedString.of("Soft sounds for clicks, toggles and menus"));
   public static final NumberSetting uiVolume = new NumberSetting(EncryptedString.of("UI Volume"), 0.0, 100.0, 70.0, 1.0)
      .getValue(EncryptedString.of("Volume of the interface sounds in percent"));
   public static final NumberSetting guiSize = new NumberSetting(EncryptedString.of("GUI Size"), 70.0, 140.0, 100.0, 5.0)
      .getValue(EncryptedString.of("Scale of the CherryBlossom menu in percent"));
   public static final BooleanSetting renderBackground = new BooleanSetting(EncryptedString.of("Background"), true)
      .setDescription(EncryptedString.of("Dims the world behind CherryBlossom editor screens"));
   public static final BooleanSetting discordRpc = new BooleanSetting(EncryptedString.of("Discord RPC"), true)
      .setDescription(EncryptedString.of("Show CherryBlossomClient in Discord with a Discord server button"));
   public static final StringSetting discordApplicationId = new StringSetting(EncryptedString.of("Discord Application ID"), cherryblossom.integration.DiscordDefaults.get("application_id"))
      .setDescription(EncryptedString.of("Public ID of your CherryBlossomClient Discord application"));
   public static final StringSetting discordInvite = new StringSetting(EncryptedString.of("Discord Server Invite"), cherryblossom.integration.DiscordDefaults.get("invite"))
      .setDescription(EncryptedString.of("Server invite opened by the Discord presence button"));
   private final BooleanSetting preventClose = new BooleanSetting(EncryptedString.of("Prevent Close"), true)
      .setDescription(EncryptedString.of("For servers with freeze plugins that don't let you open the GUI"));
   public static final ModeSetting<CherryBlossom.AnimationMode> animationMode = new ModeSetting<>(
      EncryptedString.of("Animations"), CherryBlossom.AnimationMode.NORMAL, CherryBlossom.AnimationMode.class
   );
   public boolean shouldPreventClose;

   public CherryBlossom() {
      super(EncryptedString.of("CherryBlossom+"), EncryptedString.of("Settings for the client"), 344, Category.CLIENT);
      this.addSettings(
         new Setting[]{
            theme, toggleNotifications, uiSounds, uiVolume, guiSize, renderBackground, this.preventClose, animationMode, discordRpc, discordApplicationId, discordInvite
         }
      );
   }

   @Override
   public void onEnable() {
      cherryblossom.integration.CherryGui.toggle();
      this.setEnabled(false);
   }

   @Override
   public void onDisable() {}
   @EventListener
   public void onTick(TickEvent var1) {
      if (cherryblossom.CherryBlossom.INSTANCE.GUI != null) {
         cherryblossom.CherryBlossom.INSTANCE.GUI.syncAmbience();
      }
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent var1) {
      if (this.shouldPreventClose && var1.packet instanceof OpenScreenS2CPacket && this.preventClose.getValue()) {
         var1.cancel();
      }
   }

   public static enum AnimationMode {
      NORMAL("Normal", 0),
      POSITIVE("Positive", 1),
      OFF("Off", 2);

      private AnimationMode(final String nullxx, final int nullxxx) {
      }

      private static CherryBlossom.AnimationMode[] $values() {
         return new CherryBlossom.AnimationMode[]{NORMAL, POSITIVE, OFF};
      }
   }
}
