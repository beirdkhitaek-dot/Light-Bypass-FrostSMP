package cherryblossom.module;

public interface NewFeature {
}
