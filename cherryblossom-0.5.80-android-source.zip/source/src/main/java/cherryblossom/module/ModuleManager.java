package cherryblossom.module;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import cherryblossom.event.EventListener;
import cherryblossom.event.events.KeyEvent;
import cherryblossom.event.events.MouseButtonEvent;
import cherryblossom.module.modules.client.CherryBlossom;
import cherryblossom.module.setting.BindSetting;
import cherryblossom.utils.EncryptedString;
import net.minecraft.client.gui.screen.ChatScreen;
import cherryblossom.feature.CherryBlossomClickGuiScreen;
import cherryblossom.feature.AnchorMacroModule;
import cherryblossom.feature.AutoCrystalModule;
import cherryblossom.feature.AutoInvTotemModule;
import cherryblossom.feature.AutoTotemModule;
import cherryblossom.feature.DoubleAnchorModule;
import cherryblossom.feature.ElytraSwapModule;
import cherryblossom.feature.HitboxModule;
import cherryblossom.feature.HoverTotemModule;
import cherryblossom.feature.MaceSwapModule;
import cherryblossom.feature.StaticHitboxesModule;
import cherryblossom.feature.AntiTrapModule;
import cherryblossom.feature.AntiVanishModule;
import cherryblossom.feature.AuctionSniperModule;
import cherryblossom.feature.AutoRtpModule;
import cherryblossom.feature.AutoSellModule;
import cherryblossom.feature.AutoSpawnerSellModule;
import cherryblossom.feature.SpawnerDropperModule;
import cherryblossom.feature.FakeScoreboardModule;
import cherryblossom.feature.LuckyFinderModule;
import cherryblossom.feature.NetheriteFinderModule;
import cherryblossom.feature.OgScoreboardModule;
import cherryblossom.feature.PlayerBypassModule;
import cherryblossom.feature.RegionMapModule;
import cherryblossom.feature.RtpBaseFinderModule;
import cherryblossom.feature.ShulkerDropperModule;
import cherryblossom.feature.SpawnerOrderModule;
import cherryblossom.feature.StaffListModule;
import cherryblossom.feature.TunnelBaseFinderModule;
import cherryblossom.feature.SpawnerProtectModule;
import cherryblossom.feature.AutoEatModule;
import cherryblossom.feature.AutoFireworkModule;
import cherryblossom.feature.AutoMineModule;
import cherryblossom.feature.AutoTpaModule;
import cherryblossom.feature.AutoToolModule;
import cherryblossom.feature.CordSnapperModule;
import cherryblossom.feature.ElytraGlideModule;
import cherryblossom.feature.FakePayModule;
import cherryblossom.feature.FastPlaceModule;
import cherryblossom.feature.FreecamModule;
import cherryblossom.feature.FreelookModule;
import cherryblossom.feature.NameProtectModule;
import cherryblossom.feature.PlayerDetectionModule;
import cherryblossom.feature.SkinProtectModule;
import cherryblossom.feature.SwingSpeedModule;
import cherryblossom.feature.BedrockEspModule;
import cherryblossom.feature.BlockNotifierModule;
import cherryblossom.feature.BlockOverlayModule;
import cherryblossom.feature.CustomSkysModule;
import cherryblossom.feature.CustomToolsModule;
import cherryblossom.feature.CustomTotemModule;
import cherryblossom.feature.HudModule;

import cherryblossom.feature.HandAuraModule;
import cherryblossom.feature.ItemOutlineModule;
import cherryblossom.feature.PlayerEspModule;
import cherryblossom.feature.SpawnerNotifyModule;
import cherryblossom.feature.TargetHudModule;
import cherryblossom.feature.Character3dModule;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();
   private final Map<Class<?>, Module> modulesByClass = new HashMap<>();
   private final Map<Category, List<Module>> modulesByCategory = new EnumMap<>(Category.class);

   public ModuleManager() {
      this.a();
      this.d();
   }

   public void a() {
      this.a(new ElytraSwapModule());
      this.a(new MaceSwapModule());
      this.a(new HitboxModule());
      this.a(new StaticHitboxesModule());
      this.a(new AutoTotemModule());
      this.a(new HoverTotemModule());
      this.a(new AutoInvTotemModule());
      this.a(new AnchorMacroModule());
      this.a(new AutoCrystalModule());
      this.a(new DoubleAnchorModule());
      this.a(new FastPlaceModule());
      this.a(new FreecamModule());
      this.a(new FreelookModule());
      this.a(new AutoFireworkModule());
      this.a(new ElytraGlideModule());
      this.a(new AutoToolModule());
      this.a(new SwingSpeedModule());
      this.a(new AutoEatModule());
      this.a(new AutoMineModule());
      this.a(new CordSnapperModule());
      this.a(new NameProtectModule());
      this.a(new SkinProtectModule());
      cherryblossom.anubis.esp.ChunkScanner.init();
      this.a(new PlayerDetectionModule());
      this.a(new FakePayModule());
      this.macro(new AutoTpaModule());
      this.macro(new AutoRtpModule());
      this.macro(new SpawnerProtectModule());
      
      this.a(new SpawnerOrderModule());
      this.a(new RtpBaseFinderModule());
      this.a(new TunnelBaseFinderModule());
      this.a(new NetheriteFinderModule());
      this.macro(new SpawnerDropperModule());
      this.macro(new AutoSellModule());
      this.macro(new ShulkerDropperModule());
      this.a(new AntiTrapModule());

      try {
         this.macro(new AuctionSniperModule());
      } catch (RuntimeException var3) {
         System.err.println("CherryBlossom: Auction Sniper unavailable: " + var3.getMessage());
      }

      this.macro(new AutoSpawnerSellModule());
      this.a(new FakeScoreboardModule());
      this.a(new OgScoreboardModule());
      this.a(new RegionMapModule());
      this.a(new cherryblossom.feature.BoatFlyModule());
      this.a(new cherryblossom.anubis.module.impl.misc.RenderDistanceToggleModule());
      this.a(new PlayerBypassModule());
      this.a(new cherryblossom.anubis.module.impl.render.ChunkScannerModule());
      this.a(new cherryblossom.anubis.module.impl.render.SusChunkFinderModule());
      this.a(new cherryblossom.anubis.module.impl.render.BetterSusChunkModule());
      
      this.safe("Prime Chunk Finder", cherryblossom.anubis.module.impl.render.PrimeChunkFinderModule::new);
      this.safe("Anti Vanish", AntiVanishModule::new);
      this.safe("Custom Totem", CustomTotemModule::new);
      this.safe("Custom Tools", CustomToolsModule::new);
      this.a(new cherryblossom.feature.KnifeModule());
      this.a(new cherryblossom.feature.CustomFovModule());
      this.a(new cherryblossom.feature.HandPositionModule());
      this.a(new cherryblossom.anubis.module.impl.render.CustomGlintModule());
      this.a(new cherryblossom.feature.CreamyKeysModule());
      this.a(new cherryblossom.feature.WorldLyricsModule());
      this.a(new cherryblossom.feature.KeystrokesModule());
      this.a(new cherryblossom.feature.JumpCirclesModule());
      this.a(new PlayerEspModule());
      this.a(new cherryblossom.anubis.module.impl.render.StorageEspModule());
      this.a(new cherryblossom.anubis.module.impl.render.BlockEspModule());
      this.a(new BlockNotifierModule());
      this.a(new BedrockEspModule());
      this.a(new SpawnerNotifyModule());
      this.a(new TargetHudModule());
      this.safe("3D Character", Character3dModule::new);
      this.safe("Custom Skys", CustomSkysModule::new);
      this.safe("Spotify HUD", cherryblossom.feature.SpotifyHudModule::new);
      this.safe("Block Overlay", BlockOverlayModule::new);
      this.safe("Hand Aura", HandAuraModule::new);
      this.a(new CherryBlossom());
      this.a(new HudModule());

      try {
         this.a(new ItemOutlineModule());
      } catch (Throwable var2) {
         System.err.println("CherryBlossom: Item Outline unavailable: " + var2.getClass().getSimpleName());
      }

      this.a(new LuckyFinderModule());
      this.a(new StaffListModule());
      this.a(new cherryblossom.feature.AutoSchematicBuilderModule());
   }

   public List<Module> b() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.modules;
   }

   public void d() {
      cherryblossom.CherryBlossom.INSTANCE.getEventBus().register(this);

      for (Module var2 : this.modules) {
         var2.addSetting(
            new BindSetting(EncryptedString.of("Keybind"), var2.getKeybind(), true).setDescription(EncryptedString.of("Key to enabled the module"))
         );
      }
   }

   public List<Module> a(Category var1) {
      return this.modulesByCategory.getOrDefault(var1, List.of());
   }

   public Module getModuleByClass(Class<? extends Module> var1) {
      Module var2 = this.modulesByClass.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         for (Module var4 : this.modules) {
            if (var1.isInstance(var4)) {
               return var4;
            }
         }

         return null;
      }
   }

   private void safe(String var1, Supplier<? extends Module> var2) {
      try {
         this.a((Module)var2.get());
      } catch (Throwable var4) {
         System.err.println("CherryBlossom: " + var1 + " unavailable: " + var4);
         var4.printStackTrace(System.err);
      }
   }

   private void macro(Module var1) {
      var1.setCategory(Category.MACROS);
      this.a(var1);
   }

   public void a(Module var1) {
      cherryblossom.CherryBlossom.INSTANCE.getEventBus().register(var1);
      this.modules.add(var1);
      this.modulesByClass.put(var1.getClass(), var1);
      this.modulesByCategory.computeIfAbsent(var1.getCategory(), var0 -> new ArrayList<>()).add(var1);
   }

   @EventListener
   public void a(KeyEvent var1) {
      if(net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof cherryblossom.feature.BlockPickerScreen)return;
      if (cherryblossom.integration.CherryGui.capturesKeyboard()) return;
      if (cherryblossom.integration.CherryGui.capturesInput()) {
         Module opener = this.getModuleByClass(CherryBlossom.class);
         if (opener == null || var1.key != opener.getKeybind()) return;
      }
      if (var1.mode == 1 && (cherryblossom.CherryBlossom.mc == null || !(cherryblossom.CherryBlossom.mc.currentScreen instanceof CherryBlossomClickGuiScreen var2) || !var2.isTyping())) {
         this.modules
            .forEach(
               var1x -> {
                  if (cherryblossom.integration.CherryGui.capturesInput() && !(var1x instanceof CherryBlossom)) return;
                  boolean var2x;
                  if (var1x.getKeybind() == var1.key
                     && (
                        (var2x = var1x instanceof CherryBlossom)
                           || cherryblossom.CherryBlossom.mc.player != null && cherryblossom.CherryBlossom.mc.options != null && !(cherryblossom.CherryBlossom.mc.currentScreen instanceof ChatScreen)
                     )) {
                     var1x.toggle();
                  }
               }
            );
      }
   }

   @EventListener
   public void onMouseButton(MouseButtonEvent var1) {
      if(net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof cherryblossom.feature.BlockPickerScreen)return;
      if (cherryblossom.integration.CherryGui.capturesInput()) return;
      if (var1.actions == 1
         && var1.button >= 0
         && var1.button <= 7
         && !(cherryblossom.CherryBlossom.mc.currentScreen instanceof CherryBlossomClickGuiScreen)
         && !(cherryblossom.CherryBlossom.mc.currentScreen instanceof ChatScreen)) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2;
                  if (var1x.getKeybind() == var1.button
                     && ((var2 = var1x instanceof CherryBlossom) || cherryblossom.CherryBlossom.mc.player != null && cherryblossom.CherryBlossom.mc.options != null)) {
                     var1x.toggle();
                  }
               }
            );
      }
   }
}
