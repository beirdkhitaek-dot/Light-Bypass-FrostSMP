package cherryblossom.mixin;

import cherryblossom.CherryBlossom;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import cherryblossom.feature.FreecamModule;

@Mixin(
   value = {KeyboardInput.class},
   remap = false
)
public abstract class FreecamInputMixin {
   @Inject(
      method = {"method_3129"},
      at = {@At("TAIL")},
      remap = false
   )
   private void cherryblossom$continueBodyInput(CallbackInfo var1) {
      if (CherryBlossom.INSTANCE != null && CherryBlossom.INSTANCE.getModuleManager() != null) {
         FreecamModule var2 = (FreecamModule)CherryBlossom.INSTANCE.getModuleManager().getModuleByClass(FreecamModule.class);
         if (var2 != null && var2.isEnabled()) {
            var2.applyContinuedPlayerInput((Input)(Object)this);
         }
      }
   }
}
