package cherryblossom.mixin;

import com.mojang.authlib.GameProfile;
import cherryblossom.CherryBlossom;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import cherryblossom.feature.SkinProtectModule;

@Mixin({PlayerListEntry.class})
public abstract class PlayerListEntrySkinMixin {
   @Inject(
      method = {"method_52810"},
      at = {@At("RETURN")},
      cancellable = true,
      remap = false
   )
   private void cherryblossom$replaceSkinTextures(CallbackInfoReturnable<SkinTextures> var1) {
      if (CherryBlossom.INSTANCE != null && CherryBlossom.INSTANCE.MODULE_MANAGER != null) {
         SkinProtectModule var2 = (SkinProtectModule)CherryBlossom.INSTANCE.MODULE_MANAGER.getModuleByClass(SkinProtectModule.class);
         if (var2 != null && var2.isEnabled()) {
            GameProfile var3 = ((PlayerListEntry)(Object)this).getProfile();
            var1.setReturnValue(var2.replacementFor(var3.id(), var3.name(), (SkinTextures)var1.getReturnValue()));
         }
      }
   }
}
