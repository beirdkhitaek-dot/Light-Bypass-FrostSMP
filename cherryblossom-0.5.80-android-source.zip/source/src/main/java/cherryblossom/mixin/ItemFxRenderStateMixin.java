package cherryblossom.mixin;

import cherryblossom.itemfx.ItemFx;
import cherryblossom.itemfx.ItemFxState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemRenderState.class})
public abstract class ItemFxRenderStateMixin implements ItemFxState {
   @Shadow
   ItemDisplayContext displayContext;
   @Shadow
   private int layerCount;
   @Shadow
   private LayerRenderState[] layers;
   @Unique
   private int cherryblossom$fx;

   @Override
   public int cherryblossom$fx() {
      return this.cherryblossom$fx;
   }

   @Override
   public void cherryblossom$setFx(int var1) {
      this.cherryblossom$fx = var1;
   }

   @Override
   public LayerRenderState cherryblossom$layer0() {
      return this.layers[0];
   }

   @Inject(
      method = {"clear"},
      at = {@At("HEAD")}
   )
   private void cherryblossom$clearFx(CallbackInfo var1) {
      this.cherryblossom$fx = 0;
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cherryblossom$renderFx(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, int var4, int var5, CallbackInfo var6) {
      if (this.cherryblossom$fx != 0 && this.layerCount > 0) {
         try {
            if (ItemFx.render(this.cherryblossom$fx, this.displayContext, this.layers[0], var1, var2, var3)) {
               var6.cancel();
            }
         } catch (Throwable var8) {
            this.cherryblossom$fx = 0;
            System.err.println("CherryBlossom: custom item render failed: " + var8);
         }
      }
   }
}
