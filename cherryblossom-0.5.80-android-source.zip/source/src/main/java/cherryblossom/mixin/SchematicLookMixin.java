package cherryblossom.mixin;
import cherryblossom.schematic.BuildCamera;
import cherryblossom.schematic.SchematicIntegration;
import net.minecraft.entity.Entity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Entity.class)
public abstract class SchematicLookMixin{
    @Inject(method="changeLookDirection",at=@At("HEAD"),cancellable=true)
    private void cherryblossom$schematicLook(double dx,double dy,CallbackInfo ci){
        if((Object)this==MinecraftClient.getInstance().player&&cherryblossom.integration.TrialAccess.allowed()
            &&BuildCamera.isActive()&&!SchematicIntegration.freecam()&&!SchematicIntegration.freelook()){
            BuildCamera.look(dx,dy);ci.cancel();
        }
    }
}
