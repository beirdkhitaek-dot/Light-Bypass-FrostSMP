package cherryblossom.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import cherryblossom.feature.CharacterRenderStateAccess;
import cherryblossom.feature.WornCharacterModel;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderState.class})
public abstract class CharacterRenderStateMixin implements CharacterRenderStateAccess {
   @Unique
   private WornCharacterModel cherryblossom$character;
   @Unique
   private float cherryblossom$seat;

   @Override
   public WornCharacterModel cherryblossom$character() {
      return this.cherryblossom$character;
   }

   @Override
   public void cherryblossom$setCharacter(WornCharacterModel var1) {
      this.cherryblossom$character = var1;
   }

   @Override
   public float cherryblossom$seat() {
      return this.cherryblossom$seat;
   }

   @Override
   public void cherryblossom$setSeat(float var1) {
      this.cherryblossom$seat = var1;
   }
}
