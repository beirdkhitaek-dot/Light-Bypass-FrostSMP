package cherryblossom.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import cherryblossom.feature.CustomSkysModule;

@Environment(EnvType.CLIENT)
@Mixin({FogRenderer.class})
public abstract class CustomSkysFogMixin {
   @Inject(
      method = {"getFogColor"},
      at = {@At("RETURN")}
   )
   private void cherryblossom$fogColour(Camera var1, float var2, ClientWorld var3, int var4, float var5, CallbackInfoReturnable<Vector4f> var6) {
      if (var1.getSubmersionType() == CameraSubmersionType.NONE && !(var5 > 0.0F)) {
         if (var1.getFocusedEntity() instanceof LivingEntity var7 && (var7.hasStatusEffect(StatusEffects.BLINDNESS) || var7.hasStatusEffect(StatusEffects.DARKNESS))) {
            return;
         }

         CustomSkysModule var9 = CustomSkysModule.get();
         if (var9 != null) {
            var9.fog(var1, var3, (Vector4f)var6.getReturnValue());
         }
      }
   }
}
