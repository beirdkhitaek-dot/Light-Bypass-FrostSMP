package cherryblossom.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({ClientWorld.class})
public interface CustomSkysClientWorldAccessor {
   @Accessor("lightningTicksLeft")
   int cherryblossom$atmosphereSkyFlash();
}
