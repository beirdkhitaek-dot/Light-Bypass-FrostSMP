package cherryblossom.mixin;
import cherryblossom.schematic.SchematicSetupScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public abstract class SchematicScreenHudMixin{
    @Inject(method="render",at=@At("HEAD"),cancellable=true)
    private void cherryblossom$cleanSchematicSetup(DrawContext context,RenderTickCounter counter,CallbackInfo ci){
        if(MinecraftClient.getInstance().currentScreen instanceof SchematicSetupScreen||MinecraftClient.getInstance().currentScreen instanceof cherryblossom.schematic.SchematicPreviewScreen)ci.cancel();
    }
}
