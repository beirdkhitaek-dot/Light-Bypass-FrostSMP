package cherryblossom.mixin;

import cherryblossom.module.modules.client.CherryBlossom;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The controller shares this scale between rendering and pointer hit testing. */
@Pseudo
@Mixin(targets="dev.cherryblossom.client.CherryBlossomController",remap=false)
public abstract class CherryGuiScaleMixin {
    @Inject(method="clickGuiScreenScale",at=@At("RETURN"),cancellable=true,remap=false)
    private void cherry$size(CallbackInfoReturnable<Float> result) {
        // Reserve space at the maximum size, so the whole menu remains reachable.
        float percent=(float)Math.max(70,Math.min(140,CherryBlossom.guiSize.getValue()));
        float scale=result.getReturnValue()/0.88f*0.96f*percent/140f;
        try{scale=((Number)Class.forName("dev.cherryblossom.client.setting.LayoutPreference").getMethod("screenScale",float.class).invoke(null,scale)).floatValue();}
        catch(ReflectiveOperationException ignored){}
        result.setReturnValue(scale);
    }

    @Inject(method="clock",at=@At("RETURN"),cancellable=true,remap=false)
    private void cherry$animationClock(CallbackInfoReturnable<Double> result) {
        if(CherryBlossom.animationMode.getModeIndex()==2)result.setReturnValue(0.0);
    }
}
