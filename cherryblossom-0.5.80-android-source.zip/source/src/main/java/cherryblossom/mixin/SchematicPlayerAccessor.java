package cherryblossom.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({ClientPlayerEntity.class})
public interface SchematicPlayerAccessor {
   @Accessor("lastYawClient")
   float cherryblossom$sentYaw();

   @Accessor("lastPitchClient")
   float cherryblossom$sentPitch();
}
