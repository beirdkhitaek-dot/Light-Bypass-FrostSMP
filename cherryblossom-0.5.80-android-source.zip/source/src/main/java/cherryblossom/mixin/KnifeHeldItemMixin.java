package cherryblossom.mixin;

import cherryblossom.knife.KnifeRenderer;
import cherryblossom.feature.KnifeModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({HeldItemRenderer.class})
public abstract class KnifeHeldItemMixin {
   @Inject(
      method = {"renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cherryblossom$knife(
      LivingEntity entity, ItemStack stack, ItemDisplayContext context, MatrixStack pose, OrderedRenderCommandQueue collector, int light, CallbackInfo ci
   ) {
      KnifeModule knife = KnifeModule.get();
      if (knife != null && knife.isEnabled()) {
         if (KnifeRenderer.render(
            stack,
            context,
            pose,
            collector,
            light,
            knife.size(),
            knife.matchMaterial(),
            knife.offX(),
            knife.offY(),
            knife.offZ(),
            knife.knife(),
            knife.trailSeconds()
         )) {
            ci.cancel();
         }
      }
   }

   @ModifyVariable(
      method = {"renderFirstPersonItem"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 2,
      require = 1
   )
   private float cherryblossom$noAttackSwing(float swingProgress) {
      KnifeModule knife = KnifeModule.get();
      if (knife != null && knife.isEnabled() && !knife.attackAnimation()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         return mc.player != null && KnifeRenderer.isKnifeItem(mc.player.getMainHandStack()) ? 0.0F : swingProgress;
      } else {
         return swingProgress;
      }
   }
}
