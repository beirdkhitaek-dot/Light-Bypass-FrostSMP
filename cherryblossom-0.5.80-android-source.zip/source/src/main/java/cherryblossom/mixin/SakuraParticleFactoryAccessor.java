package cherryblossom.mixin;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ParticleManager.class)
public interface SakuraParticleFactoryAccessor {
    @Invoker("createParticle")
    Particle cherry$createPetal(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz);
}
