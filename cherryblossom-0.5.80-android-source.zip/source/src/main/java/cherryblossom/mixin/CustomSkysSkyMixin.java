package cherryblossom.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.world.MoonPhase;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.SkyRendering;
import net.minecraft.world.dimension.DimensionType.Skybox;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import cherryblossom.feature.CustomSkysModule;

@Environment(EnvType.CLIENT)
@Mixin({SkyRendering.class})
public abstract class CustomSkysSkyMixin {
   @Inject(
      method = {"updateRenderState"},
      at = {@At("TAIL")}
   )
   private void cherryblossom$readSky(ClientWorld var1, float var2, Camera var3, SkyRenderState var4, CallbackInfo var5) {
      CustomSkysModule var6 = CustomSkysModule.get();
      if (var6 != null && var4.skybox == Skybox.OVERWORLD) {
         var6.extract(var1, var2, var4);
      }
   }

   @Inject(
      method = {"renderTopSky"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cherryblossom$dome(int var1, CallbackInfo var2) {
      CustomSkysModule var3 = CustomSkysModule.get();
      if (var3 != null && var3.skyDisc()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"renderGlowingSky"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cherryblossom$noSunriseFan(MatrixStack var1, float var2, int var3, CallbackInfo var4) {
      CustomSkysModule var5 = CustomSkysModule.get();
      if (var5 != null && var5.replacesSunrise()) {
         var4.cancel();
      }
   }

   @Inject(
      method = {"renderStars"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cherryblossom$stars(float var1, MatrixStack var2, CallbackInfo var3) {
      CustomSkysModule var4 = CustomSkysModule.get();
      if (var4 != null && var4.stars(var2)) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"renderCelestialBodies"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/SkyRendering;renderMoon(Lnet/minecraft/world/MoonPhase;FLnet/minecraft/client/util/math/MatrixStack;)V"
      )}
   )
   private void cherryblossom$beforeMoon(MatrixStack var1, float var2, float var3, float var4, MoonPhase var5, float var6, float var7, CallbackInfo var8) {
      CustomSkysModule var9 = CustomSkysModule.get();
      if (var9 != null) {
         var9.beforeMoon(var1);
      }
   }

   @Inject(
      method = {"renderCelestialBodies"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/SkyRendering;renderMoon(Lnet/minecraft/world/MoonPhase;FLnet/minecraft/client/util/math/MatrixStack;)V",
         shift = Shift.AFTER
      )}
   )
   private void cherryblossom$afterMoon(MatrixStack var1, float var2, float var3, float var4, MoonPhase var5, float var6, float var7, CallbackInfo var8) {
      CustomSkysModule var9 = CustomSkysModule.get();
      if (var9 != null) {
         var9.afterMoon(var1);
      }
   }

   @Inject(
      method = {"renderCelestialBodies"},
      at = {@At("TAIL")}
   )
   private void cherryblossom$afterCelestials(MatrixStack var1, float var2, float var3, float var4, MoonPhase var5, float var6, float var7, CallbackInfo var8) {
      CustomSkysModule var9 = CustomSkysModule.get();
      if (var9 != null) {
         var9.afterCelestials();
      }
   }

   @Inject(
      method = {"renderEndSky"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cherryblossom$endSky(CallbackInfo var1) {
      CustomSkysModule var2 = CustomSkysModule.get();
      if (var2 != null && var2.endSky()) {
         var1.cancel();
      }
   }
}
