package cherryblossom.mixin;

import cherryblossom.feature.CustomFovModule;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class CustomFovMixin {
    @ModifyExpressionValue(method="getFov",at=@At(value="INVOKE",target="Ljava/lang/Integer;intValue()I"))
    private int cherryblossom$customBaseFov(int vanilla){return CustomFovModule.baseFov(vanilla);}

    @Inject(method="getFov",at=@At("RETURN"),cancellable=true)
    private void cherryblossom$validProjection(Camera camera,float tickDelta,boolean changingFov,CallbackInfoReturnable<Float> result){
        if(changingFov&&CustomFovModule.active())result.setReturnValue(Math.max(1f,Math.min(170f,result.getReturnValueF())));
    }
}
