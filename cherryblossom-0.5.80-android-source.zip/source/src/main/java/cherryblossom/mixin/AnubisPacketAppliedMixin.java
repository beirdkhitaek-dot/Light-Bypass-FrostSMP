package cherryblossom.mixin;
import cherryblossom.module.ext.ExtBridge;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Detectors see packets only after vanilla has updated the client world. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class AnubisPacketAppliedMixin {
    @Inject(method={"onChunkData","onLightUpdate","onBlockUpdate","onChunkDeltaUpdate","onBlockEntityUpdate","onGameJoin"},at=@At("TAIL"))
    private void cherryblossom$applied(@Coerce Packet<?> packet,CallbackInfo ci){ExtBridge.packetApplied(packet);}
}
