package cherryblossom.mixin;

import cherryblossom.event.events.ChunkDataEvent;
import cherryblossom.event.events.EntitySpawnEvent;
import cherryblossom.event.events.LightUpdateEvent;
import cherryblossom.event.events.TotemPopEvent;
import cherryblossom.manager.EventManager;
import cherryblossom.utils.ChunkLightTracker;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.UnloadChunkS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayNetworkHandler.class})
public abstract class ClientPlayNetworkHandlerMixin {
   @Inject(
      method = {"method_11148"},
      at = {@At("TAIL")},
      remap = false
   )
   private void onEntityStatus(EntityStatusS2CPacket var1, CallbackInfo var2) {
      MinecraftClient var3 = MinecraftClient.getInstance();
      if (var3.world != null && var1.getStatus() == 35 && var1.getEntity(var3.world) == var3.player) {
         EventManager.b(new TotemPopEvent());
      }
   }

   @Inject(
      method = {"method_11128"},
      at = {@At("TAIL")},
      remap = false
   )
   private void onChunkData(ChunkDataS2CPacket var1, CallbackInfo var2) {
      ChunkLightTracker.ingest(var1.getChunkX(), var1.getChunkZ(), var1.getLightData());
      EventManager.b(new ChunkDataEvent(var1));
   }

   @Inject(
      method = {"method_11143"},
      at = {@At("TAIL")},
      remap = false
   )
   private void onLightUpdate(LightUpdateS2CPacket var1, CallbackInfo var2) {
      ChunkLightTracker.ingest(var1.getChunkX(), var1.getChunkZ(), var1.getData());
      EventManager.b(new LightUpdateEvent(var1));
   }

   @Inject(
      method = {"method_11107"},
      at = {@At("TAIL")},
      remap = false
   )
   private void onUnloadChunk(UnloadChunkS2CPacket var1, CallbackInfo var2) {
      ChunkLightTracker.unload(var1.pos().x, var1.pos().z);
   }

   @Inject(
      method = {"method_11112"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private void onEntitySpawn(EntitySpawnS2CPacket var1, CallbackInfo var2) {
      EntitySpawnEvent var3 = new EntitySpawnEvent(var1);
      EventManager.b(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }
}
