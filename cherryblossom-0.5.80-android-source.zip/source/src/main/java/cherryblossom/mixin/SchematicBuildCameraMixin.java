package cherryblossom.mixin;
import cherryblossom.schematic.BuildCamera;
import cherryblossom.schematic.SchematicIntegration;
import cherryblossom.schematic.SchematicPreviewScreen;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=Camera.class,priority=1900)
public abstract class SchematicBuildCameraMixin{
    @Shadow protected abstract void setRotation(float yaw,float pitch);
    @Inject(method="update",at=@At("TAIL"))
    private void cherryblossom$builderView(World world,Entity focused,boolean thirdPerson,boolean inverse,float partial,CallbackInfo ci){
        if(cherryblossom.integration.TrialAccess.allowed()&&BuildCamera.isActive()&&focused!=null&&!SchematicPreviewScreen.isOpen()&&!SchematicIntegration.freecam()&&!SchematicIntegration.freelook()){
            float[] view=BuildCamera.view(focused.getYaw(partial),focused.getPitch(partial),partial);setRotation(view[0],view[1]);
        }
    }
}
