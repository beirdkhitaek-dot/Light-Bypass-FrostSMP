package cherryblossom.mixin;

import cherryblossom.event.events.MouseButtonEvent;
import cherryblossom.event.events.MouseScrolledEvent;
import cherryblossom.manager.EventManager;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public abstract class MouseMixin {
   @Shadow private double cursorDeltaX;
   @Shadow private double cursorDeltaY;

   // The wheel is an overlay rather than a vanilla Screen. Refocusing the window
   // must not let vanilla re-grab its pointer or consume motion as camera input.
   @Inject(method = "lockCursor", at = @At("HEAD"), cancellable = true)
   private void cherry$keepGuiCursorFree(CallbackInfo ci) {
      if (cherryblossom.integration.CherryGui.screenGuiActive() || cherryblossom.schematic.SchematicScreenBridge.isOpen() || net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof cherryblossom.feature.BlockPickerScreen) {
         Mouse mouse=(Mouse)(Object)this;
         if(mouse.isCursorLocked()) mouse.unlockCursor();
         this.cursorDeltaX=0; this.cursorDeltaY=0;
         ci.cancel();
      }
   }

   @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
   private void cherry$blockGuiCameraMotion(double timeDelta, CallbackInfo ci) {
      if (cherryblossom.integration.CherryGui.screenGuiActive() || cherryblossom.schematic.SchematicScreenBridge.isOpen() || net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof cherryblossom.feature.BlockPickerScreen) {
         Mouse mouse=(Mouse)(Object)this;
         if(mouse.isCursorLocked()) mouse.unlockCursor();
         this.cursorDeltaX=0; this.cursorDeltaY=0;
         ci.cancel();
      }
   }

   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseButton(long window, MouseInput input, int action, CallbackInfo ci) {
      int button = input.button();
      if (cherryblossom.feature.HudDragging.button(button, action)) {ci.cancel();return;}
      if (button != -1) {
         MouseButtonEvent event = new MouseButtonEvent(button, window, action);
         EventManager.b(event);
         if (event.isCancelled()) {
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
      MouseScrolledEvent event = new MouseScrolledEvent(vertical);
      EventManager.b(event);
      if (event.isCancelled()) {
         ci.cancel();
      }
   }
}
