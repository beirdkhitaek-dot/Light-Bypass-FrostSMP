package cherryblossom.mixin;

import cherryblossom.CherryBlossom;
import cherryblossom.imixin.IKeybinding;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Key;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({KeyBinding.class})
public abstract class KeyBindingMixin implements IKeybinding {
   @Shadow
   private Key boundKey;

   @Shadow
   public abstract void setPressed(boolean var1);

   @Override
   public boolean cherryblossom$isActuallyPressed() {
      return InputUtil.isKeyPressed(CherryBlossom.mc.getWindow(), this.boundKey.getCode());
   }

   @Override
   public void cherryblossom$resetPressed() {
      this.setPressed(this.cherryblossom$isActuallyPressed());
   }
}
