package cherryblossom.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import cherryblossom.anubis.module.impl.render.CustomGlintModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.TextureTransform;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin({TextureTransform.class})
public abstract class CustomGlintTextureMixin {
   @ModifyVariable(
      method = {"getGlintTransformation"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private static float cherryblossom$glintPatternScale(float scale) {
      CustomGlintModule module = CustomGlintModule.current();
      return module == null ? scale : scale * module.uvScaleMultiplier();
   }

   @ModifyExpressionValue(
      method = {"getGlintTransformation"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/Util;getMeasuringTimeMs()J"
      )
   )
   private static long cherryblossom$glintClock(long millis) {
      CustomGlintModule module = CustomGlintModule.current();
      return module == null ? millis : module.glintMillis(millis);
   }
}
