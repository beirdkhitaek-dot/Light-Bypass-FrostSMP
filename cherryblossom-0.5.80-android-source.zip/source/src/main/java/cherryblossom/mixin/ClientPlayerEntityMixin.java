package cherryblossom.mixin;

import com.mojang.authlib.GameProfile;
import cherryblossom.event.events.SendMovementPacketsEvent;
import cherryblossom.event.events.TickEvent;
import cherryblossom.manager.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerEntity.class})
public class ClientPlayerEntityMixin extends AbstractClientPlayerEntity {
   @Inject(method="openEditSignScreen",at=@At("HEAD"),cancellable=true)
   private void cherry$completeBuilderSign(net.minecraft.block.entity.SignBlockEntity sign,boolean front,CallbackInfo ci){
      if(cherryblossom.feature.AutoSchematicBuilderModule.finishAutomaticSign(sign,front))ci.cancel();
   }
   @Shadow
   @Final
   protected MinecraftClient client;

   public ClientPlayerEntityMixin(ClientWorld world, GameProfile profile) {
      super(world, profile);
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")}
   )
   private void onSendMovementPackets(CallbackInfo ci) {
      EventManager.b(new SendMovementPacketsEvent());
   }

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onPlayerTick(CallbackInfo ci) {
      EventManager.b(new TickEvent());
   }
}
