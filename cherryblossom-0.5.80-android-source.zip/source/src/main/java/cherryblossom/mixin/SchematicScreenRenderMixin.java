package cherryblossom.mixin;
import cherryblossom.schematic.SchematicSetupScreen;
import cherryblossom.schematic.SchematicScreenBridge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Draw smooth setup controls after vanilla's queued GUI elements. */
@Mixin(value=GameRenderer.class,priority=900)
public abstract class SchematicScreenRenderMixin{
    @Inject(method="render",at=@At("TAIL"))
    private void cherryblossom$schematicScreen(RenderTickCounter counter,boolean tick,CallbackInfo ci){
        if((MinecraftClient.getInstance().currentScreen instanceof SchematicSetupScreen||MinecraftClient.getInstance().currentScreen instanceof cherryblossom.schematic.SchematicPreviewScreen)&&cherryblossom.integration.TrialAccess.allowed())SchematicScreenBridge.renderLate();
    }
}
