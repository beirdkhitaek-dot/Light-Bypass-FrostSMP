package cherryblossom.mixin;

import cherryblossom.feature.BoatFlyModule;
import net.minecraft.entity.vehicle.AbstractBoatEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractBoatEntity.class)
public abstract class BoatFlyMixin {
    @Shadow private float yawVelocity;
    @Inject(method="updateVelocity",at=@At("HEAD"),cancellable=true)
    private void cherry$flightGravity(CallbackInfo ci){
        if(BoatFlyModule.controls((AbstractBoatEntity)(Object)this))ci.cancel();
    }
    @Inject(method="updatePaddles",at=@At("HEAD"),cancellable=true)
    private void cherry$flightMovement(CallbackInfo ci){
        if(BoatFlyModule.move((AbstractBoatEntity)(Object)this)){yawVelocity=0;ci.cancel();}
    }
}
