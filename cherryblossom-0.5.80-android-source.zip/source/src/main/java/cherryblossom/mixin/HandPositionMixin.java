package cherryblossom.mixin;

import cherryblossom.feature.HandPositionModule;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(HeldItemRenderer.class)
public abstract class HandPositionMixin {
    @WrapMethod(method="renderFirstPersonItem")
    private void cherryblossom$handPosition(AbstractClientPlayerEntity player,float tickDelta,float pitch,Hand hand,float swing,ItemStack stack,float equip,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,Operation<Void> original){
        if(!HandPositionModule.active()){original.call(player,tickDelta,pitch,hand,swing,stack,equip,matrices,queue,light);return;}
        matrices.push();
        try{HandPositionModule.apply(matrices,hand);original.call(player,tickDelta,pitch,hand,swing,stack,equip,matrices,queue,light);}
        finally{matrices.pop();}
    }
}
