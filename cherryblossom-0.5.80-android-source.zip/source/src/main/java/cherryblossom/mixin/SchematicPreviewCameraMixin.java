package cherryblossom.mixin;

import cherryblossom.schematic.SchematicPreviewScreen;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {Camera.class},
   priority = 2000
)
public abstract class SchematicPreviewCameraMixin {
   @Shadow
   protected abstract void setPos(double var1, double var3, double var5);

   @Shadow
   protected abstract void setRotation(float var1, float var2);

   @Inject(
      method = {"update(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;ZZF)V"},
      at = {@At("TAIL")}
   )
   private void cherryblossom$schematicPreview(World area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickProgress, CallbackInfo ci) {
      if (SchematicPreviewScreen.isOpen()) {
         double[] c = SchematicPreviewScreen.camera();
         this.setPos(c[0], c[1], c[2]);
         this.setRotation((float)c[3], (float)c[4]);
      }
   }
}
