package cherryblossom.mixin;

import cherryblossom.event.events.Render2DEvent;
import cherryblossom.manager.EventManager;
import cherryblossom.utils.RenderUtils;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import cherryblossom.feature.OgScoreboardModule;

@Mixin({InGameHud.class})
public class InGameHudMixin {
   @org.spongepowered.asm.mixin.Unique private boolean cherry$sidebarMoved;
   @Inject(method="renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",at=@At("HEAD"))
   private void cherry$moveSidebar(DrawContext context,net.minecraft.scoreboard.ScoreboardObjective objective,CallbackInfo ci){cherry$sidebarMoved=cherryblossom.feature.FakeScoreboardModule.positionSidebar(context,objective);}
   @Inject(method="renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",at=@At("RETURN"))
   private void cherry$finishSidebar(DrawContext context,net.minecraft.scoreboard.ScoreboardObjective objective,CallbackInfo ci){if(cherry$sidebarMoved){context.getMatrices().popMatrix();cherry$sidebarMoved=false;}}
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRenderHud(DrawContext ctx, RenderTickCounter rtc, CallbackInfo ci) {
      RenderUtils.setContext(ctx);
      EventManager.b(new Render2DEvent(ctx, rtc.getTickProgress(true)));
   }

   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hideVanillaSidebar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (OgScoreboardModule.shouldHideVanillaSidebar()) {
         ci.cancel();
      }
   }
}
