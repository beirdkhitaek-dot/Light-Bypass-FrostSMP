package cherryblossom.mixin;

import java.util.concurrent.CompletableFuture;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import cherryblossom.feature.CharacterModelCache;

@Mixin({MinecraftClient.class})
public abstract class ExtReloadMixin {
   @Inject(
      method = {"reloadResources"},
      at = {@At("HEAD")}
   )
   private void cherryblossom$extResourceReload(CallbackInfoReturnable<CompletableFuture<Void>> var1) {
      CharacterModelCache.onResourceReload();
   }
}
