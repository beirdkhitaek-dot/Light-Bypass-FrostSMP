package cherryblossom.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import net.minecraft.client.gl.RenderPipelines;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({RenderPipelines.class})
public interface RenderPipelinesAccessor {
   @Invoker("register")
   static RenderPipeline cherryblossom$register(RenderPipeline var0) {
      throw new AssertionError();
   }

   @Accessor(
      value = "TRANSFORMS_AND_PROJECTION_SNIPPET",
      remap = true
   )
   static Snippet cherryblossom$getTransformsSnippet() {
      throw new AssertionError();
   }

   @Accessor(
      value = "RENDERTYPE_OUTLINE_SNIPPET",
      remap = true
   )
   static Snippet cherryblossom$getOutlineSnippet() {
      throw new AssertionError();
   }
}
