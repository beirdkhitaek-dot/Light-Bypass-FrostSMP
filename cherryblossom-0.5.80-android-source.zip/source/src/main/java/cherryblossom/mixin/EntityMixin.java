package cherryblossom.mixin;

import cherryblossom.CherryBlossom;
import cherryblossom.event.events.TargetMarginEvent;
import cherryblossom.event.events.TargetPoseEvent;
import cherryblossom.manager.EventManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import cherryblossom.feature.FreecamModule;
import cherryblossom.feature.FreelookModule;

@Mixin({Entity.class})
public class EntityMixin {
   @Inject(
      method = {"getTargetingMargin"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendMovementPackets(CallbackInfoReturnable<Float> var1) {
      if (EventManager.hasActiveListener(TargetMarginEvent.class)) {
         EventManager.b(new TargetMarginEvent(Entity.class.cast(this), var1));
      }
   }

   @Inject(
      method = {"getPose"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetPose(CallbackInfoReturnable<EntityPose> var1) {
      if (EventManager.hasActiveListener(TargetPoseEvent.class)) {
         EventManager.b(new TargetPoseEvent(Entity.class.cast(this), var1));
      }
   }

   @Inject(
      method = {"changeLookDirection"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void updateChangeLookDirection(double var1, double var3, CallbackInfo var5) {
      if (Entity.class.cast(this) == CherryBlossom.mc.player) {
         FreecamModule var6 = (FreecamModule)CherryBlossom.INSTANCE.MODULE_MANAGER.getModuleByClass(FreecamModule.class);
         if (var6.isEnabled()) {
            var6.updateRotation(var1 * 0.15, var3 * 0.15);
            var5.cancel();
            return;
         }

         FreelookModule var7 = (FreelookModule)CherryBlossom.INSTANCE.MODULE_MANAGER.getModuleByClass(FreelookModule.class);
         if (var7 != null && var7.isEnabled()) {
            var7.consumeMouseDelta(var1, var3);
            var5.cancel();
         }
      }
   }
}
