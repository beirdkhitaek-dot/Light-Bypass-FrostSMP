package cherryblossom.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import cherryblossom.feature.SwingSpeedModule;

@Mixin({LivingEntity.class})
public abstract class HeldItemRendererMixin {
   @Inject(
      method = {"getHandSwingDuration"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void cherryblossom$adjustSwingDuration(CallbackInfoReturnable<Integer> var1) {
      var1.setReturnValue(SwingSpeedModule.adjustDuration(var1.getReturnValueI()));
   }
}
