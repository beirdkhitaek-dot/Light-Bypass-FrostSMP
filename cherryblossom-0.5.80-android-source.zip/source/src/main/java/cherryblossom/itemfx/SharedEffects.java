package cherryblossom.itemfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
/** Lifecycle for item effects used by active modules. */
public final class SharedEffects {
    private static ClientWorld world;
    private static long last;
    public static void frame(){
        var mc=MinecraftClient.getInstance();long now=System.nanoTime();
        float dt=last==0?0.016f:Math.min(0.1f,(now-last)/1_000_000_000f);last=now;
        if(world!=mc.world){if(world!=null)SharedParticles.release();SharedMatrices.reset();world=mc.world;}
        SharedParticles.update(mc.isPaused()?0:dt);ItemFx.frame();
    }
}