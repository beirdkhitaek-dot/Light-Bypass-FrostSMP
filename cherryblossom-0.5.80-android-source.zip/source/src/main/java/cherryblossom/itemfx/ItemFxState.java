package cherryblossom.itemfx;

import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;

public interface ItemFxState {
   int cherryblossom$fx();

   void cherryblossom$setFx(int var1);

   LayerRenderState cherryblossom$layer0();
}
