package cherryblossom.itemfx;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.ShapeIndexBuffer;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import java.util.Random;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.BuiltBuffer;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

public final class SharedParticles {
   public static final int SMOKE = 0;
   public static final int GLOW = 1;
   public static final int SPARK = 2;
   public static final int EMBER = 3;
   public static final int DUST = 4;
   private static final int MAX = 1400;
   private static final int UBO_SIZE = 96;
   private static final RenderPipeline SMOKE_PIPE = pipeline("pipeline/hw_particle_smoke", BlendFunction.TRANSLUCENT);
   private static final RenderPipeline GLOW_PIPE = pipeline("pipeline/hw_particle_glow", BlendFunction.LIGHTNING);
   private static final double[] px = new double[1400];
   private static final double[] py = new double[1400];
   private static final double[] pz = new double[1400];
   private static final float[] vx = new float[1400];
   private static final float[] vy = new float[1400];
   private static final float[] vz = new float[1400];
   private static final float[] age = new float[1400];
   private static final float[] life = new float[1400];
   private static final float[] size = new float[1400];
   private static final float[] grow = new float[1400];
   private static final float[] rot = new float[1400];
   private static final float[] spin = new float[1400];
   private static final float[] seed = new float[1400];
   private static final float[] cr = new float[1400];
   private static final float[] cg = new float[1400];
   private static final float[] cb = new float[1400];
   private static final float[] ca = new float[1400];
   private static final int[] kind = new int[1400];
   private static int count;
   private static float clock;
   private static final Random RANDOM = new Random();
   private static GpuTexture smokeTex;
   private static GpuTextureView smokeView;
   private static GpuTexture glowTex;
   private static GpuTextureView glowView;
   private static GpuBuffer ubo;
   private static ByteBuffer data;

   private SharedParticles() {
   }

   private static RenderPipeline pipeline(String var0, BlendFunction var1) {
      return RenderPipeline.builder(new Snippet[0])
         .withLocation(Identifier.of("cherryblossom", var0))
         .withVertexShader(SharedShaders.PARTICLE)
         .withFragmentShader(SharedShaders.PARTICLE)
         .withUniform("Projection", UniformType.UNIFORM_BUFFER)
         .withUniform("Fog", UniformType.UNIFORM_BUFFER)
         .withUniform("MistData", UniformType.UNIFORM_BUFFER)
         .withSampler("Sampler0")
         .withSampler("DepthSampler")
         .withBlend(var1)
         .withDepthWrite(false)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withCull(false)
         .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
         .build();
   }

   public static Random random() {
      return RANDOM;
   }

   public static void spawn(
      int var0,
      double var1,
      double var3,
      double var5,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16
   ) {
      int var17;
      if (count < 1400) {
         var17 = count++;
      } else {
         var17 = RANDOM.nextInt(1400);
      }

      kind[var17] = var0;
      px[var17] = var1;
      py[var17] = var3;
      pz[var17] = var5;
      vx[var17] = var7;
      vy[var17] = var8;
      vz[var17] = var9;
      size[var17] = var10;
      grow[var17] = var11;
      life[var17] = Math.max(0.05F, var12);
      age[var17] = 0.0F;
      rot[var17] = RANDOM.nextFloat() * 6.2832F;
      spin[var17] = (RANDOM.nextFloat() - 0.5F) * (var0 == 0 ? 0.9F : 0.0F);
      seed[var17] = RANDOM.nextFloat() * 100.0F;
      cr[var17] = var13;
      cg[var17] = var14;
      cb[var17] = var15;
      ca[var17] = var16;
   }

   public static int count() {
      return count;
   }

   public static void clear() {
      count = 0;
   }

   public static void update(float var0) {
      if (!(var0 <= 0.0F) && count != 0) {
         clock += var0;
         float var1 = clock;

         for (int var2 = count - 1; var2 >= 0; var2--) {
            age[var2] = age[var2] + var0;
            if (age[var2] >= life[var2]) {
               kill(var2);
            } else {
               int var3 = kind[var2];
               float var4;
               float var5;
               float var6;
               switch (var3) {
                  case 0:
                     var4 = 1.5F;
                     var5 = 0.32F;
                     var6 = 0.55F;
                     break;
                  case 1:
                     var4 = 1.8F;
                     var5 = 0.18F;
                     var6 = 0.45F;
                     break;
                  case 2:
                     var4 = 1.1F;
                     var5 = -0.9F;
                     var6 = 0.25F;
                     break;
                  case 3:
                     var4 = 0.9F;
                     var5 = 0.55F;
                     var6 = 1.1F;
                     break;
                  default:
                     var4 = 2.6F;
                     var5 = 0.04F;
                     var6 = 0.35F;
               }

               float var7 = seed[var2];
               float var8 = (float)px[var2];
               float var9 = (float)py[var2];
               float var10 = (float)pz[var2];
               float var11 = (float)(
                     Math.sin((double)var9 * 1.7 + (double)var1 * 1.3 + (double)var7) + Math.sin((double)var10 * 2.3 - (double)var1 * 0.7 + (double)var7 * 0.5)
                  )
                  * 0.5F;
               float var12 = (float)Math.sin((double)var8 * 1.9 + (double)var1 * 0.9 + (double)var7 * 1.3) * 0.35F;
               float var13 = (float)(Math.cos((double)var8 * 1.5 - (double)var1 * 1.1 + (double)var7) + Math.sin((double)var9 * 2.1 + (double)var1 * 0.6))
                  * 0.5F;
               vx[var2] = vx[var2] + var11 * var6 * var0;
               vy[var2] = vy[var2] + (var12 * var6 + var5) * var0;
               vz[var2] = vz[var2] + var13 * var6 * var0;
               float var14 = (float)Math.exp((double)(-var4 * var0));
               vx[var2] = vx[var2] * var14;
               vy[var2] = vy[var2] * var14;
               vz[var2] = vz[var2] * var14;
               px[var2] = px[var2] + (double)(vx[var2] * var0);
               py[var2] = py[var2] + (double)(vy[var2] * var0);
               pz[var2] = pz[var2] + (double)(vz[var2] * var0);
               rot[var2] = rot[var2] + spin[var2] * var0;
            }
         }
      }
   }

   private static void kill(int var0) {
      int var1 = --count;
      if (var0 != var1) {
         kind[var0] = kind[var1];
         px[var0] = px[var1];
         py[var0] = py[var1];
         pz[var0] = pz[var1];
         vx[var0] = vx[var1];
         vy[var0] = vy[var1];
         vz[var0] = vz[var1];
         age[var0] = age[var1];
         life[var0] = life[var1];
         size[var0] = size[var1];
         grow[var0] = grow[var1];
         rot[var0] = rot[var1];
         spin[var0] = spin[var1];
         seed[var0] = seed[var1];
         cr[var0] = cr[var1];
         cg[var0] = cg[var1];
         cb[var0] = cb[var1];
         ca[var0] = ca[var1];
      }
   }

   public static void render(Camera var0) {
      if (count != 0 && var0 != null && SharedMatrices.hasMatrices()) {
         if (SharedShaders.ready(SMOKE_PIPE) && SharedShaders.ready(GLOW_PIPE)) {
            try {
               ensure();
               Vec3d var1 = var0.getCameraPos();
               Matrix4f var2 = SharedMatrices.view();
               FrustumIntersection var3 = new FrustumIntersection(new Matrix4f(SharedMatrices.projection()).mul(var2));
               MinecraftClient var4 = MinecraftClient.getInstance();
               Framebuffer var5 = var4.getFramebuffer();
               Matrix4f var6 = SharedMatrices.projection();
               float var7 = var6.m32() / (var6.m22() - 1.0F);
               float var8 = var6.m32() / (var6.m22() + 1.0F);
               data.clear();
               var2.get(0, data);
               SharedMatrices.put4(data, 64, var7, var8, 0.35F, 0.0F);
               SharedMatrices.put4(data, 80, (float)var5.textureWidth, (float)var5.textureHeight, 0.0F, 0.0F);
               data.position(0);
               data.limit(96);
               CommandEncoder var9 = RenderSystem.getDevice().createCommandEncoder();
               var9.writeToBuffer(ubo.slice(), data);
               draw(true, var1, var2, var3, var5, var9);
               draw(false, var1, var2, var3, var5, var9);
            } catch (Throwable var10) {
               System.err.println("CherryBlossom: item particles skipped: " + var10);
            }
         }
      }
   }

   private static void draw(boolean var0, Vec3d var1, Matrix4f var2, FrustumIntersection var3, Framebuffer var4, CommandEncoder var5) {
      float var6 = var2.m00();
      float var7 = var2.m10();
      float var8 = var2.m20();
      float var9 = var2.m01();
      float var10 = var2.m11();
      float var11 = var2.m21();
      float var12 = -var2.m02();
      float var13 = -var2.m12();
      float var14 = -var2.m22();
      BufferBuilder var15 = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      int var16 = 0;

      for (int var17 = 0; var17 < count; var17++) {
         if (kind[var17] == 0 == var0) {
            float var18 = age[var17] / life[var17];
            float var19 = (float)(px[var17] - var1.x);
            float var20 = (float)(py[var17] - var1.y);
            float var21 = (float)(pz[var17] - var1.z);
            float var22 = size[var17] * (1.0F + (grow[var17] - 1.0F) * (1.0F - (1.0F - var18) * (1.0F - var18)));
            if (var3.testSphere(var19, var20, var21, var22 * 3.0F + 0.5F)) {
               float var23;
               if (kind[var17] == 0) {
                  var23 = Math.min(1.0F, var18 / 0.18F) * (1.0F - var18) * (1.0F - var18);
               } else {
                  float var24 = kind[var17] != 3 && kind[var17] != 4
                     ? 1.0F
                     : 0.6F + 0.4F * (float)Math.sin((double)(age[var17] * (kind[var17] == 4 ? 6.0F : 17.0F) + seed[var17]));
                  var23 = Math.min(1.0F, var18 / 0.08F) * (float)Math.pow((double)(1.0F - var18), 1.4F) * var24;
               }

               var23 *= ca[var17];
               if (!(var23 < 0.004F)) {
                  int var55 = Math.min(255, Math.round(cr[var17] * 255.0F));
                  int var25 = Math.min(255, Math.round(cg[var17] * 255.0F));
                  int var26 = Math.min(255, Math.round(cb[var17] * 255.0F));
                  int var27 = Math.min(255, Math.round(var23 * 255.0F));
                  if (kind[var17] == 2) {
                     float var28 = vx[var17];
                     float var29 = vy[var17];
                     float var30 = vz[var17];
                     float var31 = var28 * var12 + var29 * var13 + var30 * var14;
                     float var32 = var28 - var12 * var31;
                     float var33 = var29 - var13 * var31;
                     float var34 = var30 - var14 * var31;
                     float var35 = (float)Math.sqrt((double)(var32 * var32 + var33 * var33 + var34 * var34));
                     if (var35 > 0.05F) {
                        float var65 = var32 / var35;
                        float var66 = var33 / var35;
                        float var67 = var34 / var35;
                        float var68 = var66 * var14 - var67 * var13;
                        float var40 = var67 * var12 - var65 * var14;
                        float var41 = var65 * var13 - var66 * var12;
                        float var42 = Math.min(1.4F, var35 * 0.07F) + var22;
                        var15.vertex(var19 - var65 * var42 - var68 * var22, var20 - var66 * var42 - var40 * var22, var21 - var67 * var42 - var41 * var22)
                           .texture(0.0F, 1.0F)
                           .color(var55, var25, var26, var27);
                        var15.vertex(var19 - var65 * var42 + var68 * var22, var20 - var66 * var42 + var40 * var22, var21 - var67 * var42 + var41 * var22)
                           .texture(1.0F, 1.0F)
                           .color(var55, var25, var26, var27);
                        var15.vertex(var19 + var65 * var22 + var68 * var22, var20 + var66 * var22 + var40 * var22, var21 + var67 * var22 + var41 * var22)
                           .texture(1.0F, 0.0F)
                           .color(var55, var25, var26, var27);
                        var15.vertex(var19 + var65 * var22 - var68 * var22, var20 + var66 * var22 - var40 * var22, var21 + var67 * var22 - var41 * var22)
                           .texture(0.0F, 0.0F)
                           .color(var55, var25, var26, var27);
                        var16++;
                        continue;
                     }
                  }

                  float var57 = (float)Math.cos((double)rot[var17]);
                  float var58 = (float)Math.sin((double)rot[var17]);
                  float var59 = (var6 * var57 + var9 * var58) * var22;
                  float var60 = (var7 * var57 + var10 * var58) * var22;
                  float var61 = (var8 * var57 + var11 * var58) * var22;
                  float var62 = (var9 * var57 - var6 * var58) * var22;
                  float var63 = (var10 * var57 - var7 * var58) * var22;
                  float var64 = (var11 * var57 - var8 * var58) * var22;
                  float var36 = 0.0F;
                  float var37 = 0.0F;
                  float var38 = 1.0F;
                  if (var0) {
                     int var39 = (int)(seed[var17] * 4.0F) & 3;
                     var36 = (float)(var39 & 1) * 0.5F;
                     var37 = (float)(var39 >> 1) * 0.5F;
                     var38 = 0.5F;
                  }

                  var15.vertex(var19 - var59 - var62, var20 - var60 - var63, var21 - var61 - var64)
                     .texture(var36, var37 + var38)
                     .color(var55, var25, var26, var27);
                  var15.vertex(var19 + var59 - var62, var20 + var60 - var63, var21 + var61 - var64)
                     .texture(var36 + var38, var37 + var38)
                     .color(var55, var25, var26, var27);
                  var15.vertex(var19 + var59 + var62, var20 + var60 + var63, var21 + var61 + var64)
                     .texture(var36 + var38, var37)
                     .color(var55, var25, var26, var27);
                  var15.vertex(var19 - var59 + var62, var20 - var60 + var63, var21 - var61 + var64)
                     .texture(var36, var37)
                     .color(var55, var25, var26, var27);
                  var16++;
               }
            }
         }
      }

      try (BuiltBuffer built = var15.endNullable()) {
         if (built == null || var16 == 0) {
            return;
         }
         RenderPipeline pipeline = var0 ? SMOKE_PIPE : GLOW_PIPE;
         GpuBuffer vertices = pipeline.getVertexFormat().uploadImmediateVertexBuffer(built.getBuffer());
         ShapeIndexBuffer indices = RenderSystem.getSequentialBuffer(DrawMode.QUADS);
         GpuBuffer indexBuffer = indices.getIndexBuffer(built.getDrawParameters().indexCount());
         GpuTextureView colorView = RenderSystem.outputColorTextureOverride != null
            ? RenderSystem.outputColorTextureOverride : var4.getColorAttachmentView();
         try (RenderPass pass = var5.createRenderPass(
               () -> "CherryBlossom item particles", colorView, OptionalInt.empty())) {
            pass.setPipeline(pipeline);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("MistData", ubo);
            pass.bindTexture("Sampler0", var0 ? smokeView : glowView,
               RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
            pass.bindTexture("DepthSampler", var4.getDepthAttachmentView(),
               RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indexBuffer, indices.getIndexType());
            pass.drawIndexed(0, 0, built.getDrawParameters().indexCount(), 1);
         }
      }
   }

   private static float hash(int var0, int var1, int var2) {
      int var3 = var0 * 73856093 ^ var1 * 19349663 ^ var2 * 83492791;
      var3 = (var3 ^ var3 >>> 13) * 1274126177;
      return (float)((var3 ^ var3 >>> 16) & 65535) / 65535.0F;
   }

   private static float noise(float var0, float var1, int var2) {
      int var3 = (int)Math.floor((double)var0);
      int var4 = (int)Math.floor((double)var1);
      float var5 = var0 - (float)var3;
      float var6 = var1 - (float)var4;
      var5 = var5 * var5 * (3.0F - 2.0F * var5);
      var6 = var6 * var6 * (3.0F - 2.0F * var6);
      float var7 = hash(var3, var4, var2);
      float var8 = hash(var3 + 1, var4, var2);
      float var9 = hash(var3, var4 + 1, var2);
      float var10 = hash(var3 + 1, var4 + 1, var2);
      return var7 + (var8 - var7) * var5 + (var9 - var7) * var6 + (var7 - var8 - var9 + var10) * var5 * var6;
   }

   private static void ensure() {
      if (smokeTex == null) {
         GpuDevice var0 = RenderSystem.getDevice();
         byte var1 = 96;
         int var2 = var1 * 2;
         smokeTex = var0.createTexture(() -> "CherryBlossom smoke", 5, TextureFormat.RGBA8, var2, var2, 1, 1);
         NativeImage var3 = new NativeImage(var2, var2, false);

         try {
            for (int var4 = 0; var4 < 4; var4++) {
               int var5 = (var4 & 1) * var1;
               int var6 = (var4 >> 1) * var1;

               for (int var7 = 0; var7 < var1; var7++) {
                  for (int var8 = 0; var8 < var1; var8++) {
                     float var9 = ((float)var8 + 0.5F) / (float)var1 * 2.0F - 1.0F;
                     float var10 = ((float)var7 + 0.5F) / (float)var1 * 2.0F - 1.0F;
                     float var11 = 0.0F;
                     float var12 = 0.5F;
                     float var13 = 2.2F;

                     for (int var14 = 0; var14 < 4; var14++) {
                        var11 += var12 * noise(var9 * var13 + (float)var4 * 7.1F, var10 * var13 - (float)var4 * 3.3F, var4 * 11 + var14);
                        var12 *= 0.5F;
                        var13 *= 2.05F;
                     }

                     float var31 = (float)Math.sqrt((double)(var9 * var9 + var10 * var10)) / (0.62F + 0.42F * var11);
                     float var15 = Math.max(0.0F, 1.0F - var31);
                     var15 = var15 * var15 * (3.0F - 2.0F * var15);
                     float var16 = Math.max(0.0F, Math.min(1.0F, var15 * (0.45F + 0.9F * var11)));
                     int var17 = Math.round(var16 * 255.0F);
                     var3.setColorArgb(var5 + var8, var6 + var7, var17 << 24 | var17 << 16 | var17 << 8 | var17);
                  }
               }
            }

            var0.createCommandEncoder().writeToTexture(smokeTex, var3);
         } catch (Throwable var21) {
            try {
               var3.close();
            } catch (Throwable var19) {
               var21.addSuppressed(var19);
            }

            throw var21;
         }

         var3.close();
         smokeView = var0.createTextureView(smokeTex);
         byte var22 = 64;
         glowTex = var0.createTexture(() -> "CherryBlossom glow", 5, TextureFormat.RGBA8, var22, var22, 1, 1);
         NativeImage var23 = new NativeImage(var22, var22, false);

         try {
            for (int var24 = 0; var24 < var22; var24++) {
               for (int var25 = 0; var25 < var22; var25++) {
                  float var26 = ((float)var25 + 0.5F) / (float)var22 * 2.0F - 1.0F;
                  float var27 = ((float)var24 + 0.5F) / (float)var22 * 2.0F - 1.0F;
                  float var28 = var26 * var26 + var27 * var27;
                  float var29 = (float)(Math.exp((double)(-var28) * 26.0) * 0.85 + Math.exp((double)(-var28) * 5.0) * 0.32)
                     * Math.max(0.0F, 1.0F - (float)Math.sqrt((double)var28));
                  int var30 = Math.round(Math.min(1.0F, var29) * 255.0F);
                  var23.setColorArgb(var25, var24, var30 << 24 | var30 << 16 | var30 << 8 | var30);
               }
            }

            var0.createCommandEncoder().writeToTexture(glowTex, var23);
         } catch (Throwable var20) {
            try {
               var23.close();
            } catch (Throwable var18) {
               var20.addSuppressed(var18);
            }

            throw var20;
         }

         var23.close();
         glowView = var0.createTextureView(glowTex);
         ubo = var0.createBuffer(() -> "CherryBlossom item particles", 136, 96L);
         data = BufferUtils.createByteBuffer(96);
      }
   }

   public static void release() {
      count = 0;

      for (AutoCloseable var3 : new AutoCloseable[]{smokeView, smokeTex, glowView, glowTex, ubo}) {
         if (var3 != null) {
            try {
               var3.close();
            } catch (Throwable var5) {
            }
         }
      }

      smokeView = null;
      smokeTex = null;
      glowView = null;
      glowTex = null;
      ubo = null;
      data = null;
   }
}
