package cherryblossom.itemfx;

import java.nio.ByteBuffer;
import java.util.Random;

final class Drips {
   static final int SLOTS = 10;
   static final int ENTRIES = 48;
   private static final int GROW = 0;
   private static final int PINCH = 1;
   private static final int RETRACT = 2;
   private static final Random RANDOM = new Random();
   private static float[] anchors = new float[0];
   private static final boolean[] alive = new boolean[10];
   private static final int[] stage = new int[10];
   private static final float[] ax = new float[10];
   private static final float[] ay = new float[10];
   private static final float[] az = new float[10];
   private static final float[] age = new float[10];
   private static final float[] growTime = new float[10];
   private static final float[] maxLen = new float[10];
   private static final float[] maxR = new float[10];
   private static final float[] len = new float[10];
   private static final float[] rad = new float[10];
   private static final float[] neck = new float[10];
   private static final boolean[] falling = new boolean[10];
   private static final float[] fy = new float[10];
   private static final float[] fv = new float[10];
   private static final float[] fr = new float[10];
   private static final float[] fage = new float[10];
   private static float nextSpawn = 0.3F;

   private Drips() {
   }

   static void setAnchors(float[] var0) {
      anchors = var0;
   }

   static void reset() {
      for (int var0 = 0; var0 < 10; var0++) {
         alive[var0] = false;
         falling[var0] = false;
      }
   }

   static void update(float var0) {
      if (!(var0 <= 0.0F) && anchors.length >= 3) {
         var0 = Math.min(var0, 0.1F);
         nextSpawn -= var0;
         if (nextSpawn <= 0.0F) {
            nextSpawn = 0.35F + RANDOM.nextFloat() * 0.9F;
            spawn();
         }

         for (int var1 = 0; var1 < 10; var1++) {
            if (falling[var1]) {
               fage[var1] = fage[var1] + var0;
               fv[var1] = fv[var1] + 1.9F * var0;
               fy[var1] = fy[var1] - fv[var1] * var0;
               if (fage[var1] > 0.75F || fy[var1] < -0.62F) {
                  falling[var1] = false;
               }
            }

            if (alive[var1]) {
               age[var1] = age[var1] + var0;
               switch (stage[var1]) {
                  case 0:
                     float var6 = Math.min(1.0F, age[var1] / growTime[var1]);
                     float var7 = 1.0F - (1.0F - var6) * (1.0F - var6);
                     len[var1] = 0.006F + (maxLen[var1] - 0.006F) * var7;
                     rad[var1] = 0.005F + (maxR[var1] - 0.005F) * (float)Math.sqrt((double)var6);
                     neck[var1] = rad[var1] * (0.75F - 0.3F * var6);
                     if (var6 >= 1.0F) {
                        stage[var1] = 1;
                        age[var1] = 0.0F;
                     }
                     break;
                  case 1:
                     float var5 = Math.min(1.0F, age[var1] / 0.28F);
                     len[var1] = maxLen[var1] * (1.0F + 0.18F * var5);
                     neck[var1] = maxR[var1] * 0.45F * (1.0F - var5);
                     if (var5 >= 1.0F) {
                        falling[var1] = true;
                        fage[var1] = 0.0F;
                        fv[var1] = 0.05F;
                        fr[var1] = rad[var1] * 0.95F;
                        fy[var1] = ay[var1] - len[var1] + rad[var1];
                        stage[var1] = 2;
                        age[var1] = 0.0F;
                     }
                     break;
                  default:
                     float var2 = Math.min(1.0F, age[var1] / 0.45F);
                     float var3 = var2 * var2 * (3.0F - 2.0F * var2);
                     len[var1] = Math.max(0.004F, maxLen[var1] * 0.55F * (1.0F - var3));
                     rad[var1] = Math.max(0.003F, maxR[var1] * 0.55F * (1.0F - var3));
                     neck[var1] = rad[var1] * 0.7F;
                     if (var2 >= 1.0F) {
                        alive[var1] = false;
                     }
               }
            }
         }
      }
   }

   private static void spawn() {
      int var0 = -1;

      for (int var1 = 0; var1 < 10; var1++) {
         if (!alive[var1] && !falling[var1]) {
            var0 = var1;
            break;
         }
      }

      if (var0 >= 0) {
         int var3 = anchors.length / 3;
         int var2 = RANDOM.nextInt(var3);
         alive[var0] = true;
         stage[var0] = 0;
         age[var0] = 0.0F;
         ax[var0] = anchors[var2 * 3];
         ay[var0] = anchors[var2 * 3 + 1] + 0.003F;
         az[var0] = anchors[var2 * 3 + 2];
         growTime[var0] = 1.3F + RANDOM.nextFloat() * 1.6F;
         maxLen[var0] = 0.032F + RANDOM.nextFloat() * 0.045F;
         maxR[var0] = 0.0095F + RANDOM.nextFloat() * 0.0065F;
         len[var0] = 0.006F;
         rad[var0] = 0.005F;
         neck[var0] = 0.004F;
      }
   }

   static int write(ByteBuffer var0, int var1) {
      int var2 = 0;

      for (int var3 = 0; var3 < 10 && var2 < 24; var3++) {
         if (alive[var3]) {
            int var4 = var1 + 16 + var2 * 32;
            put4(var0, var4, ax[var3], ay[var3], az[var3], 0.0F);
            put4(var0, var4 + 16, len[var3], rad[var3], neck[var3], 0.017F);
            var2++;
         }

         if (falling[var3] && var2 < 24) {
            int var9 = var1 + 16 + var2 * 32;
            float var5 = Math.min(0.7F, fv[var3] * 0.35F);
            float var6 = 1.0F - Math.max(0.0F, (fage[var3] - 0.5F) / 0.25F);
            float var7 = fr[var3] * Math.max(0.0F, var6);
            float var8 = fy[var3] + var7 * (1.0F + var5);
            put4(var0, var9, ax[var3], var8, az[var3], 1.0F);
            put4(var0, var9 + 16, var5, var7, 0.0F, 0.0F);
            var2++;
         }
      }

      put4(var0, var1, (float)var2, 0.0F, 0.0F, 0.0F);
      return var2;
   }

   private static void put4(ByteBuffer var0, int var1, float var2, float var3, float var4, float var5) {
      var0.putFloat(var1, var2);
      var0.putFloat(var1 + 4, var3);
      var0.putFloat(var1 + 8, var4);
      var0.putFloat(var1 + 12, var5);
   }
}
