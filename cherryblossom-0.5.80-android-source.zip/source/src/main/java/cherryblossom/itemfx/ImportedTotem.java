package cherryblossom.itemfx;

import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import cherryblossom.feature.CustomTotemModule;
import cherryblossom.itemfx.mesh.MeshData;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** Local PNG import, with a managed copy that survives moving the original file. */
public final class ImportedTotem {
    private static volatile BufferedImage image;
    private static volatile long revision;
    public static long revision(){return revision;}
    private static volatile boolean busy;
    private static Path stored() {return FabricLoader.getInstance().getConfigDir().resolve("cherryblossom/totem/imported.png");}
    public static void browse() {
        if(busy)return;
        EventQueue.invokeLater(()->{
            FileDialog picker=new FileDialog((Frame)null,"CherryBlossom - Choose totem PNG",FileDialog.LOAD);
            try {
                picker.setFile("*.png");picker.setFilenameFilter((dir,name)->name.toLowerCase(Locale.ROOT).endsWith(".png"));
                picker.setVisible(true);
                if(picker.getFile()!=null)importAsync(Path.of(picker.getDirectory(),picker.getFile()).toString());
            }finally{picker.dispose();}
        });
    }
    public static void importAsync(String path) {
        if(busy)return;busy=true;
        CompletableFuture.runAsync(()->{
            try {
                BufferedImage loaded=read(Path.of(path.trim().replaceAll("^\"|\"$","")));
                Path destination=stored();Files.createDirectories(destination.getParent());
                Path temporary=Files.createTempFile(destination.getParent(),"totem-",".png");
                try {ImageIO.write(loaded,"PNG",temporary.toFile());Files.move(temporary,destination,StandardCopyOption.REPLACE_EXISTING);}
                finally{Files.deleteIfExists(temporary);}
                image=loaded;
                revision++;
                MinecraftClient.getInstance().execute(()->{
                    ItemFxRenderer.reloadImportedTotem();
                    CustomTotemModule.imagePath.setValue(path);
                    CustomTotemModule.design.setModeIndex(4);
                    cherryblossom.module.ext.ModuleRegistry.get(CustomTotemModule.class).toggle(true);
                    cherryblossom.CherryBlossom.INSTANCE.getSettingsManager().saveNow();
                    cherryblossom.integration.CherryGui.saveSettings();
                    notice("Imported totem PNG. Design: Imported PNG.");
                });
            }catch(Exception e){MinecraftClient.getInstance().execute(()->notice("Could not import PNG: "+e.getMessage()));}
            finally{busy=false;}
        });
    }
    private static void notice(String message) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player!=null)mc.player.sendMessage(Text.literal("[CherryBlossom] "+message).withColor(0xFF8FBD),false);
        else System.out.println("CherryBlossom: "+message);
    }
    public static BufferedImage read(Path path)throws IOException {
        if(!Files.isRegularFile(path)||Files.size(path)>16*1024*1024)throw new IOException("Choose a PNG file smaller than 16 MB");
        try(ImageInputStream input=ImageIO.createImageInputStream(path.toFile())) {
            if(input==null)throw new IOException("Cannot read file");
            Iterator<ImageReader> readers=ImageIO.getImageReaders(input);
            if(!readers.hasNext())throw new IOException("Not a PNG image");
            ImageReader reader=readers.next();
            try {
                if(!reader.getFormatName().equalsIgnoreCase("png"))throw new IOException("Choose a PNG image");
                reader.setInput(input);
                int w=reader.getWidth(0),h=reader.getHeight(0);
                if(w<1||h<1||w>1024||h>1024)throw new IOException("PNG dimensions must be between 1 and 1024 pixels");
                BufferedImage original=reader.read(0);
                double scale=Math.min(1,128.0/Math.max(w,h));
                BufferedImage result=new BufferedImage(Math.max(1,(int)Math.round(w*scale)),Math.max(1,(int)Math.round(h*scale)),BufferedImage.TYPE_INT_ARGB);
                Graphics2D graphics=result.createGraphics();
                try {graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);graphics.drawImage(original,0,0,result.getWidth(),result.getHeight(),null);}
                finally{graphics.dispose();}
                boolean visible=false;
                for(int y=0;y<result.getHeight();y++)for(int x=0;x<result.getWidth();x++)if((result.getRGB(x,y)>>>24)>=128)visible=true;
                if(!visible)throw new IOException("PNG is fully transparent");
                return result;
            }finally{reader.dispose();}
        }
    }
    public static MeshData mesh() {
        BufferedImage current=image;
        if(current==null)try{image=current=read(stored());}catch(IOException e){throw new IllegalStateException("Use Choose PNG to import a totem first",e);}
        return build(current);
    }
    public static MeshData build(BufferedImage png) {
        int w=png.getWidth(),h=png.getHeight();float pixel=.9f/Math.max(w,h),depth=pixel*.45f;
        ArrayList<float[]> faces=new ArrayList<>();ArrayList<Integer> colors=new ArrayList<>();
        for(int y=0;y<h;y++)for(int x=0;x<w;x++) {
            int color=png.getRGB(x,y);if((color>>>24)<128)continue;
            float left=(x-w/2f)*pixel,right=left+pixel,top=(h/2f-y)*pixel,bottom=top-pixel;
            face(faces,colors,color,0,0,1,left,bottom,depth,right,bottom,depth,right,top,depth,left,top,depth);
            face(faces,colors,color,0,0,-1,right,bottom,-depth,left,bottom,-depth,left,top,-depth,right,top,-depth);
            if(!opaque(png,x-1,y))face(faces,colors,color,-1,0,0,left,bottom,-depth,left,bottom,depth,left,top,depth,left,top,-depth);
            if(!opaque(png,x+1,y))face(faces,colors,color,1,0,0,right,bottom,depth,right,bottom,-depth,right,top,-depth,right,top,depth);
            if(!opaque(png,x,y-1))face(faces,colors,color,0,1,0,left,top,depth,right,top,depth,right,top,-depth,left,top,-depth);
            if(!opaque(png,x,y+1))face(faces,colors,color,0,-1,0,left,bottom,-depth,right,bottom,-depth,right,bottom,depth,left,bottom,depth);
        }
        MeshData mesh=new MeshData(faces.size()*4,faces.size()*2);
        for(int i=0;i<faces.size();i++) {
            float[] f=faces.get(i);int base=i*4;
            for(int v=0;v<4;v++) {int index=base+v;System.arraycopy(f,3+v*3,mesh.pos,index*3,3);System.arraycopy(f,0,mesh.nrm,index*3,3);mesh.rgba[index]=0xFF000000|(colors.get(i)&0xFFFFFF);}
            int[] indices={base,base+1,base+2,base,base+2,base+3};System.arraycopy(indices,0,mesh.indices,i*6,6);
        }
        return mesh;
    }
    private static boolean opaque(BufferedImage i,int x,int y){return x>=0&&y>=0&&x<i.getWidth()&&y<i.getHeight()&&(i.getRGB(x,y)>>>24)>=128;}
    private static void face(List<float[]> faces,List<Integer> colors,int color,float... values){faces.add(values);colors.add(color);}
}
