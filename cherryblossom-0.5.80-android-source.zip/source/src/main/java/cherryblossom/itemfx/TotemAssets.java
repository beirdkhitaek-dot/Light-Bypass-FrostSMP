package cherryblossom.itemfx;

import com.google.gson.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.*;
import javax.imageio.ImageIO;
import cherryblossom.itemfx.mesh.MeshData;

/** Pack-backed textures, frame timings and actual textured cuboid geometry. */
public final class TotemAssets {
    public record Entry(String id,String name,String archive,String texture,String model,boolean available,String note) {}
    private static final String ROOT="/assets/cherryblossom/totems/";
    private static final List<Entry> ENTRIES;
    private static final Map<Integer,Pack> PACKS=new ConcurrentHashMap<>();
    static {
        try(Reader reader=new InputStreamReader(Objects.requireNonNull(TotemAssets.class.getResourceAsStream(ROOT+"library.json")),StandardCharsets.UTF_8)) {
            ArrayList<Entry> entries=new ArrayList<>();
            for(JsonElement value:JsonParser.parseReader(reader).getAsJsonArray()) {
                JsonObject e=value.getAsJsonObject();entries.add(new Entry(e.get("id").getAsString(),e.get("name").getAsString(),e.get("archive").getAsString(),e.get("texture").getAsString(),e.get("model").getAsString(),e.get("available").getAsBoolean(),e.get("note").getAsString()));
            }
            ENTRIES=List.copyOf(entries);
        }catch(Exception e){throw new ExceptionInInitializerError(e);}
    }
    public static List<Entry> entries(){return ENTRIES;}
    public static Pack pack(int index){return PACKS.computeIfAbsent(index,i->{try{return new Pack(ENTRIES.get(i));}catch(IOException e){throw new IllegalStateException("Cannot read totem "+ENTRIES.get(i).name(),e);}});}
    public static int key(int index,boolean animated){return 10000+index*10000+pack(index).frame(animated?System.currentTimeMillis()/50:0);}
    public static MeshData mesh(int key){int index=(key-10000)/10000, frame=(key-10000)%10000;return pack(index).mesh(frame);}
    public static boolean modelKey(int key){return key>=10000&&!ENTRIES.get((key-10000)/10000).model().isEmpty();}
    public static final class Pack {
        private final Entry entry;
        private final Map<String,byte[]> files=new HashMap<>();
        private final Map<String,BufferedImage> images=new ConcurrentHashMap<>();
        private final BufferedImage sheet;
        private final JsonObject model;
        private final int width,height;
        private final int[] frames,durations;
        private final int cycle;
        Pack(Entry entry)throws IOException {
            this.entry=entry;
            try(ZipInputStream zip=new ZipInputStream(Objects.requireNonNull(TotemAssets.class.getResourceAsStream(ROOT+entry.archive())))) {
                for(ZipEntry e;(e=zip.getNextEntry())!=null;)if(!e.isDirectory()&&!e.getName().startsWith("__MACOSX/")&&(e.getName().endsWith(".png")||e.getName().endsWith(".json")||e.getName().endsWith(".mcmeta")))files.put(e.getName(),zip.readAllBytes());
            }
            if(!entry.available()){sheet=read("pack.png");model=null;width=sheet.getWidth();height=sheet.getHeight();frames=new int[]{0};durations=new int[]{1};cycle=1;return;}
            sheet=read(entry.texture());model=entry.model().isEmpty()?null:json(entry.model());
            JsonObject metadata=files.containsKey(entry.texture()+".mcmeta")?json(entry.texture()+".mcmeta"):new JsonObject();
            JsonObject animation=metadata.has("animation")?metadata.getAsJsonObject("animation"):null;
            width=animation!=null&&animation.has("width")?animation.get("width").getAsInt():sheet.getWidth();
            height=animation==null?sheet.getHeight():animation.has("height")?animation.get("height").getAsInt():width;
            int available=(sheet.getWidth()/width)*(sheet.getHeight()/height),speed=animation!=null&&animation.has("frametime")?animation.get("frametime").getAsInt():1;
            ArrayList<Integer> order=new ArrayList<>(),times=new ArrayList<>();
            if(animation!=null&&animation.has("frames"))for(JsonElement f:animation.getAsJsonArray("frames")){order.add(f.isJsonObject()?f.getAsJsonObject().get("index").getAsInt():f.getAsInt());times.add(f.isJsonObject()&&f.getAsJsonObject().has("time")?f.getAsJsonObject().get("time").getAsInt():speed);}
            else for(int i=0;i<available;i++){order.add(i);times.add(speed);}
            frames=order.stream().mapToInt(Integer::intValue).toArray();durations=times.stream().mapToInt(t->Math.max(1,t)).toArray();cycle=Arrays.stream(durations).sum();
            for(int f:frames)if(f<0||f>=available)throw new IOException("Animation frame outside texture");
        }
        private JsonObject json(String path){return JsonParser.parseString(new String(files.get(path),StandardCharsets.UTF_8)).getAsJsonObject();}
        private BufferedImage read(String path)throws IOException {BufferedImage cached=images.get(path);if(cached!=null)return cached;byte[] bytes=files.get(path);if(bytes==null)throw new IOException("Missing texture: "+path);BufferedImage result=ImageIO.read(new ByteArrayInputStream(bytes));if(result==null)throw new IOException("Invalid texture: "+path);images.put(path,result);return result;}
        public int frame(long ticks){int t=(int)Math.floorMod(ticks,cycle);for(int i=0;i<frames.length;i++){if(t<durations[i])return frames[i];t-=durations[i];}return frames[0];}
        public int frameCount(){return (int)Arrays.stream(frames).distinct().count();}
        public boolean model3d(){return model!=null;}
        public BufferedImage preview(){if(!entry.available())return sheet;if(model==null)return frameImage(frames[0]);return previewMesh(mesh(frames[0]),true);}
        private BufferedImage frameImage(int frame){int columns=sheet.getWidth()/width;return sheet.getSubimage((frame%columns)*width,(frame/columns)*height,width,height);}
        public MeshData mesh(int frame) {
            if(!entry.available())throw new IllegalStateException(entry.note());
            if(model==null){BufferedImage source=frameImage(frame);if(Math.max(width,height)>128){BufferedImage smaller=new BufferedImage(Math.max(1,width*128/Math.max(width,height)),Math.max(1,height*128/Math.max(width,height)),BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D g=smaller.createGraphics();try{g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);g.drawImage(source,0,0,smaller.getWidth(),smaller.getHeight(),null);}finally{g.dispose();}source=smaller;}return ImportedTotem.build(source);}
            Builder builder=new Builder();JsonObject textures=model.getAsJsonObject("textures");
            for(JsonElement value:model.getAsJsonArray("elements")) {
                JsonObject element=value.getAsJsonObject();float[] from=vec(element.getAsJsonArray("from")),to=vec(element.getAsJsonArray("to"));
                if(!element.has("faces"))continue;
                for(var pair:element.getAsJsonObject("faces").entrySet()) {
                    JsonObject face=pair.getValue().getAsJsonObject();String texture=face.get("texture").getAsString();int guard=0;
                    while(texture.startsWith("#")&&guard++<10)texture=textures.get(texture.substring(1)).getAsString();
                    String[] location=texture.contains(":")?texture.split(":",2):new String[]{"minecraft",texture};String path="assets/"+location[0]+"/textures/"+location[1]+".png";
                    BufferedImage atlas;try{atlas=read(path);}catch(IOException e){throw new IllegalStateException(e);}
                    int fh=atlas.getHeight();if(files.containsKey(path+".mcmeta"))fh=atlas.getWidth();int offset=Math.min(frame,atlas.getHeight()/fh-1)*fh;
                    float[] uv=face.has("uv")?vec4(face.getAsJsonArray("uv")):new float[]{0,0,16,16};
                    int columns=Math.max(1,Math.min(128,(int)Math.ceil(Math.abs(uv[2]-uv[0])*atlas.getWidth()/16))),rows=Math.max(1,Math.min(128,(int)Math.ceil(Math.abs(uv[3]-uv[1])*fh/16)));
                    int rotation=face.has("rotation")?face.get("rotation").getAsInt():0;
                    for(int y=0;y<rows;y++)for(int x=0;x<columns;x++) {
                        float u=(x+.5f)/columns,v=(y+.5f)/rows;float ru=u,rv=v;
                        if(rotation==90){ru=v;rv=1-u;}else if(rotation==180){ru=1-u;rv=1-v;}else if(rotation==270){ru=1-v;rv=u;}
                        int tx=clamp((int)((uv[0]+(uv[2]-uv[0])*ru)/16*atlas.getWidth()),0,atlas.getWidth()-1),ty=clamp((int)((uv[1]+(uv[3]-uv[1])*rv)/16*fh),0,fh-1);
                        int color=atlas.getRGB(tx,offset+ty);if((color>>>24)<128)continue;
                        float[][] points={point(pair.getKey(),from,to,(float)x/columns,(float)y/rows),point(pair.getKey(),from,to,(float)(x+1)/columns,(float)y/rows),point(pair.getKey(),from,to,(float)(x+1)/columns,(float)(y+1)/rows),point(pair.getKey(),from,to,(float)x/columns,(float)(y+1)/rows)};
                        for(float[] p:points)rotate(p,element);
                        builder.quad(points,color,texture.contains("/outline/")||(element.has("light_emission")&&element.get("light_emission").getAsInt()>0));
                    }
                }
            }
            MeshData mesh=builder.finish();
            // Models may author their front on either Z face. Retain the pack's
            // presentation rotation so its face is visible in our neutral item pose.
            if(model.has("display")&&model.getAsJsonObject("display").has("gui")) {
                JsonObject display=model.getAsJsonObject("display").getAsJsonObject("gui");
                if(display.has("rotation")) {
                    float[] angles=vec(display.getAsJsonArray("rotation"));
                    for(int i=0;i<mesh.vertexCount;i++)for(float[] values:new float[][]{mesh.pos,mesh.nrm}) {
                        for(int axis=2;axis>=0;axis--){int a=(axis+1)%3,b=(axis+2)%3;double angle=Math.toRadians(angles[axis]),c=Math.cos(angle),s=Math.sin(angle);float x=values[i*3+a],y=values[i*3+b];values[i*3+a]=(float)(x*c-y*s);values[i*3+b]=(float)(x*s+y*c);}
                    }
                }
            }
            return mesh;
        }
    }
    private static int clamp(int x,int min,int max){return Math.max(min,Math.min(max,x));}
    private static float[] vec(JsonArray a){return new float[]{a.get(0).getAsFloat(),a.get(1).getAsFloat(),a.get(2).getAsFloat()};}
    private static float[] vec4(JsonArray a){return new float[]{a.get(0).getAsFloat(),a.get(1).getAsFloat(),a.get(2).getAsFloat(),a.get(3).getAsFloat()};}
    private static float[] point(String face,float[] a,float[] b,float u,float v){float x=a[0]+(b[0]-a[0])*u,y=b[1]-(b[1]-a[1])*v,z=a[2]+(b[2]-a[2])*u;return switch(face){case "north"->new float[]{b[0]-(b[0]-a[0])*u,y,a[2]};case "south"->new float[]{x,y,b[2]};case "west"->new float[]{a[0],y,z};case "east"->new float[]{b[0],y,b[2]-(b[2]-a[2])*u};case "up"->new float[]{x,b[1],a[2]+(b[2]-a[2])*v};default->new float[]{x,a[1],b[2]-(b[2]-a[2])*v};};}
    private static void rotate(float[] p,JsonObject element){if(!element.has("rotation"))return;JsonObject r=element.getAsJsonObject("rotation");float[] o=vec(r.getAsJsonArray("origin"));double angle=Math.toRadians(r.get("angle").getAsDouble()),c=Math.cos(angle),s=Math.sin(angle);int axis="xyz".indexOf(r.get("axis").getAsString()),a=(axis+1)%3,b=(axis+2)%3;float x=p[a]-o[a],y=p[b]-o[b];p[a]=o[a]+(float)(x*c-y*s);p[b]=o[b]+(float)(x*s+y*c);}
    private static final class Builder {
        final ArrayList<float[][]> faces=new ArrayList<>();final ArrayList<Integer> colors=new ArrayList<>();final ArrayList<Boolean> emissive=new ArrayList<>();
        void quad(float[][] p,int color,boolean glow){faces.add(new float[][]{p[0],p[3],p[2],p[1]});colors.add(color);emissive.add(glow);}
        MeshData finish(){MeshData m=new MeshData(faces.size()*4,faces.size()*2);float[] min={Float.MAX_VALUE,Float.MAX_VALUE,Float.MAX_VALUE},max={-Float.MAX_VALUE,-Float.MAX_VALUE,-Float.MAX_VALUE};for(var f:faces)for(var p:f)for(int i=0;i<3;i++){min[i]=Math.min(min[i],p[i]);max[i]=Math.max(max[i],p[i]);}float scale=.9f/Math.max(max[0]-min[0],Math.max(max[1]-min[1],max[2]-min[2]));for(int i=0;i<faces.size();i++){float[][] f=faces.get(i);float[] a={f[1][0]-f[0][0],f[1][1]-f[0][1],f[1][2]-f[0][2]},b={f[2][0]-f[0][0],f[2][1]-f[0][1],f[2][2]-f[0][2]},n={a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};float len=(float)Math.sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]);for(int v=0;v<4;v++){for(int j=0;j<3;j++){m.pos[(i*4+v)*3+j]=(f[v][j]-(min[j]+max[j])/2)*scale;m.nrm[(i*4+v)*3+j]=len>0?n[j]/len:0;}m.rgba[i*4+v]=0xFF000000|(colors.get(i)&0xFFFFFF);m.mat[i*4+v]=(short)(emissive.get(i)?3:0);}int base=i*4;int[] ids={base,base+1,base+2,base,base+2,base+3};System.arraycopy(ids,0,m.indices,i*6,6);}return m;}
    }
    public static BufferedImage previewMesh(MeshData mesh){return previewMesh(mesh,false);}
    private static BufferedImage previewMesh(MeshData mesh,boolean cull){BufferedImage image=new BufferedImage(96,96,BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D g=image.createGraphics();ArrayList<Integer> faces=new ArrayList<>();for(int i=0;i<mesh.vertexCount/4;i++)faces.add(i);faces.sort(Comparator.comparingDouble(i->mesh.pos[i*12+2]*.87-mesh.pos[i*12]*.5));for(int face:faces){if(cull&&(-.5*mesh.nrm[face*12]+.3*mesh.nrm[face*12+1]+.87*mesh.nrm[face*12+2])<=0)continue;int[] x=new int[4],y=new int[4];for(int v=0;v<4;v++){int i=(face*4+v)*3;float px=mesh.pos[i],py=mesh.pos[i+1],pz=mesh.pos[i+2];x[v]=Math.round(48+(px*.87f+pz*.5f)*85);y[v]=Math.round(48-(py*.94f-pz*.3f+px*.17f)*85);}g.setColor(new java.awt.Color(mesh.rgba[face*4],true));g.fillPolygon(x,y,4);}g.dispose();return image;}
}
