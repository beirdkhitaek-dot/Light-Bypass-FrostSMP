package cherryblossom.itemfx;
import java.nio.ByteBuffer;
import org.joml.Matrix4f;
public final class SharedMatrices {
    private static final Matrix4f VIEW=new Matrix4f(),PROJECTION=new Matrix4f();
    private static boolean valid;
    public static void capture(Matrix4f view,Matrix4f projection){VIEW.set(view);PROJECTION.set(projection);valid=true;}
    public static Matrix4f view(){return VIEW;}
    public static Matrix4f projection(){return PROJECTION;}
    public static boolean hasMatrices(){return valid;}
    public static void reset(){valid=false;}
    static void put4(ByteBuffer data,int offset,float x,float y,float z,float w){data.putFloat(offset,x);data.putFloat(offset+4,y);data.putFloat(offset+8,z);data.putFloat(offset+12,w);}
}