package cherryblossom.imixin;

public interface IKeybinding {
   boolean cherryblossom$isActuallyPressed();

   void cherryblossom$resetPressed();
}
