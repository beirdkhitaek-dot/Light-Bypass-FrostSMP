package cherryblossom.knife;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class KnifeSkin {
   static final String KARAMBIT = "Karambit";
   static final String BUTTERFLY = "Butterfly";
   static final String[] NAMES = names();
   private static final float[][] KARAMBIT_INSPECT = new float[][]{
      {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.1F, -0.192F, 0.021F, 0.06F, -10.0F, 14.0F, 10.0F, 0.0F, 1.0F, -25.0F, 0.0F, 0.0F},
      {0.14F, -0.224F, 0.024F, 0.06F, -10.0F, 14.0F, 10.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F},
      {0.205F, -0.224F, 0.026F, 0.06F, -10.0F, 14.0F, 10.0F, 0.0F, 1.0F, 180.0F, 0.0F, 0.0F},
      {0.27F, -0.224F, 0.024F, 0.06F, -10.0F, 14.0F, 10.0F, 0.0F, 1.0F, 360.0F, 0.0F, 0.0F},
      {0.335F, -0.224F, 0.026F, 0.06F, -10.0F, 14.0F, 10.0F, 0.0F, 1.0F, 540.0F, 0.0F, 0.0F},
      {0.4F, -0.224F, 0.024F, 0.06F, -10.0F, 14.0F, 10.0F, 0.0F, 1.0F, 720.0F, 0.0F, 0.0F},
      {0.48F, -0.208F, 0.024F, 0.06F, -10.0F, 12.0F, 10.0F, 0.0F, 1.0F, 750.0F, 0.0F, 0.0F},
      {0.56F, -0.16F, 0.018F, 0.06F, 20.0F, 10.0F, -70.0F, 0.0F, 1.0F, 720.0F, 0.0F, 0.0F},
      {0.72F, -0.16F, 0.019F, 0.06F, -10.0F, 10.0F, -60.0F, 0.0F, 0.6F, 720.0F, 0.0F, 1.0F},
      {0.86F, -0.096F, 0.012F, 0.05F, -6.0F, 4.0F, 8.0F, 0.0F, 0.2F, 360.0F, 0.0F, 1.0F},
      {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 360.0F, 0.0F, 1.0F}
   };
   private static final float[][] KARAMBIT_DEPLOY = new float[][]{
      {0.0F, 0.02F, -0.14F, 0.02F, 0.0F, -30.0F, -20.0F, 0.0F, 1.0F, -540.0F, 0.0F, 0.0F},
      {0.55F, 0.0F, 0.0F, 0.0F, 0.0F, 4.0F, 4.0F, 0.0F, 1.0F, -60.0F, 0.0F, 0.0F},
      {0.78F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0F, -2.0F, 0.0F, 0.3F, 12.0F, 0.0F, 0.0F},
      {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F}
   };
   private static final float[][] BUTTERFLY_INSPECT = new float[][]{
      {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.08F, -0.07F, 0.09F, 0.05F, -8.0F, 8.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.14F, -0.09F, 0.12F, 0.06F, -12.0F, 8.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.19F, -0.09F, 0.12F, 0.06F, -10.0F, 10.0F, 2.0F, -18.0F, 0.0F, 90.0F, 180.0F, 0.0F, 0.0F},
      {0.24F, -0.09F, 0.13F, 0.06F, -12.0F, 8.0F, 10.0F, 0.0F, 0.0F, 180.0F, 360.0F, 0.0F, 0.0F},
      {0.29F, -0.09F, 0.12F, 0.06F, -10.0F, 10.0F, 2.0F, 18.0F, 0.0F, 270.0F, 540.0F, 0.0F, 0.0F},
      {0.34F, -0.09F, 0.12F, 0.06F, -12.0F, 8.0F, 14.0F, 0.0F, 0.0F, 360.0F, 720.0F, 0.0F, 0.0F},
      {0.39F, -0.09F, 0.12F, 0.06F, -10.0F, 10.0F, 2.0F, -18.0F, 0.0F, 450.0F, 900.0F, 0.0F, 0.0F},
      {0.44F, -0.09F, 0.13F, 0.06F, -12.0F, 8.0F, 10.0F, 0.0F, 0.0F, 540.0F, 1080.0F, 0.0F, 0.0F},
      {0.49F, -0.09F, 0.12F, 0.06F, -10.0F, 10.0F, 2.0F, 18.0F, 0.0F, 630.0F, 1260.0F, 0.0F, 0.0F},
      {0.54F, -0.09F, 0.12F, 0.06F, -12.0F, 8.0F, 14.0F, 0.0F, 0.0F, 720.0F, 1440.0F, 0.0F, 0.0F},
      {0.62F, -0.1F, 0.12F, 0.07F, -35.0F, 6.0F, 20.0F, 0.0F, 0.0F, 720.0F, 1440.0F, 0.0F, 0.0F},
      {0.76F, -0.1F, 0.13F, 0.07F, 25.0F, 6.0F, 16.0F, 0.0F, 0.0F, 720.0F, 1440.0F, 1.0F, 0.0F},
      {0.88F, -0.05F, 0.06F, 0.03F, 8.0F, 3.0F, 6.0F, 0.0F, 0.0F, 720.0F, 1440.0F, 1.0F, 0.0F},
      {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 720.0F, 1440.0F, 1.0F, 0.0F}
   };
   private static final float[][] BUTTERFLY_DEPLOY = new float[][]{
      {0.0F, 0.02F, -0.14F, 0.02F, 0.0F, -30.0F, -20.0F, 0.0F, 0.0F, 180.0F, 0.0F, 0.0F, 0.0F},
      {0.3F, 0.01F, -0.04F, 0.01F, 0.0F, -10.0F, -10.0F, 0.0F, 0.0F, 220.0F, 100.0F, 0.0F, 0.0F},
      {0.62F, 0.0F, 0.01F, 0.0F, 0.0F, 4.0F, 6.0F, 0.0F, 0.0F, 350.0F, 340.0F, 0.0F, 0.0F},
      {0.8F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0F, -2.0F, 0.0F, 0.0F, 365.0F, 368.0F, 0.0F, 0.0F},
      {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 360.0F, 360.0F, 0.0F, 0.0F}
   };
   private static final Map<String, KnifeSkin> CACHE = new HashMap<>();
   final String name;
   final InspectAnimation.Clip inspect;
   final InspectAnimation.Clip deploy;
   private final KnifeSkin.Part[] parts;
   private final KnifeSkin.Streak[] streaks;
   private final float voxel;
   private final float gripX;
   private final float gripY;
   private final Vector3f fist;
   private final Vector3f elbow = new Vector3f();
   private final Quaternionf rest;
   private final float shineTail;
   private float holdX = Float.NaN;
   private final Vector3f bladeAxis = new Vector3f();
   private final Vector3f restForearm = new Vector3f();
   private final Vector3f spinForearm = new Vector3f();
   private static final float KARAMBIT_VOXEL = 0.0213F;
   private static final Vector3f KARAMBIT_HOLD_RING = new Vector3f(-0.058F, 0.622F, 0.068F);
   private static final Vector3f KARAMBIT_HOLD_BLADE = new Vector3f(-0.903F, -0.429F, -0.027F);
   private static final Vector3f KARAMBIT_HOLD_SPINE = new Vector3f(0.418F, -0.892F, 0.174F);
   private static final Vector3f KARAMBIT_ARM_SHIFT = new Vector3f(0.2F, -0.22F, -0.1F);
   private static final Vector3f KARAMBIT_HOLD_FOREARM = new Vector3f(0.6F, -0.62F, 0.5F);
   private static final Vector3f KARAMBIT_FOREARM = new Vector3f(0.2F, -0.5F, 0.84F).normalize();
   private static final Vector3f KARAMBIT_FIST = new Vector3f(-0.1F, 0.16F, 0.02F);
   private static final Vector3f KARAMBIT_BLADE = new Vector3f(-0.96F, 0.1F, -0.26F);
   private static final Vector3f KARAMBIT_SPINE = new Vector3f(0.1F, 1.0F, 0.0F);
   private static final float BUTTERFLY_GRIP_X = -27.0F;
   private static final Vector3f BUTTERFLY_FIST = new Vector3f(-0.1F, 0.12F, 0.02F);
   private static final Vector3f BUTTERFLY_BLADE = new Vector3f(-0.6F, 0.7F, -0.3F);
   private static final Vector3f BUTTERFLY_SPINE = new Vector3f(-0.7F, -0.5F, 0.3F);
   private static final Vector3f FIXED_FOREARM = new Vector3f(0.9F, -0.4F, 0.1F).normalize();
   private static final Vector3f FIXED_FIST = new Vector3f(-0.1F, 0.14F, 0.02F);
   private static final Vector3f FIXED_BLADE = new Vector3f(-0.5F, 0.62F, -0.6F);
   private static final Vector3f FIXED_SPINE = new Vector3f(0.55F, 0.75F, 0.25F);
   private static final float[][] FIXED_INSPECT = new float[][]{
      {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.12F, -0.08F, 0.1F, 0.04F, -8.0F, 8.0F, 10.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.32F, -0.1F, 0.13F, 0.05F, 6.0F, 12.0F, 16.0F, 180.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.52F, -0.1F, 0.13F, 0.05F, 10.0F, 8.0F, -8.0F, 360.0F, 0.0F, 0.0F, 0.0F, 0.6F},
      {0.7F, -0.08F, 0.1F, 0.04F, -20.0F, 8.0F, -38.0F, 360.0F, 0.0F, 0.0F, 0.0F, 1.0F},
      {0.86F, -0.04F, 0.05F, 0.02F, -6.0F, 3.0F, 6.0F, 360.0F, 0.0F, 0.0F, 0.0F, 1.0F},
      {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 360.0F, 0.0F, 0.0F, 0.0F, 1.0F}
   };
   private static final float[][] FIXED_DEPLOY = new float[][]{
      {0.0F, 0.02F, -0.14F, 0.02F, 0.0F, -30.0F, -20.0F, -270.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.55F, 0.0F, 0.0F, 0.0F, 0.0F, 4.0F, 4.0F, -40.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {0.78F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0F, -2.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F},
      {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F}
   };

   private static String[] names() {
      FixedKnives.Spec[] fixed = FixedKnives.all();
      String[] out = new String[2 + fixed.length];
      out[0] = "Karambit";
      out[1] = "Butterfly";

      for (int i = 0; i < fixed.length; i++) {
         out[2 + i] = fixed[i].name;
      }

      return out;
   }

   private KnifeSkin(
      String name,
      KnifeSkin.Part[] parts,
      KnifeSkin.Streak[] streaks,
      float voxel,
      float gripX,
      float gripY,
      Vector3f fist,
      Vector3f blade,
      Vector3f spine,
      InspectAnimation.Clip inspect,
      InspectAnimation.Clip deploy,
      Vector3f forearm,
      float shineTail
   ) {
      this.name = name;
      this.parts = parts;
      this.streaks = streaks;
      this.voxel = voxel;
      this.gripX = gripX;
      this.gripY = gripY;
      this.fist = fist;
      this.inspect = inspect;
      this.deploy = deploy;
      this.shineTail = shineTail;
      Vector3f x = new Vector3f(blade).normalize();
      Vector3f y = new Vector3f(spine).fma(-spine.dot(x), x).normalize();
      this.rest = new Quaternionf().setFromNormalized(new Matrix3f(x, y, new Vector3f(x).cross(y)));
      this.bladeAxis.set(x);
      this.spinForearm.set(forearm);
      this.restForearm.set(forearm);
      fist.fma(0.6F, forearm, this.elbow);
   }

   static KnifeSkin of(String name) {
      KnifeSkin skin = CACHE.get(name);
      if (skin != null) {
         return skin;
      } else {
         if ("Karambit".equals(name)) {
            skin = karambit();
         } else if ("Butterfly".equals(name)) {
            skin = butterfly();
         } else {
            for (FixedKnives.Spec spec : FixedKnives.all()) {
               if (spec.name.equals(name)) {
                  skin = fixed(spec);
                  break;
               }
            }
         }

         if (skin != null) {
            CACHE.put(name, skin);
         }

         return skin;
      }
   }

   private static KnifeSkin karambit() {
      float ringX = -22.0F;
      float ringY = 0.0F;
      KnifeSkin.Part[] parts = new KnifeSkin.Part[]{new KnifeSkin.Part(KnifeModels.karambit(), 8, ringX, ringY)};
      float[] tip = KnifeModels.karambitTip();
      KnifeSkin.Streak[] streaks = new KnifeSkin.Streak[]{new KnifeSkin.Streak(0, 1.0F, 0.0F, tip[0], tip[1], 1.0F)};
      KnifeSkin skin = new KnifeSkin(
         "Karambit",
         parts,
         streaks,
         0.0213F,
         ringX,
         ringY,
         new Vector3f(KARAMBIT_HOLD_RING),
         KARAMBIT_HOLD_BLADE,
         KARAMBIT_HOLD_SPINE,
         new InspectAnimation.Clip(KARAMBIT_INSPECT, 3.2F, 0.14F, 0.4F),
         new InspectAnimation.Clip(KARAMBIT_DEPLOY, 0.8F),
         KARAMBIT_FOREARM,
         0.0F
      );
      skin.holdX = -12.0F;
      skin.restForearm.set(KARAMBIT_HOLD_FOREARM).normalize();
      return skin;
   }

   private static KnifeSkin butterfly() {
      float pivotX = -1.5F;
      float pivotY = 0.5F;
      KnifeSkin.Part[] parts = new KnifeSkin.Part[]{
         new KnifeSkin.Part(KnifeModels.butterflyHandle(1), -1, pivotX, pivotY),
         new KnifeSkin.Part(KnifeModels.butterflyBlade(), 8, pivotX, pivotY),
         new KnifeSkin.Part(KnifeModels.butterflyHandle(-1), 9, pivotX, pivotY)
      };
      KnifeSkin.Streak[] streaks = new KnifeSkin.Streak[]{
         new KnifeSkin.Streak(1, 2.5F, 0.5F, 21.5F, -0.5F, 1.0F), new KnifeSkin.Streak(2, -4.0F, 0.5F, -27.5F, 0.5F, 0.8F)
      };
      return new KnifeSkin(
         "Butterfly",
         parts,
         streaks,
         0.021F,
         -27.0F,
         0.5F,
         BUTTERFLY_FIST,
         BUTTERFLY_BLADE,
         BUTTERFLY_SPINE,
         new InspectAnimation.Clip(BUTTERFLY_INSPECT, 3.8F, 0.14F, 0.54F),
         new InspectAnimation.Clip(BUTTERFLY_DEPLOY, 0.9F),
         FIXED_FOREARM,
         0.0F
      );
   }

   Vector3f handAt(float[] at, float weight) {
      return new Vector3f(this.fist).add(at[0] * weight, at[1] * weight, at[2] * weight);
   }

   Vector3f elbowPoint() {
      return new Vector3f(this.elbow);
   }

   private static KnifeSkin fixed(FixedKnives.Spec spec) {
      float baseX = spec.blade * 0.35F;
      KnifeSkin.Part[] parts;
      KnifeSkin.Streak[] streaks;
      if (spec.folding) {
         parts = new KnifeSkin.Part[]{
            new KnifeSkin.Part(FixedKnives.build(spec, 1), -1, 0.0F, 0.0F), new KnifeSkin.Part(FixedKnives.build(spec, 2), 8, -1.0F, spec.hingeY())
         };
         streaks = new KnifeSkin.Streak[]{new KnifeSkin.Streak(1, baseX, spec.bladeMidY(baseX), (float)spec.blade, spec.bladeEndY(), 1.0F)};
      } else if (spec.ring) {
         parts = new KnifeSkin.Part[]{new KnifeSkin.Part(FixedKnives.build(spec), 8, spec.ringX(), spec.ringY())};
         streaks = new KnifeSkin.Streak[]{new KnifeSkin.Streak(0, baseX, spec.bladeMidY(baseX), (float)spec.blade, spec.bladeEndY(), 1.0F)};
      } else {
         parts = new KnifeSkin.Part[]{new KnifeSkin.Part(FixedKnives.build(spec), -1, 0.0F, 0.0F)};
         streaks = new KnifeSkin.Streak[]{new KnifeSkin.Streak(0, baseX, spec.bladeMidY(baseX), (float)spec.blade, spec.bladeEndY(), 1.0F)};
      }

      KnifeClips.Set clips = KnifeClips.of(spec.name);
      InspectAnimation.Clip inspect = clips == null
         ? new InspectAnimation.Clip(FIXED_INSPECT, 3.0F)
         : new InspectAnimation.Clip(clips.inspect(), clips.inspectSeconds(), clips.loopFrom(), clips.loopTo());
      InspectAnimation.Clip deploy = new InspectAnimation.Clip(clips == null ? FIXED_DEPLOY : clips.deploy(), clips == null ? 0.7F : clips.deploySeconds());
      boolean ring = spec.ring;
      return new KnifeSkin(
         spec.name,
         parts,
         streaks,
         spec.voxel,
         spec.gripX(),
         spec.gripY(),
         new Vector3f(ring ? KARAMBIT_FIST : FIXED_FIST),
         ring ? KARAMBIT_BLADE : FIXED_BLADE,
         ring ? KARAMBIT_SPINE : FIXED_SPINE,
         inspect,
         deploy,
         ring ? KARAMBIT_FOREARM : FIXED_FOREARM,
         spec.shineTail
      );
   }

   int streakCount() {
      return this.streaks.length;
   }

   float streakStrength(int i) {
      return this.streaks[i].strength;
   }

   void draw(MatrixStack pose, float[] at, float weight, boolean slim, float size, KnifeSkin.Sink sink, float[] trail) {
      Matrix4f knife = this.knifeMatrix(at, weight, size, new Matrix4f());
      Vector3f hand = new Vector3f(this.fist).add(at[0] * weight, at[1] * weight, at[2] * weight);
      Vector3f elbowNow = this.elbow;
      if (!Float.isNaN(this.holdX)) {
         float spin = Math.max(0.0F, Math.min(1.0F, at[7] * weight));
         float hold = (this.holdX - this.gripX) * this.voxel * size;
         hand.fma(hold * (1.0F - spin), this.bladeAxis);
         hand.fma(1.0F - spin, KARAMBIT_ARM_SHIFT);
         Vector3f holdElbow = new Vector3f(this.fist).fma(hold, this.bladeAxis).add(KARAMBIT_ARM_SHIFT).fma(0.6F, this.restForearm);
         Vector3f spinElbow = new Vector3f(this.fist).fma(0.6F, this.spinForearm);
         elbowNow = holdElbow.lerp(spinElbow, spin);
      }

      FirstPersonArm.place(pose, hand, elbowNow, slim, posed -> sink.arm(posed));
      float sweep = shinePosition(at[10]);
      KnifeMesh.Shine shine = new KnifeMesh.Shine(sweep, sweep > 0.0F ? (float)Math.sin(Math.PI * sweep) * weight : 0.0F, this.shineTail);
      if (trail != null) {
         this.streakEnds(knife, at, weight, trail);
      }

      pose.push();
      pose.multiplyPositionMatrix(knife);

      for (KnifeSkin.Part part : this.parts) {
         pose.push();
         if (part.channel >= 0) {
            float angle = wrap(at[part.channel]) * weight;
            if (angle != 0.0F) {
               pose.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle), part.pivotX, part.pivotY, 0.5F);
            }
         }

         sink.part(pose, part.mesh, shine);
         pose.pop();
      }

      pose.pop();
   }

   private void streakEnds(Matrix4f knife, float[] at, float weight, float[] out) {
      Vector3f p = new Vector3f();

      for (int s = 0; s < this.streaks.length; s++) {
         KnifeSkin.Streak st = this.streaks[s];
         KnifeSkin.Part part = this.parts[st.part];
         Matrix4f m = new Matrix4f(knife);
         if (part.channel >= 0) {
            float angle = wrap(at[part.channel]) * weight;
            if (angle != 0.0F) {
               m.rotateAround(RotationAxis.POSITIVE_Z.rotationDegrees(angle), part.pivotX, part.pivotY, 0.5F);
            }
         }

         m.transformPosition(st.baseX, st.baseY, 0.5F, p);
         out[s * 6] = p.x;
         out[s * 6 + 1] = p.y;
         out[s * 6 + 2] = p.z;
         m.transformPosition(st.tipX, st.tipY, 0.5F, p);
         out[s * 6 + 3] = p.x;
         out[s * 6 + 4] = p.y;
         out[s * 6 + 5] = p.z;
      }
   }

   Matrix4f knifeMatrix(float[] at, float weight, float size, Matrix4f dest) {
      float turn = (float) (Math.PI / 180.0) * weight;
      float scale = this.voxel * size;
      dest.translation(this.fist.x + at[0] * weight, this.fist.y + at[1] * weight, this.fist.z + at[2] * weight)
         .rotate(new Quaternionf().rotateY(wrap(at[3]) * turn).rotateX(wrap(at[4]) * turn).rotateZ(wrap(at[5]) * turn))
         .rotate(this.rest);
      float flip = wrap(at[6]) * turn;
      if (flip != 0.0F) {
         dest.rotateX(flip);
      }

      return dest.scale(scale).translate(at[11] * weight - this.gripX, -this.gripY, -0.5F);
   }

   static float shinePosition(float channel) {
      if (channel <= 0.0F) {
         return 0.0F;
      } else {
         float f = channel - 2.0F * (float)Math.floor(channel / 2.0F);
         return f < 1.0F ? f : 0.0F;
      }
   }

   static float wrap(float degrees) {
      float v = degrees % 360.0F;
      if (v >= 180.0F) {
         v -= 360.0F;
      }

      if (v < -180.0F) {
         v += 360.0F;
      }

      return v;
   }

   private record Part(KnifeMesh mesh, int channel, float pivotX, float pivotY) {
   }

   interface Sink {
      void part(MatrixStack var1, KnifeMesh var2, KnifeMesh.Shine var3);

      void arm(MatrixStack var1);
   }

   private record Streak(int part, float baseX, float baseY, float tipX, float tipY, float strength) {
   }
}
