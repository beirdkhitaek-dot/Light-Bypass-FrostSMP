package cherryblossom.knife;

import java.util.function.Consumer;
import java.util.function.DoubleUnaryOperator;

final class FixedKnives {
   static final float HINGE_X = -1.0F;
   static final int WHOLE = 0;
   static final int HANDLE_ONLY = 1;
   static final int BLADE_ONLY = 2;

   private FixedKnives() {
   }

   static DoubleUnaryOperator taper(double base, double tip, double start, double end, double power) {
      return x -> {
         if (x <= start) {
            return base;
         } else {
            double t = Math.min(1.0, (x - start) / (end - start));
            return base + (tip - base) * Math.pow(t, power);
         }
      };
   }

   static KnifeMesh build(FixedKnives.Spec s) {
      return build(s, 0);
   }

   static KnifeMesh build(FixedKnives.Spec s, int part) {
      KnifeMesh.Voxels v = new KnifeMesh.Voxels();
      if (part != 1) {
         fillBlade(v, s);
      }

      if (part != 2) {
         fillHandle(v, s);
         fillGuard(v, s);
         fillPommel(v, s);
         s.post.accept(v);
      }

      if (s.folding && part != 2) {
         int hz = s.handleZ + 1;
         int py = (int)Math.floor(s.handleCy);
         v.set(-1, py, hz, 5, 1.0F);
         v.set(-1, py, -hz, 5, 1.0F);
      }

      if (s.folding && part != 1) {
         int py = (int)Math.floor(s.handleCy);

         for (int x = -2; x < 0; x++) {
            for (int y = py - 1; y <= py; y++) {
               v.set(x, y, 0, 1, KnifeModels.grain(x, y, 0));
            }
         }
      }

      if (part != 1 && s.postBlade != null) {
         s.postBlade.accept(v);
      }

      return v.mesh(0.0F, s.blade);
   }

   private static void fillBlade(KnifeMesh.Voxels v, FixedKnives.Spec s) {
      for (int x = 0; x < s.blade; x++) {
         double xc = x + 0.5;
         double b = s.bend.applyAsDouble(xc);
         double top = s.top.applyAsDouble(xc) + b;
         double bot = s.bottom.applyAsDouble(xc) + b;
         if (!(top <= bot)) {
            boolean placed = false;

            for (int y = (int)Math.floor(bot) - 1; y <= (int)Math.ceil(top) + 1; y++) {
               double yc = y + 0.5;
               if (!(yc < bot) && !(yc > top)) {
                  placed = true;
                  bladeCell(v, s, x, y, xc, yc, top, bot);
               }
            }

            if (!placed) {
               int yx = (int)Math.floor((top + bot) / 2.0);
               v.set(x, yx, 0, 2, KnifeModels.grain(x, yx, 0));
            }
         }
      }

      if (s.serrTo > s.serrFrom) {
         for (int xx = s.serrFrom; xx < s.serrTo; xx += 3) {
            int yx = topCell(v, xx);
            if (yx != Integer.MIN_VALUE) {
               for (int z = -1; z <= 1; z++) {
                  v.clear(xx, yx, z);
                  v.clear(xx, yx - 1, z);
               }
            }
         }
      }
   }

   private static int topCell(KnifeMesh.Voxels v, int x) {
      for (int y = 31; y >= -32; y--) {
         if (v.filled(x, y, 0)) {
            return y;
         }
      }

      return Integer.MIN_VALUE;
   }

   private static void bladeCell(KnifeMesh.Voxels v, FixedKnives.Spec s, int x, int y, double xc, double yc, double top, double bot) {
      double band = s.hamon ? 0.35 * (top - bot) + 0.45 * Math.sin(xc * 0.6) : s.edgeBand;
      int ink;
      if (yc - bot < band) {
         ink = 2;
      } else if (s.doubleEdge && top - yc < s.edgeBand) {
         ink = 2;
      } else if (s.spineBand > 0.0F && top - yc < s.spineBand) {
         ink = 1;
      } else if (s.fuller && xc > s.fullerFrom && xc < s.fullerTo && Math.abs(yc - (top + bot) / 2.0 - 0.3) < 0.5) {
         ink = 1;
      } else {
         ink = 0;
      }

      v.set(x, y, 0, ink, KnifeModels.grain(x, y, 0));
      if (s.thickSpine && top - yc < 1.1) {
         v.set(x, y, -1, 1, KnifeModels.grain(x, y, -1));
         v.set(x, y, 1, 1, KnifeModels.grain(x, y, 1));
      }
   }

   private static double handleTop(FixedKnives.Spec s, double xc) {
      return s.handleCy + s.handleHalf + s.flare.applyAsDouble(xc + s.handle) + s.handleBend.applyAsDouble(xc);
   }

   private static double handleBottom(FixedKnives.Spec s, double xc) {
      return s.handleCy - s.handleHalf - s.flare.applyAsDouble(xc + s.handle) + s.handleBend.applyAsDouble(xc);
   }

   private static void fillHandle(KnifeMesh.Voxels v, FixedKnives.Spec s) {
      int hz = s.handleZ;

      for (int x = -s.handle; x < 0; x++) {
         double xc = x + 0.5;
         double top = handleTop(s, xc);
         double bot = handleBottom(s, xc);

         for (int y = (int)Math.floor(bot) - 1; y <= (int)Math.ceil(top) + 1; y++) {
            double yc = y + 0.5;
            if (!(yc < bot) && !(yc > top) && (s.grip != FixedKnives.Grip.SKELETON || !skeletonHole(s, x, yc))) {
               boolean rim = top - yc < 0.9 || yc - bot < 0.9;

               for (int z = -hz; z <= hz; z++) {
                  if (hz < 2 || Math.abs(z) != hz || !rim) {
                     v.set(x, y, z, handleInk(s, x, y, z, hz, rim), KnifeModels.grain(x, y, z));
                  }
               }
            }
         }
      }

      if (s.grip == FixedKnives.Grip.SCALES) {
         int[] at = new int[]{-(s.guardLen + 2), -s.handle / 2, -s.handle + 2};
         int yx = (int)Math.floor(s.handleCy);

         for (int x : at) {
            v.set(x, yx, hz + 1, 5, 1.0F);
            v.set(x, yx, -hz - 1, 5, 1.0F);
         }
      }
   }

   private static boolean skeletonHole(FixedKnives.Spec s, int x, double yc) {
      if (x <= -4 && x >= -s.handle / 2 - 1) {
         int phase = Math.floorMod(x + s.handle, 5);
         return phase >= 1 && phase <= 3 && Math.abs(yc - s.handleCy) < s.handleHalf - 0.9;
      } else {
         return false;
      }
   }

   private static int handleInk(FixedKnives.Spec s, int x, int y, int z, int hz, boolean rim) {
      if (Math.abs(z) < hz) {
         return 4;
      } else {
         switch (s.grip) {
            case PLAIN:
            case SCALES:
            default:
               return rim ? 4 : 3;
            case GROOVES:
               return !rim && Math.floorMod(x, 3) != 0 ? 3 : 4;
            case WRAP:
               return (x + y & 3) < 2 ? 7 : 3;
            case STAG:
               int h = x * 73856093 ^ y * 19349663 ^ z * 83492791;
               h ^= h >>> 13;
               if ((h & 7) == 0) {
                  return 4;
               }

               return (h >>> 4 & 15) == 0 ? 6 : 3;
            case SKELETON:
               return x <= -s.handle / 2 && (x + y & 3) < 2 ? 7 : 5;
            case TSUKA:
               int a = rim ? z : y;
               boolean ito = Math.floorMod(x + a, 6) < 2 || Math.floorMod(x - a, 6) < 2;
               return ito ? 7 : 6;
         }
      }
   }

   private static void fillGuard(KnifeMesh.Voxels v, FixedKnives.Spec s) {
      if (s.guard != FixedKnives.Guard.NONE) {
         int gz = s.handleZ + 1;
         int ink = s.guard == FixedKnives.Guard.BRASS ? 8 : 5;
         double top = handleTop(s, -0.5);
         double bot = handleBottom(s, -0.5);
         double cy = (top + bot) / 2.0;

         for (int x = -s.guardLen; x < 0; x++) {
            if (s.guard == FixedKnives.Guard.DISC) {
               double r = (top - bot) / 2.0 + s.guardReach;

               for (int y = (int)Math.floor(cy - r) - 1; y <= (int)Math.ceil(cy + r); y++) {
                  for (int z = -8; z < 8; z++) {
                     double dy = y + 0.5 - cy;
                     double dz = z;
                     double d = Math.sqrt(dy * dy + dz * dz);
                     if (!(d > r)) {
                        boolean rim = d > r - 1.0;
                        v.set(x, y, z, rim ? 8 : ink, KnifeModels.grain(x, y, z));
                     }
                  }
               }
            } else {
               int y0 = (int)Math.floor(bot - (s.guard == FixedKnives.Guard.FINGER ? s.guardReach * 2 : s.guardReach));
               int y1 = (int)Math.ceil(top + (s.guard == FixedKnives.Guard.FINGER ? 0.5 : s.guardReach));

               for (int y = y0; y < y1; y++) {
                  for (int zx = -gz; zx <= gz; zx++) {
                     v.set(x, y, zx, ink, KnifeModels.grain(x, y, zx));
                  }
               }
            }
         }
      }
   }

   private static void fillPommel(KnifeMesh.Voxels v, FixedKnives.Spec s) {
      if (s.pommel != FixedKnives.Pommel.NONE) {
         int hz = s.handleZ;
         double xc = -s.handle + 0.5;
         double top = handleTop(s, xc);
         double bot = handleBottom(s, xc);
         int y0 = (int)Math.floor(bot);
         int y1 = (int)Math.ceil(top);
         int x = -s.handle - 1;
         switch (s.pommel) {
            case CAP:
            case BRASS_CAP:
               int ink = s.pommel == FixedKnives.Pommel.BRASS_CAP ? 8 : 5;

               for (int yx = y0; yx < y1; yx++) {
                  for (int zx = -hz; zx <= hz; zx++) {
                     v.set(x, yx, zx, ink, KnifeModels.grain(x, yx, zx));
                  }
               }
               break;
            case KNOB:
               for (int xx = x - 1; xx <= x; xx++) {
                  for (int yx = y0 - 1; yx < y1 + 1; yx++) {
                     for (int z = -hz - 1; z <= hz + 1; z++) {
                        boolean corner = (yx == y0 - 1 || yx == y1) && Math.abs(z) == hz + 1;
                        if (!corner) {
                           v.set(xx, yx, z, 5, KnifeModels.grain(xx, yx, z));
                        }
                     }
                  }
               }
               break;
            case RING:
               double cx = x - 1.5;
               double cy = (top + bot) / 2.0;

               for (int xx = (int)Math.floor(cx - 3.2); xx <= Math.ceil(cx + 3.2); xx++) {
                  for (int y = (int)Math.floor(cy - 3.2); y <= Math.ceil(cy + 3.2); y++) {
                     double d = Math.hypot(xx + 0.5 - cx, y + 0.5 - cy);
                     if (!(d < 1.5) && !(d > 3.0) && !v.filled(xx, y, 0)) {
                        for (int z = -1; z <= 1; z++) {
                           v.set(xx, y, z, 5, (!(d > 2.6) && !(d < 1.9) ? 1.0F : 0.86F) * KnifeModels.grain(xx, y, z));
                        }
                     }
                  }
               }
         }
      }
   }

   static FixedKnives.Spec[] all() {
      return new FixedKnives.Spec[]{
         katana(),
         bayonet(),
         m9(),
         flip(),
         gut(),
         huntsman(),
         falchion(),
         bowie(),
         navaja(),
         stiletto(),
         talon(),
         ursus(),
         classic(),
         paracord(),
         survival(),
         nomad(),
         skeleton(),
         kukri()
      };
   }

   static FixedKnives.Spec katana() {
      FixedKnives.Spec s = new FixedKnives.Spec("Katana");
      s.voxel = 0.0145F;
      s.blade = 54;
      s.top = taper(2.0, 0.2, 47.0, 54.0, 1.0);
      s.bottom = taper(-2.0, 0.2, 49.0, 54.0, 1.0);
      s.bend = x -> 0.0015 * x * x;
      s.hamon = true;
      s.spineBand = 0.55F;
      s.fuller = true;
      s.fullerFrom = 4;
      s.fullerTo = 46;
      s.handle = 21;
      s.handleZ = 2;
      s.handleHalf = 1.85;
      s.grip = FixedKnives.Grip.TSUKA;
      s.guard = FixedKnives.Guard.DISC;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.BRASS_CAP;
      s.gripBack = 0.0F;
      s.shineTail = 9.0F;
      s.post = v -> {
         for (int x = 0; x <= 1; x++) {
            for (int y = -2; y <= 1; y++) {
               for (int z = -1; z <= 1; z++) {
                  v.set(x, y, z, 8, KnifeModels.grain(x, y, z));
               }
            }
         }

         for (int x : new int[]{-13, -8}) {
            for (int z : new int[]{-3, 2}) {
               v.set(x, 0, z, 8, 1.0F);
            }
         }
      };
      return s;
   }

   static FixedKnives.Spec bayonet() {
      FixedKnives.Spec s = new FixedKnives.Spec("Bayonet");
      s.blade = 24;
      s.top = taper(2.4, 0.3, 15.0, 24.0, 1.3);
      s.bottom = taper(-2.4, 0.3, 18.0, 24.0, 1.7);
      s.fuller = true;
      s.fullerFrom = 3;
      s.fullerTo = 18;
      s.handle = 11;
      s.handleHalf = 1.9;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.KNOB;
      return s;
   }

   static FixedKnives.Spec m9() {
      FixedKnives.Spec s = new FixedKnives.Spec("M9 Bayonet");
      s.blade = 27;
      s.top = taper(3.0, 0.4, 17.0, 27.0, 1.15);
      s.bottom = taper(-3.0, 0.4, 20.0, 27.0, 1.6);
      s.fuller = true;
      s.fullerFrom = 8;
      s.fullerTo = 22;
      s.serrFrom = 3;
      s.serrTo = 14;
      s.handle = 12;
      s.handleHalf = 2.2;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.KNOB;
      s.post = v -> {
         for (int x = 4; x <= 6; x++) {
            for (int y = -1; y <= 0; y++) {
               v.clear(x, y, 0);
            }
         }
      };
      return s;
   }

   static FixedKnives.Spec flip() {
      FixedKnives.Spec s = new FixedKnives.Spec("Flip Knife");
      s.voxel = 0.022F;
      s.blade = 19;
      s.top = taper(2.8, 0.4, 10.0, 19.0, 1.6);
      s.bottom = taper(-2.8, 0.4, 5.0, 19.0, 2.0);
      s.handle = 21;
      s.handleHalf = 2.9;
      s.grip = FixedKnives.Grip.SCALES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 1;
      s.guardReach = 0;
      s.pommel = FixedKnives.Pommel.CAP;
      s.folding = true;
      s.postBlade = v -> {
         v.set(1, 2, 1, 5, 1.0F);
         v.set(1, 2, -1, 5, 1.0F);
      };
      s.post = v -> {
         for (int y = -2; y <= 2; y++) {
            v.set(-19, y, 0, 5, 1.0F);
         }
      };
      return s;
   }

   static FixedKnives.Spec gut() {
      FixedKnives.Spec s = new FixedKnives.Spec("Gut Knife");
      s.blade = 19;
      s.top = taper(3.2, 0.5, 8.0, 19.0, 1.4);
      s.bottom = taper(-3.2, 0.5, 3.0, 19.0, 2.3);
      s.handle = 12;
      s.handleHalf = 2.4;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 1;
      s.guardReach = 1;
      s.pommel = FixedKnives.Pommel.CAP;
      s.post = v -> {
         for (int x = 8; x <= 10; x++) {
            int y = topCell(v, x);
            v.clear(x, y, 0);
            v.clear(x, y - 1, 0);
            if (x == 9) {
               v.clear(x, y - 2, 0);
            }
         }
      };
      return s;
   }

   static FixedKnives.Spec huntsman() {
      FixedKnives.Spec s = new FixedKnives.Spec("Huntsman");
      s.blade = 23;
      s.top = taper(3.4, 0.5, 11.0, 23.0, 1.2);
      s.bottom = taper(-3.6, 0.5, 2.0, 23.0, 2.4);
      s.handle = 12;
      s.handleHalf = 2.3;
      s.grip = FixedKnives.Grip.STAG;
      s.guard = FixedKnives.Guard.FINGER;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.KNOB;
      return s;
   }

   static FixedKnives.Spec falchion() {
      FixedKnives.Spec s = new FixedKnives.Spec("Falchion");
      s.blade = 29;
      s.top = taper(2.3, 0.5, 7.0, 29.0, 1.0);
      s.bottom = x -> x < 29.0 ? -2.3 - 2.4 * Math.sin(Math.PI * Math.min(1.0, x / 29.0) * 0.9) + 2.8 * Math.pow(Math.max(0.0, (x - 21.0) / 8.0), 2.0) : 0.5;
      s.bend = x -> 0.0045 * x * x;
      s.thickSpine = true;
      s.handle = 12;
      s.handleHalf = 1.9;
      s.grip = FixedKnives.Grip.WRAP;
      s.guard = FixedKnives.Guard.FINGER;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.KNOB;
      return s;
   }

   static FixedKnives.Spec bowie() {
      FixedKnives.Spec s = new FixedKnives.Spec("Bowie");
      s.blade = 27;
      s.top = taper(3.4, 0.6, 17.0, 27.0, 0.55);
      s.bottom = taper(-3.4, 0.6, 6.0, 27.0, 2.4);
      s.thickSpine = true;
      s.handle = 13;
      s.handleHalf = 2.2;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.BRASS;
      s.guardLen = 2;
      s.guardReach = 3;
      s.pommel = FixedKnives.Pommel.BRASS_CAP;
      return s;
   }

   static FixedKnives.Spec navaja() {
      FixedKnives.Spec s = new FixedKnives.Spec("Navaja");
      s.voxel = 0.021F;
      s.blade = 23;
      s.top = taper(2.2, 0.2, 2.0, 23.0, 1.1);
      s.bottom = taper(-2.2, 0.2, 10.0, 23.0, 1.6);
      s.handle = 25;
      s.handleHalf = 2.5;
      s.handleBend = x -> -0.012 * (x + 12.5) * (x + 12.5) + 1.9;
      s.grip = FixedKnives.Grip.SCALES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 1;
      s.guardReach = 0;
      s.pommel = FixedKnives.Pommel.CAP;
      s.folding = true;
      s.gripBack = -1.0F;
      return s;
   }

   static FixedKnives.Spec stiletto() {
      FixedKnives.Spec s = new FixedKnives.Spec("Stiletto");
      s.voxel = 0.027F;
      s.blade = 27;
      s.top = taper(1.6, 0.2, 0.0, 27.0, 0.9);
      DoubleUnaryOperator half = taper(1.6, 0.2, 0.0, 27.0, 0.9);
      s.bottom = x -> -half.applyAsDouble(x);
      s.doubleEdge = true;
      s.fuller = true;
      s.fullerFrom = 2;
      s.fullerTo = 20;
      s.handle = 10;
      s.handleHalf = 1.5;
      s.flare = d -> d < 3.0 ? (3.0 - d) * 0.25 : 0.0;
      s.grip = FixedKnives.Grip.WRAP;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 1;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.KNOB;
      s.gripBack = -3.0F;
      return s;
   }

   static FixedKnives.Spec talon() {
      FixedKnives.Spec s = new FixedKnives.Spec("Talon");
      s.voxel = 0.023F;
      s.blade = 19;
      s.top = taper(2.4, 0.3, 4.0, 19.0, 1.0);
      s.bottom = taper(-2.4, 0.3, 4.0, 19.0, 1.0);
      s.bend = x -> -0.02 * x * x;
      s.thickSpine = true;
      s.handle = 12;
      s.handleHalf = 1.9;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.FINGER;
      s.guardLen = 1;
      s.guardReach = 1;
      s.pommel = FixedKnives.Pommel.RING;
      s.gripBack = -2.5F;
      s.ring = true;
      return s;
   }

   static FixedKnives.Spec ursus() {
      FixedKnives.Spec s = new FixedKnives.Spec("Ursus");
      s.blade = 22;
      s.top = taper(2.8, 0.5, 12.0, 22.0, 1.0);
      s.bottom = taper(-2.8, 0.5, 2.0, 22.0, 2.2);
      s.serrFrom = 1;
      s.serrTo = 9;
      s.handle = 12;
      s.handleHalf = 2.2;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.FINGER;
      s.guardLen = 1;
      s.guardReach = 1;
      s.pommel = FixedKnives.Pommel.KNOB;
      s.post = v -> {
         for (int y = -4; y <= -3; y++) {
            v.clear(-1, y, 0);
         }
      };
      return s;
   }

   static FixedKnives.Spec classic() {
      FixedKnives.Spec s = new FixedKnives.Spec("Classic");
      s.blade = 23;
      s.top = taper(2.6, 0.4, 14.0, 23.0, 1.5);
      s.bottom = taper(-2.6, 0.4, 9.0, 23.0, 1.6);
      s.fuller = true;
      s.fullerFrom = 3;
      s.fullerTo = 15;
      s.handle = 12;
      s.handleHalf = 2.1;
      s.grip = FixedKnives.Grip.STAG;
      s.guard = FixedKnives.Guard.BRASS;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.BRASS_CAP;
      return s;
   }

   static FixedKnives.Spec paracord() {
      FixedKnives.Spec s = new FixedKnives.Spec("Paracord");
      s.voxel = 0.023F;
      s.blade = 20;
      s.top = taper(2.5, 0.4, 10.0, 20.0, 1.5);
      s.bottom = taper(-2.5, 0.4, 4.0, 20.0, 2.0);
      s.handle = 13;
      s.handleHalf = 2.2;
      s.handleZ = 2;
      s.grip = FixedKnives.Grip.WRAP;
      s.guard = FixedKnives.Guard.NONE;
      s.pommel = FixedKnives.Pommel.RING;
      s.gripBack = -2.5F;
      s.ring = true;
      return s;
   }

   static FixedKnives.Spec survival() {
      FixedKnives.Spec s = new FixedKnives.Spec("Survival");
      s.blade = 26;
      s.top = taper(3.2, 0.6, 17.0, 26.0, 0.9);
      s.bottom = taper(-3.2, 0.6, 16.0, 26.0, 1.5);
      s.thickSpine = true;
      s.serrFrom = 3;
      s.serrTo = 16;
      s.handle = 13;
      s.handleHalf = 2.4;
      s.handleZ = 2;
      s.grip = FixedKnives.Grip.GROOVES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.KNOB;
      return s;
   }

   static FixedKnives.Spec nomad() {
      FixedKnives.Spec s = new FixedKnives.Spec("Nomad");
      s.blade = 22;
      s.top = taper(2.6, 0.3, 6.0, 22.0, 1.0);
      s.bottom = taper(-2.6, 0.3, 6.0, 22.0, 1.2);
      s.bend = x -> -0.012 * x * x;
      s.thickSpine = true;
      s.handle = 12;
      s.handleHalf = 2.0;
      s.flare = d -> d < 3.0 ? (3.0 - d) * 0.3 : 0.0;
      s.grip = FixedKnives.Grip.WRAP;
      s.guard = FixedKnives.Guard.FINGER;
      s.guardLen = 2;
      s.guardReach = 2;
      s.pommel = FixedKnives.Pommel.CAP;
      return s;
   }

   static FixedKnives.Spec skeleton() {
      FixedKnives.Spec s = new FixedKnives.Spec("Skeleton");
      s.voxel = 0.022F;
      s.blade = 21;
      s.top = taper(2.6, 0.4, 11.0, 21.0, 1.5);
      s.bottom = taper(-2.6, 0.4, 5.0, 21.0, 2.0);
      s.handle = 16;
      s.handleHalf = 2.4;
      s.grip = FixedKnives.Grip.SKELETON;
      s.guard = FixedKnives.Guard.NONE;
      s.pommel = FixedKnives.Pommel.RING;
      s.gripBack = -2.5F;
      s.ring = true;
      return s;
   }

   static FixedKnives.Spec kukri() {
      FixedKnives.Spec s = new FixedKnives.Spec("Kukri");
      s.blade = 27;
      s.top = taper(3.4, 0.5, 14.0, 27.0, 0.9);
      s.bottom = taper(-3.4, 0.5, 10.0, 27.0, 1.4);
      s.bend = x -> -0.011 * x * x;
      s.thickSpine = true;
      s.handle = 12;
      s.handleHalf = 2.0;
      s.flare = d -> d < 4.0 ? (4.0 - d) * 0.35 : 0.0;
      s.grip = FixedKnives.Grip.SCALES;
      s.guard = FixedKnives.Guard.CROSS;
      s.guardLen = 1;
      s.guardReach = 1;
      s.pommel = FixedKnives.Pommel.KNOB;
      s.post = v -> {
         v.clear(1, -3, 0);
         v.clear(2, -3, 0);
         v.clear(1, -4, 0);
      };
      return s;
   }

   static enum Grip {
      PLAIN,
      GROOVES,
      WRAP,
      SCALES,
      STAG,
      SKELETON,
      TSUKA;
   }

   static enum Guard {
      NONE,
      CROSS,
      BRASS,
      FINGER,
      DISC;
   }

   static enum Pommel {
      NONE,
      CAP,
      BRASS_CAP,
      KNOB,
      RING;
   }

   static final class Spec {
      final String name;
      float voxel = 0.026F;
      int blade = 22;
      DoubleUnaryOperator top = x -> 2.5;
      DoubleUnaryOperator bottom = x -> -2.5;
      DoubleUnaryOperator bend = x -> 0.0;
      float edgeBand = 0.7F;
      float spineBand = 0.0F;
      boolean doubleEdge;
      boolean thickSpine;
      boolean fuller;
      boolean hamon;
      int fullerFrom = 3;
      int fullerTo = 16;
      int serrFrom;
      int serrTo;
      int handle = 12;
      int handleZ = 1;
      double handleHalf = 2.0;
      double handleCy = 0.0;
      DoubleUnaryOperator flare = d -> 0.0;
      DoubleUnaryOperator handleBend = x -> 0.0;
      FixedKnives.Grip grip = FixedKnives.Grip.PLAIN;
      FixedKnives.Guard guard = FixedKnives.Guard.NONE;
      int guardLen = 2;
      int guardReach = 2;
      FixedKnives.Pommel pommel = FixedKnives.Pommel.CAP;
      float gripBack = -2.0F;
      float shineTail;
      Consumer<KnifeMesh.Voxels> post = v -> {};
      Consumer<KnifeMesh.Voxels> postBlade = null;
      boolean folding;
      boolean ring;

      Spec(String name) {
         this.name = name;
      }

      float gripX() {
         return -(this.handle - this.gripBack);
      }

      float hingeY() {
         return (float)this.handleCy;
      }

      float ringX() {
         return -this.handle - 2.5F;
      }

      float ringY() {
         return (float)(this.handleCy + this.handleBend.applyAsDouble(-this.handle + 0.5));
      }

      float gripY() {
         return (float)(this.handleCy + this.handleBend.applyAsDouble(-this.handle / 2.0));
      }

      float bladeEndY() {
         return (float)(
            (this.top.applyAsDouble(this.blade - 0.5) + this.bottom.applyAsDouble(this.blade - 0.5)) / 2.0 + this.bend.applyAsDouble(this.blade - 0.5)
         );
      }

      float bladeMidY(double x) {
         return (float)((this.top.applyAsDouble(x) + this.bottom.applyAsDouble(x)) / 2.0 + this.bend.applyAsDouble(x));
      }
   }
}
