package cherryblossom.knife;

final class KnifeModels {
   static final int KARAMBIT_DETAIL = 1;
   static final float KARAMBIT_RING_X = -22.0F;
   static final float KARAMBIT_RING_Y = 0.0F;
   static final float KARAMBIT_BLADE_LENGTH = 17.0F;
   static final float KARAMBIT_HOLD_X = -12.0F;
   static final int KARAMBIT_BLADE_X = -2;
   static final int KARAMBIT_BLADE_Y = 7;
   private static final String[] HANDLE = new String[]{
      "...#...............",
      "..###..............",
      ".####..............",
      "#########..........",
      "##########.....##..",
      "#################..",
      "...###############.",
      ".....#############.",
      ".....##############",
      ".........#########.",
      ".........#########.",
      "...............##.."
   };
   private static final int HANDLE_X0 = -21;

   private KnifeModels() {
   }

   static float grain(int x, int y, int z) {
      int h = x * 73856093 ^ y * 19349663 ^ z * 83492791;
      h ^= h >>> 13;
      h *= 1540483477;
      h ^= h >>> 15;
      return 0.92F + 0.08F * ((h & 1023) / 1023.0F);
   }

   private static float[] karambitCurve(float s) {
      float x = 0.0F;
      float y = 0.0F;
      float step = 0.05F;

      for (float t = 0.0F; t < s; t += step) {
         float heading = -(0.026F * t + 0.0042F * t * t);
         x += (float)Math.cos(heading) * step;
         y += (float)Math.sin(heading) * step;
      }

      float heading = -(0.026F * s + 0.0042F * s * s);
      return new float[]{x, y, (float)Math.cos(heading), (float)Math.sin(heading)};
   }

   static float[] karambitTip() {
      float[] c = karambitCurve(17.0F);
      return new float[]{(c[0] + -2.0F) * 1.0F, (c[1] + 7.0F) * 1.0F};
   }

   private static int fade(float t) {
      int i = Math.round(Math.max(0.0F, Math.min(1.0F, t)) * 11.0F);
      return 9 + i;
   }

   static KnifeMesh karambit() {
      KnifeMesh.Voxels v = new KnifeMesh.Voxels();
      float ringX = -22.0F;
      float ringY = 0.0F;
      int lastX = Integer.MIN_VALUE;
      int lastY = 0;

      for (int row = 0; row < HANDLE.length; row++) {
         for (int col = 0; col < HANDLE[row].length(); col++) {
            if (HANDLE[row].charAt(col) == '#') {
               int x = -21 + col;
               int y = row;
               v.set(x, row, 0, 22, grain(x, row, 0));

               for (int z : new int[]{-1, 1}) {
                  v.set(x, y, z, 21, 0.85F * grain(x, y, z) + 0.15F * grain(x * 3, y * 5, z));
               }

               if (x > lastX || x == lastX && y > lastY) {
                  lastX = x;
                  lastY = y;
               }
            }
         }
      }

      v.set(lastX - 3, lastY - 1, 2, 24, 1.0F);
      v.set(lastX - 3, lastY - 1, -2, 22, 1.0F);

      for (int x = Math.round(ringX - 3.6F); x <= Math.round(ringX + 3.6F); x++) {
         for (int y = Math.round(ringY - 3.6F); y <= Math.round(ringY + 3.6F); y++) {
            float dx = x + 0.5F - ringX;
            float dy = y + 0.5F - ringY;
            float d = (float)Math.sqrt(dx * dx + dy * dy);
            if (!(d < 1.9F) && !(d > 3.2F) && !v.filled(x, y, 0)) {
               float ang = (float)Math.atan2(dy, dx);
               float t = 0.5F - 0.5F * (float)Math.cos(ang - 0.9F);
               int ink = fade(t * 0.95F);

               for (int z = -1; z <= 1; z++) {
                  v.set(x, y, z, ink, (z == 0 ? 1.0F : 0.86F) * grain(x, y, z));
               }
            }
         }
      }

      int samples = 240;
      float[][] curve = new float[samples + 1][];

      for (int i = 0; i <= samples; i++) {
         float[] c = karambitCurve(17.0F * i / samples);
         curve[i] = new float[]{c[0] + -2.0F, c[1] + 7.0F, c[2], c[3]};
      }

      for (int x = -3; x < 20; x++) {
         for (int yx = -15; yx < 15; yx++) {
            float px = x + 0.5F;
            float py = yx + 0.5F;
            int best = 0;
            float bestDistance = Float.MAX_VALUE;

            for (int i = 0; i <= samples; i++) {
               float dx = px - curve[i][0];
               float dy = py - curve[i][1];
               float d = dx * dx + dy * dy;
               if (d < bestDistance) {
                  bestDistance = d;
                  best = i;
               }
            }

            float[] c = curve[best];
            float dx = px - c[0];
            float dy = py - c[1];
            float along = dx * c[2] + dy * c[3];
            float across = -dx * c[3] + dy * c[2];
            if ((best != 0 || !(along < -0.5F)) && (best != samples || !(along > 0.3F))) {
               float left = 1.0F - (float)best / samples;
               float spine = 1.3F * (float)Math.pow(left, 0.7) + 0.2F;
               float edge = 1.8F * (float)Math.pow(left, 1.0) + 0.2F;
               if (!(across > spine) && !(across < -edge) && !v.filled(x, yx, 0)) {
                  float along01 = (float)best / samples;
                  int ink = fade(along01 * 1.05F);
                  float tone = across < -edge + 0.9F ? 1.12F : (across > spine - 0.9F ? 0.78F : 1.0F);
                  v.set(x, yx, 0, ink, tone * grain(x, yx, 0));
               }
            }
         }
      }

      return v.mesh(0.0F, 14.0F);
   }

   static KnifeMesh butterflyBlade() {
      KnifeMesh.Voxels v = new KnifeMesh.Voxels();

      for (int x = -3; x <= 21; x++) {
         int top = x <= 12 ? 2 : Math.round(2.0F - (x - 12) * 3.0F / 9.0F);
         int bottom = x <= 14 ? -2 : Math.round(-2.0F + (float)Math.pow((x - 14) / 7.0F, 2.0) * 1.0F);

         for (int y = bottom; y <= top; y++) {
            int ink = x < 0 ? 5 : (x <= 1 ? 1 : (y == bottom ? 2 : (y == top ? (x >= 13 ? 2 : 1) : 0)));
            v.set(x, y, 0, ink, grain(x, y, 0));
         }
      }

      return v.mesh(0.0F, 22.0F);
   }

   static KnifeMesh butterflyHandle(int side) {
      KnifeMesh.Voxels v = new KnifeMesh.Voxels();
      int inner = side > 0 ? 1 : -1;
      int outer = side > 0 ? 2 : -2;
      int cap = side > 0 ? 3 : -3;

      for (int x = -27; x <= 0; x++) {
         for (int y = -2; y <= 2; y++) {
            boolean corner = (x == 0 || x == -27) && Math.abs(y) == 2;
            boolean hole = Math.abs(y) <= 1 && (x <= -6 && x >= -8 || x <= -12 && x >= -14 || x <= -18 && x >= -20);
            if (!corner && !hole) {
               v.set(x, y, inner, 4, grain(x, y, inner));
               int ink = 3;
               if ((x == -10 || x == -16) && Math.abs(y) <= 1) {
                  ink = 6;
               }

               if (y == 0 && (x == -2 || x == -25)) {
                  ink = 5;
               }

               v.set(x, y, outer, ink, grain(x, y, outer));
            }
         }
      }

      v.set(-2, 0, cap, 5, 1.0F);
      v.set(-25, 0, cap, 5, 1.0F);
      if (side < 0) {
         v.set(-28, 1, inner, 5, 1.0F);
         v.set(-28, 2, inner, 5, 1.0F);
         v.set(-29, 2, inner, 5, 1.0F);
      }

      return v.mesh(-29.0F, 0.0F);
   }
}
