package cherryblossom.knife;

import java.util.ArrayDeque;
import java.util.Arrays;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack.Entry;

final class KnifeTrail {
   private static final long MAX_GAP = 100000000L;
   private static final long MIN_GAP = 2000000L;
   private final ArrayDeque<KnifeTrail.Sample> samples = new ArrayDeque<>();

   void clear() {
      this.samples.clear();
   }

   boolean isEmpty() {
      return this.samples.isEmpty();
   }

   void add(long now, float[] ends) {
      KnifeTrail.Sample last = this.samples.peekLast();
      if (last == null || now - last.time >= 2000000L) {
         this.samples.addLast(new KnifeTrail.Sample(now, (float[])ends.clone()));
      }
   }

   void expire(long now, float seconds) {
      long keep = (long)(seconds * 1.0E9F);

      while (!this.samples.isEmpty() && now - this.samples.peekFirst().time > keep) {
         this.samples.removeFirst();
      }
   }

   float[] build(long now, float seconds, KnifeSkin skin) {
      float[] out = new float[256];
      int n = 0;
      KnifeTrail.Sample prev = null;
      float span = seconds * 1.0E9F;

      for (KnifeTrail.Sample cur : this.samples) {
         if (prev != null && cur.time - prev.time <= 100000000L) {
            float wa = fade((float)(now - prev.time) / span);
            float wb = fade((float)(now - cur.time) / span);

            for (int s = 0; s < skin.streakCount(); s++) {
               float strength = skin.streakStrength(s);
               float tipA = wa * strength * 0.6F;
               float tipB = wb * strength * 0.6F;
               if (!(tipA < 0.004F) || !(tipB < 0.004F)) {
                  if (n + 16 > out.length) {
                     out = Arrays.copyOf(out, out.length * 2);
                  }

                  int i = s * 6;
                  n = corner(out, n, prev.ends, i, tipA * 0.2F);
                  n = corner(out, n, prev.ends, i + 3, tipA);
                  n = corner(out, n, cur.ends, i + 3, tipB);
                  n = corner(out, n, cur.ends, i, tipB * 0.2F);
               }
            }
         }

         prev = cur;
      }

      return Arrays.copyOf(out, n);
   }

   private static float fade(float age) {
      float k = Math.max(0.0F, 1.0F - age);
      return k * k;
   }

   private static int corner(float[] out, int n, float[] ends, int at, float alpha) {
      out[n] = ends[at];
      out[n + 1] = ends[at + 1];
      out[n + 2] = ends[at + 2];
      out[n + 3] = alpha;
      return n + 4;
   }

   static void emit(Entry pose, VertexConsumer out, float[] quads, int rgb) {
      int r = rgb >> 16 & 0xFF;
      int g = rgb >> 8 & 0xFF;
      int b = rgb & 0xFF;

      for (int q = 0; q + 16 <= quads.length; q += 16) {
         for (int pass = 0; pass < 2; pass++) {
            for (int v = 0; v < 4; v++) {
               int i = q + (pass == 0 ? v : 3 - v) * 4;
               out.vertex(pose, quads[i], quads[i + 1], quads[i + 2])
                  .color(r, g, b, Math.round(Math.min(1.0F, quads[i + 3]) * 255.0F))
                  .texture(0.5F, 0.5F)
                  .overlay(OverlayTexture.DEFAULT_UV)
                  .light(15728880)
                  .normal(pose, 0.0F, 0.0F, 1.0F);
            }
         }
      }
   }

   private record Sample(long time, float[] ends) {
   }
}
