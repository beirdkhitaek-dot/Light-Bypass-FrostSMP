package cherryblossom.knife;

final class InspectAnimation {
   static final int X = 0;
   static final int Y = 1;
   static final int Z = 2;
   static final int YAW = 3;
   static final int PITCH = 4;
   static final int ROLL = 5;
   static final int FLIP = 6;
   static final int SPIN = 7;
   static final int PART_A = 8;
   static final int PART_B = 9;
   static final int SHINE = 10;
   static final int SLIDE = 11;
   static final int DRAW = 12;
   static final int SHEATH = 13;
   static final int OFF_HAND = 14;
   static final int OFF_AT = 15;
   static final int CHANNELS = 16;

   private InspectAnimation() {
   }

   static float[] sample(float[][] keys, float t, float[] out) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      int i = 0;

      while (i < keys.length - 2 && t > keys[i + 1][0]) {
         i++;
      }

      float[] to = keys[i + 1];
      float[] from = keys[i];
      float span = to[0] - from[0];
      float u = span <= 0.0F ? 1.0F : (t - from[0]) / span;

      for (int c = 0; c < 16; c++) {
         out[c] = hermite(value(from, c), value(to, c), slope(keys, i, c) * span, slope(keys, i + 1, c) * span, u);
      }

      return out;
   }

   static float[] sampleLoop(float[][] keys, float t, float[] out) {
      t -= (float)Math.floor(t);
      int n = keys.length;
      int i = 0;

      while (i < n - 2 && t > keys[i + 1][0]) {
         i++;
      }

      float[] to = keys[i + 1];
      float[] from = keys[i];
      float span = to[0] - from[0];
      float u = span <= 0.0F ? 1.0F : (t - from[0]) / span;

      for (int c = 0; c < 16; c++) {
         out[c] = hermite(value(from, c), value(to, c), loopSlope(keys, i, c) * span, loopSlope(keys, i + 1, c) * span, u);
      }

      return out;
   }

   private static float loopSlope(float[][] keys, int i, int c) {
      int n = keys.length;
      float drift = value(keys[n - 1], c) - value(keys[0], c);
      float prevT;
      float prevV;
      if (i == 0) {
         prevT = keys[n - 2][0] - 1.0F;
         prevV = value(keys[n - 2], c) - drift;
      } else {
         prevT = keys[i - 1][0];
         prevV = value(keys[i - 1], c);
      }

      float nextT;
      float nextV;
      if (i == n - 1) {
         nextT = keys[1][0] + 1.0F;
         nextV = value(keys[1], c) + drift;
      } else {
         nextT = keys[i + 1][0];
         nextV = value(keys[i + 1], c);
      }

      return (nextV - prevV) / (nextT - prevT);
   }

   private static float value(float[] key, int channel) {
      return channel + 1 < key.length ? key[channel + 1] : 0.0F;
   }

   private static float slope(float[][] keys, int i, int c) {
      if (i != 0 && i != keys.length - 1) {
         float[] prev = keys[i - 1];
         float[] next = keys[i + 1];
         return (value(next, c) - value(prev, c)) / (next[0] - prev[0]);
      } else {
         return 0.0F;
      }
   }

   private static float hermite(float p0, float p1, float m0, float m1, float u) {
      float u2 = u * u;
      float u3 = u2 * u;
      return (2.0F * u3 - 3.0F * u2 + 1.0F) * p0 + (u3 - 2.0F * u2 + u) * m0 + (-2.0F * u3 + 3.0F * u2) * p1 + (u3 - u2) * m1;
   }

   static final class Clip {
      final float[][] keys;
      final float seconds;
      final float loopEnter;
      final float loopExit;
      private final float[][] loop;

      Clip(float[][] keys, float seconds) {
         this(keys, seconds, 0.0F, 0.0F);
      }

      Clip(float[][] keys, float seconds, float loopEnter, float loopExit) {
         this.keys = keys;
         this.seconds = seconds;
         this.loopEnter = loopEnter;
         this.loopExit = loopExit;
         this.loop = loopExit > loopEnter ? cut(keys, loopEnter, loopExit) : null;
      }

      boolean loops() {
         return this.loop != null;
      }

      float[] sample(float t, float[] out) {
         return this.loop != null && t > this.loopEnter && t < this.loopExit
            ? InspectAnimation.sampleLoop(this.loop, (t - this.loopEnter) / (this.loopExit - this.loopEnter), out)
            : InspectAnimation.sample(this.keys, t, out);
      }

      private static float[][] cut(float[][] keys, float enter, float exit) {
         int from = -1;
         int to = -1;

         for (int i = 0; i < keys.length; i++) {
            if (Math.abs(keys[i][0] - enter) < 1.0E-4F) {
               from = i;
            }

            if (Math.abs(keys[i][0] - exit) < 1.0E-4F) {
               to = i;
            }
         }

         if (from >= 0 && to > from) {
            float[][] out = new float[to - from + 1][];

            for (int i = from; i <= to; i++) {
               out[i - from] = (float[])keys[i].clone();
               out[i - from][0] = (keys[i][0] - enter) / (exit - enter);
            }

            return out;
         } else {
            throw new IllegalArgumentException("a loop starts and ends on keys");
         }
      }
   }
}
