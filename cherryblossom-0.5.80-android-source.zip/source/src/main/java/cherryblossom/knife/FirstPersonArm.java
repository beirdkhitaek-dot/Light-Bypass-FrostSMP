package cherryblossom.knife;

import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerModelPart;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class FirstPersonArm {
   static final Vector3f FOREARM = new Vector3f(0.75F, -0.45F, 0.5F).normalize();
   static final float ELBOW = 0.6F;
   private static final Vector3f ARM_UP = new Vector3f(0.0F, 1.0F, 0.0F);
   private static final float ARM_SHOULDER = -0.625F;

   private FirstPersonArm() {
   }

   static FirstPersonArm.Arm arm() {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity player = mc.player;
      if (player != null && !player.isInvisible()) {
         if (mc.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerEntityRenderer<?> avatar) {
            SkinTextures skin = player.getSkin();
            return new FirstPersonArm.Arm(
               avatar,
               skin.body().texturePath(),
               player.isModelPartVisible(PlayerModelPart.RIGHT_SLEEVE),
               player.isModelPartVisible(PlayerModelPart.LEFT_SLEEVE),
               skin.model() == PlayerSkinType.SLIM
            );
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   static void place(MatrixStack pose, Vector3f hand, Vector3f elbow, boolean slim, Consumer<MatrixStack> draw) {
      Vector3f along = new Vector3f(hand).sub(elbow).normalize();
      Vector3f front = new Vector3f(ARM_UP).fma(-ARM_UP.dot(along), along).normalize();
      Vector3f side = new Vector3f(along).cross(front);
      pose.push();
      pose.translate(hand.x, hand.y, hand.z);
      pose.multiply(new Quaternionf().setFromNormalized(new Matrix3f(side, along, front)));
      drawPart(pose, slim, draw);
      pose.translate(0.0F, -0.625F, 0.0F);
      pose.scale(-1.0F, -3.0F, 1.0F);
      pose.translate(0.0F, 0.625F, 0.0F);
      drawPart(pose, slim, draw);
      pose.pop();
   }

   private static void drawPart(MatrixStack pose, boolean slim, Consumer<MatrixStack> draw) {
      pose.push();
      pose.translate(slim ? 0.03125F : 0.0625F, -0.5F, 0.0F);
      pose.multiply(RotationAxis.POSITIVE_Z.rotation(-0.1F));
      pose.translate(0.3125F, -0.125F, 0.0F);
      draw.accept(pose);
      pose.pop();
   }

   record Arm(PlayerEntityRenderer<?> renderer, Identifier texture, boolean rightSleeve, boolean leftSleeve, boolean slim) {
      void draw(MatrixStack pose, boolean left, OrderedRenderCommandQueue collector, int light) {
         if (left) {
            pose.scale(-1.0F, 1.0F, 1.0F);
            this.renderer.renderLeftArm(pose, collector, light, this.texture, this.leftSleeve);
         } else {
            this.renderer.renderRightArm(pose, collector, light, this.texture, this.rightSleeve);
         }
      }
   }
}
