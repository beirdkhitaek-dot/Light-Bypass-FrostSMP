package cherryblossom.knife;

import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

final class KnifeMaterial {
   static final int BLADE = 0;
   static final int BLADE_DARK = 1;
   static final int EDGE = 2;
   static final int HANDLE = 3;
   static final int HANDLE_DARK = 4;
   static final int METAL = 5;
   static final int ACCENT = 6;
   static final int WRAP = 7;
   static final int GOLD = 8;
   static final int FADE_0 = 9;
   static final int FADE_STEPS = 12;
   static final int BLACK = 21;
   static final int BLACK_DARK = 22;
   static final int PURPLE = 23;
   static final int RED = 24;
   private static final int[] FIXED = fixed();
   private static final KnifeMaterial DIAMOND = new KnifeMaterial(7340016, 4187087, 1941139, 13828087, 1780531, 989213, 12109772, 4187087, 1391168, 15253850);
   private static final KnifeMaterial NETHERITE = new KnifeMaterial(16742973, 6445663, 3813942, 11773356, 1709592, 920333, 7234665, 13715758, 3806228, 13213770);
   private static final KnifeMaterial IRON = new KnifeMaterial(16777215, 14277081, 10197915, 16777215, 4862754, 2825490, 9342606, 13158600, 2829099, 14267466);
   private static final KnifeMaterial GOLDEN = new KnifeMaterial(
      16769126, 16242762, 13015574, 16775096, 5905950, 3674128, 15188812, 16770688, 7216927, 15912795
   );
   private static final KnifeMaterial COPPER = new KnifeMaterial(16755319, 15043163, 11096108, 16763302, 3096378, 1844771, 6274975, 6274975, 2375738, 14263130);
   private static final KnifeMaterial STONE = new KnifeMaterial(14540253, 10263708, 6710886, 13158600, 4862754, 2825490, 8026746, 11053224, 3811868, 12558416);
   private static final KnifeMaterial WOOD = new KnifeMaterial(15782560, 12290902, 8279854, 14529402, 5914146, 3679763, 9071172, 13081442, 4861976, 13213770);
   final int[] palette;
   final int glow;

   private static int[] fixed() {
      int[][] stops = new int[][]{{74, 26, 120}, {154, 28, 88}, {200, 36, 60}, {224, 106, 36}, {242, 180, 28}};
      int[] out = new int[16];

      for (int i = 0; i < 12; i++) {
         float t = i / 11.0F * (stops.length - 1);
         int a = Math.min(stops.length - 2, (int)t);
         float f = t - a;
         int r = Math.round(stops[a][0] + (stops[a + 1][0] - stops[a][0]) * f);
         int g = Math.round(stops[a][1] + (stops[a + 1][1] - stops[a][1]) * f);
         int b = Math.round(stops[a][2] + (stops[a + 1][2] - stops[a][2]) * f);
         out[i] = 0xFF000000 | r << 16 | g << 8 | b;
      }

      out[12] = -14935010;
      out[13] = -16053491;
      out[14] = -9818960;
      out[15] = -3660740;
      return out;
   }

   private KnifeMaterial(int glow, int... palette) {
      this.glow = glow;
      this.palette = new int[palette.length + FIXED.length];

      for (int i = 0; i < palette.length; i++) {
         this.palette[i] = 0xFF000000 | palette[i];
      }

      System.arraycopy(FIXED, 0, this.palette, palette.length, FIXED.length);
   }

   static KnifeMaterial of(ItemStack stack) {
      return named(Registries.ITEM.getId(stack.getItem()).getPath());
   }

   static KnifeMaterial named(String path) {
      if (path.startsWith("netherite")) {
         return NETHERITE;
      } else if (path.startsWith("diamond")) {
         return DIAMOND;
      } else if (path.startsWith("golden")) {
         return GOLDEN;
      } else if (path.startsWith("copper")) {
         return COPPER;
      } else if (path.startsWith("stone")) {
         return STONE;
      } else {
         return path.startsWith("wooden") ? WOOD : IRON;
      }
   }

   static boolean fade(int m) {
      return m >= 9 && m < 21;
   }

   static boolean blade(int m) {
      return m == 0 || m == 1 || m == 2 || fade(m);
   }

   static boolean metallic(int m) {
      return blade(m) || m == 5 || m == 8;
   }
}
