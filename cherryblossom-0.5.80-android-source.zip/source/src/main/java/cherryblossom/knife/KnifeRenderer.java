package cherryblossom.knife;

import java.util.Arrays;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;
import org.joml.Vector3f;

public final class KnifeRenderer {
   private static final Identifier WHITE = Identifier.of("cherryblossom", "textures/misc/knife_white.png");
   public static final String[] KNIVES = KnifeSkin.NAMES;
   private static final float[] AT = new float[16];
   private static long inspectStart = -1L;
   private static long deployStart = -1L;
   private static boolean holding;
   private static boolean keyWasDown;
   private static boolean deployEnabled = true;
   private static Item lastItem;
   private static int lastSlot = -1;
   private static KnifeSkin lastSkin;
   private static final KnifeTrail TRAIL = new KnifeTrail();
   private static float[] trailEnds = new float[0];

   private KnifeRenderer() {
   }

   public static boolean isKnifeItem(ItemStack stack) {
      return stack.isIn(ItemTags.SWORDS);
   }

   public static void reset() {
      deployStart = -1L;
      inspectStart = -1L;
      keyWasDown = false;
      holding = false;
      lastItem = null;
      lastSlot = -1;
      lastSkin = null;
      TRAIL.clear();
   }

   public static void tick(boolean inspectDown, boolean deployOnEquip, boolean cancelOnSwing) {
      deployEnabled = deployOnEquip;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) {
         reset();
      } else {
         long now = System.nanoTime();
         ItemStack main = mc.player.getMainHandStack();
         int slot = mc.player.getInventory().getSelectedSlot();
         if (slot != lastSlot || main.getItem() != lastItem) {
            lastSlot = slot;
            lastItem = main.getItem();
            inspectStart = -1L;
            deployStart = deployOnEquip && isKnifeItem(main) ? now : -1L;
            TRAIL.clear();
         }

         holding = inspectDown;
         if (inspectDown && !keyWasDown && isKnifeItem(main) && deployStart < 0L && inspectStart < 0L) {
            inspectStart = now;
         }

         keyWasDown = inspectDown;
         if (cancelOnSwing && mc.player.handSwinging) {
            inspectStart = -1L;
         }
      }
   }

   public static boolean render(
      ItemStack stack,
      ItemDisplayContext context,
      MatrixStack pose,
      OrderedRenderCommandQueue collector,
      int light,
      float size,
      boolean matchMaterial,
      float offX,
      float offY,
      float offZ,
      int knife,
      float trailSeconds
   ) {
      boolean right = context == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
      final boolean left = context == ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
      if ((right || left) && isKnifeItem(stack)) {
         KnifeSkin skin = KnifeSkin.of(KNIVES[Math.max(0, Math.min(KNIVES.length - 1, knife - 1))]);
         if (skin == null) {
            return false;
         } else {
            long now = System.nanoTime();
            if (skin != lastSkin) {
               lastSkin = skin;
               inspectStart = -1L;
               deployStart = deployEnabled ? now : -1L;
               TRAIL.clear();
               trailEnds = new float[skin.streakCount() * 6];
            }

            MinecraftClient mc = MinecraftClient.getInstance();
            boolean animated = mc.player != null && stack == mc.player.getMainHandStack();
            if (animated) {
               sample(skin);
            } else {
               Arrays.fill(AT, 0.0F);
            }

            boolean moving = animated && (deployStart >= 0L || inspectStart >= 0L);
            boolean trailOn = trailSeconds > 0.0F;
            final FirstPersonArm.Arm arm = FirstPersonArm.arm();
            KnifeMaterial material = matchMaterial ? KnifeMaterial.of(stack) : KnifeMaterial.named("iron");
            final int[] palette = material.palette;
            final RenderLayer type = RenderLayers.entityCutoutNoCull(WHITE);
            KnifeSkin.Sink sink = new KnifeSkin.Sink() {
               @Override
               public void part(MatrixStack p, KnifeMesh mesh, KnifeMesh.Shine shine) {
                  collector.submitCustom(p, type, (last, buffer) -> mesh.emit(last, buffer, palette, light, shine));
               }

               @Override
               public void arm(MatrixStack p) {
                  if (arm != null) {
                     arm.draw(p, left, collector, light);
                  }
               }
            };
            pose.push();
            if (pose.peek().getPositionMatrix().getTranslation(new Vector3f()).length() < 0.3F) {
               pose.translate(left ? -0.56F : 0.56F, -0.52F, -0.72F);
            }

            pose.translate(left ? -offX : offX, offY, offZ);
            if (left) {
               pose.scale(-1.0F, 1.0F, 1.0F);
            }

            boolean record = trailOn && moving;
            skin.draw(pose, AT, 1.0F, arm != null && arm.slim(), size, sink, record ? trailEnds : null);
            if (record) {
               TRAIL.add(now, trailEnds);
            }

            if (animated) {
               if (!trailOn) {
                  TRAIL.clear();
               } else {
                  TRAIL.expire(now, trailSeconds);
                  float[] quads = TRAIL.build(now, trailSeconds, skin);
                  if (quads.length > 0) {
                     int rgb = material.glow;
                     collector.submitCustom(pose, RenderLayers.entityTranslucent(WHITE), (last, buffer) -> KnifeTrail.emit(last, buffer, quads, rgb));
                  }
               }
            }

            pose.pop();
            return true;
         }
      } else {
         return false;
      }
   }

   private static void sample(KnifeSkin skin) {
      long now = System.nanoTime();
      if (deployStart >= 0L) {
         float p = (float)(now - deployStart) / 1.0E9F / skin.deploy.seconds;
         if (p < 1.0F) {
            skin.deploy.sample(p, AT);
            return;
         }

         deployStart = -1L;
      }

      if (inspectStart >= 0L) {
         InspectAnimation.Clip clip = skin.inspect;
         float p = (float)(now - inspectStart) / 1.0E9F / clip.seconds;
         if (clip.loops() && holding && p >= clip.loopEnter) {
            p = clip.loopEnter + (p - clip.loopEnter) % (clip.loopExit - clip.loopEnter);
            inspectStart = now - (long)(p * clip.seconds * 1.0E9F);
         }

         if (p < 1.0F) {
            clip.sample(p, AT);
            return;
         }

         inspectStart = -1L;
      }

      Arrays.fill(AT, 0.0F);
   }
}
