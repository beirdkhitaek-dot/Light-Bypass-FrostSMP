import dev.cherryblossom.obfuscator.Main;
import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import javax.tools.ToolProvider;
import org.objectweb.asm.*;

public final class ObfuscatorTests {
    private static int checks;
    private static com.google.gson.JsonObject mapping;
    private static String mappedClass(String n){var v=mapping.getAsJsonObject("classes").get(n.replace('.','/'));return v==null?n:v.getAsString().replace('/','.');}
    private static Method mappedMethod(Class<?> c,String name,Class<?>... parameters)throws Exception{
        String owner="";for(var e:mapping.getAsJsonObject("classes").entrySet())if(e.getValue().getAsString().replace('/','.').equals(c.getName()))owner=e.getKey();
        for(Method method:c.getMethods()){
            String descriptor=java.lang.invoke.MethodType.methodType(method.getReturnType(),method.getParameterTypes()).descriptorString();
            var value=mapping.getAsJsonObject("methods").get(owner+"."+name+descriptor);
            if(method.getName().equals(value==null?name:value.getAsString())&&Arrays.equals(parameters,method.getParameterTypes()))return method;
        }throw new NoSuchMethodException(name);
    }
    private static void check(boolean value,String label){if(!value)throw new AssertionError(label);checks++;}
    private static void entry(ZipOutputStream zip,String name,byte[] bytes)throws IOException{zip.putNextEntry(new ZipEntry(name));zip.write(bytes);zip.closeEntry();}
    private static byte[] bytes(Path jar,String name)throws Exception{try(ZipFile file=new ZipFile(jar.toFile())){return file.getInputStream(file.getEntry(name)).readAllBytes();}}
    public static void main(String[] args)throws Exception {
        Path dir=Path.of(args[0]).toAbsolutePath();Files.createDirectories(dir);Path classes=dir.resolve("classes"),source=dir.resolve("Probe.java");Files.createDirectories(classes);
        Files.writeString(source,"""
            package cherryblossom.fixture;
            import java.lang.annotation.*;
            class Parent {public static String inherited(){return "inherited works";}}
            public final class Probe extends Parent {
                @Retention(RetentionPolicy.RUNTIME) public @interface Note {String value();}
                public record Point(String name,int x){}
                @Note("kept metadata") public static String text(){return concealedHelper();}
                private static String concealedHelper(){return "SENTINEL Sakura \\u0000 \\uD83C\\uDF38 \\u96EA";}
                public static String inheritedCall(){return Probe.inherited();}
                public static String empty(){return "";}
                public static Object[] numbers(){return new Object[]{-1,0,5,127,32767,Integer.MIN_VALUE,Integer.MAX_VALUE,Long.MIN_VALUE,Long.MAX_VALUE,-0.0f,Float.POSITIVE_INFINITY,Float.intBitsToFloat(0x7fc01234),-0.0d,Double.NEGATIVE_INFINITY,Double.longBitsToDouble(0x7ff8000000001234L)};}
                public static String branch(int n){try{return switch(n){case 1->"one";case 2->"two";default->throw new IllegalArgumentException("bad");};}catch(IllegalArgumentException e){return e.getMessage();}}
                public static String lambda(){java.util.function.Supplier<String> s=()->"lambda works";return s.get();}
                public static String record(){return new Point("Sakura",9).toString();}
            }
            """);
        check(ToolProvider.getSystemJavaCompiler().run(null,null,null,"--release","21","-g","-d",classes.toString(),source.toString())==0,"Fixture compiles");
        ClassWriter mixin=new ClassWriter(0);mixin.visit(Opcodes.V21,Opcodes.ACC_PUBLIC,"cherryblossom/mixin/Keep",null,"java/lang/Object",null);mixin.visitEnd();byte[] mixinBytes=mixin.toByteArray();
        ClassWriter large=new ClassWriter(ClassWriter.COMPUTE_MAXS);large.visit(Opcodes.V21,Opcodes.ACC_PUBLIC,"cherryblossom/fixture/Large",null,"java/lang/Object",null);var method=large.visitMethod(Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC,"big","()I",null,null);method.visitCode();for(int i=0;i<4000;i++){method.visitInsn(Opcodes.ICONST_0);method.visitInsn(Opcodes.POP);}method.visitInsn(Opcodes.ICONST_1);method.visitInsn(Opcodes.IRETURN);method.visitMaxs(0,0);method.visitEnd();large.visitEnd();
        Path input=dir.resolve("input.jar"),output=dir.resolve("output.jar");
        try(var zip=new ZipOutputStream(Files.newOutputStream(input))){
            try(var files=Files.walk(classes)){for(Path path:files.filter(Files::isRegularFile).toList())entry(zip,classes.relativize(path).toString().replace('\\','/'),Files.readAllBytes(path));}
            entry(zip,"cherryblossom/mixin/Keep.class",mixinBytes);entry(zip,"cherryblossom/fixture/Large.class",large.toByteArray());entry(zip,"LICENSE.txt","Fixture notice must remain".getBytes(StandardCharsets.UTF_8));entry(zip,"fabric.mod.json","{\"entrypoints\":{}}".getBytes(StandardCharsets.UTF_8));
        }
        byte[] hash=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(input));Main.protect(input,output);
        check(Arrays.equals(hash,MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(input))),"Original input remains unchanged");
        check(Arrays.equals(bytes(input,"LICENSE.txt"),bytes(output,"LICENSE.txt")),"Notices unchanged");
        check(Arrays.equals(bytes(input,"fabric.mod.json"),bytes(output,"fabric.mod.json")),"Fabric metadata unchanged");
        check(Arrays.equals(mixinBytes,bytes(output,"cherryblossom/mixin/Keep.class")),"Mixin class is byte-for-byte unchanged");
        mapping=com.google.gson.JsonParser.parseString(Files.readString(Path.of(output+".mapping.json"))).getAsJsonObject();
        check(!mappedClass("cherryblossom.fixture.Probe").equals("cherryblossom.fixture.Probe"),"Public class renamed");
        byte[] transformed=bytes(output,mappedClass("cherryblossom.fixture.Probe").replace('.','/')+".class");
        check(!new String(transformed,StandardCharsets.ISO_8859_1).contains("SENTINEL"),"Plaintext method literal removed from constant pool");
        check(!new String(transformed,StandardCharsets.ISO_8859_1).contains("Probe.java"),"Debug source name removed");
        check(new String(bytes(output,Main.REPORT),StandardCharsets.UTF_8).contains(mappedClass("cherryblossom.fixture.Large").replace('.','/')+"."),"Oversized-method exclusion is reported");
        try(var loader=new URLClassLoader(new URL[]{output.toUri().toURL()},ClassLoader.getPlatformClassLoader())){
            Class<?> probe=loader.loadClass(mappedClass("cherryblossom.fixture.Probe"));String expected="SENTINEL Sakura \u0000 \uD83C\uDF38 \u96EA";
            check(mappedMethod(probe,"text").invoke(null)==expected,"Unicode, NUL and JVM literal interning preserved");
            check(Arrays.stream(probe.getDeclaredMethods()).noneMatch(m->m.getName().equals("concealedHelper")),"Private helper renamed while its call site still works");
            check(mappedMethod(probe,"inheritedCall").invoke(null).equals("inherited works"),"Inherited static method owners are remapped correctly");
            check(mappedMethod(probe,"empty").invoke(null).equals(""),"Empty literal preserved");
            Object[] values=(Object[])mappedMethod(probe,"numbers").invoke(null);Object[] expectedNumbers={-1,0,5,127,32767,Integer.MIN_VALUE,Integer.MAX_VALUE,Long.MIN_VALUE,Long.MAX_VALUE,-0.0f,Float.POSITIVE_INFINITY,Float.intBitsToFloat(0x7fc01234),-0.0d,Double.NEGATIVE_INFINITY,Double.longBitsToDouble(0x7ff8000000001234L)};
            for(int i=0;i<values.length;i++)check(values[i].equals(expectedNumbers[i]),"Numeric constant "+i);
            check(Float.floatToRawIntBits((Float)values[11])==0x7fc01234,"Float NaN payload retained");
            check(Double.doubleToRawLongBits((Double)values[14])==0x7ff8000000001234L,"Double NaN payload retained");
            check(mappedMethod(probe,"branch",int.class).invoke(null,1).equals("one")&&mappedMethod(probe,"branch",int.class).invoke(null,0).equals("bad"),"Switch and catch frames execute");
            check(mappedMethod(probe,"lambda").invoke(null).equals("lambda works"),"Lambda bootstrap retained");
            check(mappedMethod(probe,"record").invoke(null).equals("Point[name=Sakura, x=9]"),"Record behavior retained");
            var annotation=mappedMethod(probe,"text").getAnnotations()[0];check(annotation.annotationType().getMethod("value").invoke(annotation).equals("kept metadata"),"Runtime annotations retained");
            check(mappedMethod(loader.loadClass(mappedClass("cherryblossom.fixture.Large")),"big").invoke(null).equals(1),"Excluded large method still executes");
            Method encode=Main.class.getDeclaredMethod("encode",String.class);encode.setAccessible(true);Method decode=loader.loadClass("cherryblossom.obfuscation.Literals").getMethod("text",String.class);
            Random random=new Random(310);for(int test=0;test<1000;test++){char[] chars=new char[1+random.nextInt(100)];for(int i=0;i<chars.length;i++)chars[i]=(char)random.nextInt(65536);String value=new String(chars);check(decode.invoke(null,encode.invoke(null,value)).equals(value),"UTF-16 roundtrip "+test);}
        }
        try{Main.protect(input,input);throw new AssertionError("Same path accepted");}catch(IOException expected){checks++;}
        try{Main.protect(output,dir.resolve("twice.jar"));throw new AssertionError("Double obfuscation accepted");}catch(IOException expected){checks++;}
        check(!Files.exists(dir.resolve("twice.jar")),"Rejected transform writes no output");
        Path signed=dir.resolve("signed.jar");try(var zip=new ZipOutputStream(Files.newOutputStream(signed))){entry(zip,"META-INF/test.SF",new byte[]{1});}
        try{Main.protect(signed,dir.resolve("signed-output.jar"));throw new AssertionError("Signed input accepted");}catch(IOException expected){checks++;}
        check(!Files.exists(dir.resolve("signed-output.jar")),"Signed-input rejection writes no output");
        Path unsafe=dir.resolve("unsafe.jar");try(var zip=new ZipOutputStream(Files.newOutputStream(unsafe))){entry(zip,"../escape",new byte[]{1});}
        try{Main.protect(unsafe,dir.resolve("unsafe-output.jar"));throw new AssertionError("Unsafe entry accepted");}catch(IOException expected){checks++;}
        check(!Files.exists(dir.resolve("unsafe-output.jar")),"Unsafe-entry rejection writes no output");
        Main.protect(input,dir.resolve("second.jar"));check(!Arrays.equals(Files.readAllBytes(output),Files.readAllBytes(dir.resolve("second.jar"))),"Independent runs randomize output");
        System.out.println("PASS: "+checks+" obfuscator checks.");
    }
}

