CherryBlossom Obfuscator 2.0 - Java 21

Run: java -jar CherryBlossomObfuscator-2.0.jar input.jar output.jar
Build: powershell -ExecutionPolicy Bypass -File tools/BuildObfuscator.ps1
Client builds: build.ps1 -Protect (add -Trial for the trial edition).
Use an unsigned, unprotected input. Input/output must differ. Already protected,
signed and unsafe archives are rejected. Each run uses independent random names.

Protection
- Broad class renaming within the existing packages, including records and enums.
- Private and static helper method renaming, including lambda bodies; typed call
  sites and method handles are updated together, including inherited static calls.
- Exact reflective class-name literals are remapped. Literal method names used by
  reflection, annotated callbacks and the compatibility keep list are retained.
- Nonempty method strings are masked with salted UTF-16/Base64 payloads, decoded
  and interned by a cached runtime helper.
- Integer/long XOR masks; float/double original bit patterns are preserved.
- Debug source/line/local names are stripped from transformed implementations.

Compatibility
Fabric entrypoints, mixin class names and integration APIs remain named. Field
names, serialization hooks, annotated method names and external dependencies are
preserved. Original resource/license bytes remain unchanged. Package names stay
intact to preserve Java package access. Large methods use a reported conservative
fallback. Annotation values and bootstrap recipes can still contain readable text.
META-INF/cherryblossom-obfuscator.json records protection counts and exclusions.

An external output.jar.mapping.json is generated for local crash recovery and
isolated verifier adaptation. Do not distribute this mapping with the client.
The mapping is never inserted into the production JAR. The separate verifier mod
uses it without rewriting or bypassing production code.

Limits
Java remains decompilable, including in RATScanner. This adds resistance to casual
copying; it cannot guarantee secrecy or prevent reverse engineering. Some public
APIs remain recognizable and decoded strings exist in memory. No scanner evasion,
anti-debugging, extra launcher or protection server is introduced by this tool.

Tests
javac --release 21 -proc:none -encoding UTF-8 -cp "dist/CherryBlossomObfuscator-2.0.jar;build/deps/*" -d build/obfuscator-test obfuscator/test/ObfuscatorTests.java
java -Xverify:all -cp "build/obfuscator-test;dist/CherryBlossomObfuscator-2.0.jar;build/deps/*" ObfuscatorTests build/obfuscator-fixtures-v2
1043 checks cover Unicode/NUL/interning, 1000 UTF-16 round trips, numeric edge
cases, annotations, records, lambdas, inherited statics, switch/catch frames,
resources, fallbacks, input preservation, rejection and output randomization.

ASM's required BSD notice is bundled in LICENSE-ASM.txt and in the tool JAR.
Source: https://asm.ow2.io/license.html
