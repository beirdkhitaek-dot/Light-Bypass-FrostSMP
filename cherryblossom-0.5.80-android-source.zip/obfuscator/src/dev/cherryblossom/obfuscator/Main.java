package dev.cherryblossom.obfuscator;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.commons.ClassRemapper;
import org.objectweb.asm.commons.Remapper;

/** Independent, conservative Fabric-client bytecode obfuscator; Java 21 CLI. */
public final class Main {
    public static final String REPORT="META-INF/cherryblossom-obfuscator.json";
    private static final String HELPER="cherryblossom/obfuscation/Literals";
    private static final SecureRandom RANDOM=new SecureRandom();
    private static final class Counts {int classes,strings,numbers,methods;final List<String> skipped=new ArrayList<>();}
    private Main(){}
    public static void main(String[] args)throws Exception {
        if(args.length!=2){System.err.println("Usage: java -jar CherryBlossomObfuscator-2.0.jar input.jar output.jar");System.exit(2);}
        protect(Path.of(args[0]),Path.of(args[1]));
    }
    public static void protect(Path input,Path output)throws IOException {
        input=input.toRealPath();output=output.toAbsolutePath().normalize();
        if(input.equals(output)||Files.exists(output)&&Files.isSameFile(input,output))throw new IOException("Input and output must be different files");
        var entries=new LinkedHashMap<String,byte[]>();
        try(ZipFile jar=new ZipFile(input.toFile())){
            for(ZipEntry entry:Collections.list(jar.entries()))if(!entry.isDirectory()){
                String name=entry.getName();
                if(name.startsWith("/")||Arrays.asList(name.split("/")).contains(".."))throw new IOException("Unsafe archive entry");
                if(name.matches("(?i)META-INF/[^/]+\\.(SF|RSA|DSA|EC)"))throw new IOException("Signed input is unsupported; use the unsigned client build");
                if(entries.putIfAbsent(name,jar.getInputStream(entry).readAllBytes())!=null)throw new IOException("Duplicate entry: "+name);
            }
        }
        if(entries.containsKey(REPORT)||entries.containsKey(HELPER+".class")||entries.containsKey("META-INF/cherryblossom-qprotect.txt"))
            throw new IOException("Input is already protected. Start with the unprotected client JAR");
        Counts total=new Counts();
        Map<String,String> classes=classNames(entries);
        Map<String,String> renamed=privateMethodNames(entries);
        Map<String,ClassNode> hierarchy=new HashMap<>();
        for(var entry:entries.entrySet())if(entry.getKey().endsWith(".class")){var node=new ClassNode();new ClassReader(entry.getValue()).accept(node,ClassReader.SKIP_CODE|ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);hierarchy.put(node.name,node);}
        total.methods=renamed.size();
        Remapper names=new Remapper(){
            @Override public String map(String name){return classes.getOrDefault(name,name);}
            @Override public String mapMethodName(String owner,String name,String descriptor){
                // javac may reference an inherited static method through its subclass.
                Set<String> visited=new HashSet<>();
                while(owner!=null&&visited.add(owner)){
                    String replacement=renamed.get(owner+"."+name+descriptor);if(replacement!=null)return replacement;
                    var node=hierarchy.get(owner);if(node==null)return name;
                    for(var method:node.methods)if(method.name.equals(name)&&method.desc.equals(descriptor))return name;
                    owner=node.superName;
                }return name;
            }
            @Override public Object mapValue(Object value){
                if(value instanceof String text){String internal=text.replace('.','/');if(classes.containsKey(internal))return text.indexOf('/')>=0?classes.get(internal):classes.get(internal).replace('/','.');}
                return super.mapValue(value);
            }
        };
        var protectedEntries=new LinkedHashMap<String,byte[]>();
        for(var entry:entries.entrySet()){
            String path=entry.getKey();
            if(!path.endsWith(".class")){protectedEntries.put(path,entry.getValue());continue;}
            ClassNode remapped=new ClassNode();new ClassReader(entry.getValue()).accept(new ClassRemapper(remapped,names),0);
            ClassWriter writer=new ClassWriter(0);remapped.accept(writer);
            boolean owned=(path.startsWith("cherryblossom/")||path.startsWith("dev/cherryblossom/"))&&!path.contains("/mixin/")&&!path.contains("/mixins/");
            protectedEntries.put(names.map(path.substring(0,path.length()-6))+".class",owned?transform(writer.toByteArray(),total):writer.toByteArray());
        }
        entries=protectedEntries;
        if(total.classes==0)throw new IOException("No CherryBlossom classes found");
        try(InputStream helper=Main.class.getResourceAsStream("/"+HELPER+".class")){
            if(helper==null)throw new IOException("Obfuscator runtime helper is missing");entries.put(HELPER+".class",helper.readAllBytes());
        }
        String report="{\"tool\":\"CherryBlossom Obfuscator\",\"version\":\"2.0\",\"classes\":"+total.classes+",\"classesRenamed\":"+classes.size()+",\"strings\":"+total.strings+",\"numbers\":"+total.numbers+",\"methodsRenamed\":"+total.methods+",\"skipped\":["+
            String.join(",",total.skipped.stream().map(s->"\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"").toList())+"]}\n";
        entries.put(REPORT,report.getBytes(StandardCharsets.UTF_8));
        Files.createDirectories(output.getParent());Path temporary=Files.createTempFile(output.getParent(),"cherry-obfuscator-",".tmp");
        try{
            try(ZipOutputStream jar=new ZipOutputStream(Files.newOutputStream(temporary))){
                jar.setLevel(9);
                for(var entry:entries.entrySet()){
                    ZipEntry name=new ZipEntry(entry.getKey());name.setTime(0);jar.putNextEntry(name);jar.write(entry.getValue());jar.closeEntry();
                }
            }
            try{Files.move(temporary,output,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException ignored){Files.move(temporary,output,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(temporary);}
        // Recovery/testing map is a separate local file and is never inserted in the client.
        writeMapping(output.resolveSibling(output.getFileName()+".mapping.json"),input,classes,renamed,names);
        System.out.println("CherryBlossom Obfuscator 2.0: "+total.classes+" classes protected, "+classes.size()+" classes renamed, "+total.strings+" strings, "+total.numbers+" numbers, "+total.methods+" methods renamed; "+total.skipped.size()+" conservative exclusions.");
        System.out.println("Output: "+output);
    }
    private static Map<String,String> classNames(Map<String,byte[]> entries){
        Map<String,String> result=new LinkedHashMap<>();Set<String> taken=new HashSet<>(entries.keySet());
        for(String path:entries.keySet()){
            if(!path.endsWith(".class")||!(path.startsWith("cherryblossom/")||path.startsWith("dev/cherryblossom/"))||path.contains("/mixin/")||path.contains("/mixins/")||path.startsWith("cherryblossom/integration/")||path.startsWith("cherryblossom/obfuscation/"))continue;
            String name=path.substring(0,path.length()-6);
            if(name.equals("cherryblossom/Main")||name.startsWith("cherryblossom/Main$")||name.equals("cherryblossom/CherryBlossom")||name.startsWith("cherryblossom/CherryBlossom$")||name.equals("dev/cherryblossom/client/CherryBlossomClient")||name.startsWith("dev/cherryblossom/client/CherryBlossomClient$"))continue;
            String replacement;do{replacement=name.substring(0,name.lastIndexOf('/')+1)+"C"+Long.toUnsignedString(RANDOM.nextLong(),36);}while(!taken.add(replacement+".class"));
            result.put(name,replacement);
        }
        return result;
    }
    private static String quote(String value){return "\""+value.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    private static void writeMapping(Path path,Path source,Map<String,String> classes,Map<String,String> methods,Remapper mapper)throws IOException{
        StringBuilder out=new StringBuilder("{\"sourceJar\":"+quote(source.toString())+",\"classes\":{");boolean first=true;
        for(var e:classes.entrySet()){if(!first)out.append(',');first=false;out.append(quote(e.getKey())).append(':').append(quote(e.getValue()));}
        out.append("},\"methods\":{");first=true;
        for(var e:methods.entrySet()){if(!first)out.append(',');first=false;out.append(quote(e.getKey())).append(':').append(quote(e.getValue()));}
        out.append("},\"methodReverse\":{");first=true;
        for(var e:methods.entrySet()){
            int dot=e.getKey().lastIndexOf('.',e.getKey().indexOf('(')),paren=e.getKey().indexOf('(');String owner=e.getKey().substring(0,dot),name=e.getKey().substring(dot+1,paren),desc=e.getKey().substring(paren);
            if(!first)out.append(',');first=false;out.append(quote(mapper.map(owner)+"."+e.getValue()+mapper.mapMethodDesc(desc))).append(':').append(quote(name));
        }
        out.append("}}\n");Files.writeString(path,out,StandardCharsets.UTF_8);
    }
    private static Map<String,String> privateMethodNames(Map<String,byte[]> entries)throws IOException {
        Set<String> keep=new HashSet<>(List.of("readObject","writeObject","readObjectNoData","readResolve","writeReplace","main","values","valueOf"));
        try(InputStream input=Main.class.getResourceAsStream("/META-INF/cherryblossom-keep-methods.txt")){
            if(input!=null)keep.addAll(new String(input.readAllBytes(),StandardCharsets.UTF_8).lines().toList());
        }
        List<ClassNode> owned=new ArrayList<>();
        for(var entry:entries.entrySet())if(entry.getKey().endsWith(".class")){
            ClassNode node=new ClassNode();new ClassReader(entry.getValue()).accept(node,0);
            boolean eligible=(node.name.startsWith("cherryblossom/")||node.name.startsWith("dev/cherryblossom/"))&&!node.name.contains("/mixin/")&&!node.name.contains("/mixins/")&&(node.access&(Opcodes.ACC_INTERFACE|Opcodes.ACC_ANNOTATION))==0;
            if(eligible)owned.add(node);
            for(FieldNode field:node.fields)if(field.value instanceof String value)keep.add(value);
            for(MethodNode method:node.methods)for(AbstractInsnNode instruction:method.instructions){
                if(instruction instanceof LdcInsnNode ldc&&ldc.cst instanceof String value)keep.add(value);
                if(!eligible&&instruction instanceof MethodInsnNode call)keep.add(call.name);
                if(instruction instanceof InvokeDynamicInsnNode dynamic)for(Object value:dynamic.bsmArgs){if(value instanceof String text)keep.add(text);if(!eligible&&value instanceof Handle handle)keep.add(handle.getName());}
            }
        }
        Map<String,String> result=new HashMap<>();
        for(ClassNode node:owned){Set<String> taken=new HashSet<>();for(MethodNode method:node.methods)taken.add(method.name);
            for(MethodNode method:node.methods){
                if((method.access&(Opcodes.ACC_PRIVATE|Opcodes.ACC_STATIC))==0||(method.access&Opcodes.ACC_NATIVE)!=0||(node.access&Opcodes.ACC_ENUM)!=0||node.name.startsWith("cherryblossom/integration/")||(node.name.equals("dev/cherryblossom/client/CherryBlossomClient"))||method.name.length()<4||method.name.startsWith("<")||method.name.equals("$deserializeLambda$")||keep.contains(method.name)||method.visibleAnnotations!=null||method.invisibleAnnotations!=null)continue;
                String replacement;do{replacement="m"+Long.toUnsignedString(RANDOM.nextLong(),36);}while(!taken.add(replacement));
                result.put(node.name+"."+method.name+method.desc,replacement);
            }
        }
        return result;
    }
    private static byte[] transform(byte[] original,Counts total){
        Set<String> excluded=new HashSet<>();
        while(true){
            ClassNode node=new ClassNode();new ClassReader(original).accept(node,0);
            if((node.access&(Opcodes.ACC_INTERFACE|Opcodes.ACC_ANNOTATION))!=0)return original;
            Counts attempt=new Counts();node.sourceFile=null;node.sourceDebug=null;
            for(MethodNode method:node.methods){
                String id=method.name+method.desc;
                method.localVariables=null;method.parameters=null;
                boolean skip=excluded.contains(id)||method.instructions.size()>3500;
                if(skip)attempt.skipped.add(node.name+"."+id);
                for(AbstractInsnNode instruction:method.instructions.toArray()){
                    if(instruction instanceof LineNumberNode){method.instructions.remove(instruction);continue;}
                    if(skip)continue;
                    if(instruction instanceof LdcInsnNode ldc&&ldc.cst instanceof String value){
                        if(value.isEmpty()||value.length()>20000)continue;
                        InsnList replacement=new InsnList();replacement.add(new LdcInsnNode(encode(value)));
                        replacement.add(new MethodInsnNode(Opcodes.INVOKESTATIC,HELPER,"text","(Ljava/lang/String;)Ljava/lang/String;",false));
                        method.instructions.insertBefore(instruction,replacement);method.instructions.remove(instruction);attempt.strings++;continue;
                    }
                    Object number=number(instruction);if(number==null)continue;
                    InsnList replacement=new InsnList();
                    if(number instanceof Integer value)integer(replacement,value);
                    else if(number instanceof Long value)longNumber(replacement,value);
                    else if(number instanceof Float value){integer(replacement,Float.floatToRawIntBits(value));replacement.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"java/lang/Float","intBitsToFloat","(I)F",false));}
                    else if(number instanceof Double value){longNumber(replacement,Double.doubleToRawLongBits(value));replacement.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"java/lang/Double","longBitsToDouble","(J)D",false));}
                    method.instructions.insertBefore(instruction,replacement);method.instructions.remove(instruction);attempt.numbers++;
                }
            }
            try{
                // Every replacement has the same final stack type and no branches. Original frames stay valid.
                ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);node.accept(writer);byte[] result=writer.toByteArray();
                total.classes++;total.strings+=attempt.strings;total.numbers+=attempt.numbers;total.skipped.addAll(attempt.skipped);return result;
            }catch(MethodTooLargeException limit){
                if(!excluded.add(limit.getMethodName()+limit.getDescriptor()))throw limit;
            }catch(ClassTooLargeException limit){total.skipped.add(node.name+" (constant pool limit)");return original;}
        }
    }
    private static Object number(AbstractInsnNode instruction){
        int op=instruction.getOpcode();
        if(instruction instanceof LdcInsnNode ldc&&(ldc.cst instanceof Integer||ldc.cst instanceof Long||ldc.cst instanceof Float||ldc.cst instanceof Double))return ldc.cst;
        if(instruction instanceof IntInsnNode value&&(op==Opcodes.BIPUSH||op==Opcodes.SIPUSH))return value.operand;
        if(op>=Opcodes.ICONST_M1&&op<=Opcodes.ICONST_5)return op-Opcodes.ICONST_0;
        if(op>=Opcodes.LCONST_0&&op<=Opcodes.LCONST_1)return (long)(op-Opcodes.LCONST_0);
        if(op>=Opcodes.FCONST_0&&op<=Opcodes.FCONST_2)return (float)(op-Opcodes.FCONST_0);
        if(op>=Opcodes.DCONST_0&&op<=Opcodes.DCONST_1)return (double)(op-Opcodes.DCONST_0);
        return null;
    }
    private static void integer(InsnList out,int value){int mask=RANDOM.nextInt();out.add(new LdcInsnNode(value^mask));out.add(new LdcInsnNode(mask));out.add(new InsnNode(Opcodes.IXOR));}
    private static void longNumber(InsnList out,long value){long mask=RANDOM.nextLong();out.add(new LdcInsnNode(value^mask));out.add(new LdcInsnNode(mask));out.add(new InsnNode(Opcodes.LXOR));}
    private static String encode(String value){
        byte[] bytes=new byte[4+value.length()*2];int state;do{state=RANDOM.nextInt();}while(state==0);
        bytes[0]=(byte)(state>>>24);bytes[1]=(byte)(state>>>16);bytes[2]=(byte)(state>>>8);bytes[3]=(byte)state;
        for(int i=0;i<value.length();i++){
            state=step(state);bytes[4+i*2]=(byte)((value.charAt(i)>>>8)^state);
            state=step(state);bytes[5+i*2]=(byte)(value.charAt(i)^state);
        }
        return Base64.getEncoder().encodeToString(bytes);
    }
    private static int step(int state){state^=state<<13;state^=state>>>17;return state^(state<<5);}
}
