package cherryblossom.obfuscation;

import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;

/** Injected into the client. Cached decoding keeps repeated UI literals inexpensive. */
public final class Literals {
    private static final ConcurrentHashMap<String,String> CACHE=new ConcurrentHashMap<>();
    private Literals(){}
    public static String text(String encoded){
        String cached=CACHE.get(encoded);if(cached!=null)return cached;
        byte[] bytes=Base64.getDecoder().decode(encoded);
        int state=(bytes[0]&255)<<24|(bytes[1]&255)<<16|(bytes[2]&255)<<8|bytes[3]&255;
        char[] value=new char[(bytes.length-4)/2];
        for(int i=4;i<bytes.length;i+=2){
            state=step(state);int high=(bytes[i]^state)&255;
            state=step(state);int low=(bytes[i+1]^state)&255;
            value[(i-4)/2]=(char)(high<<8|low);
        }
        String decoded=new String(value).intern();String previous=CACHE.putIfAbsent(encoded,decoded);
        return previous==null?decoded:previous;
    }
    private static int step(int state){state^=state<<13;state^=state>>>17;return state^(state<<5);}
}
