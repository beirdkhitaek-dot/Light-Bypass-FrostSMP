package com.vrzt.zinc.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.vrzt.zinc.modules.Render.Capes;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin {
   @ModifyExpressionValue(
      method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/SkinTextures;cape()Lnet/minecraft/util/AssetInfo$TextureAsset;")
   )
   private AssetInfo.TextureAsset zinc$modifyCape(AssetInfo.TextureAsset original, MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state, float f, float g) {
      if (Capes.capeed == null) {
         return original;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      // Only replace the cape on the local player.
      if (mc.player != null && state.name != null && state.name.equals(mc.getSession().getUsername())) {
         Identifier id = Identifier.of("zinc", "textures/capes/" + Capes.capeed + ".png");
         return new AssetInfo.TextureAssetInfo(id, id);
      }
      return original;
   }
}
