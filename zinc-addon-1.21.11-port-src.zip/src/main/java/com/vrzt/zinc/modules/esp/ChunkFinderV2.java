package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.text.Text;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.Properties;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.entity.passive.TraderLlamaEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.util.math.Direction.Axis;

public class ChunkFinderV2 extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> showCoords = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("show-coordinates")).description("Show coordinates in chat and notifications")).defaultValue(true))
            .build()
      );
   private final Setting<Integer> renderDistance = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("render-distance"))
                  .description("Hide detections further than this distance."))
               .defaultValue(512))
            .min(32)
            .sliderMax(2048)
            .build()
      );
   private final Setting<ChunkFinderV2.HoleMode> holeMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("hole-detection"))
                  .description("Detect chunks with or without holes"))
               .defaultValue(ChunkFinderV2.HoleMode.Both))
            .build()
      );
   private final Setting<SettingColor> chunkColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("chunk-color"))
               .description("Color of detected chunks"))
            .defaultValue(new SettingColor(0, 255, 255, 100))
            .build()
      );
   private final Setting<Boolean> showTracers = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("show-tracers")).description("Draw tracers to detected chunks")).defaultValue(false)).build());
   private final Setting<Integer> holeCheckRadius = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("hole-check-radius"))
                     .description("Blocks radius to check for holes"))
                  .defaultValue(8))
               .min(0)
               .max(64)
               .visible(() -> this.holeMode.get() == ChunkFinderV2.HoleMode.Without_Holes))
            .build()
      );
   private static final int MIN_VINE_LENGTH = 20;
   private static final int MIN_KELP_LENGTH = 20;
   private static final int ROTATED_DEEPSLATE_THRESHOLD = 5;
   private static final int ENTITY_MAX_DISTANCE = 256;
   private static final int MIN_Y_LEVEL = 16;
   private final Map<ChunkPos, ChunkFinderV2.DetectionInfo> detectedChunks = new ConcurrentHashMap<>();
   private final Set<ChunkPos> chunksWithBrokenBlocks = ConcurrentHashMap.newKeySet();
   private final Set<Integer> detectedEntities = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;

   public ChunkFinderV2() {
      super(ZincAddon.esp, "chunk-finder-v2", "Detects suspicious chunks via unnatural blocks and player-only entities.");
   }

   public void onActivate() {
      this.clearData();
      this.threadPool = Executors.newFixedThreadPool(2);
      if (this.mc.world != null) {
         for (Chunk chunk : Utils.chunks()) {
            if (chunk instanceof WorldChunk worldChunk) {
               this.threadPool.submit(() -> this.scanChunk(worldChunk));
            }
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
      }

      this.clearData();
   }

   private void clearData() {
      this.detectedChunks.clear();
      this.chunksWithBrokenBlocks.clear();
      this.detectedEntities.clear();
      this.scannedChunks.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (event.pos.getY() > 16) {
         if (event.newState.isAir()) {
            ChunkPos cp = new ChunkPos(event.pos);
            if (this.detectedChunks.containsKey(cp)) {
               this.chunksWithBrokenBlocks.add(cp);
            }
         }

         if (this.threadPool != null && !this.threadPool.isShutdown()) {
            this.threadPool.submit(() -> {
               BlockState state = event.newState;
               if (state.isOf(Blocks.field_10597)) {
                  this.checkVine(event.pos);
               }

               if (state.isOf(Blocks.field_9993) || state.isOf(Blocks.field_10463)) {
                  this.checkKelp(event.pos);
               }

               if (state.isOf(Blocks.field_28888)) {
                  this.checkRotatedDeepslate(event.pos);
               }
            });
         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.checkEntities();
         Color sideColor = (Color)this.chunkColor.get();
         Color lineColor = new Color(sideColor).a(255);

         for (Entry<ChunkPos, ChunkFinderV2.DetectionInfo> entry : this.detectedChunks.entrySet()) {
            ChunkPos cp = entry.getKey();
            BlockPos pos = entry.getValue().position;
            double distSq = PlayerUtils.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (!(distSq > Math.pow(((Integer)this.renderDistance.get()).intValue(), 2.0))) {
               double x1 = cp.getStartX();
               double z1 = cp.getStartZ();
               double y = pos.getY();
               event.renderer.box(x1, y, z1, x1 + 16.0, y + 0.3, z1 + 16.0, sideColor, lineColor, ShapeMode.Both, 0);
               if ((Boolean)this.showTracers.get() && !this.chunksWithBrokenBlocks.contains(cp)) {
                  event.renderer
                     .line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z, x1 + 8.0, y + 0.15, z1 + 8.0, lineColor);
               }
            }
         }
      }
   }

   private void addDetection(BlockPos pos) {
      if (pos.getY() > 16) {
         ChunkPos chunkPos = new ChunkPos(pos);
         if (this.holeMode.get() != ChunkFinderV2.HoleMode.Without_Holes || !this.chunkHasHoles(chunkPos)) {
            for (ChunkPos existing : this.detectedChunks.keySet()) {
               if (Math.abs(existing.x - chunkPos.x) <= 2 && Math.abs(existing.z - chunkPos.z) <= 2) {
                  return;
               }
            }

            this.detectedChunks.put(chunkPos, new ChunkFinderV2.DetectionInfo(pos, System.currentTimeMillis()));
            this.mc.execute(() -> {
               if (this.mc.world != null && this.mc.player != null) {
                  this.mc.world.playSound(this.mc.player, pos, SoundEvents.field_14627, SoundCategory.field_15256, 1.0F, 1.0F);
               }
            });
            if ((Boolean)this.showCoords.get()) {
               this.info("Detected suspicious chunk at X: %d, Z: %d", new Object[]{pos.getX(), pos.getZ()});
               this.mc
                  .getToastManager()
                  .add(
                     new ChunkFinderV2.CustomChunkToast(
                        new ItemStack(Items.CHEST),
                        Text.of("ChunkFinderV2"),
                        Text.of("X: " + pos.getX() + " Z: " + pos.getZ())
                     )
                  );
            }
         }
      }
   }

   private void checkEntities() {
      if (this.mc.world != null && this.mc.player != null) {
         for (Entity entity : this.mc.world.getEntities()) {
            if (entity.getBlockPos().getY() > 16) {
               boolean isSuspicious = entity instanceof VillagerEntity
                  || entity instanceof PillagerEntity
                  || entity instanceof WanderingTraderEntity
                  || entity instanceof TraderLlamaEntity;
               if (isSuspicious && this.mc.player.distanceTo(entity) <= 256.0F && this.detectedEntities.add(entity.getId())) {
                  this.addDetection(entity.getBlockPos());
               }
            }
         }
      }
   }

   private void scanChunk(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();
      if (this.scannedChunks.add(cpos)) {
         this.scanChunkForVines(chunk);
         this.scanChunkForKelp(chunk);
         this.scanChunkForRotatedDeepslate(chunk);
      }
   }

   private void scanChunkForRotatedDeepslate(WorldChunk chunk) {
      int rotatedCount = 0;
      BlockPos firstFound = null;
      ChunkPos cPos = chunk.getPos();

      for (int x = cPos.getStartX(); x < cPos.getEndX(); x++) {
         for (int z = cPos.getStartZ(); z < cPos.getEndZ(); z++) {
            for (int y = 17; y < 319; y++) {
               BlockPos pos = new BlockPos(x, y, z);
               BlockState state = chunk.getBlockState(pos);
               if (state.isOf(Blocks.field_28888) && state.contains(Properties.AXIS)) {
                  Axis axis = (Axis)state.get(Properties.AXIS);
                  if (axis == Axis.field_11048 || axis == Axis.field_11051) {
                     rotatedCount++;
                     if (firstFound == null) {
                        firstFound = pos;
                     }

                     if (rotatedCount >= 5) {
                        this.addDetection(firstFound);
                        return;
                     }
                  }
               }
            }
         }
      }
   }

   private void scanChunkForKelp(WorldChunk chunk) {
      ChunkPos cPos = chunk.getPos();

      for (int x = cPos.getStartX(); x < cPos.getEndX(); x++) {
         for (int z = cPos.getStartZ(); z < cPos.getEndZ(); z++) {
            for (int y = 17; y < 64; y++) {
               BlockPos pos = new BlockPos(x, y, z);
               if (chunk.getBlockState(pos).isOf(Blocks.field_9993) && this.getKelpLength(pos) >= 20) {
                  this.addDetection(pos);
               }
            }
         }
      }
   }

   private void scanChunkForVines(WorldChunk chunk) {
      ChunkPos cPos = chunk.getPos();

      for (int x = cPos.getStartX(); x < cPos.getEndX(); x++) {
         for (int z = cPos.getStartZ(); z < cPos.getEndZ(); z++) {
            for (int y = 318; y > 16; y--) {
               BlockPos pos = new BlockPos(x, y, z);
               if (chunk.getBlockState(pos).isOf(Blocks.field_10597) && this.vineExtendsToY16(pos) && this.getVineLength(pos) >= 20) {
                  this.addDetection(pos);
               }
            }
         }
      }
   }

   private void checkRotatedDeepslate(BlockPos pos) {
      if (this.mc.world != null && pos.getY() > 16) {
         WorldChunk chunk = this.mc.world.getWorldChunk(pos);
         if (chunk != null) {
            this.scanChunkForRotatedDeepslate(chunk);
         }
      }
   }

   private void checkVine(BlockPos pos) {
      if (pos.getY() > 16 && this.vineExtendsToY16(pos) && this.getVineLength(pos) >= 20) {
         this.addDetection(pos);
      }
   }

   private void checkKelp(BlockPos pos) {
      if (pos.getY() > 16 && this.getKelpLength(pos) >= 20) {
         this.addDetection(pos);
      }
   }

   private boolean chunkHasHoles(ChunkPos cp) {
      if (this.mc.world == null) {
         return false;
      } else {
         int air = 0;
         int total = 0;
         int radius = (Integer)this.holeCheckRadius.get();
         int cx = cp.getCenterX();
         int cz = cp.getCenterZ();

         for (int x = cx - radius; x <= cx + radius; x++) {
            for (int z = cz - radius; z <= cz + radius; z++) {
               for (int y = 60; y <= 70; y++) {
                  if (this.mc.world.getBlockState(new BlockPos(x, y, z)).isAir()) {
                     air++;
                  }

                  total++;
               }
            }
         }

         return total > 0 && (double)air / total > 0.1;
      }
   }

   private boolean vineExtendsToY16(BlockPos start) {
      if (this.mc.world == null) {
         return false;
      } else {
         for (BlockPos p = start; p.getY() >= 16; p = p.method_10074()) {
            if (!this.mc.world.getBlockState(p).isOf(Blocks.field_10597)) {
               return false;
            }

            if (p.getY() == 16) {
               return true;
            }
         }

         return false;
      }
   }

   private int getVineLength(BlockPos start) {
      if (this.mc.world == null) {
         return 0;
      } else {
         int l = 0;

         for (BlockPos p = start; this.mc.world.getBlockState(p).isOf(Blocks.field_10597); p = p.up()) {
            l++;
         }

         for (BlockPos p = start.method_10074();
            p.getY() >= 16 && this.mc.world.getBlockState(p).isOf(Blocks.field_10597);
            p = p.method_10074()
         ) {
            l++;
         }

         return l;
      }
   }

   private int getKelpLength(BlockPos start) {
      if (this.mc.world == null) {
         return 0;
      } else {
         int l = 0;

         for (BlockPos p = start;
            this.mc.world.getBlockState(p).isOf(Blocks.field_9993) || this.mc.world.getBlockState(p).isOf(Blocks.field_10463);
            p = p.up()
         ) {
            l++;
         }

         for (BlockPos p = start.method_10074();
            p.getY() >= 16
               && (
                  this.mc.world.getBlockState(p).isOf(Blocks.field_9993)
                     || this.mc.world.getBlockState(p).isOf(Blocks.field_10463)
               );
            p = p.method_10074()
         ) {
            l++;
         }

         return l;
      }
   }

   public String getInfoString() {
      return this.detectedChunks.isEmpty() ? null : String.valueOf(this.detectedChunks.size());
   }

   private static class CustomChunkToast extends MeteorToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public CustomChunkToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -872415232);
         int lightBlue = -16712705;
         context.fill(0, 0, 160, 1, lightBlue);
         context.fill(0, 31, 160, 32, lightBlue);
         context.fill(0, 1, 1, 31, lightBlue);
         context.fill(159, 1, 160, 31, lightBlue);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, lightBlue, false);
         }
      }
   }

   private record DetectionInfo(BlockPos position, long timestamp) {
   }

   public static enum HoleMode {
      Without_Holes,
      Both;

      private HoleMode() {
      }
   }
}
