package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.modules.Zinc.RTPer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.biome.Biome;
import net.minecraft.util.math.BlockPos;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.entry.RegistryEntry;

public class BiomeNoti extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
   private final SettingGroup sgAreaScan = this.settings.createGroup("Area Scan");
   private final Setting<Integer> checkRadius = this.sgAreaScan
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("check-radius")).description("The radius (in blocks) around the player to check for the biome."))
               .defaultValue(32))
            .min(5)
            .max(2000)
            .sliderMax(2000)
            .build()
      );
   private final Setting<Integer> checkInterval = this.sgAreaScan
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("check-interval")).description("How often (in ticks) to check the area. Higher value reduces lag."))
               .defaultValue(20))
            .min(1)
            .max(100)
            .sliderMax(100)
            .build()
      );
   private final Setting<Boolean> sendNotifications = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("notifications"))
                  .description("Send in-game notifications when entering the selected biome."))
               .defaultValue(true))
            .build()
      );
   private final Setting<BiomeNoti.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("notification-mode"))
                     .description("The mode to use for notifications."))
                  .defaultValue(BiomeNoti.Mode.Both))
               .visible(this.sendNotifications::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("webhook"))
                  .description("Send Discord webhook when entering the selected biome."))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("webhook-url"))
                     .description("Discord webhook URL."))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("self-ping"))
                     .description("Ping yourself in the webhook message."))
                  .defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("discord-id"))
                     .description("Your Discord user ID for pinging."))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private RTPer.MinecraftBiome selectedBiome = RTPer.MinecraftBiome.PLAINS;
   private boolean isInsideTargetBiomeArea = false;
   private int tickCounter = 0;
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public BiomeNoti() {
      super(ZincAddon.Zinc, "biome-noti", "Notifies when entering the selected biome within a set radius.");
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.world != null && this.mc.player != null) {
         this.tickCounter++;
         if (this.tickCounter >= (Integer)this.checkInterval.get()) {
            this.tickCounter = 0;
            BlockPos playerPos = this.mc.player.getBlockPos();
            int radius = (Integer)this.checkRadius.get();
            boolean foundTargetBiome = false;

            for (int x = -radius; x <= radius; x += 16) {
               for (int z = -radius; z <= radius; z += 16) {
                  BlockPos checkPos = playerPos.method_10069(x, 0, z);
                  RegistryEntry<Biome> biomeEntry = this.mc.world.getBiome(checkPos);
                  String biomeId = biomeEntry.getKey().map(key -> key.getValue().toString()).orElse("unknown");
                  if (biomeId.equals(this.selectedBiome.getId())) {
                     foundTargetBiome = true;
                     break;
                  }
               }

               if (foundTargetBiome) {
                  break;
               }
            }

            if (foundTargetBiome && !this.isInsideTargetBiomeArea) {
               this.isInsideTargetBiomeArea = true;
               this.notifyBiome(this.selectedBiome.getId());
            } else if (!foundTargetBiome && this.isInsideTargetBiomeArea) {
               this.isInsideTargetBiomeArea = false;
            }
         }
      }
   }

   private void notifyBiome(String biomeId) {
      String displayName = this.selectedBiome.getDisplayName();
      String notificationMessage = "Detected " + displayName + " within " + this.checkRadius.get() + " blocks.";
      if ((Boolean)this.sendNotifications.get()) {
         switch ((BiomeNoti.Mode)this.notificationMode.get()) {
            case Chat:
               this.info(notificationMessage, new Object[0]);
               break;
            case Toast:
               this.mc
                  .getToastManager()
                  .add(
                     new BiomeNoti.BiomeToast(Items.GRASS_BLOCK.getDefaultStack(), Text.literal("Biome Noti"), Text.literal(displayName))
                  );
               break;
            case Both:
               this.info(notificationMessage, new Object[0]);
               this.mc
                  .getToastManager()
                  .add(
                     new BiomeNoti.BiomeToast(Items.GRASS_BLOCK.getDefaultStack(), Text.literal("Biome Noti"), Text.literal(displayName))
                  );
         }
      }

      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(displayName);
      }
   }

   private void sendWebhookNotification(String biomeName) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (url.isEmpty()) {
         this.warning("Webhook URL not configured!", new Object[0]);
      } else {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String messageContent = "";
                  if ((Boolean)this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()) {
                     messageContent = String.format("<@%s>", ((String)this.discordId.get()).trim());
                  }

                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Singleplayer";
                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"BiomeNoti\",\"embeds\":[{\"title\":\"\ud83d\uddfa Biome Area Entered!\",\"description\":\"**%s** detected within **%d** blocks.\",\"color\":65280,\"fields\":[{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"BiomeNoti\"}}]}",
                     messageContent,
                     biomeName,
                     this.checkRadius.get(),
                     serverInfo,
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .timeout(Duration.ofSeconds(30L))
                     .build();
                  HttpResponse<String> response = this.httpClient.send(request, BodyHandlers.ofString());
                  if (response.statusCode() == 204) {
                     this.info("Webhook sent successfully", new Object[0]);
                  } else {
                     this.error("Webhook failed with status: " + response.statusCode(), new Object[0]);
                  }
               } catch (Exception var8) {
                  this.error("Failed to send webhook: " + var8.getMessage(), new Object[0]);
               }
            }
         );
      }
   }

   public WWidget getWidget(GuiTheme theme) {
      WVerticalList list = theme.verticalList();
      list.add(theme.label("Biome Picker:"));

      for (RTPer.MinecraftBiome biome : RTPer.MinecraftBiome.values()) {
         WButton button = (WButton)list.add(theme.button(biome.getDisplayName())).widget();
         button.action = () -> {
            this.selectedBiome = biome;
            this.info("Selected biome: " + biome.getDisplayName(), new Object[0]);
         };
      }

      WButton reset = (WButton)list.add(theme.button("Reset State")).widget();
      reset.action = () -> {
         this.isInsideTargetBiomeArea = false;
         this.tickCounter = 0;
         this.info("Biome area state reset.", new Object[0]);
      };
      return list;
   }

   private static class BiomeToast extends MeteorToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public BiomeToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int green = -16711936;
         context.fill(0, 0, 160, 1, green);
         context.fill(0, 31, 160, 32, green);
         context.fill(0, 1, 1, 31, green);
         context.fill(159, 1, 160, 31, green);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, -16711936, false);
         }
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }
}
