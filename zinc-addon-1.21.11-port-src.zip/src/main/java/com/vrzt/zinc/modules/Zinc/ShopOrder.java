package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.Item.TooltipContext;

public class ShopOrder extends Module {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private static final Map<ShopOrder.Section, String> SECTION_TRIGGER = Map.of(
      ShopOrder.Section.END, "end stone", ShopOrder.Section.NETHER, "netherrack", ShopOrder.Section.PVP, "totem of undying"
   );
   private static final Map<ShopOrder.Section, List<String>> SECTION_ITEMS = Map.of(
      ShopOrder.Section.END,
      List.of("ender chest", "ender pearl", "end stone", "dragon breath", "end rod", "chorus fruit", "shulker shell", "shulker box"),
      ShopOrder.Section.NETHER,
      List.of("blaze rod", "nether wart", "glowstone dust", "magma cream", "ghast tear", "nether quartz", "soul sand", "magma block", "crying obsidian"),
      ShopOrder.Section.PVP,
      List.of(
         "obsidian",
         "end crystal",
         "respawn anchor",
         "glowstone",
         "totem of undying",
         "ender pearl",
         "golden apple",
         "potion of slow falling",
         "bottle o' enchanting"
      )
   );
   private ShopOrder.Stage stage = ShopOrder.Stage.NONE;
   private long stageStart = 0L;
   private static final long WAIT_TIME_MS = 50L;
   private ShopOrder.Section currentSection;
   private String selectedItem;
   private String targetPlayer = "";
   private boolean isTargetingActive = false;
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgTargeting = this.settings.createGroup("Player Targeting");
   private final Setting<ShopOrder.Section> section = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("section")).description("Which shop section to use.")).defaultValue(ShopOrder.Section.NETHER))
            .build()
      );
   private final Setting<String> item = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("item"))
                  .description("Item to buy from the selected section."))
               .defaultValue("blaze rod"))
            .build()
      );
   private final Setting<String> minPrice = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("min-price"))
                  .description("Minimum price to accept (supports K, M, B)."))
               .defaultValue("850"))
            .build()
      );
   private final Setting<Boolean> notifications = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("notifications"))
                  .description("Show info in chat."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> enableTargeting = this.sgTargeting
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("enable-targeting"))
                  .description("Target a specific player."))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> targetPlayerName = this.sgTargeting
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("target-player"))
                     .description("Player name to target."))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableTargeting.get()))
            .build()
      );
   private final Setting<Boolean> targetOnlyMode = this.sgTargeting
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("target-only-mode"))
                     .description("Ignore all orders except from the target player."))
                  .defaultValue(false))
               .visible(() -> (Boolean)this.enableTargeting.get()))
            .build()
      );

   public ShopOrder() {
      super(ZincAddon.Zinc, "ShopOrder", "Buys one configurable item from End/Nether/PvP and fulfills orders.");
   }

   public void onActivate() {
      if (this.parsePrice((String)this.minPrice.get()) == -1.0 && !(Boolean)this.enableTargeting.get()) {
         if ((Boolean)this.notifications.get()) {
            ChatUtils.error("Invalid min-price!", new Object[0]);
         }

         this.toggle();
      } else {
         this.currentSection = (ShopOrder.Section)this.section.get();
         this.selectedItem = ((String)this.item.get()).trim().toLowerCase(Locale.ROOT);
         if (!SECTION_ITEMS.get(this.currentSection).stream().anyMatch(s -> s.contains(this.selectedItem))) {
            if ((Boolean)this.notifications.get()) {
               ChatUtils.error("Item \"%s\" not found in %s section!", new Object[]{this.item.get(), this.currentSection});
            }

            this.toggle();
         } else {
            this.updateTargetPlayer();
            this.stage = ShopOrder.Stage.SHOP;
            this.stageStart = System.currentTimeMillis();
            if ((Boolean)this.notifications.get()) {
               String mode = this.isTargetingActive ? " | Target: " + this.targetPlayer : "";
               this.log("ShopOrder ON → %s → %s%s", this.currentSection, this.selectedItem, mode);
            }
         }
      }
   }

   public void onDeactivate() {
      this.stage = ShopOrder.Stage.NONE;
   }

   private void updateTargetPlayer() {
      this.targetPlayer = "";
      this.isTargetingActive = false;
      if ((Boolean)this.enableTargeting.get() && !((String)this.targetPlayerName.get()).trim().isEmpty()) {
         this.targetPlayer = ((String)this.targetPlayerName.get()).trim();
         this.isTargetingActive = true;
         if ((Boolean)this.notifications.get()) {
            this.log("Targeting player: %s", this.targetPlayer);
         }
      }
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null && this.mc.world != null) {
         long now = System.currentTimeMillis();
         switch (this.stage) {
            case NONE:
            default:
               break;
            case SHOP:
               ChatUtils.sendPlayerMsg("/shop");
               this.stage = ShopOrder.Stage.OPEN_SECTION;
               this.stageStart = now;
               break;
            case OPEN_SECTION:
               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler var32 = screen.getScreenHandler();
               String var37 = SECTION_TRIGGER.get(this.currentSection);

               for (Slot s : var32.slots) {
                  ItemStack st = s.getStack();
                  if (!st.isEmpty() && this.itemNameContains(st, var37)) {
                     this.clickSlot(var32, s.id);
                     this.stage = ShopOrder.Stage.BUY_ITEM;
                     this.stageStart = now;
                     return;
                  }
               }

               if (now - this.stageStart > 3000L) {
                  this.mc.player.closeHandledScreen();
                  this.stage = ShopOrder.Stage.SHOP;
                  this.stageStart = now;
               }
               break;
            case BUY_ITEM:
               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler var30 = screen.getScreenHandler();
               boolean var36 = false;

               for (Slot sx : var30.slots) {
                  ItemStack st = sx.getStack();
                  if (!st.isEmpty() && this.itemNameContains(st, this.selectedItem)) {
                     for (int i = 0; i < 5; i++) {
                        this.clickSlot(var30, sx.id);
                     }

                     var36 = true;
                     break;
                  }
               }

               if (var36) {
                  this.stage = ShopOrder.Stage.CONFIRM;
                  this.stageStart = now;
               } else if (now - this.stageStart > 1500L) {
                  this.mc.player.closeHandledScreen();
                  this.stage = ShopOrder.Stage.WAIT;
                  this.stageStart = now;
               }
               break;
            case CONFIRM:
               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler h = screen.getScreenHandler();

               for (Slot sxx : h.slots) {
                  ItemStack st = sxx.getStack();
                  if (!st.isEmpty() && this.isGreenGlass(st)) {
                     for (int i = 0; i < 64; i++) {
                        this.clickSlot(h, sxx.id);
                     }

                     this.stage = ShopOrder.Stage.WAIT;
                     this.stageStart = now;
                     return;
                  }
               }

               if (now - this.stageStart > 800L) {
                  this.stage = ShopOrder.Stage.BUY_ITEM;
                  this.stageStart = now;
               }
               break;
            case WAIT:
               if (now - this.stageStart >= 50L) {
                  if (this.isTargetingActive && !this.targetPlayer.isEmpty()) {
                     this.stage = ShopOrder.Stage.TARGET_ORDERS;
                  } else {
                     ChatUtils.sendPlayerMsg("/orders " + this.selectedItem);
                     this.stage = ShopOrder.Stage.ORDERS;
                  }

                  this.stageStart = now;
               }
               break;
            case ORDERS:
               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler var26 = screen.getScreenHandler();
               boolean var34 = false;

               for (Slot sxxx : var26.slots) {
                  ItemStack st = sxxx.getStack();
                  if (!st.isEmpty() && this.itemNameContains(st, this.selectedItem)) {
                     boolean take = false;
                     String orderPlayer = this.getOrderPlayerName(st);
                     boolean isTarget = this.isTargetingActive && orderPlayer != null && orderPlayer.equalsIgnoreCase(this.targetPlayer);
                     if (isTarget) {
                        take = true;
                        if ((Boolean)this.notifications.get()) {
                           double p = this.getOrderPrice(st);
                           this.log("TARGET order %s: %s", orderPlayer, p > 0.0 ? this.formatPrice(p) : "???");
                        }
                     } else if (!(Boolean)this.targetOnlyMode.get()) {
                        double p = this.getOrderPrice(st);
                        double min = this.parsePrice((String)this.minPrice.get());
                        if (p >= min) {
                           take = true;
                           if ((Boolean)this.notifications.get()) {
                              this.log("Good order: %s", this.formatPrice(p));
                           }
                        }
                     }

                     if (take) {
                        this.clickSlot(var26, sxxx.id);
                        this.stage = ShopOrder.Stage.ORDERS_SELECT;
                        this.stageStart = now + 50L;
                        var34 = true;
                        if ((Boolean)this.notifications.get()) {
                           this.log("Moving items to order...");
                        }
                        break;
                     }
                  }
               }

               if (!var34 && now - this.stageStart > 5000L) {
                  this.mc.player.closeHandledScreen();
                  this.stage = ShopOrder.Stage.SHOP;
                  this.stageStart = now;
               }
               break;
            case ORDERS_SELECT:
               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler var24 = screen.getScreenHandler();
               int var33 = 0;
               long var38 = 100L;
               if (now - this.stageStart >= var38) {
                  for (int i = 0; i < 1 && var33 < 36; var33++) {
                     ItemStack inv = this.mc.player.getInventory().getStack(var33);
                     if (!inv.isEmpty() && this.itemNameContains(inv, this.selectedItem)) {
                        int slotId = -1;

                        for (Slot sxxxx : var24.slots) {
                           if (sxxxx.inventory == this.mc.player.getInventory() && sxxxx.getIndex() == var33) {
                              slotId = sxxxx.id;
                              break;
                           }
                        }

                        if (slotId != -1) {
                           this.clickSlot(var24, slotId, SlotActionType.QUICK_MOVE);
                        }
                     }

                     i++;
                  }

                  this.stageStart = now;
               }

               if (var33 >= 36) {
                  this.mc.player.closeHandledScreen();
                  this.stage = ShopOrder.Stage.ORDERS_CONFIRM;
                  this.stageStart = now;
               }
               break;
            case ORDERS_CONFIRM:
               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler h = screen.getScreenHandler();

               for (Slot sxxxxx : h.slots) {
                  ItemStack st = sxxxxx.getStack();
                  if (!st.isEmpty() && this.isGreenGlass(st)) {
                     for (int i = 0; i < 64; i++) {
                        this.clickSlot(h, sxxxxx.id);
                     }

                     this.stage = ShopOrder.Stage.ORDERS_FINAL_EXIT;
                     this.stageStart = now;
                     if ((Boolean)this.notifications.get()) {
                        this.log("Order completed – back to shop");
                     }

                     return;
                  }
               }

               if (now - this.stageStart > 5000L) {
                  this.mc.player.closeHandledScreen();
                  this.stage = ShopOrder.Stage.SHOP;
                  this.stageStart = now;
               }
               break;
            case ORDERS_FINAL_EXIT:
               if (this.mc.currentScreen == null) {
                  this.stage = ShopOrder.Stage.CYCLE_PAUSE;
                  this.stageStart = now;
               }
               break;
            case CYCLE_PAUSE:
               if (now - this.stageStart >= 25L) {
                  this.updateTargetPlayer();
                  this.stage = ShopOrder.Stage.SHOP;
                  this.stageStart = now;
               }
               break;
            case TARGET_ORDERS:
               ChatUtils.sendPlayerMsg("/orders " + this.targetPlayer + " " + this.selectedItem);
               this.stage = ShopOrder.Stage.ORDERS;
               this.stageStart = now;
               if ((Boolean)this.notifications.get()) {
                  this.log("Checking orders for %s → %s", this.targetPlayer, this.selectedItem);
               }
         }
      }
   }

   private void clickSlot(ScreenHandler h, int slotId) {
      this.mc.interactionManager.clickSlot(h.syncId, slotId, 0, SlotActionType.PICKUP, this.mc.player);
   }

   private void clickSlot(ScreenHandler h, int slotId, SlotActionType type) {
      this.mc.interactionManager.clickSlot(h.syncId, slotId, 0, type, this.mc.player);
   }

   private boolean itemNameContains(ItemStack stack, String needle) {
      return stack.getName().getString().toLowerCase(Locale.ROOT).contains(needle);
   }

   private boolean isGreenGlass(ItemStack stack) {
      return stack.getItem() == Items.LIME_STAINED_GLASS_PANE || stack.getItem() == Items.GREEN_STAINED_GLASS_PANE;
   }

   private String getOrderPlayerName(ItemStack stack) {
      for (Text t : stack.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC)) {
         String line = t.getString();
         Pattern[] pats = new Pattern[]{
            Pattern.compile("(?i)player\\s*:\\s*([a-zA-Z0-9_]+)"),
            Pattern.compile("(?i)from\\s*:\\s*([a-zA-Z0-9_]+)"),
            Pattern.compile("(?i)by\\s*:\\s*([a-zA-Z0-9_]+)"),
            Pattern.compile("(?i)seller\\s*:\\s*([a-zA-Z0-9_]+)"),
            Pattern.compile("(?i)owner\\s*:\\s*([a-zA-Z0-9_]+)"),
            Pattern.compile("\\b([a-zA-Z0-9_]{3,16})\\b")
         };

         for (Pattern p : pats) {
            Matcher m = p.matcher(line);
            if (m.find()) {
               String n = m.group(1);
               if (n.length() >= 3 && n.length() <= 16 && n.matches("[a-zA-Z0-9_]+")) {
                  return n;
               }
            }
         }
      }

      return null;
   }

   private double getOrderPrice(ItemStack stack) {
      List<Text> tooltip = stack.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC);
      return this.parseTooltipPrice(tooltip);
   }

   private double parseTooltipPrice(List<Text> tooltip) {
      Pattern[] pats = new Pattern[]{
         Pattern.compile("\\$([\\d,]+(?:\\.[\\d]+)?)([kmb])?", 2),
         Pattern.compile("(?i)price\\s*:\\s*([\\d,]+(?:\\.[\\d]+)?)([kmb])?", 2),
         Pattern.compile("(?i)pay\\s*:\\s*([\\d,]+(?:\\.[\\d]+)?)([kmb])?", 2),
         Pattern.compile("(?i)reward\\s*:\\s*([\\d,]+(?:\\.[\\d]+)?)([kmb])?", 2),
         Pattern.compile("([\\d,]+(?:\\.[\\d]+)?)([kmb])?\\s*coins?", 2),
         Pattern.compile("\\b([\\d,]+(?:\\.[\\d]+)?)([kmb])\\b", 2)
      };

      for (Text t : tooltip) {
         String line = t.getString();

         for (Pattern p : pats) {
            Matcher m = p.matcher(line);
            if (m.find()) {
               String num = m.group(1).replace(",", "");
               String suf = m.groupCount() >= 2 && m.group(2) != null ? m.group(2).toLowerCase() : "";

               try {
                  double base = Double.parseDouble(num);

                  double mul = switch (suf) {
                     case "k" -> 1000.0;
                     case "m" -> 1000000.0;
                     case "b" -> 1.0E9;
                     default -> 1.0;
                  };
                  return base * mul;
               } catch (NumberFormatException var19) {
               }
            }
         }
      }

      return -1.0;
   }

   private double parsePrice(String s) {
      if (s != null && !s.isEmpty()) {
         String c = s.trim().toLowerCase().replace(",", "");
         double mul = 1.0;
         if (c.endsWith("b")) {
            mul = 1.0E9;
            c = c.substring(0, c.length() - 1);
         } else if (c.endsWith("m")) {
            mul = 1000000.0;
            c = c.substring(0, c.length() - 1);
         } else if (c.endsWith("k")) {
            mul = 1000.0;
            c = c.substring(0, c.length() - 1);
         }

         try {
            return Double.parseDouble(c) * mul;
         } catch (NumberFormatException var6) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   private String formatPrice(double p) {
      if (p >= 1.0E9) {
         return String.format("$%.1fB", p / 1.0E9);
      } else if (p >= 1000000.0) {
         return String.format("$%.1fM", p / 1000000.0);
      } else {
         return p >= 1000.0 ? String.format("$%.1fK", p / 1000.0) : String.format("$%.0f", p);
      }
   }

   private void log(String msg, Object... args) {
      if ((Boolean)this.notifications.get()) {
         ChatUtils.info(String.format(msg, args), new Object[0]);
      }
   }

   private static enum Section {
      END,
      NETHER,
      PVP;

      private Section() {
      }
   }

   private static enum Stage {
      NONE,
      SHOP,
      OPEN_SECTION,
      BUY_ITEM,
      CONFIRM,
      WAIT,
      ORDERS,
      ORDERS_SELECT,
      ORDERS_CONFIRM,
      ORDERS_FINAL_EXIT,
      CYCLE_PAUSE,
      TARGET_ORDERS;

      private Stage() {
      }
   }
}
