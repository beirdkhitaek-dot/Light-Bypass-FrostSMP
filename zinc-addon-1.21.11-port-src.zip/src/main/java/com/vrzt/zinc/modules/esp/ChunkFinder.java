package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.Properties;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Axis;

public class ChunkFinder extends Module {
   private final SettingGroup sgDetection = this.settings.createGroup("Detection");
   private final SettingGroup sgYLevels = this.settings.createGroup("Y Levels");
   private final SettingGroup sgRender = this.settings.createGroup("Render");
   private final SettingGroup sgBlockHighlight = this.settings.createGroup("Block Highlighting");
   private final SettingGroup sgPerformance = this.settings.createGroup("Performance");
   private final SettingGroup sgNotifications = this.settings.createGroup("Notifications");
   private final Setting<Boolean> detectNormalDeepslate = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-normal-deepslate")).description("Find regular Deepslate blocks (not cobbled/rotated)"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectCobbledDeepslate = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-cobbled-deepslate")).description("Find cobbled deepslate blocks")).defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectRotatedDeepslate = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-rotated-deepslate")).description("Find rotated deepslate blocks")).defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectCobblestoneLines = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-cobblestone-lines")).description("Detect vertical cobblestone lines (>10 blocks)"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectTuffLines = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-tuff-lines"))
                  .description("Detect vertical tuff lines (>10 blocks) with no other tuff nearby"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectAndesiteLines = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-andesite-lines"))
                  .description("Detect vertical andesite lines (>10 blocks) with no other andesite nearby"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectDioriteLines = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-diorite-lines"))
                  .description("Detect vertical diorite lines (>10 blocks) with no other diorite nearby"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> detectObsidianLines = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("detect-obsidian-lines"))
                  .description("Detect vertical obsidian lines (>5 blocks) with no other obsidian nearby"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> ignoreExposed = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("ignore-exposed")).description("Ignore blocks exposed to air or fluid")).defaultValue(true)).build()
      );
   private final Setting<Boolean> ignoreExposedLines = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("ignore-exposed-lines"))
                     .description("Ignore line blocks exposed to air or fluid (for line detection only)"))
                  .defaultValue(true))
               .visible(
                  () -> (Boolean)this.detectCobblestoneLines.get()
                     || (Boolean)this.detectTuffLines.get()
                     || (Boolean)this.detectAndesiteLines.get()
                     || (Boolean)this.detectDioriteLines.get()
                     || (Boolean)this.detectObsidianLines.get()
               ))
            .build()
      );
   private final Setting<Boolean> ignoreTrialChambers = this.sgDetection
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("ignore-trial-chambers"))
                  .description("Completely ignore trial chambers (no highlight, no detection)"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> trialChamberThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("trial-chamber-threshold"))
                     .description("Min trial chamber blocks to ignore chunk"))
                  .defaultValue(40))
               .range(10, 200)
               .sliderRange(10, 100)
               .visible(this.ignoreTrialChambers::get))
            .build()
      );
   private final Setting<Integer> normalDeepslateThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("normal-deepslate-threshold"))
                     .description("Min normal deepslate to flag chunk"))
                  .defaultValue(3))
               .range(1, 30)
               .sliderRange(1, 30)
               .visible(this.detectNormalDeepslate::get))
            .build()
      );
   private final Setting<Integer> cobbledDeepslateThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("cobbled-deepslate-threshold"))
                     .description("Min cobbled deepslate to flag"))
                  .defaultValue(1))
               .range(1, 15)
               .sliderRange(1, 15)
               .visible(this.detectCobbledDeepslate::get))
            .build()
      );
   private final Setting<Integer> rotatedDeepslateThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("rotated-threshold"))
                     .description("Min rotated deepslate to flag"))
                  .defaultValue(2))
               .range(1, 20)
               .sliderRange(1, 20)
               .visible(this.detectRotatedDeepslate::get))
            .build()
      );
   private final Setting<Integer> cobblestoneLineThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("cobblestone-line-threshold"))
                     .description("Minimum length of cobblestone line to detect (in blocks)"))
                  .defaultValue(10))
               .range(5, 30)
               .sliderRange(5, 30)
               .visible(this.detectCobblestoneLines::get))
            .build()
      );
   private final Setting<Integer> tuffLineThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("tuff-line-threshold"))
                     .description("Minimum length of tuff line to detect (in blocks)"))
                  .defaultValue(10))
               .range(5, 30)
               .sliderRange(5, 30)
               .visible(this.detectTuffLines::get))
            .build()
      );
   private final Setting<Integer> andesiteLineThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("andesite-line-threshold"))
                     .description("Minimum length of andesite line to detect (in blocks)"))
                  .defaultValue(10))
               .range(5, 30)
               .sliderRange(5, 30)
               .visible(this.detectAndesiteLines::get))
            .build()
      );
   private final Setting<Integer> dioriteLineThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("diorite-line-threshold"))
                     .description("Minimum length of diorite line to detect (in blocks)"))
                  .defaultValue(10))
               .range(5, 30)
               .sliderRange(5, 30)
               .visible(this.detectDioriteLines::get))
            .build()
      );
   private final Setting<Integer> obsidianLineThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("obsidian-line-threshold"))
                     .description("Minimum length of obsidian line to detect (in blocks)"))
                  .defaultValue(5))
               .range(3, 20)
               .sliderRange(3, 20)
               .visible(this.detectObsidianLines::get))
            .build()
      );
   private final Setting<Integer> cobblestoneIsolationRadius = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("cobblestone-isolation-radius"))
                     .description("Radius to check for other cobblestone blocks (excluding the line itself)"))
                  .defaultValue(8))
               .range(3, 20)
               .sliderRange(3, 20)
               .visible(this.detectCobblestoneLines::get))
            .build()
      );
   private final Setting<Integer> tuffIsolationRadius = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("tuff-isolation-radius"))
                     .description("Radius to check for other tuff blocks (excluding the line itself)"))
                  .defaultValue(8))
               .range(3, 20)
               .sliderRange(3, 20)
               .visible(this.detectTuffLines::get))
            .build()
      );
   private final Setting<Integer> andesiteIsolationRadius = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("andesite-isolation-radius"))
                     .description("Radius to check for other andesite blocks (excluding the line itself)"))
                  .defaultValue(8))
               .range(3, 20)
               .sliderRange(3, 20)
               .visible(this.detectAndesiteLines::get))
            .build()
      );
   private final Setting<Integer> dioriteIsolationRadius = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("diorite-isolation-radius"))
                     .description("Radius to check for other diorite blocks (excluding the line itself)"))
                  .defaultValue(8))
               .range(3, 20)
               .sliderRange(3, 20)
               .visible(this.detectDioriteLines::get))
            .build()
      );
   private final Setting<Integer> obsidianIsolationRadius = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("obsidian-isolation-radius"))
                     .description("Radius to check for other obsidian blocks (excluding the line itself)"))
                  .defaultValue(12))
               .range(3, 20)
               .sliderRange(3, 20)
               .visible(this.detectObsidianLines::get))
            .build()
      );
   private final Setting<Integer> cobblestoneLineCountThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("cobblestone-line-count-threshold"))
                     .description("Minimum number of isolated cobblestone lines to flag chunk"))
                  .defaultValue(1))
               .range(1, 10)
               .sliderRange(1, 5)
               .visible(this.detectCobblestoneLines::get))
            .build()
      );
   private final Setting<Integer> tuffLineCountThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("tuff-line-count-threshold"))
                     .description("Minimum number of isolated tuff lines to flag chunk"))
                  .defaultValue(1))
               .range(1, 10)
               .sliderRange(1, 5)
               .visible(this.detectTuffLines::get))
            .build()
      );
   private final Setting<Integer> andesiteLineCountThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("andesite-line-count-threshold"))
                     .description("Minimum number of isolated andesite lines to flag chunk"))
                  .defaultValue(1))
               .range(1, 10)
               .sliderRange(1, 5)
               .visible(this.detectAndesiteLines::get))
            .build()
      );
   private final Setting<Integer> dioriteLineCountThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("diorite-line-count-threshold"))
                     .description("Minimum number of isolated diorite lines to flag chunk"))
                  .defaultValue(1))
               .range(1, 10)
               .sliderRange(1, 5)
               .visible(this.detectDioriteLines::get))
            .build()
      );
   private final Setting<Integer> obsidianLineCountThreshold = this.sgDetection
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("obsidian-line-count-threshold"))
                     .description("Minimum number of isolated obsidian lines to flag chunk"))
                  .defaultValue(1))
               .range(1, 10)
               .sliderRange(1, 5)
               .visible(this.detectObsidianLines::get))
            .build()
      );
   private final Setting<Integer> minY = this.sgYLevels
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("general-min-y"))
                  .description("Minimum Y for Cobbled & Rotated Deepslate"))
               .defaultValue(-64))
            .range(-64, 320)
            .sliderRange(-64, 300)
            .build()
      );
   private final Setting<Integer> maxY = this.sgYLevels
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("max-y"))
                  .description("Maximum Y level to scan"))
               .defaultValue(300))
            .range(-64, 320)
            .sliderRange(-64, 300)
            .build()
      );
   private final Setting<Integer> deepslateMinY = this.sgYLevels
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("deepslate-min-y"))
                     .description("Minimum Y for NORMAL Deepslate only"))
                  .defaultValue(16))
               .range(16, 320)
               .sliderRange(16, 320)
               .visible(this.detectNormalDeepslate::get))
            .build()
      );
   private final Setting<Integer> deepslateMaxY = this.sgYLevels
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("deepslate-max-y"))
                     .description("Maximum Y for normal Deepslate"))
                  .defaultValue(320))
               .range(16, 320)
               .sliderRange(16, 320)
               .visible(this.detectNormalDeepslate::get))
            .build()
      );
   private final Setting<Double> renderY = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("render-height"))
               .description("Height to render chunk highlights"))
            .defaultValue(64.0)
            .range(-64.0, 320.0)
            .sliderRange(-64.0, 320.0)
            .build()
      );
   private final Setting<ShapeMode> renderMode = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("render-mode"))
                  .description("How to render highlighted chunks"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<SettingColor> chunkColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("chunk-color"))
               .description("Color for suspicious chunks"))
            .defaultValue(new SettingColor(255, 215, 0, 120))
            .build()
      );
   private final Setting<Double> thickness = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("thickness"))
               .description("Thickness of highlight box"))
            .defaultValue(0.3)
            .range(0.1, 2.0)
            .sliderRange(0.1, 2.0)
            .build()
      );
   private final Setting<Boolean> highlightBlocks = this.sgBlockHighlight
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("highlight-blocks")).description("Highlight individual suspicious blocks")).defaultValue(true))
            .build()
      );
   private final Setting<Integer> maxBlocksToRender = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("max-blocks-render"))
                     .description("Max blocks to highlight"))
                  .defaultValue(200))
               .range(50, 1000)
               .sliderRange(50, 1000)
               .visible(this.highlightBlocks::get))
            .build()
      );
   private final Setting<ShapeMode> blockRenderMode = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("block-render-mode"))
                     .description("How to render blocks"))
                  .defaultValue(ShapeMode.Lines))
               .visible(this.highlightBlocks::get))
            .build()
      );
   private final Setting<SettingColor> cobbledDeepslateBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("cobbled-deepslate-color"))
               .defaultValue(new SettingColor(80, 80, 80, 200))
               .visible(this.highlightBlocks::get))
            .build()
      );
   private final Setting<SettingColor> rotatedDeepslateBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("rotated-deepslate-color"))
               .defaultValue(new SettingColor(120, 0, 120, 200))
               .visible(this.highlightBlocks::get))
            .build()
      );
   private final Setting<SettingColor> normalDeepslateBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("normal-deepslate-color"))
                  .description("Color for normal deepslate blocks"))
               .defaultValue(new SettingColor(50, 50, 70, 220))
               .visible(() -> (Boolean)this.highlightBlocks.get() && (Boolean)this.detectNormalDeepslate.get()))
            .build()
      );
   private final Setting<SettingColor> cobblestoneLineBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("cobblestone-line-color"))
                  .description("Color for cobblestone line blocks"))
               .defaultValue(new SettingColor(140, 140, 140, 210))
               .visible(() -> (Boolean)this.highlightBlocks.get() && (Boolean)this.detectCobblestoneLines.get()))
            .build()
      );
   private final Setting<SettingColor> tuffLineBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("tuff-line-color"))
                  .description("Color for tuff line blocks"))
               .defaultValue(new SettingColor(100, 80, 60, 200))
               .visible(() -> (Boolean)this.highlightBlocks.get() && (Boolean)this.detectTuffLines.get()))
            .build()
      );
   private final Setting<SettingColor> andesiteLineBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("andesite-line-color"))
                  .description("Color for andesite line blocks"))
               .defaultValue(new SettingColor(140, 140, 140, 200))
               .visible(() -> (Boolean)this.highlightBlocks.get() && (Boolean)this.detectAndesiteLines.get()))
            .build()
      );
   private final Setting<SettingColor> dioriteLineBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("diorite-line-color"))
                  .description("Color for diorite line blocks"))
               .defaultValue(new SettingColor(220, 220, 220, 200))
               .visible(() -> (Boolean)this.highlightBlocks.get() && (Boolean)this.detectDioriteLines.get()))
            .build()
      );
   private final Setting<SettingColor> obsidianLineBlockColor = this.sgBlockHighlight
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("obsidian-line-color"))
                  .description("Color for obsidian line blocks"))
               .defaultValue(new SettingColor(30, 15, 50, 200))
               .visible(() -> (Boolean)this.highlightBlocks.get() && (Boolean)this.detectObsidianLines.get()))
            .build()
      );
   private final Setting<Boolean> useMultiThreading = this.sgPerformance
      .add(((Builder)((Builder)((Builder)new Builder().name("threading")).description("Use background threads")).defaultValue(true)).build());
   private final Setting<Integer> threadCount = this.sgPerformance
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("thread-count"))
                  .defaultValue(Math.max(1, Runtime.getRuntime().availableProcessors() / 2)))
               .range(1, 4)
               .sliderRange(1, 4)
               .visible(this.useMultiThreading::get))
            .build()
      );
   private final Setting<Integer> scanInterval = this.sgPerformance
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("scan-delay"))
                  .description("Delay between scans (ms)"))
               .defaultValue(100))
            .range(50, 2000)
            .sliderRange(50, 2000)
            .build()
      );
   private final Setting<Integer> maxConcurrentScans = this.sgPerformance
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("max-concurrent-scans"))
               .defaultValue(3))
            .range(1, 8)
            .sliderRange(1, 8)
            .build()
      );
   private final Setting<Integer> cleanupInterval = this.sgPerformance
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("cleanup-interval"))
                  .description("Cleanup distant chunks every X seconds"))
               .defaultValue(30))
            .range(15, 300)
            .sliderRange(15, 300)
            .build()
      );
   private final Setting<ChunkFinder.Mode> notificationMode = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                  .name("notification-mode"))
               .defaultValue(ChunkFinder.Mode.Both))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgNotifications
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("chat-feedback")).description("Show chat message when suspicious chunk is found")).defaultValue(true))
            .build()
      );
   private final Setting<Boolean> playSound = this.sgNotifications.add(((Builder)((Builder)new Builder().name("sound-alerts")).defaultValue(true)).build());
   private final Setting<Integer> maxAlerts = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("max-alerts"))
               .defaultValue(5))
            .range(1, 20)
            .sliderRange(1, 20)
            .build()
      );
   private final Set<ChunkPos> flaggedChunks = ConcurrentHashMap.newKeySet();
   private final ConcurrentHashMap<ChunkPos, ChunkFinder.ChunkAnalysis> chunkData = new ConcurrentHashMap<>();
   private final Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
   private final ConcurrentHashMap<ChunkPos, Long> notificationTimes = new ConcurrentHashMap<>();
   private final ConcurrentLinkedQueue<Long> recentAlerts = new ConcurrentLinkedQueue<>();
   private final AtomicLong activeScanCount = new AtomicLong(0L);
   private final Map<BlockPos, ChunkFinder.SuspiciousBlock> suspiciousBlocks = new ConcurrentHashMap<>();
   private final Set<ChunkPos> trialChamberChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkFinder.CobblestoneLine> detectedCobblestoneLines = ConcurrentHashMap.newKeySet();
   private final Set<ChunkFinder.TuffLine> detectedTuffLines = ConcurrentHashMap.newKeySet();
   private final Set<ChunkFinder.AndesiteLine> detectedAndesiteLines = ConcurrentHashMap.newKeySet();
   private final Set<ChunkFinder.DioriteLine> detectedDioriteLines = ConcurrentHashMap.newKeySet();
   private final Set<ChunkFinder.ObsidianLine> detectedObsidianLines = ConcurrentHashMap.newKeySet();
   private ExecutorService scannerPool;
   private volatile boolean shouldScan = false;
   private long lastCleanup = 0L;

   public ChunkFinder() {
      super(ZincAddon.esp, "ChunkFinder", "ChunkFinderV5 - Clean & Accurate");
   }

   public void onActivate() {
      if (this.mc.world != null && this.mc.player != null) {
         this.clearAll();
         this.shouldScan = true;
         this.lastCleanup = System.currentTimeMillis();
         if ((Boolean)this.useMultiThreading.get()) {
            this.createScannerPool();
         }

         this.startInitialScan();
         this.info("ChunkFinder activated", new Object[0]);
      }
   }

   public void onDeactivate() {
      this.shouldScan = false;
      this.shutdownScannerPool();
      this.clearAll();
   }

   private void createScannerPool() {
      if (this.scannerPool == null || this.scannerPool.isShutdown()) {
         this.scannerPool = Executors.newFixedThreadPool((Integer)this.threadCount.get(), r -> {
            Thread t = new Thread(r, "ChunkFinder-Worker");
            t.setDaemon(true);
            t.setPriority(4);
            return t;
         });
      }
   }

   private void shutdownScannerPool() {
      if (this.scannerPool != null) {
         this.scannerPool.shutdownNow();
         this.scannerPool = null;
      }
   }

   private void clearAll() {
      this.flaggedChunks.clear();
      this.chunkData.clear();
      this.scannedChunks.clear();
      this.notificationTimes.clear();
      this.recentAlerts.clear();
      this.suspiciousBlocks.clear();
      this.trialChamberChunks.clear();
      this.detectedCobblestoneLines.clear();
      this.detectedTuffLines.clear();
      this.detectedAndesiteLines.clear();
      this.detectedDioriteLines.clear();
      this.detectedObsidianLines.clear();
      this.activeScanCount.set(0L);
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.world != null && this.mc.player != null) {
         long now = System.currentTimeMillis();

         while (!this.recentAlerts.isEmpty() && now - this.recentAlerts.peek() > 60000L) {
            this.recentAlerts.poll();
         }

         if (now - this.lastCleanup > ((Integer)this.cleanupInterval.get()).intValue() * 1000L) {
            this.performCleanup();
            this.lastCleanup = now;
         }
      }
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.shouldScan && this.activeScanCount.get() < ((Integer)this.maxConcurrentScans.get()).intValue()) {
         ChunkPos pos = event.chunk().getPos();
         if (!this.scannedChunks.contains(pos)) {
            this.scheduleChunkScan(event.chunk());
         }
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (this.shouldScan) {
         BlockPos blockPos = event.pos;
         if (this.isRelevantBlock(event.newState) || event.newState.isAir()) {
            ChunkPos chunkPos = new ChunkPos(blockPos);
            WorldChunk chunk = this.mc.world.method_8497(chunkPos.x, chunkPos.z);
            this.scheduleChunkScan(chunk);
         }
      }
   }

   private boolean isRelevantBlock(BlockState state) {
      Block b = state.getBlock();
      return b == Blocks.field_29031
         || b == Blocks.field_28888
         || b == Blocks.field_10445
         || b == Blocks.field_27165
         || b == Blocks.field_10115
         || b == Blocks.field_10508
         || b == Blocks.field_10540
         || this.isTrialChamberBlock(state);
   }

   private void startInitialScan() {
      Runnable task = () -> {
         try {
            for (Chunk chunk : Utils.chunks()) {
               if (!this.shouldScan) {
                  break;
               }

               if (chunk instanceof WorldChunk worldChunk && this.activeScanCount.get() < ((Integer)this.maxConcurrentScans.get()).intValue()) {
                  if ((Boolean)this.useMultiThreading.get() && this.scannerPool != null) {
                     this.scannerPool.submit(() -> this.analyzeChunk(worldChunk));
                  } else {
                     this.analyzeChunk(worldChunk);
                  }
               }

               Thread.sleep(((Integer)this.scanInterval.get()).intValue());
            }
         } catch (InterruptedException var4) {
         }
      };
      if ((Boolean)this.useMultiThreading.get() && this.scannerPool != null) {
         this.scannerPool.submit(task);
      } else {
         new Thread(task, "ChunkFinder-Initial").start();
      }
   }

   private void scheduleChunkScan(Chunk chunk) {
      if (chunk instanceof WorldChunk worldChunk) {
         if (this.activeScanCount.get() < ((Integer)this.maxConcurrentScans.get()).intValue()) {
            Runnable task = () -> {
               try {
                  Thread.sleep((Integer)this.scanInterval.get() / 2);
                  if (this.shouldScan) {
                     this.analyzeChunk(worldChunk);
                  }
               } catch (InterruptedException var3x) {
               }
            };
            if ((Boolean)this.useMultiThreading.get() && this.scannerPool != null) {
               this.scannerPool.submit(task);
            } else {
               new Thread(task, "ChunkFinder-Scan").start();
            }
         }
      }
   }

   private void analyzeChunk(WorldChunk chunk) {
      if (this.shouldScan && chunk != null) {
         ChunkPos pos = chunk.getPos();
         if (!this.scannedChunks.contains(pos)) {
            this.activeScanCount.incrementAndGet();

            try {
               this.scannedChunks.add(pos);
               ChunkFinder.ChunkAnalysis analysis = new ChunkFinder.ChunkAnalysis();
               this.scanChunkSections(chunk, analysis);
               if ((Boolean)this.detectCobblestoneLines.get()) {
                  this.scanForCobblestoneLines(chunk, analysis);
               }

               if ((Boolean)this.detectTuffLines.get()) {
                  this.scanForTuffLines(chunk, analysis);
               }

               if ((Boolean)this.detectAndesiteLines.get()) {
                  this.scanForAndesiteLines(chunk, analysis);
               }

               if ((Boolean)this.detectDioriteLines.get()) {
                  this.scanForDioriteLines(chunk, analysis);
               }

               if ((Boolean)this.detectObsidianLines.get()) {
                  this.scanForObsidianLines(chunk, analysis);
               }

               this.chunkData.put(pos, analysis);
               this.evaluateChunk(pos, analysis);
            } finally {
               this.activeScanCount.decrementAndGet();
            }
         }
      }
   }

   private void scanChunkSections(WorldChunk chunk, ChunkFinder.ChunkAnalysis analysis) {
      ChunkSection[] sections = chunk.getSectionArray();

      for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
         if (!this.shouldScan) {
            return;
         }

         ChunkSection section = sections[sectionIndex];
         if (section != null && !section.isEmpty()) {
            int sectionY = chunk.getBottomY() + sectionIndex * 16;
            int startY = Math.max((Integer)this.minY.get(), sectionY);
            int endY = Math.min((Integer)this.maxY.get(), sectionY + 15);
            if (startY <= endY) {
               for (int x = 0; x < 16; x++) {
                  for (int z = 0; z < 16; z++) {
                     for (int y = startY - sectionY; y <= endY - sectionY; y++) {
                        if (y >= 0 && y <= 15) {
                           BlockState state = section.getBlockState(x, y, z);
                           int worldY = sectionY + y;
                           BlockPos blockPos = new BlockPos(chunk.getPos().getStartX() + x, worldY, chunk.getPos().getStartZ() + z);
                           this.analyzeBlock(blockPos, state, worldY, analysis);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void analyzeBlock(BlockPos blockPos, BlockState state, int worldY, ChunkFinder.ChunkAnalysis analysis) {
      ChunkPos chunkPos = new ChunkPos(blockPos);
      if (!(Boolean)this.ignoreTrialChambers.get() || !this.trialChamberChunks.contains(chunkPos)) {
         if ((Boolean)this.ignoreTrialChambers.get() && this.isTrialChamberBlock(state)) {
            analysis.trialChamberCount++;
         }

         if (!(Boolean)this.ignoreExposed.get() || !this.isExposedToAirOrFluid(blockPos)) {
            ChunkFinder.SuspiciousBlockType blockType = null;
            if ((Boolean)this.detectRotatedDeepslate.get()
               && worldY >= (Integer)this.minY.get()
               && worldY <= (Integer)this.maxY.get()
               && this.isRotatedDeepslateBlock(state)) {
               analysis.rotatedDeepslateCount++;
               blockType = ChunkFinder.SuspiciousBlockType.ROTATED_DEEPSLATE;
            }

            if ((Boolean)this.detectCobbledDeepslate.get()
               && worldY >= (Integer)this.minY.get()
               && worldY <= (Integer)this.maxY.get()
               && state.isOf(Blocks.field_29031)) {
               analysis.cobbledDeepslateCount++;
               if (blockType == null) {
                  blockType = ChunkFinder.SuspiciousBlockType.COBBLED_DEEPSLATE;
               }
            }

            if ((Boolean)this.detectNormalDeepslate.get()
               && worldY >= (Integer)this.deepslateMinY.get()
               && worldY <= (Integer)this.deepslateMaxY.get()
               && state.isOf(Blocks.field_28888)) {
               boolean isVerticalOrNoAxis = !state.contains(Properties.AXIS)
                  || state.contains(Properties.AXIS) && state.get(Properties.AXIS) == Axis.field_11052;
               if (isVerticalOrNoAxis) {
                  analysis.normalDeepslateCount++;
                  if (blockType == null) {
                     blockType = ChunkFinder.SuspiciousBlockType.NORMAL_DEEPSLATE;
                  }
               }
            }

            if (blockType != null && (Boolean)this.highlightBlocks.get()) {
               this.suspiciousBlocks.put(blockPos.toImmutable(), new ChunkFinder.SuspiciousBlock(blockType, System.currentTimeMillis()));
            }
         }
      }
   }

   private void scanForCobblestoneLines(WorldChunk chunk, ChunkFinder.ChunkAnalysis analysis) {
      if ((Boolean)this.detectCobblestoneLines.get() && chunk != null) {
         ChunkSection[] sections = chunk.getSectionArray();
         int minChunkY = chunk.getBottomY();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               int currentLineLength = 0;
               int lineStartY = -1;
               BlockPos lineStartPos = null;

               for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
                  ChunkSection section = sections[sectionIndex];
                  if (section != null && !section.isEmpty()) {
                     int sectionY = minChunkY + sectionIndex * 16;

                     for (int y = 0; y < 16; y++) {
                        int worldY = sectionY + y;
                        if (worldY >= (Integer)this.minY.get() && worldY <= (Integer)this.maxY.get()) {
                           BlockPos pos = new BlockPos(chunk.getPos().getStartX() + x, worldY, chunk.getPos().getStartZ() + z);
                           BlockState state = section.getBlockState(x, y, z);
                           if (state.isOf(Blocks.field_10445)) {
                              if ((Boolean)this.ignoreExposedLines.get() && this.isExposedToAirOrFluid(pos)) {
                                 if (currentLineLength >= (Integer)this.cobblestoneLineThreshold.get()) {
                                    this.checkAndRecordCobblestoneLine(lineStartPos, lineStartY, currentLineLength, analysis);
                                 }

                                 currentLineLength = 0;
                                 lineStartY = -1;
                                 lineStartPos = null;
                              } else {
                                 if (currentLineLength == 0) {
                                    lineStartY = worldY;
                                    lineStartPos = pos;
                                 }

                                 currentLineLength++;
                              }
                           } else {
                              if (currentLineLength >= (Integer)this.cobblestoneLineThreshold.get()) {
                                 this.checkAndRecordCobblestoneLine(lineStartPos, lineStartY, currentLineLength, analysis);
                              }

                              currentLineLength = 0;
                              lineStartY = -1;
                              lineStartPos = null;
                           }
                        }
                     }
                  }
               }

               if (currentLineLength >= (Integer)this.cobblestoneLineThreshold.get()) {
                  this.checkAndRecordCobblestoneLine(lineStartPos, lineStartY, currentLineLength, analysis);
               }
            }
         }
      }
   }

   private void scanForTuffLines(WorldChunk chunk, ChunkFinder.ChunkAnalysis analysis) {
      if ((Boolean)this.detectTuffLines.get() && chunk != null) {
         ChunkSection[] sections = chunk.getSectionArray();
         int minChunkY = chunk.getBottomY();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               int currentLineLength = 0;
               int lineStartY = -1;
               BlockPos lineStartPos = null;

               for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
                  ChunkSection section = sections[sectionIndex];
                  if (section != null && !section.isEmpty()) {
                     int sectionY = minChunkY + sectionIndex * 16;

                     for (int y = 0; y < 16; y++) {
                        int worldY = sectionY + y;
                        if (worldY >= (Integer)this.minY.get() && worldY <= (Integer)this.maxY.get()) {
                           BlockPos pos = new BlockPos(chunk.getPos().getStartX() + x, worldY, chunk.getPos().getStartZ() + z);
                           BlockState state = section.getBlockState(x, y, z);
                           if (state.isOf(Blocks.field_27165)) {
                              if ((Boolean)this.ignoreExposedLines.get() && this.isExposedToAirOrFluid(pos)) {
                                 if (currentLineLength >= (Integer)this.tuffLineThreshold.get()) {
                                    this.checkAndRecordTuffLine(lineStartPos, lineStartY, currentLineLength, analysis);
                                 }

                                 currentLineLength = 0;
                                 lineStartY = -1;
                                 lineStartPos = null;
                              } else {
                                 if (currentLineLength == 0) {
                                    lineStartY = worldY;
                                    lineStartPos = pos;
                                 }

                                 currentLineLength++;
                              }
                           } else {
                              if (currentLineLength >= (Integer)this.tuffLineThreshold.get()) {
                                 this.checkAndRecordTuffLine(lineStartPos, lineStartY, currentLineLength, analysis);
                              }

                              currentLineLength = 0;
                              lineStartY = -1;
                              lineStartPos = null;
                           }
                        }
                     }
                  }
               }

               if (currentLineLength >= (Integer)this.tuffLineThreshold.get()) {
                  this.checkAndRecordTuffLine(lineStartPos, lineStartY, currentLineLength, analysis);
               }
            }
         }
      }
   }

   private void scanForAndesiteLines(WorldChunk chunk, ChunkFinder.ChunkAnalysis analysis) {
      if ((Boolean)this.detectAndesiteLines.get() && chunk != null) {
         ChunkSection[] sections = chunk.getSectionArray();
         int minChunkY = chunk.getBottomY();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               int currentLineLength = 0;
               int lineStartY = -1;
               BlockPos lineStartPos = null;

               for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
                  ChunkSection section = sections[sectionIndex];
                  if (section != null && !section.isEmpty()) {
                     int sectionY = minChunkY + sectionIndex * 16;

                     for (int y = 0; y < 16; y++) {
                        int worldY = sectionY + y;
                        if (worldY >= (Integer)this.minY.get() && worldY <= (Integer)this.maxY.get()) {
                           BlockPos pos = new BlockPos(chunk.getPos().getStartX() + x, worldY, chunk.getPos().getStartZ() + z);
                           BlockState state = section.getBlockState(x, y, z);
                           if (state.isOf(Blocks.field_10115)) {
                              if ((Boolean)this.ignoreExposedLines.get() && this.isExposedToAirOrFluid(pos)) {
                                 if (currentLineLength >= (Integer)this.andesiteLineThreshold.get()) {
                                    this.checkAndRecordAndesiteLine(lineStartPos, lineStartY, currentLineLength, analysis);
                                 }

                                 currentLineLength = 0;
                                 lineStartY = -1;
                                 lineStartPos = null;
                              } else {
                                 if (currentLineLength == 0) {
                                    lineStartY = worldY;
                                    lineStartPos = pos;
                                 }

                                 currentLineLength++;
                              }
                           } else {
                              if (currentLineLength >= (Integer)this.andesiteLineThreshold.get()) {
                                 this.checkAndRecordAndesiteLine(lineStartPos, lineStartY, currentLineLength, analysis);
                              }

                              currentLineLength = 0;
                              lineStartY = -1;
                              lineStartPos = null;
                           }
                        }
                     }
                  }
               }

               if (currentLineLength >= (Integer)this.andesiteLineThreshold.get()) {
                  this.checkAndRecordAndesiteLine(lineStartPos, lineStartY, currentLineLength, analysis);
               }
            }
         }
      }
   }

   private void scanForDioriteLines(WorldChunk chunk, ChunkFinder.ChunkAnalysis analysis) {
      if ((Boolean)this.detectDioriteLines.get() && chunk != null) {
         ChunkSection[] sections = chunk.getSectionArray();
         int minChunkY = chunk.getBottomY();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               int currentLineLength = 0;
               int lineStartY = -1;
               BlockPos lineStartPos = null;

               for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
                  ChunkSection section = sections[sectionIndex];
                  if (section != null && !section.isEmpty()) {
                     int sectionY = minChunkY + sectionIndex * 16;

                     for (int y = 0; y < 16; y++) {
                        int worldY = sectionY + y;
                        if (worldY >= (Integer)this.minY.get() && worldY <= (Integer)this.maxY.get()) {
                           BlockPos pos = new BlockPos(chunk.getPos().getStartX() + x, worldY, chunk.getPos().getStartZ() + z);
                           BlockState state = section.getBlockState(x, y, z);
                           if (state.isOf(Blocks.field_10508)) {
                              if ((Boolean)this.ignoreExposedLines.get() && this.isExposedToAirOrFluid(pos)) {
                                 if (currentLineLength >= (Integer)this.dioriteLineThreshold.get()) {
                                    this.checkAndRecordDioriteLine(lineStartPos, lineStartY, currentLineLength, analysis);
                                 }

                                 currentLineLength = 0;
                                 lineStartY = -1;
                                 lineStartPos = null;
                              } else {
                                 if (currentLineLength == 0) {
                                    lineStartY = worldY;
                                    lineStartPos = pos;
                                 }

                                 currentLineLength++;
                              }
                           } else {
                              if (currentLineLength >= (Integer)this.dioriteLineThreshold.get()) {
                                 this.checkAndRecordDioriteLine(lineStartPos, lineStartY, currentLineLength, analysis);
                              }

                              currentLineLength = 0;
                              lineStartY = -1;
                              lineStartPos = null;
                           }
                        }
                     }
                  }
               }

               if (currentLineLength >= (Integer)this.dioriteLineThreshold.get()) {
                  this.checkAndRecordDioriteLine(lineStartPos, lineStartY, currentLineLength, analysis);
               }
            }
         }
      }
   }

   private void scanForObsidianLines(WorldChunk chunk, ChunkFinder.ChunkAnalysis analysis) {
      if ((Boolean)this.detectObsidianLines.get() && chunk != null) {
         ChunkSection[] sections = chunk.getSectionArray();
         int minChunkY = chunk.getBottomY();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               int currentLineLength = 0;
               int lineStartY = -1;
               BlockPos lineStartPos = null;

               for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
                  ChunkSection section = sections[sectionIndex];
                  if (section != null && !section.isEmpty()) {
                     int sectionY = minChunkY + sectionIndex * 16;

                     for (int y = 0; y < 16; y++) {
                        int worldY = sectionY + y;
                        if (worldY >= (Integer)this.minY.get() && worldY <= (Integer)this.maxY.get()) {
                           BlockPos pos = new BlockPos(chunk.getPos().getStartX() + x, worldY, chunk.getPos().getStartZ() + z);
                           BlockState state = section.getBlockState(x, y, z);
                           if (state.isOf(Blocks.field_10540)) {
                              if ((Boolean)this.ignoreExposedLines.get() && this.isExposedToAirOrFluid(pos)) {
                                 if (currentLineLength >= (Integer)this.obsidianLineThreshold.get()) {
                                    this.checkAndRecordObsidianLine(lineStartPos, lineStartY, currentLineLength, analysis);
                                 }

                                 currentLineLength = 0;
                                 lineStartY = -1;
                                 lineStartPos = null;
                              } else {
                                 if (currentLineLength == 0) {
                                    lineStartY = worldY;
                                    lineStartPos = pos;
                                 }

                                 currentLineLength++;
                              }
                           } else {
                              if (currentLineLength >= (Integer)this.obsidianLineThreshold.get()) {
                                 this.checkAndRecordObsidianLine(lineStartPos, lineStartY, currentLineLength, analysis);
                              }

                              currentLineLength = 0;
                              lineStartY = -1;
                              lineStartPos = null;
                           }
                        }
                     }
                  }
               }

               if (currentLineLength >= (Integer)this.obsidianLineThreshold.get()) {
                  this.checkAndRecordObsidianLine(lineStartPos, lineStartY, currentLineLength, analysis);
               }
            }
         }
      }
   }

   private void checkAndRecordCobblestoneLine(BlockPos startPos, int startY, int length, ChunkFinder.ChunkAnalysis analysis) {
      if (startPos != null && length >= (Integer)this.cobblestoneLineThreshold.get()) {
         if (this.isCobblestoneLineIsolated(startPos, startY, length)) {
            analysis.cobblestoneLineCount++;
            ChunkFinder.CobblestoneLine cobblestoneLine = new ChunkFinder.CobblestoneLine(startPos, length, System.currentTimeMillis());
            this.detectedCobblestoneLines.add(cobblestoneLine);
            if ((Boolean)this.highlightBlocks.get()) {
               for (int yOffset = 0; yOffset < length; yOffset++) {
                  BlockPos blockPos = startPos.up(yOffset);
                  this.suspiciousBlocks
                     .put(
                        blockPos.toImmutable(), new ChunkFinder.SuspiciousBlock(ChunkFinder.SuspiciousBlockType.COBBLESTONE_LINE, System.currentTimeMillis())
                     );
               }
            }
         }
      }
   }

   private void checkAndRecordTuffLine(BlockPos startPos, int startY, int length, ChunkFinder.ChunkAnalysis analysis) {
      if (startPos != null && length >= (Integer)this.tuffLineThreshold.get()) {
         if (this.isTuffLineIsolated(startPos, startY, length)) {
            analysis.tuffLineCount++;
            ChunkFinder.TuffLine tuffLine = new ChunkFinder.TuffLine(startPos, length, System.currentTimeMillis());
            this.detectedTuffLines.add(tuffLine);
            if ((Boolean)this.highlightBlocks.get()) {
               for (int yOffset = 0; yOffset < length; yOffset++) {
                  BlockPos blockPos = startPos.up(yOffset);
                  this.suspiciousBlocks
                     .put(blockPos.toImmutable(), new ChunkFinder.SuspiciousBlock(ChunkFinder.SuspiciousBlockType.TUFF_LINE, System.currentTimeMillis()));
               }
            }
         }
      }
   }

   private void checkAndRecordAndesiteLine(BlockPos startPos, int startY, int length, ChunkFinder.ChunkAnalysis analysis) {
      if (startPos != null && length >= (Integer)this.andesiteLineThreshold.get()) {
         if (this.isAndesiteLineIsolated(startPos, startY, length)) {
            analysis.andesiteLineCount++;
            ChunkFinder.AndesiteLine andesiteLine = new ChunkFinder.AndesiteLine(startPos, length, System.currentTimeMillis());
            this.detectedAndesiteLines.add(andesiteLine);
            if ((Boolean)this.highlightBlocks.get()) {
               for (int yOffset = 0; yOffset < length; yOffset++) {
                  BlockPos blockPos = startPos.up(yOffset);
                  this.suspiciousBlocks
                     .put(blockPos.toImmutable(), new ChunkFinder.SuspiciousBlock(ChunkFinder.SuspiciousBlockType.ANDESITE_LINE, System.currentTimeMillis()));
               }
            }
         }
      }
   }

   private void checkAndRecordDioriteLine(BlockPos startPos, int startY, int length, ChunkFinder.ChunkAnalysis analysis) {
      if (startPos != null && length >= (Integer)this.dioriteLineThreshold.get()) {
         if (this.isDioriteLineIsolated(startPos, startY, length)) {
            analysis.dioriteLineCount++;
            ChunkFinder.DioriteLine dioriteLine = new ChunkFinder.DioriteLine(startPos, length, System.currentTimeMillis());
            this.detectedDioriteLines.add(dioriteLine);
            if ((Boolean)this.highlightBlocks.get()) {
               for (int yOffset = 0; yOffset < length; yOffset++) {
                  BlockPos blockPos = startPos.up(yOffset);
                  this.suspiciousBlocks
                     .put(blockPos.toImmutable(), new ChunkFinder.SuspiciousBlock(ChunkFinder.SuspiciousBlockType.DIORITE_LINE, System.currentTimeMillis()));
               }
            }
         }
      }
   }

   private void checkAndRecordObsidianLine(BlockPos startPos, int startY, int length, ChunkFinder.ChunkAnalysis analysis) {
      if (startPos != null && length >= (Integer)this.obsidianLineThreshold.get()) {
         if (this.isObsidianLineIsolated(startPos, startY, length)) {
            analysis.obsidianLineCount++;
            ChunkFinder.ObsidianLine obsidianLine = new ChunkFinder.ObsidianLine(startPos, length, System.currentTimeMillis());
            this.detectedObsidianLines.add(obsidianLine);
            if ((Boolean)this.highlightBlocks.get()) {
               for (int yOffset = 0; yOffset < length; yOffset++) {
                  BlockPos blockPos = startPos.up(yOffset);
                  this.suspiciousBlocks
                     .put(blockPos.toImmutable(), new ChunkFinder.SuspiciousBlock(ChunkFinder.SuspiciousBlockType.OBSIDIAN_LINE, System.currentTimeMillis()));
               }
            }
         }
      }
   }

   private boolean isCobblestoneLineIsolated(BlockPos startPos, int startY, int length) {
      int isolationRadius = (Integer)this.cobblestoneIsolationRadius.get();
      Mutable mutable = new Mutable();

      for (int dx = -isolationRadius; dx <= isolationRadius; dx++) {
         for (int dy = -isolationRadius; dy <= isolationRadius; dy++) {
            for (int dz = -isolationRadius; dz <= isolationRadius; dz++) {
               if (dx != 0 || dz != 0 || dy < 0 || dy >= length) {
                  int checkY = startY + dy;
                  if (checkY >= (Integer)this.minY.get() && checkY <= (Integer)this.maxY.get()) {
                     mutable.set(startPos.getX() + dx, checkY, startPos.getZ() + dz);
                     if (this.mc.world.isChunkLoaded(mutable.getX() >> 4, mutable.getZ() >> 4)) {
                        BlockState state = this.mc.world.getBlockState(mutable);
                        if (state.isOf(Blocks.field_10445)) {
                           return false;
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean isTuffLineIsolated(BlockPos startPos, int startY, int length) {
      int isolationRadius = (Integer)this.tuffIsolationRadius.get();
      Mutable mutable = new Mutable();

      for (int dx = -isolationRadius; dx <= isolationRadius; dx++) {
         for (int dy = -isolationRadius; dy <= isolationRadius; dy++) {
            for (int dz = -isolationRadius; dz <= isolationRadius; dz++) {
               if (dx != 0 || dz != 0 || dy < 0 || dy >= length) {
                  int checkY = startY + dy;
                  if (checkY >= (Integer)this.minY.get() && checkY <= (Integer)this.maxY.get()) {
                     mutable.set(startPos.getX() + dx, checkY, startPos.getZ() + dz);
                     if (this.mc.world.isChunkLoaded(mutable.getX() >> 4, mutable.getZ() >> 4)) {
                        BlockState state = this.mc.world.getBlockState(mutable);
                        if (state.isOf(Blocks.field_27165)) {
                           return false;
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean isAndesiteLineIsolated(BlockPos startPos, int startY, int length) {
      int isolationRadius = (Integer)this.andesiteIsolationRadius.get();
      Mutable mutable = new Mutable();

      for (int dx = -isolationRadius; dx <= isolationRadius; dx++) {
         for (int dy = -isolationRadius; dy <= isolationRadius; dy++) {
            for (int dz = -isolationRadius; dz <= isolationRadius; dz++) {
               if (dx != 0 || dz != 0 || dy < 0 || dy >= length) {
                  int checkY = startY + dy;
                  if (checkY >= (Integer)this.minY.get() && checkY <= (Integer)this.maxY.get()) {
                     mutable.set(startPos.getX() + dx, checkY, startPos.getZ() + dz);
                     if (this.mc.world.isChunkLoaded(mutable.getX() >> 4, mutable.getZ() >> 4)) {
                        BlockState state = this.mc.world.getBlockState(mutable);
                        if (state.isOf(Blocks.field_10115)) {
                           return false;
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean isDioriteLineIsolated(BlockPos startPos, int startY, int length) {
      int isolationRadius = (Integer)this.dioriteIsolationRadius.get();
      Mutable mutable = new Mutable();

      for (int dx = -isolationRadius; dx <= isolationRadius; dx++) {
         for (int dy = -isolationRadius; dy <= isolationRadius; dy++) {
            for (int dz = -isolationRadius; dz <= isolationRadius; dz++) {
               if (dx != 0 || dz != 0 || dy < 0 || dy >= length) {
                  int checkY = startY + dy;
                  if (checkY >= (Integer)this.minY.get() && checkY <= (Integer)this.maxY.get()) {
                     mutable.set(startPos.getX() + dx, checkY, startPos.getZ() + dz);
                     if (this.mc.world.isChunkLoaded(mutable.getX() >> 4, mutable.getZ() >> 4)) {
                        BlockState state = this.mc.world.getBlockState(mutable);
                        if (state.isOf(Blocks.field_10508)) {
                           return false;
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean isObsidianLineIsolated(BlockPos startPos, int startY, int length) {
      int isolationRadius = (Integer)this.obsidianIsolationRadius.get();
      Mutable mutable = new Mutable();

      for (int dx = -isolationRadius; dx <= isolationRadius; dx++) {
         for (int dy = -isolationRadius; dy <= isolationRadius; dy++) {
            for (int dz = -isolationRadius; dz <= isolationRadius; dz++) {
               if (dx != 0 || dz != 0 || dy < 0 || dy >= length) {
                  int checkY = startY + dy;
                  if (checkY >= (Integer)this.minY.get() && checkY <= (Integer)this.maxY.get()) {
                     mutable.set(startPos.getX() + dx, checkY, startPos.getZ() + dz);
                     if (this.mc.world.isChunkLoaded(mutable.getX() >> 4, mutable.getZ() >> 4)) {
                        BlockState state = this.mc.world.getBlockState(mutable);
                        if (state.isOf(Blocks.field_10540)) {
                           return false;
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean isExposedToAirOrFluid(BlockPos pos) {
      for (Direction dir : Direction.values()) {
         BlockState adjacent = this.mc.world.getBlockState(pos.method_10093(dir));
         if (adjacent.isAir() || !adjacent.getFluidState().isEmpty()) {
            return true;
         }
      }

      return false;
   }

   private void evaluateChunk(ChunkPos pos, ChunkFinder.ChunkAnalysis analysis) {
      if ((Boolean)this.ignoreTrialChambers.get() && analysis.trialChamberCount >= (Integer)this.trialChamberThreshold.get()) {
         this.trialChamberChunks.add(pos);
         this.flaggedChunks.remove(pos);
         this.notificationTimes.remove(pos);
      } else {
         this.trialChamberChunks.remove(pos);
         boolean suspicious = false;
         StringBuilder reasons = new StringBuilder();
         if ((Boolean)this.detectNormalDeepslate.get() && analysis.normalDeepslateCount >= (Integer)this.normalDeepslateThreshold.get()) {
            suspicious = true;
            reasons.append("Deepslate[").append(analysis.normalDeepslateCount).append("] ");
         }

         if ((Boolean)this.detectCobbledDeepslate.get() && analysis.cobbledDeepslateCount >= (Integer)this.cobbledDeepslateThreshold.get()) {
            suspicious = true;
            reasons.append("Cobbled[").append(analysis.cobbledDeepslateCount).append("] ");
         }

         if ((Boolean)this.detectRotatedDeepslate.get() && analysis.rotatedDeepslateCount >= (Integer)this.rotatedDeepslateThreshold.get()) {
            suspicious = true;
            reasons.append("Rotated[").append(analysis.rotatedDeepslateCount).append("] ");
         }

         if ((Boolean)this.detectCobblestoneLines.get() && analysis.cobblestoneLineCount >= (Integer)this.cobblestoneLineCountThreshold.get()) {
            suspicious = true;
            reasons.append("CobblestoneLine[").append(analysis.cobblestoneLineCount).append("] ");
         }

         if ((Boolean)this.detectTuffLines.get() && analysis.tuffLineCount >= (Integer)this.tuffLineCountThreshold.get()) {
            suspicious = true;
            reasons.append("TuffLine[").append(analysis.tuffLineCount).append("] ");
         }

         if ((Boolean)this.detectAndesiteLines.get() && analysis.andesiteLineCount >= (Integer)this.andesiteLineCountThreshold.get()) {
            suspicious = true;
            reasons.append("AndesiteLine[").append(analysis.andesiteLineCount).append("] ");
         }

         if ((Boolean)this.detectDioriteLines.get() && analysis.dioriteLineCount >= (Integer)this.dioriteLineCountThreshold.get()) {
            suspicious = true;
            reasons.append("DioriteLine[").append(analysis.dioriteLineCount).append("] ");
         }

         if ((Boolean)this.detectObsidianLines.get() && analysis.obsidianLineCount >= (Integer)this.obsidianLineCountThreshold.get()) {
            suspicious = true;
            reasons.append("ObsidianLine[").append(analysis.obsidianLineCount).append("] ");
         }

         if (suspicious) {
            if (this.flaggedChunks.add(pos)) {
               this.notifyChunkFound(pos, reasons.toString().trim());
            }
         } else {
            this.flaggedChunks.remove(pos);
            this.notificationTimes.remove(pos);
         }
      }
   }

   private boolean isRotatedDeepslateBlock(BlockState state) {
      return state.isOf(Blocks.field_28888)
         && state.contains(Properties.AXIS)
         && state.get(Properties.AXIS) != Axis.field_11052;
   }

   private boolean isTrialChamberBlock(BlockState state) {
      Block b = state.getBlock();
      return b == Blocks.field_27133
         || b == Blocks.field_27135
         || b == Blocks.field_27134
         || b == Blocks.field_33407
         || b == Blocks.field_27165
         || b == Blocks.field_47035
         || b == Blocks.field_47034
         || b == Blocks.field_47039;
   }

   private void notifyChunkFound(ChunkPos pos, String details) {
      long now = System.currentTimeMillis();
      if (this.recentAlerts.size() < (Integer)this.maxAlerts.get()) {
         Long last = this.notificationTimes.get(pos);
         if (last == null || now - last >= 45000L) {
            String coordinates = String.format("[%d, %d]", pos.x * 16, pos.z * 16);
            String formattedDetails = this.formatDetectionDetails(details);
            this.mc
               .execute(
                  () -> {
                     switch ((ChunkFinder.Mode)this.notificationMode.get()) {
                        case Chat:
                           if ((Boolean)this.chatFeedback.get() && this.mc.player != null) {
                              this.sendChatMessage(coordinates, formattedDetails);
                           }
                           break;
                        case Toast:
                           this.mc
                              .getToastManager()
                              .add(
                                 new ChunkFinder.ChunkToast(
                                    Items.CHEST.getDefaultStack(), Text.literal("ChunkFinder"), Text.literal(coordinates)
                                 )
                              );
                           break;
                        case Both:
                           if ((Boolean)this.chatFeedback.get() && this.mc.player != null) {
                              this.sendChatMessage(coordinates, formattedDetails);
                           }

                           this.mc
                              .getToastManager()
                              .add(
                                 new ChunkFinder.ChunkToast(
                                    Items.CHEST.getDefaultStack(), Text.literal("ChunkFinder"), Text.literal(coordinates)
                                 )
                              );
                     }

                     if ((Boolean)this.playSound.get()) {
                        this.mc.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.field_14627, 1.5F));
                     }

                     this.recentAlerts.offer(now);
                     this.notificationTimes.put(pos, now);
                  }
               );
         }
      }
   }

   private String formatDetectionDetails(String details) {
      if (details.isEmpty()) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();
         String[] parts = details.split(" ");

         for (String part : parts) {
            if (part.contains("[")) {
               String type = part.substring(0, part.indexOf("["));
               String count = part.substring(part.indexOf("[") + 1, part.indexOf("]"));
               switch (type) {
                  case "Deepslate":
                     sb.append("§9").append(type).append("§7[§b").append(count).append("§7] ");
                     break;
                  case "Cobbled":
                     sb.append("§8").append(type).append("§7[§7").append(count).append("§7] ");
                     break;
                  case "Rotated":
                     sb.append("§5").append(type).append("§7[§d").append(count).append("§7] ");
                     break;
                  case "CobblestoneLine":
                     sb.append("§7Cobble§7[§f").append(count).append("§7] ");
                     break;
                  case "TuffLine":
                     sb.append("§6Tuff§7[§e").append(count).append("§7] ");
                     break;
                  case "AndesiteLine":
                     sb.append("§7Andesite§7[§f").append(count).append("§7] ");
                     break;
                  case "DioriteLine":
                     sb.append("§fDiorite§7[§f").append(count).append("§7] ");
                     break;
                  case "ObsidianLine":
                     sb.append("§5Obsidian§7[§d").append(count).append("§7] ");
                     break;
                  default:
                     sb.append("§f").append(part).append(" ");
               }
            } else {
               sb.append("§f").append(part).append(" ");
            }
         }

         return sb.toString().trim();
      }
   }

   private void sendChatMessage(String coordinates, String details) {
      String message = String.format("§6[§eChunkFinder§6] §fFound suspicious chunk at §e%s §f- %s", coordinates, details);
      this.mc.player.sendMessage(Text.literal(message), false);
   }

   private void performCleanup() {
      if (this.mc.player != null) {
         int viewDist = (Integer)this.mc.options.getViewDistance().getValue();
         int playerChunkX = (int)this.mc.player.getX() / 16;
         int playerChunkZ = (int)this.mc.player.getZ() / 16;
         this.flaggedChunks.removeIf(pos -> {
            boolean tooFar = Math.abs(pos.x - playerChunkX) > viewDist + 5 || Math.abs(pos.z - playerChunkZ) > viewDist + 5;
            if (tooFar) {
               this.chunkData.remove(pos);
               this.notificationTimes.remove(pos);
            }

            return tooFar;
         });
         this.trialChamberChunks
            .removeIf(pos -> Math.abs(pos.x - playerChunkX) > viewDist + 10 || Math.abs(pos.z - playerChunkZ) > viewDist + 10);
         this.scannedChunks.removeIf(pos -> Math.abs(pos.x - playerChunkX) > viewDist + 3 || Math.abs(pos.z - playerChunkZ) > viewDist + 3);
         this.suspiciousBlocks
            .entrySet()
            .removeIf(e -> this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter((Vec3i)e.getKey())) > viewDist * 16 + 80);
         this.detectedCobblestoneLines
            .removeIf(
               cobblestoneLine -> Math.abs(cobblestoneLine.startPos.getX() / 16 - playerChunkX) > viewDist + 5
                  || Math.abs(cobblestoneLine.startPos.getZ() / 16 - playerChunkZ) > viewDist + 5
                  || System.currentTimeMillis() - cobblestoneLine.detectedTime > 300000L
            );
         this.detectedTuffLines
            .removeIf(
               tuffLine -> Math.abs(tuffLine.startPos.getX() / 16 - playerChunkX) > viewDist + 5
                  || Math.abs(tuffLine.startPos.getZ() / 16 - playerChunkZ) > viewDist + 5
                  || System.currentTimeMillis() - tuffLine.detectedTime > 300000L
            );
         this.detectedAndesiteLines
            .removeIf(
               andesiteLine -> Math.abs(andesiteLine.startPos.getX() / 16 - playerChunkX) > viewDist + 5
                  || Math.abs(andesiteLine.startPos.getZ() / 16 - playerChunkZ) > viewDist + 5
                  || System.currentTimeMillis() - andesiteLine.detectedTime > 300000L
            );
         this.detectedDioriteLines
            .removeIf(
               dioriteLine -> Math.abs(dioriteLine.startPos.getX() / 16 - playerChunkX) > viewDist + 5
                  || Math.abs(dioriteLine.startPos.getZ() / 16 - playerChunkZ) > viewDist + 5
                  || System.currentTimeMillis() - dioriteLine.detectedTime > 300000L
            );
         this.detectedObsidianLines
            .removeIf(
               obsidianLine -> Math.abs(obsidianLine.startPos.getX() / 16 - playerChunkX) > viewDist + 5
                  || Math.abs(obsidianLine.startPos.getZ() / 16 - playerChunkZ) > viewDist + 5
                  || System.currentTimeMillis() - obsidianLine.detectedTime > 300000L
            );
      }
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.player != null) {
         if (!this.flaggedChunks.isEmpty()) {
            Color color = new Color((Color)this.chunkColor.get());
            int rendered = 0;

            for (ChunkPos pos : this.flaggedChunks) {
               if (rendered++ > 50) {
                  break;
               }

               Box box = new Box(
                  pos.getStartX(),
                  (Double)this.renderY.get(),
                  pos.getStartZ(),
                  pos.getEndX() + 1,
                  (Double)this.renderY.get() + (Double)this.thickness.get(),
                  pos.getEndZ() + 1
               );
               event.renderer.box(box, color, color, (ShapeMode)this.renderMode.get(), 0);
            }
         }

         if ((Boolean)this.highlightBlocks.get()) {
            int rendered = 0;

            for (Entry<BlockPos, ChunkFinder.SuspiciousBlock> e : this.suspiciousBlocks.entrySet()) {
               if (rendered >= (Integer)this.maxBlocksToRender.get()) {
                  break;
               }

               BlockPos pos = e.getKey();
               if (this.flaggedChunks.contains(new ChunkPos(pos))
                  && !(
                     this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(pos))
                        > (Integer)this.mc.options.getViewDistance().getValue() * 16
                  )) {
                  Color color = this.getColorForBlockType(e.getValue().type);
                  if (color != null) {
                     event.renderer.box(new Box(pos), color, color, (ShapeMode)this.blockRenderMode.get(), 0);
                     rendered++;
                  }
               }
            }

            if ((Boolean)this.detectCobblestoneLines.get()) {
               for (ChunkFinder.CobblestoneLine cobblestoneLine : this.detectedCobblestoneLines) {
                  if (rendered >= (Integer)this.maxBlocksToRender.get()) {
                     break;
                  }

                  if (!(
                     this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(cobblestoneLine.startPos))
                        > (Integer)this.mc.options.getViewDistance().getValue() * 16
                  )) {
                     Color cobblestoneColor = new Color((Color)this.cobblestoneLineBlockColor.get());

                     for (int yOffset = 0; yOffset < cobblestoneLine.length && rendered < this.maxBlocksToRender.get(); yOffset++) {
                        BlockPos pos = cobblestoneLine.startPos.up(yOffset);
                        event.renderer.box(new Box(pos), cobblestoneColor, cobblestoneColor, (ShapeMode)this.blockRenderMode.get(), 0);
                        rendered++;
                     }
                  }
               }
            }

            if ((Boolean)this.detectTuffLines.get()) {
               for (ChunkFinder.TuffLine tuffLine : this.detectedTuffLines) {
                  if (rendered >= (Integer)this.maxBlocksToRender.get()) {
                     break;
                  }

                  if (!(
                     this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(tuffLine.startPos))
                        > (Integer)this.mc.options.getViewDistance().getValue() * 16
                  )) {
                     Color tuffColor = new Color((Color)this.tuffLineBlockColor.get());

                     for (int yOffset = 0; yOffset < tuffLine.length && rendered < this.maxBlocksToRender.get(); yOffset++) {
                        BlockPos pos = tuffLine.startPos.up(yOffset);
                        event.renderer.box(new Box(pos), tuffColor, tuffColor, (ShapeMode)this.blockRenderMode.get(), 0);
                        rendered++;
                     }
                  }
               }
            }

            if ((Boolean)this.detectAndesiteLines.get()) {
               for (ChunkFinder.AndesiteLine andesiteLine : this.detectedAndesiteLines) {
                  if (rendered >= (Integer)this.maxBlocksToRender.get()) {
                     break;
                  }

                  if (!(
                     this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(andesiteLine.startPos))
                        > (Integer)this.mc.options.getViewDistance().getValue() * 16
                  )) {
                     Color andesiteColor = new Color((Color)this.andesiteLineBlockColor.get());

                     for (int yOffset = 0; yOffset < andesiteLine.length && rendered < this.maxBlocksToRender.get(); yOffset++) {
                        BlockPos pos = andesiteLine.startPos.up(yOffset);
                        event.renderer.box(new Box(pos), andesiteColor, andesiteColor, (ShapeMode)this.blockRenderMode.get(), 0);
                        rendered++;
                     }
                  }
               }
            }

            if ((Boolean)this.detectDioriteLines.get()) {
               for (ChunkFinder.DioriteLine dioriteLine : this.detectedDioriteLines) {
                  if (rendered >= (Integer)this.maxBlocksToRender.get()) {
                     break;
                  }

                  if (!(
                     this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(dioriteLine.startPos))
                        > (Integer)this.mc.options.getViewDistance().getValue() * 16
                  )) {
                     Color dioriteColor = new Color((Color)this.dioriteLineBlockColor.get());

                     for (int yOffset = 0; yOffset < dioriteLine.length && rendered < this.maxBlocksToRender.get(); yOffset++) {
                        BlockPos pos = dioriteLine.startPos.up(yOffset);
                        event.renderer.box(new Box(pos), dioriteColor, dioriteColor, (ShapeMode)this.blockRenderMode.get(), 0);
                        rendered++;
                     }
                  }
               }
            }

            if ((Boolean)this.detectObsidianLines.get()) {
               for (ChunkFinder.ObsidianLine obsidianLine : this.detectedObsidianLines) {
                  if (rendered >= (Integer)this.maxBlocksToRender.get()) {
                     break;
                  }

                  if (!(
                     this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(obsidianLine.startPos))
                        > (Integer)this.mc.options.getViewDistance().getValue() * 16
                  )) {
                     Color obsidianColor = new Color((Color)this.obsidianLineBlockColor.get());

                     for (int yOffset = 0; yOffset < obsidianLine.length && rendered < this.maxBlocksToRender.get(); yOffset++) {
                        BlockPos pos = obsidianLine.startPos.up(yOffset);
                        event.renderer.box(new Box(pos), obsidianColor, obsidianColor, (ShapeMode)this.blockRenderMode.get(), 0);
                        rendered++;
                     }
                  }
               }
            }
         }
      }
   }

   private Color getColorForBlockType(ChunkFinder.SuspiciousBlockType type) {
      return switch (type) {
         case COBBLED_DEEPSLATE -> new Color((Color)this.cobbledDeepslateBlockColor.get());
         case ROTATED_DEEPSLATE -> new Color((Color)this.rotatedDeepslateBlockColor.get());
         case NORMAL_DEEPSLATE -> new Color((Color)this.normalDeepslateBlockColor.get());
         case COBBLESTONE_LINE -> new Color((Color)this.cobblestoneLineBlockColor.get());
         case TUFF_LINE -> new Color((Color)this.tuffLineBlockColor.get());
         case ANDESITE_LINE -> new Color((Color)this.andesiteLineBlockColor.get());
         case DIORITE_LINE -> new Color((Color)this.dioriteLineBlockColor.get());
         case OBSIDIAN_LINE -> new Color((Color)this.obsidianLineBlockColor.get());
      };
   }

   public String getInfoString() {
      if (!this.flaggedChunks.isEmpty()) {
         ChunkPos first = this.flaggedChunks.iterator().next();
         return String.format("%d, %d", first.x * 16, first.z * 16);
      } else {
         return "None";
      }
   }

   private static class AndesiteLine {
      final BlockPos startPos;
      final int length;
      final long detectedTime;

      AndesiteLine(BlockPos startPos, int length, long detectedTime) {
         this.startPos = startPos.toImmutable();
         this.length = length;
         this.detectedTime = detectedTime;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            ChunkFinder.AndesiteLine andesiteLine = (ChunkFinder.AndesiteLine)o;
            return this.startPos.equals(andesiteLine.startPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return this.startPos.hashCode();
      }
   }

   private static class ChunkAnalysis {
      int cobbledDeepslateCount = 0;
      int rotatedDeepslateCount = 0;
      int normalDeepslateCount = 0;
      int trialChamberCount = 0;
      int cobblestoneLineCount = 0;
      int tuffLineCount = 0;
      int andesiteLineCount = 0;
      int dioriteLineCount = 0;
      int obsidianLineCount = 0;

      private ChunkAnalysis() {
      }
   }

   private static class ChunkToast extends MeteorToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public ChunkToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int yellow = -256;
         context.fill(0, 0, 160, 1, yellow);
         context.fill(0, 31, 160, 32, yellow);
         context.fill(0, 1, 1, 31, yellow);
         context.fill(159, 1, 160, 31, yellow);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, 16776960, false);
         }
      }
   }

   private static class CobblestoneLine {
      final BlockPos startPos;
      final int length;
      final long detectedTime;

      CobblestoneLine(BlockPos startPos, int length, long detectedTime) {
         this.startPos = startPos.toImmutable();
         this.length = length;
         this.detectedTime = detectedTime;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            ChunkFinder.CobblestoneLine cobblestoneLine = (ChunkFinder.CobblestoneLine)o;
            return this.startPos.equals(cobblestoneLine.startPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return this.startPos.hashCode();
      }
   }

   private static class DioriteLine {
      final BlockPos startPos;
      final int length;
      final long detectedTime;

      DioriteLine(BlockPos startPos, int length, long detectedTime) {
         this.startPos = startPos.toImmutable();
         this.length = length;
         this.detectedTime = detectedTime;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            ChunkFinder.DioriteLine dioriteLine = (ChunkFinder.DioriteLine)o;
            return this.startPos.equals(dioriteLine.startPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return this.startPos.hashCode();
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }

   private static class ObsidianLine {
      final BlockPos startPos;
      final int length;
      final long detectedTime;

      ObsidianLine(BlockPos startPos, int length, long detectedTime) {
         this.startPos = startPos.toImmutable();
         this.length = length;
         this.detectedTime = detectedTime;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            ChunkFinder.ObsidianLine obsidianLine = (ChunkFinder.ObsidianLine)o;
            return this.startPos.equals(obsidianLine.startPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return this.startPos.hashCode();
      }
   }

   private static class SuspiciousBlock {
      final ChunkFinder.SuspiciousBlockType type;
      final long detectedTime;

      SuspiciousBlock(ChunkFinder.SuspiciousBlockType type, long time) {
         this.type = type;
         this.detectedTime = time;
      }
   }

   private static enum SuspiciousBlockType {
      COBBLED_DEEPSLATE,
      ROTATED_DEEPSLATE,
      NORMAL_DEEPSLATE,
      COBBLESTONE_LINE,
      TUFF_LINE,
      ANDESITE_LINE,
      DIORITE_LINE,
      OBSIDIAN_LINE;

      private SuspiciousBlockType() {
      }
   }

   private static class TuffLine {
      final BlockPos startPos;
      final int length;
      final long detectedTime;

      TuffLine(BlockPos startPos, int length, long detectedTime) {
         this.startPos = startPos.toImmutable();
         this.length = length;
         this.detectedTime = detectedTime;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            ChunkFinder.TuffLine tuffLine = (ChunkFinder.TuffLine)o;
            return this.startPos.equals(tuffLine.startPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return this.startPos.hashCode();
      }
   }
}
