package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class TabDetector extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<List<String>> targetPlayers = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("target-players")).description("List of player names to detect when they join"))
               .defaultValue(new ArrayList()))
            .build()
      );
   private final Setting<TabDetector.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-mode"))
                  .description("How to notify when target players are detected"))
               .defaultValue(TabDetector.Mode.Both))
            .build()
      );
   private final Setting<Boolean> logOffline = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("log-offline"))
                  .description("Also log when target players go offline"))
               .defaultValue(true))
            .build()
      );
   private final Set<String> currentTargetPlayers = new HashSet<>();
   private final Set<String> previousTargetPlayers = new HashSet<>();

   public TabDetector() {
      super(ZincAddon.Zinc, "TabDetector", "Detects when specific players join or leave the server");
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.getNetworkHandler() != null) {
         this.currentTargetPlayers.clear();

         for (PlayerListEntry entry : this.mc.getNetworkHandler().getPlayerList()) {
            String playerName = entry.getProfile().name();

            for (String targetName : (List)this.targetPlayers.get()) {
               if (targetName.equalsIgnoreCase(playerName)) {
                  this.currentTargetPlayers.add(playerName);
                  break;
               }
            }
         }

         Set<String> newPlayers = new HashSet<>(this.currentTargetPlayers);
         newPlayers.removeAll(this.previousTargetPlayers);
         if (!newPlayers.isEmpty()) {
            this.handlePlayerJoin(newPlayers);
         }

         if ((Boolean)this.logOffline.get()) {
            Set<String> leftPlayers = new HashSet<>(this.previousTargetPlayers);
            leftPlayers.removeAll(this.currentTargetPlayers);
            if (!leftPlayers.isEmpty()) {
               this.handlePlayerLeave(leftPlayers);
            }
         }

         this.previousTargetPlayers.clear();
         this.previousTargetPlayers.addAll(this.currentTargetPlayers);
      }
   }

   private void handlePlayerJoin(Set<String> players) {
      String playerList = String.join(", ", players);
      String message = players.size() == 1
         ? String.format("Target player joined: (highlight)%s", playerList)
         : String.format("Target players joined: (highlight)%s", playerList);
      switch ((TabDetector.Mode)this.notificationMode.get()) {
         case Chat:
            this.info(message, new Object[0]);
            break;
         case Toast: {
            String playerName = players.iterator().next();
            this.mc
               .getToastManager()
               .add(
                  new TabDetector.TabDetectorToast(
                     Items.PLAYER_HEAD.getDefaultStack(), Text.literal("Tab Detector"), Text.literal(playerName)
                  )
               );
            break;
         }
         case Both: {
            this.info(message, new Object[0]);
            String playerName = players.iterator().next();
            this.mc
               .getToastManager()
               .add(
                  new TabDetector.TabDetectorToast(
                     Items.PLAYER_HEAD.getDefaultStack(), Text.literal("Tab Detector"), Text.literal(playerName)
                  )
               );
         }
      }
   }

   private void handlePlayerLeave(Set<String> players) {
      String playerList = String.join(", ", players);
      String message = players.size() == 1
         ? String.format("Target player left: (highlight)%s", playerList)
         : String.format("Target players left: (highlight)%s", playerList);
      switch ((TabDetector.Mode)this.notificationMode.get()) {
         case Chat:
            this.info(message, new Object[0]);
            break;
         case Toast: {
            String playerName = players.iterator().next();
            this.mc
               .getToastManager()
               .add(
                  new TabDetector.TabDetectorToast(
                     Items.BARRIER.getDefaultStack(), Text.literal("Tab Detector"), Text.literal(playerName + " (Left)")
                  )
               );
            break;
         }
         case Both: {
            this.info(message, new Object[0]);
            String playerName = players.iterator().next();
            this.mc
               .getToastManager()
               .add(
                  new TabDetector.TabDetectorToast(
                     Items.BARRIER.getDefaultStack(), Text.literal("Tab Detector"), Text.literal(playerName + " (Left)")
                  )
               );
         }
      }
   }

   public void onActivate() {
      this.currentTargetPlayers.clear();
      this.previousTargetPlayers.clear();
      if (this.mc.getNetworkHandler() != null) {
         for (PlayerListEntry entry : this.mc.getNetworkHandler().getPlayerList()) {
            String playerName = entry.getProfile().name();

            for (String targetName : (List)this.targetPlayers.get()) {
               if (targetName.equalsIgnoreCase(playerName)) {
                  this.previousTargetPlayers.add(playerName);
                  break;
               }
            }
         }
      }
   }

   public void onDeactivate() {
      this.currentTargetPlayers.clear();
      this.previousTargetPlayers.clear();
   }

   public String getInfoString() {
      if (this.currentTargetPlayers.isEmpty()) {
         return ((List)this.targetPlayers.get()).isEmpty() ? "No targets" : null;
      } else {
         return String.valueOf(this.currentTargetPlayers.size());
      }
   }

   public static enum Mode {
      Chat("Chat"),
      Toast("Toast"),
      Both("Both");

      private final String name;

      private Mode(String name) {
         this.name = name;
      }

      @Override
      public String toString() {
         return this.name;
      }
   }

   private static class TabDetectorToast extends MeteorToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public TabDetectorToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int grey = -8355712;
         context.fill(0, 0, 160, 1, grey);
         context.fill(0, 31, 160, 32, grey);
         context.fill(0, 1, 1, 31, grey);
         context.fill(159, 1, 160, 31, grey);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, -8355712, false);
         }
      }
   }
}
