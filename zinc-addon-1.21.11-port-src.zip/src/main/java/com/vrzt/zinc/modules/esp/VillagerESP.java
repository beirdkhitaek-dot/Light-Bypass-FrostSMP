package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

public class VillagerESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgRender = this.settings.createGroup("Render");
   private final SettingGroup sgwebhook = this.settings.createGroup("Webhook");
   private final Setting<Boolean> showTracers = this.sgRender
      .add(((Builder)((Builder)((Builder)new Builder().name("Show Tracers")).description("Draw tracer lines to villagers")).defaultValue(true)).build());
   private final Setting<SettingColor> villagerTracerColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("Villager Tracer Color"))
                  .description("Color of the tracer lines for villagers"))
               .defaultValue(new SettingColor(139, 69, 19, 127))
               .visible(this.showTracers::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgwebhook
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Webhook")).description("Send webhook notifications when villagers are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("Webhook URL"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgwebhook
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("Self Ping")).description("Ping yourself in the webhook message")).defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("Discord ID"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private final Setting<Boolean> enableDisconnect = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Disconnect")).description("Automatically disconnect when villagers are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<VillagerESP.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-mode"))
                  .description("How to notify when villagers are detected"))
               .defaultValue(VillagerESP.Mode.Both))
            .build()
      );
   private final Setting<Boolean> toggleOnFind = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Toggle when found")).description("Automatically toggles the module when villagers are detected"))
               .defaultValue(false))
            .build()
      );
   private final Set<Integer> detectedVillagers = new HashSet<>();
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public VillagerESP() {
      super(ZincAddon.esp, "VillagerESP", "Detects villagers in the world");
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         Set<Integer> currentVillagers = new HashSet<>();
         int villagerCount = 0;
         Color color = new Color((Color)this.villagerTracerColor.get());

         for (Entity entity : this.mc.world.getEntities()) {
            if (entity instanceof VillagerEntity villager) {
               currentVillagers.add(entity.getId());
               villagerCount++;
               if ((Boolean)this.showTracers.get()) {
                  double x = MathHelper.lerp(event.tickDelta, entity.lastX, entity.getX());
                  double y = MathHelper.lerp(event.tickDelta, entity.lastY, entity.getY());
                  double z = MathHelper.lerp(event.tickDelta, entity.lastZ, entity.getZ());
                  double heightOffset = villager.getBoundingBox().getLengthY() / 2.0;
                  event.renderer
                     .line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z, x, y + heightOffset, z, color);
               }
            }
         }

         if (!currentVillagers.isEmpty() && !currentVillagers.equals(this.detectedVillagers)) {
            Set<Integer> newVillagers = new HashSet<>(currentVillagers);
            newVillagers.removeAll(this.detectedVillagers);
            if (!newVillagers.isEmpty()) {
               this.detectedVillagers.addAll(newVillagers);
               this.handleVillagerDetection(villagerCount);
            }
         } else if (currentVillagers.isEmpty()) {
            this.detectedVillagers.clear();
         }
      }
   }

   private void handleVillagerDetection(int villagerCount) {
      String message = villagerCount == 1 ? "Villager detected!" : String.format("%d villagers detected!", villagerCount);
      switch ((VillagerESP.Mode)this.notificationMode.get()) {
         case Chat:
            this.info("(highlight)%s", new Object[]{message});
            break;
         case Toast:
            this.mc
               .getToastManager()
               .add(
                  new VillagerESP.VillagerToast(
                     Items.field_8687.getDefaultStack(), Text.literal("VillagerESP"), Text.literal(villagerCount + " Villagers")
                  )
               );
            break;
         case Both:
            this.info("(highlight)%s", new Object[]{message});
            this.mc
               .getToastManager()
               .add(
                  new VillagerESP.VillagerToast(
                     Items.field_8687.getDefaultStack(), Text.literal("VillagerESP"), Text.literal(villagerCount + " Villagers")
                  )
               );
      }

      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(villagerCount);
      }

      if ((Boolean)this.toggleOnFind.get()) {
         this.toggle();
      }

      if ((Boolean)this.enableDisconnect.get()) {
         this.disconnectFromServer(message);
      }
   }

   private void sendWebhookNotification(int villagerCount) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (!url.isEmpty()) {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
                  String messageContent = this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()
                     ? String.format("<@%s>", ((String)this.discordId.get()).trim())
                     : "";
                  String description = villagerCount == 1 ? "Villager detected!" : String.format("%d villagers detected!", villagerCount);
                  String coordinates = this.mc.player != null
                     ? String.format(
                        "X: %.0f, Y: %.0f, Z: %.0f", this.mc.player.getX(), this.mc.player.getY(), this.mc.player.getZ()
                     )
                     : "Unknown";
                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"VillagerESP\",\"embeds\":[{\"title\":\"\ud83c\udfd8️ Villager Alert\",\"description\":\"%s\",\"color\":65280,\"thumbnail\":{\"url\":\"https://i.imgur.com/OL2y1cr.png\"},\"fields\":[{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Villagers\",\"value\":\"%d\",\"inline\":true},{\"name\":\"Coordinates\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Sent by zinc\"}}]}",
                     messageContent,
                     description.replace("\"", "\\\""),
                     serverInfo.replace("\"", "\\\""),
                     villagerCount,
                     coordinates.replace("\"", "\\\""),
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .build();
                  this.httpClient.send(request, BodyHandlers.ofString());
               } catch (Exception var9) {
               }
            }
         );
      }
   }

   private void disconnectFromServer(String reason) {
      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal(reason));
      }
   }

   public void onActivate() {
      this.detectedVillagers.clear();
   }

   public void onDeactivate() {
      this.detectedVillagers.clear();
   }

   public String getInfoString() {
      return this.detectedVillagers.isEmpty() ? null : String.valueOf(this.detectedVillagers.size());
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }

   private static class VillagerToast extends MeteorToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public VillagerToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int brown = -7650029;
         context.fill(0, 0, 160, 1, brown);
         context.fill(0, 31, 160, 32, brown);
         context.fill(0, 1, 1, 31, brown);
         context.fill(159, 1, 160, 31, brown);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, -7650029, false);
         }
      }
   }
}
