package com.vrzt.zinc.modules.esp;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.vrzt.zinc.ZincAddon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.BlockPos;
import net.minecraft.text.Text;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.block.entity.BarrelBlockEntity;

public class AdvancedStashFinder extends Module {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
   private final Setting<List<BlockEntityType<?>>> storageBlocks = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("storage-blocks")).description("Select the storage blocks to search for."))
            .defaultValue(StorageBlockListSetting.STORAGE_BLOCKS)
            .build()
      );
   private final Setting<Integer> minimumStorageCount = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("minimum-storage-count"))
                  .description("The minimum amount of storage blocks in a chunk to record the chunk."))
               .defaultValue(4))
            .min(1)
            .sliderMin(1)
            .sliderMax(1000)
            .build()
      );
   private final Setting<Integer> minimumDistance = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("minimum-distance"))
                  .description("The minimum distance you must be from spawn to record a certain chunk."))
               .defaultValue(0))
            .min(0)
            .sliderMax(10000)
            .build()
      );
   private final Setting<Boolean> criticalSpawner = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("critical-spawner"))
                  .description("Mark chunk as stash even if only a single spawner is found."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> disconnectOnFind = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("disconnect-on-base-find"))
                  .description("Automatically disconnect from the server when a base is found."))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> sendNotifications = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("notifications"))
                  .description("Sends Minecraft notifications when new stashes are found."))
               .defaultValue(true))
            .build()
      );
   private final Setting<AdvancedStashFinder.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("notification-mode"))
                     .description("The mode to use for notifications."))
                  .defaultValue(AdvancedStashFinder.Mode.Both))
               .visible(this.sendNotifications::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("webhook"))
                  .description("Send webhook notifications when stashes are found"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("webhook-url"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("self-ping"))
                     .description("Ping yourself in the webhook message"))
                  .defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("discord-id"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   public List<AdvancedStashFinder.Chunk> chunks = new ArrayList<>();
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public AdvancedStashFinder() {
      super(ZincAddon.esp, "AdvancedStashFinder", "Advanced stash finder with webhook support and auto-disconnect.");
   }

   public void onActivate() {
      this.load();
   }

   @EventHandler
   private void onChunkData(ChunkDataEvent event) {
      double chunkXAbs = Math.abs(event.chunk().getPos().x * 16);
      double chunkZAbs = Math.abs(event.chunk().getPos().z * 16);
      if (!(Math.sqrt(chunkXAbs * chunkXAbs + chunkZAbs * chunkZAbs) < ((Integer)this.minimumDistance.get()).intValue())) {
         AdvancedStashFinder.Chunk chunk = new AdvancedStashFinder.Chunk(event.chunk().getPos());

         for (BlockEntity blockEntity : event.chunk().getBlockEntities().values()) {
            BlockEntityType<?> type = blockEntity.getType();
            if (blockEntity instanceof MobSpawnerBlockEntity) {
               chunk.spawners++;
            } else if (((List)this.storageBlocks.get()).contains(type)) {
               if (blockEntity instanceof ChestBlockEntity) {
                  chunk.chests++;
               } else if (blockEntity instanceof BarrelBlockEntity) {
                  chunk.barrels++;
               } else if (blockEntity instanceof ShulkerBoxBlockEntity) {
                  chunk.shulkers++;
               } else if (blockEntity instanceof EnderChestBlockEntity) {
                  chunk.enderChests++;
               } else if (blockEntity instanceof AbstractFurnaceBlockEntity) {
                  chunk.furnaces++;
               } else if (blockEntity instanceof DispenserBlockEntity) {
                  chunk.dispensersDroppers++;
               } else if (blockEntity instanceof HopperBlockEntity) {
                  chunk.hoppers++;
               }
            }
         }

         boolean isStash = false;
         boolean isCriticalSpawner = false;
         String detectionReason = "";
         if ((Boolean)this.criticalSpawner.get() && chunk.spawners > 0) {
            isStash = true;
            isCriticalSpawner = true;
            detectionReason = "Spawner(s) detected (Critical mode)";
         } else if (chunk.getTotal() >= (Integer)this.minimumStorageCount.get()) {
            isStash = true;
            detectionReason = "Storage threshold reached (" + chunk.getTotal() + " blocks)";
         }

         if (isStash) {
            AdvancedStashFinder.Chunk prevChunk = null;
            int i = this.chunks.indexOf(chunk);
            if (i < 0) {
               this.chunks.add(chunk);
            } else {
               prevChunk = this.chunks.set(i, chunk);
            }

            this.saveJson();
            this.saveCsv();
            boolean isNewOrUpdated = !chunk.equals(prevChunk) || !chunk.countsEqual(prevChunk);
            if ((Boolean)this.sendNotifications.get() && isNewOrUpdated) {
               String stashType = isCriticalSpawner ? "spawner base" : "stash";
               int totalStorage = chunk.getTotal();
               switch ((AdvancedStashFinder.Mode)this.notificationMode.get()) {
                  case Chat:
                     this.info("Found %s at (highlight)%s(default), (highlight)%s(default). %s", new Object[]{stashType, chunk.x, chunk.z, detectionReason});
                     break;
                  case Toast:
                     this.mc
                        .getToastManager()
                        .add(
                           new AdvancedStashFinder.StashToast(
                              Items.CHEST.getDefaultStack(), Text.literal("StashFinder"), Text.literal(totalStorage + " storage")
                           )
                        );
                     break;
                  case Both:
                     this.info("Found %s at (highlight)%s(default), (highlight)%s(default). %s", new Object[]{stashType, chunk.x, chunk.z, detectionReason});
                     this.mc
                        .getToastManager()
                        .add(
                           new AdvancedStashFinder.StashToast(
                              Items.CHEST.getDefaultStack(), Text.literal("StashFinder"), Text.literal(totalStorage + " storage")
                           )
                        );
               }
            }

            if ((Boolean)this.enableWebhook.get() && isNewOrUpdated) {
               this.sendWebhookNotification(chunk, isCriticalSpawner, detectionReason);
            }

            if ((Boolean)this.disconnectOnFind.get() && isNewOrUpdated) {
               this.toggle();
               if (this.mc.world != null) {
                  this.mc.world.disconnect(net.minecraft.text.Text.empty());
               }
            }
         }
      }
   }

   private void sendWebhookNotification(AdvancedStashFinder.Chunk chunk, boolean isCriticalSpawner, String detectionReason) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (url.isEmpty()) {
         this.warning("Webhook URL not configured!", new Object[0]);
      } else {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
                  String messageContent = "";
                  if ((Boolean)this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()) {
                     messageContent = String.format("<@%s>", ((String)this.discordId.get()).trim());
                  }

                  String stashType = isCriticalSpawner ? "Spawner Base" : "Stash";
                  String description = String.format("%s found at coordinates %d, %d", stashType, chunk.x, chunk.z);
                  StringBuilder itemsFound = new StringBuilder();
                  int totalItems = 0;
                  if (chunk.spawners > 0) {
                     itemsFound.append("Spawners: ").append(chunk.spawners).append("\\n");
                     totalItems += chunk.spawners;
                  }

                  if (chunk.chests > 0) {
                     itemsFound.append("Chests: ").append(chunk.chests).append("\\n");
                     totalItems += chunk.chests;
                  }

                  if (chunk.barrels > 0) {
                     itemsFound.append("Barrels: ").append(chunk.barrels).append("\\n");
                     totalItems += chunk.barrels;
                  }

                  if (chunk.shulkers > 0) {
                     itemsFound.append("Shulker Boxes: ").append(chunk.shulkers).append("\\n");
                     totalItems += chunk.shulkers;
                  }

                  if (chunk.enderChests > 0) {
                     itemsFound.append("Ender Chests: ").append(chunk.enderChests).append("\\n");
                     totalItems += chunk.enderChests;
                  }

                  if (chunk.furnaces > 0) {
                     itemsFound.append("Furnaces: ").append(chunk.furnaces).append("\\n");
                     totalItems += chunk.furnaces;
                  }

                  if (chunk.dispensersDroppers > 0) {
                     itemsFound.append("Dispensers/Droppers: ").append(chunk.dispensersDroppers).append("\\n");
                     totalItems += chunk.dispensersDroppers;
                  }

                  if (chunk.hoppers > 0) {
                     itemsFound.append("Hoppers: ").append(chunk.hoppers).append("\\n");
                     totalItems += chunk.hoppers;
                  }

                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"Advanced Stashfinder\",\"embeds\":[{\"title\":\"\ud83d\udce6 Advanced Stashfinder Alert\",\"description\":\"%s\",\"color\":%d,\"fields\":[{\"name\":\"Detection Reason\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Total Items Found\",\"value\":\"%d\",\"inline\":false},{\"name\":\"Items Breakdown\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Coordinates\",\"value\":\"%d, %d\",\"inline\":true},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Advanced Stashfinder\"}}]}",
                     messageContent.replace("\"", "\\\""),
                     description.replace("\"", "\\\""),
                     isCriticalSpawner ? 16711680 : 3066993,
                     detectionReason.replace("\"", "\\\""),
                     totalItems,
                     itemsFound.toString().replace("\"", "\\\""),
                     chunk.x,
                     chunk.z,
                     serverInfo.replace("\"", "\\\""),
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .timeout(Duration.ofSeconds(30L))
                     .build();
                  HttpResponse<String> response = this.httpClient.send(request, BodyHandlers.ofString());
                  if (response.statusCode() == 204) {
                     this.info("Webhook notification sent successfully", new Object[0]);
                  } else {
                     this.error("Webhook failed with status: " + response.statusCode(), new Object[0]);
                  }
               } catch (InterruptedException | IOException var14) {
                  this.error("Failed to send webhook: " + var14.getMessage(), new Object[0]);
               }
            }
         );
      }
   }

   public WWidget getWidget(GuiTheme theme) {
      this.chunks.sort(Comparator.comparingInt(value -> -value.getTotal()));
      WVerticalList list = theme.verticalList();
      WButton clear = (WButton)list.add(theme.button("Clear")).widget();
      WTable table = new WTable();
      if (!this.chunks.isEmpty()) {
         list.add(table);
      }

      clear.action = () -> {
         this.chunks.clear();
         table.clear();
      };
      this.fillTable(theme, table);
      return list;
   }

   private void fillTable(GuiTheme theme, WTable table) {
      for (AdvancedStashFinder.Chunk chunk : this.chunks) {
         table.add(theme.label("Pos: " + chunk.x + ", " + chunk.z));
         table.add(theme.label("Total: " + chunk.getTotal()));
         WButton open = (WButton)table.add(theme.button("Open")).widget();
         open.action = () -> this.mc.setScreen(new AdvancedStashFinder.ChunkScreen(theme, chunk));
         WButton gotoBtn = (WButton)table.add(theme.button("Goto")).widget();
         gotoBtn.action = () -> PathManagers.get().moveTo(new BlockPos(chunk.x, 0, chunk.z), true);
         WMinus delete = (WMinus)table.add(theme.minus()).widget();
         delete.action = () -> {
            if (this.chunks.remove(chunk)) {
               table.clear();
               this.fillTable(theme, table);
               this.saveJson();
               this.saveCsv();
            }
         };
         table.row();
      }
   }

   private void load() {
      boolean loaded = false;
      File file = this.getJsonFile();
      if (file.exists()) {
         try {
            FileReader reader = new FileReader(file);
            this.chunks = (List<AdvancedStashFinder.Chunk>)GSON.fromJson(reader, (new TypeToken<List<AdvancedStashFinder.Chunk>>() {}).getType());
            reader.close();

            for (AdvancedStashFinder.Chunk chunk : this.chunks) {
               chunk.calculatePos();
            }

            loaded = true;
         } catch (Exception var8) {
            if (this.chunks == null) {
               this.chunks = new ArrayList<>();
            }
         }
      }

      file = this.getCsvFile();
      if (!loaded && file.exists()) {
         try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
               String[] values = line.split(",");
               AdvancedStashFinder.Chunk chunk = new AdvancedStashFinder.Chunk(new ChunkPos(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
               chunk.chests = Integer.parseInt(values[2]);
               chunk.barrels = Integer.parseInt(values[3]);
               chunk.shulkers = Integer.parseInt(values[4]);
               chunk.enderChests = Integer.parseInt(values[5]);
               chunk.furnaces = Integer.parseInt(values[6]);
               chunk.dispensersDroppers = Integer.parseInt(values[7]);
               chunk.hoppers = Integer.parseInt(values[8]);
               if (values.length > 9) {
                  chunk.spawners = Integer.parseInt(values[9]);
               }

               this.chunks.add(chunk);
            }

            reader.close();
         } catch (Exception var7) {
            if (this.chunks == null) {
               this.chunks = new ArrayList<>();
            }
         }
      }
   }

   private void saveCsv() {
      try {
         File file = this.getCsvFile();
         file.getParentFile().mkdirs();
         Writer writer = new FileWriter(file);
         writer.write("X,Z,Chests,Barrels,Shulkers,EnderChests,Furnaces,DispensersDroppers,Hoppers,Spawners\n");

         for (AdvancedStashFinder.Chunk chunk : this.chunks) {
            chunk.write(writer);
         }

         writer.close();
      } catch (IOException var5) {
         var5.printStackTrace();
      }
   }

   private void saveJson() {
      try {
         File file = this.getJsonFile();
         file.getParentFile().mkdirs();
         Writer writer = new FileWriter(file);
         GSON.toJson(this.chunks, writer);
         writer.close();
      } catch (IOException var3) {
         var3.printStackTrace();
      }
   }

   private File getJsonFile() {
      return new File(new File(new File(MeteorClient.FOLDER, "stashes"), Utils.getFileWorldName()), "advanced-stashes.json");
   }

   private File getCsvFile() {
      return new File(new File(new File(MeteorClient.FOLDER, "stashes"), Utils.getFileWorldName()), "advanced-stashes.csv");
   }

   public String getInfoString() {
      return String.valueOf(this.chunks.size());
   }

   public static class Chunk {
      private static final StringBuilder sb = new StringBuilder();
      public ChunkPos chunkPos;
      public transient int x;
      public transient int z;
      public int chests;
      public int barrels;
      public int shulkers;
      public int enderChests;
      public int furnaces;
      public int dispensersDroppers;
      public int hoppers;
      public int spawners;

      public Chunk(ChunkPos chunkPos) {
         this.chunkPos = chunkPos;
         this.calculatePos();
      }

      public void calculatePos() {
         this.x = this.chunkPos.x * 16 + 8;
         this.z = this.chunkPos.z * 16 + 8;
      }

      public int getTotal() {
         return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers + this.spawners;
      }

      public void write(Writer writer) throws IOException {
         sb.setLength(0);
         sb.append(this.x).append(',').append(this.z).append(',');
         sb.append(this.chests)
            .append(',')
            .append(this.barrels)
            .append(',')
            .append(this.shulkers)
            .append(',')
            .append(this.enderChests)
            .append(',')
            .append(this.furnaces)
            .append(',')
            .append(this.dispensersDroppers)
            .append(',')
            .append(this.hoppers)
            .append(',')
            .append(this.spawners)
            .append('\n');
         writer.write(sb.toString());
      }

      public boolean countsEqual(AdvancedStashFinder.Chunk c) {
         return c == null
            ? false
            : this.chests != c.chests
               || this.barrels != c.barrels
               || this.shulkers != c.shulkers
               || this.enderChests != c.enderChests
               || this.furnaces != c.furnaces
               || this.dispensersDroppers != c.dispensersDroppers
               || this.hoppers != c.hoppers
               || this.spawners != c.spawners;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            AdvancedStashFinder.Chunk chunk = (AdvancedStashFinder.Chunk)o;
            return Objects.equals(this.chunkPos, chunk.chunkPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return Objects.hash(this.chunkPos);
      }
   }

   private static class ChunkScreen extends WindowScreen {
      private final AdvancedStashFinder.Chunk chunk;

      public ChunkScreen(GuiTheme theme, AdvancedStashFinder.Chunk chunk) {
         super(theme, "Chunk at " + chunk.x + ", " + chunk.z);
         this.chunk = chunk;
      }

      public void initWidgets() {
         WTable t = (WTable)this.add(this.theme.table()).expandX().widget();
         t.add(this.theme.label("Total:"));
         t.add(this.theme.label(this.chunk.getTotal() + ""));
         t.row();
         t.add(this.theme.horizontalSeparator()).expandX();
         t.row();
         t.add(this.theme.label("Chests:"));
         t.add(this.theme.label(this.chunk.chests + ""));
         t.row();
         t.add(this.theme.label("Barrels:"));
         t.add(this.theme.label(this.chunk.barrels + ""));
         t.row();
         t.add(this.theme.label("Shulkers:"));
         t.add(this.theme.label(this.chunk.shulkers + ""));
         t.row();
         t.add(this.theme.label("Ender Chests:"));
         t.add(this.theme.label(this.chunk.enderChests + ""));
         t.row();
         t.add(this.theme.label("Spawners:"));
         t.add(this.theme.label(this.chunk.spawners + ""));
         t.row();
         t.add(this.theme.label("Furnaces:"));
         t.add(this.theme.label(this.chunk.furnaces + ""));
         t.row();
         t.add(this.theme.label("Dispensers and droppers:"));
         t.add(this.theme.label(this.chunk.dispensersDroppers + ""));
         t.row();
         t.add(this.theme.label("Hoppers:"));
         t.add(this.theme.label(this.chunk.hoppers + ""));
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }

   private static class StashToast extends MeteorToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public StashToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int yellow = -256;
         context.fill(0, 0, 160, 1, yellow);
         context.fill(0, 31, 160, 32, yellow);
         context.fill(0, 1, 1, 31, yellow);
         context.fill(159, 1, 160, 31, yellow);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, 16776960, false);
         }
      }
   }
}
