package com.vrzt.zinc.modules.main;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;

public class PlayerDetection extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgwhitelist = this.settings.createGroup("Whitelist");
   private final SettingGroup sgwebhook = this.settings.createGroup("Webhook");
   private final SettingGroup sgPanicPay = this.settings.createGroup("Panic Pay");
   private static final Set<String> PERMANENT_WHITELIST = new HashSet<>(Arrays.asList("FreeCamera"));
   private final Setting<List<String>> userWhitelist = this.sgwhitelist
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("User Whitelist")).description("List of player names to ignore")).defaultValue(new ArrayList()))
            .build()
      );
   private final Setting<List<Module>> modulesToToggle = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ModuleListSetting.Builder)((meteordevelopment.meteorclient.settings.ModuleListSetting.Builder)((meteordevelopment.meteorclient.settings.ModuleListSetting.Builder)new meteordevelopment.meteorclient.settings.ModuleListSetting.Builder()
                     .name("Modules To Toggle"))
                  .description("Select modules to toggle when a non-whitelisted player is detected"))
               .defaultValue(new ArrayList()))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Webhook"))
                  .description("Send webhook notifications when players are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("Webhook URL"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("Self Ping"))
                     .description("Ping yourself in the webhook message"))
                  .defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("Discord ID"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private final Setting<Boolean> enableDisconnect = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Disconnect"))
                  .description("Automatically disconnect when players are detected"))
               .defaultValue(true))
            .build()
      );
   private final Setting<PlayerDetection.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-mode"))
                  .description("How to notify when players are detected"))
               .defaultValue(PlayerDetection.Mode.Both))
            .build()
      );
   private final Setting<Boolean> toggleonplayer = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Toggle when a player is detected"))
                  .description("Automatically toggles THIS module when a player is detected"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> enablePanicPay = this.sgPanicPay
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("Enable Panic Pay"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> panicPayTarget = this.sgPanicPay
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("Target Player"))
                  .defaultValue(""))
               .visible(this.enablePanicPay::get))
            .build()
      );
   private final Setting<String> panicPayAmount = this.sgPanicPay
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("Amount"))
                  .defaultValue(""))
               .visible(this.enablePanicPay::get))
            .build()
      );
   private final Set<String> detectedPlayers = new HashSet<>();
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public PlayerDetection() {
      super(ZincAddon.Zinc, "PlayerDetection", "Detects when players are in the world");
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         Set<String> currentPlayers = new HashSet<>();
         String currentPlayerName = this.mc.player.getGameProfile().name();
         Set<String> fullWhitelist = new HashSet<>(PERMANENT_WHITELIST);
         fullWhitelist.addAll((Collection<? extends String>)this.userWhitelist.get());

         for (PlayerEntity player : this.mc.world.getPlayers()) {
            if (player != this.mc.player) {
               String playerName = player.getGameProfile().name();
               if (!playerName.equals(currentPlayerName) && !fullWhitelist.contains(playerName)) {
                  currentPlayers.add(playerName);
               }
            }
         }

         if (!currentPlayers.isEmpty() && !currentPlayers.equals(this.detectedPlayers)) {
            this.detectedPlayers.clear();
            this.detectedPlayers.addAll(currentPlayers);
            this.handlePlayerDetection(currentPlayers);
         } else if (currentPlayers.isEmpty()) {
            this.detectedPlayers.clear();
         }
      }
   }

   private void handlePlayerDetection(Set<String> players) {
      String playerList = String.join(", ", players);
      if (this.notificationMode.get() == PlayerDetection.Mode.Toast || this.notificationMode.get() == PlayerDetection.Mode.Both) {
         this.mc
            .getToastManager()
            .add(new PlayerDetection.DetectionToast(Text.literal("Player Detection"), Text.literal(playerList)));
      }

      if (this.notificationMode.get() == PlayerDetection.Mode.Chat || this.notificationMode.get() == PlayerDetection.Mode.Both) {
         this.info("Player(s) detected: (highlight)%s", new Object[]{playerList});
      }

      ChatUtils.sendPlayerMsg("#stop");

      for (Module m : (List)this.modulesToToggle.get()) {
         m.toggle();
      }

      if ((Boolean)this.enablePanicPay.get()) {
         String target = ((String)this.panicPayTarget.get()).trim();
         String amount = ((String)this.panicPayAmount.get()).trim();
         if (!target.isEmpty() && !amount.isEmpty()) {
            ChatUtils.sendPlayerMsg(String.format("/pay %s %s", target, amount));
         }
      }

      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(players);
      }

      if ((Boolean)this.toggleonplayer.get()) {
         this.toggle();
      }

      if ((Boolean)this.enableDisconnect.get()) {
         CompletableFuture.runAsync(() -> {
            try {
               Thread.sleep(500L);
               this.disconnectFromServer(playerList);
            } catch (InterruptedException var3) {
               Thread.currentThread().interrupt();
            }
         });
      }
   }

   private void sendWebhookNotification(Set<String> players) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (!url.isEmpty()) {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String playerList = String.join(", ", players);
                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
                  String messageContent = this.selfPing.get() && !((String)this.discordId.get()).isEmpty()
                     ? String.format("<@%s>", ((String)this.discordId.get()).trim())
                     : "";
                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"embeds\":[{\"title\":\"\ud83d\udea8 Player Detection Alert\",\"color\":15158332,\"fields\":[{\"name\":\"Players\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}]}]}",
                     messageContent,
                     playerList,
                     serverInfo,
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .build();
                  this.httpClient.send(request, BodyHandlers.ofString());
               } catch (Exception var8) {
               }
            }
         );
      }
   }

   private void disconnectFromServer(String playerList) {
      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("Player(s) detected: " + playerList));
      }
   }

   public void onActivate() {
      this.detectedPlayers.clear();
   }

   public void onDeactivate() {
      this.detectedPlayers.clear();
   }

   public String getInfoString() {
      return this.detectedPlayers.isEmpty() ? null : String.valueOf(this.detectedPlayers.size());
   }

   private static class DetectionToast implements Toast {
      private final Text title;
      private final Text description;
      private long startTime = -1L;
      private Visibility visibility = Visibility.field_2210;

      public DetectionToast(Text title, Text description) {
         this.title = title;
         this.description = description;
      }

      public Visibility getVisibility() {
         return this.visibility;
      }

      public void update(ToastManager manager, long currentTime) {
         if (this.startTime == -1L) {
            this.startTime = currentTime;
         }

         if (currentTime - this.startTime >= 5000L) {
            this.visibility = Visibility.field_2209;
         }
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int red = -52429;
         context.fill(0, 0, 160, 1, red);
         context.fill(0, 31, 160, 32, red);
         context.fill(0, 1, 1, 31, red);
         context.fill(159, 1, 160, 31, red);
         context.drawItem(new ItemStack(Items.PLAYER_HEAD), 8, 8);
         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16733525, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, 16777215, false);
         }
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }
}
