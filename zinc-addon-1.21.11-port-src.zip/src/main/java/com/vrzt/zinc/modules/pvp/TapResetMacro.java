package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;

public class TapResetMacro extends Module {
   private final Setting<Boolean> sTap = this.settings.getDefaultGroup().add(((Builder)((Builder)new Builder().name("s-tap")).defaultValue(true)).build());
   private final Setting<Integer> tapDuration = this.settings
      .getDefaultGroup()
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("s-tap-duration"))
                  .defaultValue(100))
               .min(10)
               .sliderMax(300)
               .visible(this.sTap::get))
            .build()
      );
   private final Setting<Boolean> wTap = this.settings.getDefaultGroup().add(((Builder)((Builder)new Builder().name("w-tap")).defaultValue(true)).build());
   private final Setting<Integer> wTapDuration = this.settings
      .getDefaultGroup()
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("w-tap-duration"))
                  .defaultValue(100))
               .min(10)
               .sliderMax(300)
               .visible(this.wTap::get))
            .build()
      );
   private long sTapReleaseTime = 0L;
   private boolean sTapActive = false;
   private long wTapRePressTime = 0L;
   private boolean wTapActive = false;

   public TapResetMacro() {
      super(ZincAddon.pvp, "tap-reset-macro", "Simulated S-tap and W-tap using GLFW.");
   }

   @EventHandler
   private void onAttack(AttackEntityEvent event) {
      if (event.entity instanceof PlayerEntity && this.mc.player != null) {
         if ((Boolean)this.sTap.get()) {
            this.sTapReleaseTime = System.currentTimeMillis() + ((Integer)this.tapDuration.get()).intValue();
            this.sTapActive = true;
            this.simulateKey(83, true);
         }

         if ((Boolean)this.wTap.get() && this.mc.options.forwardKey.isPressed()) {
            this.wTapRePressTime = System.currentTimeMillis() + ((Integer)this.wTapDuration.get()).intValue();
            this.wTapActive = true;
            this.simulateKey(87, false);
         }
      }
   }

   @EventHandler
   private void onTickUpdate(Pre event) {
      long currentTime = System.currentTimeMillis();
      if (this.sTapActive && currentTime >= this.sTapReleaseTime) {
         this.simulateKey(83, false);
         this.sTapActive = false;
      }

      if (this.wTapActive && currentTime >= this.wTapRePressTime) {
         this.simulateKey(87, true);
         this.wTapActive = false;
      }
   }

   private void simulateKey(int keyCode, boolean press) {
      if (this.mc.getWindow() != null && this.mc.keyboard != null) {
         int action = press ? 1 : 0;
         this.mc.keyboard.onKey(this.mc.getWindow().getHandle(), action, new net.minecraft.client.input.KeyInput(keyCode, 0, 0));
      }
   }
}
