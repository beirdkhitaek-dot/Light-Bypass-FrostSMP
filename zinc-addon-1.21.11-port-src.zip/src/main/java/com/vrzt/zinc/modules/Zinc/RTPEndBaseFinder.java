package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.text.Text;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.DropperBlockEntity;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.block.entity.BarrelBlockEntity;

public class RTPEndBaseFinder extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
   private final Setting<List<BlockEntityType<?>>> storageBlocks = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("storage-blocks")).description("Select the storage blocks to search for."))
            .defaultValue(StorageBlockListSetting.STORAGE_BLOCKS)
            .build()
      );
   private final Setting<Integer> minimumStorageCount = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("minimum-storage-count"))
                  .description("The minimum amount of storage blocks in a chunk to record the chunk (spawners ignore this limit)."))
               .defaultValue(4))
            .min(1)
            .sliderMax(100)
            .build()
      );
   private final Setting<Boolean> criticalSpawner = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("critical-spawner"))
                  .description("Mark chunk as stash even if only a single spawner is found."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> rtpInterval = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("rtp-interval"))
                  .description("Interval between RTP commands in seconds."))
               .defaultValue(1))
            .min(1)
            .sliderMax(60000)
            .build()
      );
   private final Setting<Boolean> disconnectOnBaseFind = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("disconnect-on-base-find"))
                  .description("Automatically disconnect when a base is found."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> sendNotifications = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("notifications"))
                  .description("Sends Minecraft notifications when new stashes are found."))
               .defaultValue(true))
            .build()
      );
   private final Setting<RTPEndBaseFinder.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("notification-mode"))
                     .description("The mode to use for notifications."))
                  .defaultValue(RTPEndBaseFinder.Mode.Both))
               .visible(this.sendNotifications::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("webhook"))
                  .description("Send webhook notifications when stashes are found"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("webhook-url"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("self-ping"))
                     .description("Ping yourself in the webhook message"))
                  .defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("discord-id"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   public List<RTPEndBaseFinder.EndStashChunk> foundStashes = new ArrayList<>();
   private final Set<ChunkPos> processedChunks = new HashSet<>();
   private long lastRtpTime = 0L;
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();
   private final Random random = new Random();
   private long nextJumpTime = 0L;
   private long nextSneakTime = 0L;
   private long nextFullTurnTime = 0L;
   private long nextSmallLookTime = 0L;
   private boolean doingFullTurn = false;
   private float targetYaw = 0.0F;

   public RTPEndBaseFinder() {
      super(ZincAddon.Zinc, "RTPEndBaseFinder", "RTPs in the End, scans stashes, jumps/sneaks every 11-16s, and looks around (no walking).");
   }

   public void onActivate() {
      this.foundStashes.clear();
      this.processedChunks.clear();
      this.lastRtpTime = 0L;
      this.resetBehavior();
      this.info("Started RTP End Base Finder (jump/sneak + looking only)", new Object[0]);
   }

   public void onDeactivate() {
      this.releaseAllKeys();
      this.processedChunks.clear();
   }

   private void resetBehavior() {
      long now = System.currentTimeMillis();
      this.nextJumpTime = now + 11000L + this.random.nextInt(5000);
      this.nextSneakTime = now + 11000L + this.random.nextInt(5000);
      this.nextFullTurnTime = now + 8000L + this.random.nextInt(7000);
      this.nextSmallLookTime = now + 2000L + this.random.nextInt(3000);
      this.doingFullTurn = false;
      this.targetYaw = this.mc.player.getYaw();
      this.releaseAllKeys();
   }

   private void releaseAllKeys() {
      if (this.mc.options != null) {
         this.mc.options.jumpKey.setPressed(false);
         this.mc.options.sneakKey.setPressed(false);
      }
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.options != null) {
         long currentTime = System.currentTimeMillis();
         if (currentTime - this.lastRtpTime >= ((Integer)this.rtpInterval.get()).intValue() * 1000L) {
            ChatUtils.sendPlayerMsg("/rtp end");
            this.lastRtpTime = currentTime;
            this.resetBehavior();
         }

         if (currentTime > this.nextJumpTime && this.mc.player.isOnGround()) {
            this.mc.options.jumpKey.setPressed(true);
            Executors.newSingleThreadScheduledExecutor().schedule(() -> {
               if (this.mc.options != null) {
                  this.mc.options.jumpKey.setPressed(false);
               }
            }, (long)(400 + this.random.nextInt(300)), TimeUnit.MILLISECONDS);
            this.nextJumpTime = currentTime + 11000L + this.random.nextInt(5000);
         }

         if (currentTime > this.nextSneakTime) {
            this.mc.options.sneakKey.setPressed(true);
            int sneakDuration = 2000 + this.random.nextInt(2000);
            Executors.newSingleThreadScheduledExecutor().schedule(() -> {
               if (this.mc.options != null) {
                  this.mc.options.sneakKey.setPressed(false);
               }
            }, (long)sneakDuration, TimeUnit.MILLISECONDS);
            this.nextSneakTime = currentTime + 11000L + this.random.nextInt(5000);
         }

         if (currentTime > this.nextFullTurnTime && !this.doingFullTurn) {
            this.doingFullTurn = true;
            this.targetYaw = this.mc.player.getYaw() + 360.0F;
            this.nextFullTurnTime = currentTime + 15000L + this.random.nextInt(10000);
         }

         if (currentTime > this.nextSmallLookTime) {
            if (!this.doingFullTurn || this.random.nextFloat() < 0.4F) {
               this.targetYaw = this.mc.player.getYaw() + (this.random.nextFloat() - 0.5F) * 80.0F;
               this.mc.player.setPitch(MathHelper.clamp((this.random.nextFloat() - 0.5F) * 50.0F, -50.0F, 40.0F));
            }

            this.nextSmallLookTime = currentTime + 2000L + this.random.nextInt(4000);
         }

         float yawDiff = MathHelper.wrapDegrees(this.targetYaw - this.mc.player.getYaw());
         float rotationSpeed = this.doingFullTurn ? 4.0F : 2.5F;
         float yawStep = MathHelper.clamp(yawDiff, -rotationSpeed, rotationSpeed);
         this.mc.player.setYaw(this.mc.player.getYaw() + yawStep);
         this.mc.player.setYaw(this.mc.player.getYaw() + (this.random.nextFloat() - 0.5F) * 0.7F);
         this.mc.player.setPitch(MathHelper.clamp(this.mc.player.getPitch() + (this.random.nextFloat() - 0.5F) * 1.2F, -90.0F, 90.0F));
         if (this.doingFullTurn && Math.abs(yawDiff) < 6.0F) {
            this.doingFullTurn = false;
         }
      } else {
         if (this.isActive()) {
            this.toggle();
         }
      }
   }

   @EventHandler
   private void onChunkData(ChunkDataEvent event) {
      if (this.mc.player != null) {
         ChunkPos chunkPos = event.chunk().getPos();
         if (!this.processedChunks.contains(chunkPos)) {
            RTPEndBaseFinder.EndStashChunk chunk = new RTPEndBaseFinder.EndStashChunk(chunkPos);
            boolean hasSpawner = false;

            for (int x = 0; x < 16; x++) {
               for (int z = 0; z < 16; z++) {
                  for (int y = 0; y < 80; y++) {
                     BlockPos pos = new BlockPos(chunkPos.getStartX() + x, y, chunkPos.getStartZ() + z);
                     if (this.mc.world.getBlockState(pos).getBlock() == Blocks.field_10260) {
                        chunk.spawners++;
                        hasSpawner = true;
                     }
                  }
               }
            }

            for (BlockEntity blockEntity : event.chunk().getBlockEntities().values()) {
               BlockEntityType<?> type = blockEntity.getType();
               if (((List)this.storageBlocks.get()).contains(type)) {
                  if (blockEntity instanceof ChestBlockEntity) {
                     chunk.chests++;
                  } else if (blockEntity instanceof BarrelBlockEntity) {
                     chunk.barrels++;
                  } else if (blockEntity instanceof ShulkerBoxBlockEntity) {
                     chunk.shulkers++;
                  } else if (blockEntity instanceof EnderChestBlockEntity) {
                     chunk.enderChests++;
                  } else if (blockEntity instanceof AbstractFurnaceBlockEntity) {
                     chunk.furnaces++;
                  } else if (blockEntity instanceof DispenserBlockEntity || blockEntity instanceof DropperBlockEntity) {
                     chunk.dispensersDroppers++;
                  } else if (blockEntity instanceof HopperBlockEntity) {
                     chunk.hoppers++;
                  }
               }
            }

            boolean isStash = false;
            boolean isCriticalSpawner = false;
            String detectionReason = "";
            if ((Boolean)this.criticalSpawner.get() && hasSpawner) {
               isStash = true;
               isCriticalSpawner = true;
               detectionReason = "Spawner(s) detected (Critical mode)";
            } else if (chunk.getTotalNonSpawner() >= (Integer)this.minimumStorageCount.get()) {
               isStash = true;
               detectionReason = "Storage threshold reached (" + chunk.getTotalNonSpawner() + " blocks)";
            }

            if (isStash) {
               this.processedChunks.add(chunkPos);
               RTPEndBaseFinder.EndStashChunk prevChunk = null;
               int existingIndex = this.foundStashes.indexOf(chunk);
               if (existingIndex < 0) {
                  this.foundStashes.add(chunk);
               } else {
                  prevChunk = this.foundStashes.set(existingIndex, chunk);
               }

               boolean newOrUpdated = prevChunk == null || !chunk.countsEqual(prevChunk);
               if ((Boolean)this.sendNotifications.get() && newOrUpdated) {
                  String stashType = isCriticalSpawner ? "End spawner base" : "End stash";
                  switch ((RTPEndBaseFinder.Mode)this.notificationMode.get()) {
                     case Chat:
                        this.info("Found %s at (highlight)%d(default), (highlight)%d(default). %s", new Object[]{stashType, chunk.x, chunk.z, detectionReason});
                        break;
                     case Toast:
                        this.mc
                           .getToastManager()
                           .add(
                              new MeteorToast(
                                 Items.ENDER_CHEST, this.title, "Found " + stashType.substring(0, 1).toUpperCase() + stashType.substring(1) + "!"
                              )
                           );
                        break;
                     case Both:
                        this.info("Found %s at (highlight)%d(default), (highlight)%d(default). %s", new Object[]{stashType, chunk.x, chunk.z, detectionReason});
                        this.mc
                           .getToastManager()
                           .add(
                              new MeteorToast(
                                 Items.ENDER_CHEST, this.title, "Found " + stashType.substring(0, 1).toUpperCase() + stashType.substring(1) + "!"
                              )
                           );
                  }
               }

               if ((Boolean)this.enableWebhook.get() && newOrUpdated) {
                  this.sendWebhookNotification(chunk, isCriticalSpawner, detectionReason);
               }

               if ((Boolean)this.disconnectOnBaseFind.get()) {
                  String stashTypeForDisconnect = isCriticalSpawner ? "End spawner base" : "End stash";
                  this.disconnectPlayer(stashTypeForDisconnect, chunk);
               }
            }
         }
      }
   }

   private void disconnectPlayer(String stashType, RTPEndBaseFinder.EndStashChunk chunk) {
      this.info("Disconnecting due to " + stashType + " found at " + chunk.x + ", " + chunk.z, new Object[0]);
      this.toggle();
      Executors.newSingleThreadScheduledExecutor().schedule(() -> {
         if (this.mc.player != null && this.mc.player.networkHandler != null) {
            this.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(Text.literal("END STASH FOUND AT " + chunk.x + ", " + chunk.z + "!")));
         }
      }, 1L, TimeUnit.SECONDS);
   }

   private void sendWebhookNotification(RTPEndBaseFinder.EndStashChunk chunk, boolean isCriticalSpawner, String detectionReason) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (url.isEmpty()) {
         this.warning("Webhook URL not configured!", new Object[0]);
      } else {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
                  String messageContent = this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()
                     ? String.format("<@%s> ", ((String)this.discordId.get()).trim())
                     : "";
                  String stashType = isCriticalSpawner ? "End Spawner Base" : "End Stash";
                  String description = String.format("%s found at End coordinates %d, %d!", stashType, chunk.x, chunk.z);
                  StringBuilder itemsFound = new StringBuilder();
                  int totalItems = 0;
                  if (chunk.chests > 0) {
                     itemsFound.append("Chests: ").append(chunk.chests).append("\\n");
                     totalItems += chunk.chests;
                  }

                  if (chunk.barrels > 0) {
                     itemsFound.append("Barrels: ").append(chunk.barrels).append("\\n");
                     totalItems += chunk.barrels;
                  }

                  if (chunk.shulkers > 0) {
                     itemsFound.append("Shulker Boxes: ").append(chunk.shulkers).append("\\n");
                     totalItems += chunk.shulkers;
                  }

                  if (chunk.enderChests > 0) {
                     itemsFound.append("Ender Chests: ").append(chunk.enderChests).append("\\n");
                     totalItems += chunk.enderChests;
                  }

                  if (chunk.furnaces > 0) {
                     itemsFound.append("Furnaces: ").append(chunk.furnaces).append("\\n");
                     totalItems += chunk.furnaces;
                  }

                  if (chunk.dispensersDroppers > 0) {
                     itemsFound.append("Dispensers/Droppers: ").append(chunk.dispensersDroppers).append("\\n");
                     totalItems += chunk.dispensersDroppers;
                  }

                  if (chunk.hoppers > 0) {
                     itemsFound.append("Hoppers: ").append(chunk.hoppers).append("\\n");
                     totalItems += chunk.hoppers;
                  }

                  if (isCriticalSpawner) {
                     itemsFound.append("Spawners: Present\\n");
                  }

                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"RTP End-Stashfinder\",\"embeds\":[{\"title\":\"\ud83c\udf0c End Stashfinder Alert\",\"description\":\"%s\",\"color\":%d,\"fields\":[{\"name\":\"Detection Reason\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Total Items Found\",\"value\":\"%d\",\"inline\":false},{\"name\":\"Items Breakdown\",\"value\":\"%s\",\"inline\":false},{\"name\":\"End Coordinates\",\"value\":\"%d, %d\",\"inline\":true},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"RTP End-Stashfinder\"}}]}",
                     messageContent.replace("\"", "\\\""),
                     description.replace("\"", "\\\""),
                     isCriticalSpawner ? 9830144 : 8388736,
                     detectionReason.replace("\"", "\\\""),
                     totalItems,
                     itemsFound.toString().isEmpty() ? "None" : itemsFound.toString().replace("\"", "\\\""),
                     chunk.x,
                     chunk.z,
                     serverInfo.replace("\"", "\\\""),
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .timeout(Duration.ofSeconds(30L))
                     .build();
                  HttpResponse<String> response = this.httpClient.send(request, BodyHandlers.ofString());
                  if (response.statusCode() == 204) {
                     this.info("Webhook notification sent successfully", new Object[0]);
                  } else {
                     this.error("Webhook failed with status: " + response.statusCode(), new Object[0]);
                  }
               } catch (InterruptedException | IOException var14) {
                  this.error("Failed to send webhook: " + var14.getMessage(), new Object[0]);
               }
            }
         );
      }
   }

   public String getInfoString() {
      return String.valueOf(this.foundStashes.size());
   }

   public static class EndStashChunk {
      public ChunkPos chunkPos;
      public transient int x;
      public transient int z;
      public int chests;
      public int barrels;
      public int shulkers;
      public int enderChests;
      public int furnaces;
      public int dispensersDroppers;
      public int hoppers;
      public int spawners;

      public EndStashChunk(ChunkPos chunkPos) {
         this.chunkPos = chunkPos;
         this.calculatePos();
      }

      public void calculatePos() {
         this.x = this.chunkPos.x * 16 + 8;
         this.z = this.chunkPos.z * 16 + 8;
      }

      public int getTotal() {
         return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers + this.spawners;
      }

      public int getTotalNonSpawner() {
         return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers;
      }

      public boolean countsEqual(RTPEndBaseFinder.EndStashChunk c) {
         return c == null
            ? false
            : this.chests == c.chests
               && this.barrels == c.barrels
               && this.shulkers == c.shulkers
               && this.enderChests == c.enderChests
               && this.furnaces == c.furnaces
               && this.dispensersDroppers == c.dispensersDroppers
               && this.hoppers == c.hoppers
               && this.spawners == c.spawners;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            RTPEndBaseFinder.EndStashChunk chunk = (RTPEndBaseFinder.EndStashChunk)o;
            return Objects.equals(this.chunkPos, chunk.chunkPos);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         return Objects.hash(this.chunkPos);
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }
}
