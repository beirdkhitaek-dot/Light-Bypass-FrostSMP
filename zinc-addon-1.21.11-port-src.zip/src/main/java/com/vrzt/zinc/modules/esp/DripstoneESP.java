package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.MeteorToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.block.PointedDripstoneBlock;

public class DripstoneESP extends Module {
   private final SettingGroup sgStalactite = this.settings.createGroup("Stalactite ESP");
   private final SettingGroup sgStalagmite = this.settings.createGroup("Stalagmite ESP");
   private final SettingGroup sgThreading = this.settings.createGroup("Threading");
   private final SettingGroup sgNotifications = this.settings.createGroup("Notifications");
   private final Setting<SettingColor> stalactiteColor = this.sgStalactite
      .add(((Builder)new Builder().name("esp-color")).defaultValue(new SettingColor(128, 128, 128, 100)).build());
   private final Setting<ShapeMode> stalactiteShapeMode = this.sgStalactite
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                  .name("shape-mode"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> stalactiteTracers = this.sgStalactite
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("tracers"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> stalactiteTracerColor = this.sgStalactite
      .add(
         ((Builder)((Builder)new Builder().name("tracer-color")).defaultValue(new SettingColor(128, 128, 128, 200)).visible(this.stalactiteTracers::get))
            .build()
      );
   private final Setting<Integer> stalactiteMinLength = this.sgStalactite
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("min-length"))
               .defaultValue(4))
            .min(4)
            .max(16)
            .build()
      );
   private final Setting<SettingColor> stalagmiteColor = this.sgStalagmite
      .add(((Builder)new Builder().name("esp-color")).defaultValue(new SettingColor(160, 160, 160, 100)).build());
   private final Setting<ShapeMode> stalagmiteShapeMode = this.sgStalagmite
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                  .name("shape-mode"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> stalagmiteTracers = this.sgStalagmite
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("tracers"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> stalagmiteTracerColor = this.sgStalagmite
      .add(
         ((Builder)((Builder)new Builder().name("tracer-color")).defaultValue(new SettingColor(160, 160, 160, 200)).visible(this.stalagmiteTracers::get))
            .build()
      );
   private final Setting<Integer> stalagmiteMinLength = this.sgStalagmite
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("min-length"))
               .defaultValue(8))
            .min(4)
            .max(16)
            .build()
      );
   private final Setting<Boolean> showNotifications = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("notifications"))
               .defaultValue(true))
            .build()
      );
   private final Setting<DripstoneESP.Mode> notificationMode = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-mode"))
                  .defaultValue(DripstoneESP.Mode.Both))
               .visible(this.showNotifications::get))
            .build()
      );
   private final Setting<Integer> notificationLengthThreshold = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("notification-length"))
                  .defaultValue(8))
               .min(4)
               .max(20)
               .visible(this.showNotifications::get))
            .build()
      );
   private final Setting<Boolean> useThreading = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("enable-threading"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> threadPoolSize = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("thread-pool-size"))
                  .defaultValue(2))
               .min(1)
               .max(8)
               .visible(this.useThreading::get))
            .build()
      );
   private final Set<BlockPos> longStalactiteBottoms = ConcurrentHashMap.newKeySet();
   private final Set<BlockPos> longStalagmiteTops = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;

   public DripstoneESP() {
      super(ZincAddon.esp, "DripstoneESP", "ESP for long dripstones with tracers and threading.");
   }

   public void onActivate() {
      if ((Boolean)this.useThreading.get()) {
         this.threadPool = Executors.newFixedThreadPool((Integer)this.threadPoolSize.get());
      }

      this.longStalactiteBottoms.clear();
      this.longStalagmiteTops.clear();

      for (Chunk chunk : Utils.chunks()) {
         if (chunk instanceof WorldChunk wc) {
            if ((Boolean)this.useThreading.get()) {
               this.threadPool.submit(() -> this.scanChunk(wc));
            } else {
               this.scanChunk(wc);
            }
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdown();
         this.threadPool = null;
      }

      this.longStalactiteBottoms.clear();
      this.longStalagmiteTops.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if ((Boolean)this.useThreading.get() && this.threadPool != null) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      } else {
         this.scanChunk(event.chunk());
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      Runnable scanTask = () -> {
         if (event.newState.isOf(Blocks.field_28048)) {
            for (int dx = -2; dx <= 2; dx++) {
               for (int dz = -2; dz <= 2; dz++) {
                  for (int dy = -16; dy <= 16; dy++) {
                     BlockPos scanPos = event.pos.method_10069(dx, dy, dz);
                     BlockState scanState = this.mc.world.getBlockState(scanPos);
                     if (this.isDripstoneTipDown(scanState)) {
                        DripstoneESP.StalactiteInfo info = this.getStalactiteInfo(scanPos);
                        if (info != null && info.length >= (Integer)this.stalactiteMinLength.get() && this.longStalactiteBottoms.add(info.bottomPos)) {
                           this.notifyDripstoneFound("Stalactite", scanPos, info.length);
                        }
                     }

                     if (this.isDripstoneTipUp(scanState)) {
                        DripstoneESP.StalagmiteInfo info = this.getStalagmiteInfo(scanPos);
                        if (info != null && info.length >= (Integer)this.stalagmiteMinLength.get() && this.longStalagmiteTops.add(info.topPos)) {
                           this.notifyDripstoneFound("Stalagmite", scanPos, info.length);
                        }
                     }
                  }
               }
            }
         }
      };
      if ((Boolean)this.useThreading.get() && this.threadPool != null) {
         this.threadPool.submit(scanTask);
      } else {
         scanTask.run();
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      for (BlockPos pos : this.longStalactiteBottoms) {
         double distSq = this.mc.player.getEntityPos().squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
         if (!(distSq > 10000.0)) {
            Color color = new Color((Color)this.stalactiteColor.get());
            event.renderer.box(pos, color, color, (ShapeMode)this.stalactiteShapeMode.get(), 0);
            if ((Boolean)this.stalactiteTracers.get()) {
               event.renderer
                  .line(
                     RenderUtils.center.x,
                     RenderUtils.center.y,
                     RenderUtils.center.z,
                     pos.getX() + 0.5,
                     pos.getY() + 0.5,
                     pos.getZ() + 0.5,
                     (Color)this.stalactiteTracerColor.get()
                  );
            }
         }
      }

      for (BlockPos posx : this.longStalagmiteTops) {
         double distSq = this.mc.player.getEntityPos().squaredDistanceTo(posx.getX() + 0.5, posx.getY() + 0.5, posx.getZ() + 0.5);
         if (!(distSq > 10000.0)) {
            Color color = new Color((Color)this.stalagmiteColor.get());
            event.renderer.box(posx, color, color, (ShapeMode)this.stalagmiteShapeMode.get(), 0);
            if ((Boolean)this.stalagmiteTracers.get()) {
               event.renderer
                  .line(
                     RenderUtils.center.x,
                     RenderUtils.center.y,
                     RenderUtils.center.z,
                     posx.getX() + 0.5,
                     posx.getY() + 0.5,
                     posx.getZ() + 0.5,
                     (Color)this.stalagmiteTracerColor.get()
                  );
            }
         }
      }
   }

   private void scanChunk(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();

      for (int x = cpos.getStartX(); x < cpos.getStartX() + 16; x++) {
         for (int z = cpos.getStartZ(); z < cpos.getStartZ() + 16; z++) {
            for (int y = chunk.getBottomY(); y < chunk.getBottomY() + chunk.getHeight(); y++) {
               BlockPos pos = new BlockPos(x, y, z);
               BlockState state = chunk.getBlockState(pos);
               if (this.isDripstoneTipDown(state)) {
                  DripstoneESP.StalactiteInfo info = this.getStalactiteInfo(pos);
                  if (info != null && info.length >= (Integer)this.stalactiteMinLength.get()) {
                     this.longStalactiteBottoms.add(info.bottomPos);
                  }
               } else if (this.isDripstoneTipUp(state)) {
                  DripstoneESP.StalagmiteInfo info = this.getStalagmiteInfo(pos);
                  if (info != null && info.length >= (Integer)this.stalagmiteMinLength.get()) {
                     this.longStalagmiteTops.add(info.topPos);
                  }
               }
            }
         }
      }
   }

   private boolean isDripstoneTipDown(BlockState state) {
      return state.isOf(Blocks.field_28048)
         && state.contains(PointedDripstoneBlock.VERTICAL_DIRECTION)
         && state.get(PointedDripstoneBlock.VERTICAL_DIRECTION) == Direction.field_11033;
   }

   private boolean isDripstoneTipUp(BlockState state) {
      return state.isOf(Blocks.field_28048)
         && state.contains(PointedDripstoneBlock.VERTICAL_DIRECTION)
         && state.get(PointedDripstoneBlock.VERTICAL_DIRECTION) == Direction.field_11036;
   }

   private DripstoneESP.StalactiteInfo getStalactiteInfo(BlockPos tipPos) {
      if (this.mc.world == null) {
         return null;
      } else {
         int length = 0;
         BlockPos current = tipPos;

         BlockPos bottom;
         for (bottom = tipPos;
            current.getY() >= this.mc.world.getBottomY() && this.isDripstoneTipDown(this.mc.world.getBlockState(current));
            current = current.method_10074()
         ) {
            length++;
            bottom = current;
         }

         return length > 0 ? new DripstoneESP.StalactiteInfo(length, bottom) : null;
      }
   }

   private DripstoneESP.StalagmiteInfo getStalagmiteInfo(BlockPos tipPos) {
      if (this.mc.world == null) {
         return null;
      } else {
         int length = 0;
         BlockPos current = tipPos;

         BlockPos top;
         for (top = tipPos; current.getY() < 320 && this.isDripstoneTipUp(this.mc.world.getBlockState(current)); current = current.up()) {
            length++;
            top = current;
         }

         return length > 0 ? new DripstoneESP.StalagmiteInfo(length, top) : null;
      }
   }

   private void notifyDripstoneFound(String type, BlockPos pos, int length) {
      if ((Boolean)this.showNotifications.get() && length >= (Integer)this.notificationLengthThreshold.get()) {
         String msg = String.format("%s found at [%d, %d, %d] (len: %d)", type, pos.getX(), pos.getY(), pos.getZ(), length);
         String subText = type + " (" + length + ")";
         if (this.notificationMode.get() == DripstoneESP.Mode.Chat || this.notificationMode.get() == DripstoneESP.Mode.Both) {
            this.info("(highlight)%s", new Object[]{msg});
         }

         if (this.notificationMode.get() == DripstoneESP.Mode.Toast || this.notificationMode.get() == DripstoneESP.Mode.Both) {
            this.mc.getToastManager().add(new DripstoneESP.DripstoneToast(Items.POINTED_DRIPSTONE.getDefaultStack(), "DripstoneESP", subText));
         }
      }
   }

   private static class DripstoneToast extends MeteorToast {
      private final String customTitle;
      private final String customDesc;

      public DripstoneToast(ItemStack icon, String title, String desc) {
         super(icon.getItem(), title, desc);
         this.customTitle = title;
         this.customDesc = desc;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int grey = -8355712;
         context.fill(0, 0, 160, 1, grey);
         context.fill(0, 31, 160, 32, grey);
         context.fill(0, 1, 1, 31, grey);
         context.fill(159, 1, 160, 31, grey);
         context.drawItem(Items.POINTED_DRIPSTONE.getDefaultStack(), 8, 8);
         context.drawText(textRenderer, this.customTitle, 32, 7, 16777215, false);
         context.drawText(textRenderer, this.customDesc, 32, 18, -8355712, false);
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }

   private static class StalactiteInfo {
      final int length;
      final BlockPos bottomPos;

      StalactiteInfo(int length, BlockPos bottomPos) {
         this.length = length;
         this.bottomPos = bottomPos;
      }
   }

   private static class StalagmiteInfo {
      final int length;
      final BlockPos topPos;

      StalagmiteInfo(int length, BlockPos topPos) {
         this.length = length;
         this.topPos = topPos;
      }
   }
}
