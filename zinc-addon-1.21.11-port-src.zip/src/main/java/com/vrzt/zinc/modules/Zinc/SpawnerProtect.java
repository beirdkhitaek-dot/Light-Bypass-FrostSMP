package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;

public class SpawnerProtect extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgWhitelist;
   private final SettingGroup sgWebhook;
   private final Setting<Boolean> webhook;
   private final Setting<String> webhookUrl;
   private final Setting<Boolean> selfPing;
   private final Setting<String> discordId;
   private final Setting<List<String>> whitelistPlayers;
   private static final int SPAWNER_RANGE = 50;
   private static final double POSITION_TOLERANCE = 5.0;
   private static final boolean AUTO_RECALIBRATE = true;
   private static final int RECALIBRATE_DELAY = 0;
   private SpawnerProtect.State currentState;
   private String detectedPlayer;
   private long detectionTime;
   private boolean spawnersMinedSuccessfully;
   private boolean itemsDepositedSuccessfully;
   private int tickCounter;
   private boolean chestOpened;
   private int lastProcessedSlot;
   private boolean sneaking;
   private BlockPos currentTarget;
   private int confirmDelay;
   private boolean waiting;
   private boolean isMining;
   private BlockPos targetChest;
   private int chestOpenAttempts;
   private Vec3d startPosition;
   private boolean positionTracked;
   private int positionCheckTimer;
   private boolean isAttackKeyHeld;
   private int spawnersTransferred;
   private int stationaryTicks;
   private static final int TICKS_PER_CHECK = 10;
   private int recalibrationAttempts;
   private int calibrationTicks;
   private boolean firstActivation = true;
   private final MinecraftClient mc = MinecraftClient.getInstance();

   public SpawnerProtect() {
      super(
         ZincAddon.Zinc,
         "SpawnerProtect",
         "Automatically moves to and mines spawners, then stores them in an ender chest when a player is detected, with a configurable delay between spawner stack transfers."
      );
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgWhitelist = this.settings.createGroup("Whitelist");
      this.sgWebhook = this.settings.createGroup("Webhook");
      this.webhook = this.sgWebhook
         .add(((Builder)((Builder)((Builder)new Builder().name("webhook")).description("Enable Discord webhook notifications.")).defaultValue(false)).build());
      this.webhookUrl = this.sgWebhook
         .add(
            ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                           .name("webhook-url"))
                        .description("Discord webhook URL for notifications."))
                     .defaultValue(""))
                  .visible(this.webhook::get))
               .build()
         );
      this.selfPing = this.sgWebhook
         .add(
            ((Builder)((Builder)((Builder)((Builder)new Builder().name("self-ping")).description("Ping yourself in the webhook message.")).defaultValue(false))
                  .visible(this.webhook::get))
               .build()
         );
      this.discordId = this.sgWebhook
         .add(
            ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                           .name("discord-id"))
                        .description("Your Discord user ID for pinging."))
                     .defaultValue(""))
                  .visible(() -> (Boolean)this.webhook.get() && (Boolean)this.selfPing.get()))
               .build()
         );
      this.whitelistPlayers = this.sgWhitelist
         .add(
            ((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)new meteordevelopment.meteorclient.settings.StringListSetting.Builder()
                           .name("whitelisted-players"))
                        .description("List of player names to ignore (Whitelist is permanently enabled). 'venom' cannot be removed."))
                     .defaultValue(new ArrayList<>(List.of("venom"))))
                  .onChanged(list -> {
                     if (!list.contains("venom")) {
                        list.add("venom");
                        ChatUtils.error("Player 'venom' cannot be removed from the whitelist!", new Object[0]);
                     }
                  }))
               .build()
         );
      this.resetState();
   }

   public void onActivate() {
      this.resetState();
      this.firstActivation = false;
      if (this.mc.player != null) {
         this.currentState = SpawnerProtect.State.AWAITING_RECALIBRATION;
         this.positionTracked = false;
         this.startPosition = null;
         this.calibrationTicks = 0;
         this.info("SpawnerProtect activated.", new Object[0]);
         this.info("Calibrating position... Stand at your base.", new Object[0]);
      }

      ChatUtils.warning("Ensure your inventory is empty except for a silk touch pickaxe and an ender chest nearby!", new Object[0]);
   }

   private void resetState() {
      this.currentState = SpawnerProtect.State.AWAITING_RECALIBRATION;
      this.detectedPlayer = "";
      this.detectionTime = 0L;
      this.spawnersMinedSuccessfully = false;
      this.itemsDepositedSuccessfully = false;
      this.tickCounter = 0;
      this.chestOpened = false;
      this.lastProcessedSlot = -1;
      this.sneaking = false;
      this.currentTarget = null;
      this.confirmDelay = 0;
      this.waiting = false;
      this.isMining = false;
      this.targetChest = null;
      this.chestOpenAttempts = 0;
      this.positionCheckTimer = 0;
      this.isAttackKeyHeld = false;
      this.stationaryTicks = 0;
      this.spawnersTransferred = 0;
      this.recalibrationAttempts = 0;
      this.calibrationTicks = 0;
      this.positionTracked = false;
      this.startPosition = null;
      this.releaseAllKeys();
   }

   private void disableAutoReconnectIfEnabled() {
      Module autoReconnect = Modules.get().get(AutoReconnect.class);
      if (autoReconnect != null && autoReconnect.isActive()) {
         autoReconnect.toggle();
         this.info("AutoReconnect disabled due to player detection.", new Object[0]);
      }
   }

   private boolean isPlayerAtStartPosition() {
      return this.positionTracked && this.startPosition != null && this.mc.player != null
         ? this.mc.player.getEntityPos().distanceTo(this.startPosition) <= 5.0
         : false;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.tickCounter++;
         this.positionCheckTimer++;
         Vec3d currentPos = this.mc.player.getEntityPos();
         if (this.currentState == SpawnerProtect.State.AWAITING_RECALIBRATION) {
            this.calibrationTicks++;
            if (this.calibrationTicks >= 10) {
               this.startPosition = currentPos;
               this.positionTracked = true;
               this.currentState = SpawnerProtect.State.IDLE;
               this.info(
                  "Base position calibrated: %.1f, %.1f, %.1f",
                  new Object[]{this.startPosition.x, this.startPosition.y, this.startPosition.z}
               );
               this.info("SpawnerProtect now ACTIVE and monitoring for players!", new Object[0]);
            } else if (this.calibrationTicks == 1) {
               this.info("Calibrating position...", new Object[0]);
            }

            return;
         }

         if (this.positionCheckTimer >= 10) {
            this.positionCheckTimer = 0;
            if (!this.positionTracked || this.startPosition == null) {
               this.currentState = SpawnerProtect.State.AWAITING_RECALIBRATION;
               this.calibrationTicks = 0;
               this.info("Position lost. Recalibrating...", new Object[0]);
               return;
            }

            double dist = currentPos.distanceTo(this.startPosition);
            if (this.currentState == SpawnerProtect.State.IDLE && dist > 5.0) {
               this.currentState = SpawnerProtect.State.POSITION_DISPLACED;
               this.info("Left protected zone (%.1fm away). Paused until return.", new Object[]{dist});
            }

            if (this.currentState == SpawnerProtect.State.POSITION_DISPLACED && dist <= 5.0) {
               this.currentState = SpawnerProtect.State.IDLE;
               this.info("Returned to protected zone. Protection RESUMED.", new Object[0]);
            }
         }

         if ((
               this.currentState == SpawnerProtect.State.IDLE
                  || this.currentState == SpawnerProtect.State.GOING_TO_SPAWNERS
                  || this.currentState == SpawnerProtect.State.MINING_SPAWNER
                  || this.currentState == SpawnerProtect.State.GOING_TO_CHEST
                  || this.currentState == SpawnerProtect.State.OPENING_CHEST
                  || this.currentState == SpawnerProtect.State.DEPOSITING_ITEMS
                  || this.currentState == SpawnerProtect.State.DISCONNECTING
            )
            && this.isPlayerAtStartPosition()) {
            switch (this.currentState) {
               case IDLE:
                  this.checkForPlayers();
                  break;
               case GOING_TO_SPAWNERS:
               case MINING_SPAWNER:
                  this.handleGoingToSpawners();
                  break;
               case GOING_TO_CHEST:
                  this.handleGoingToChest();
                  break;
               case OPENING_CHEST:
                  this.handleOpeningChest();
                  break;
               case DEPOSITING_ITEMS:
                  this.handleDepositingItems();
                  break;
               case DISCONNECTING:
                  this.handleDisconnecting();
            }
         }
      }
   }

   private void checkForPlayers() {
      if (this.isPlayerAtStartPosition()) {
         for (Entity entity : this.mc.world.getEntities()) {
            if (entity instanceof PlayerEntity player && player != this.mc.player) {
               String playerName = player.getName().getString();
               if (!this.isPlayerWhitelisted(playerName)) {
                  this.detectedPlayer = playerName;
                  this.detectionTime = System.currentTimeMillis();
                  this.info("Player detected: %s", new Object[]{this.detectedPlayer});
                  this.disableAutoReconnectIfEnabled();
                  this.currentState = SpawnerProtect.State.GOING_TO_SPAWNERS;
                  this.setSneaking(false);
                  this.info("Starting protection sequence...", new Object[0]);
                  break;
               }
            }
         }
      }
   }

   private boolean isPlayerWhitelisted(String playerName) {
      return ((List)this.whitelistPlayers.get()).stream().anyMatch(whitelistedName -> whitelistedName.equalsIgnoreCase(playerName));
   }

   private void handleGoingToSpawners() {
      if (this.isMining) {
         this.setSneaking(true);
      } else {
         this.setSneaking(false);
      }

      if (!this.isMining && this.currentTarget == null) {
         this.currentTarget = this.findNearestSpawner();
         if (this.currentTarget == null && !this.waiting) {
            this.waiting = true;
            this.confirmDelay = 0;
            this.info("No spawners found, waiting to confirm...", new Object[0]);
         } else if (this.currentTarget != null) {
            this.info("Targeting spawner at %s", new Object[]{this.currentTarget});
            this.currentState = SpawnerProtect.State.GOING_TO_SPAWNERS;
         }
      } else if (this.currentTarget != null) {
         double distanceToSpawner = this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(this.currentTarget));
         if (distanceToSpawner > 4.5 && this.currentState == SpawnerProtect.State.GOING_TO_SPAWNERS) {
            this.moveTowardsBlock(this.currentTarget);
         } else {
            this.currentState = SpawnerProtect.State.MINING_SPAWNER;
            if (!this.isMining) {
               this.stopBreaking();
               this.isMining = true;
               this.info("Initiating mining of spawner at %s", new Object[]{this.currentTarget});
               this.setSneaking(true);
               if (this.mc.interactionManager != null) {
                  this.mc.interactionManager.attackBlock(this.currentTarget, Direction.field_11036);
               }
            }
         }
      }

      if (this.currentState == SpawnerProtect.State.MINING_SPAWNER && this.isMining && this.currentTarget != null) {
         this.lookAtBlock(this.currentTarget);
         this.breakBlock(this.currentTarget);
         if (this.mc.world.getBlockState(this.currentTarget).isAir()) {
            this.info("Spawner at %s mined!", new Object[]{this.currentTarget});
            this.stopBreaking();
            this.isMining = false;
            this.setSneaking(false);
            this.currentTarget = null;
            this.info("Checking for next spawner immediately...", new Object[0]);
            this.currentState = SpawnerProtect.State.GOING_TO_SPAWNERS;
         }
      }

      if (this.waiting) {
         this.handleWaitingForSpawners();
      }
   }

   private void handleWaitingForSpawners() {
      BlockPos foundSpawner = this.findNearestSpawner();
      if (foundSpawner != null) {
         this.waiting = false;
         this.currentTarget = foundSpawner;
         this.currentState = SpawnerProtect.State.GOING_TO_SPAWNERS;
         this.info("Found spawner at %s", new Object[]{foundSpawner});
      } else {
         this.confirmDelay++;
         if (this.confirmDelay >= 5) {
            this.stopBreaking();
            this.spawnersMinedSuccessfully = true;
            this.setSneaking(false);
            this.isMining = false;
            this.currentState = SpawnerProtect.State.GOING_TO_CHEST;
            this.info("All spawners mined. Moving to ender chest...", new Object[0]);
         }
      }
   }

   private BlockPos findNearestSpawner() {
      BlockPos playerPos = this.mc.player.getBlockPos();
      BlockPos nearestSpawner = null;
      double nearestDistance = Double.MAX_VALUE;

      for (BlockPos pos : BlockPos.iterate(playerPos.method_10069(-50, -50, -50), playerPos.method_10069(50, 50, 50))) {
         if (this.mc.world.getBlockState(pos).getBlock() == Blocks.field_10260) {
            double distance = pos.getSquaredDistance(this.mc.player.getEntityPos());
            if (distance < nearestDistance) {
               nearestDistance = distance;
               nearestSpawner = pos.toImmutable();
            }
         }
      }

      return nearestSpawner;
   }

   private void lookAtBlock(BlockPos pos) {
      Vec3d targetPos = Vec3d.ofCenter(pos);
      Vec3d playerPos = this.mc.player.getEyePos();
      Vec3d direction = targetPos.subtract(playerPos).normalize();
      double yaw = Math.toDegrees(Math.atan2(-direction.x, direction.z));
      double pitch = Math.toDegrees(-Math.asin(direction.y));
      this.mc.player.setYaw((float)yaw);
      this.mc.player.setPitch((float)pitch);
   }

   private void breakBlock(BlockPos pos) {
      if (this.mc.interactionManager != null && !this.isAttackKeyHeld) {
         this.mc.options.attackKey.setPressed(true);
         this.isAttackKeyHeld = true;
         this.mc.interactionManager.updateBlockBreakingProgress(pos, Direction.field_11036);
      }
   }

   private void stopBreaking() {
      if (this.mc.interactionManager != null) {
         this.mc.interactionManager.cancelBlockBreaking();
      }

      if (this.isAttackKeyHeld) {
         this.mc.options.attackKey.setPressed(false);
         this.isAttackKeyHeld = false;
      }
   }

   private void setSneaking(boolean sneak) {
      if (this.mc.options != null) {
         if (sneak && !this.sneaking) {
            this.mc.options.sneakKey.setPressed(true);
            this.sneaking = true;
         } else if (!sneak && this.sneaking) {
            this.mc.options.sneakKey.setPressed(false);
            this.sneaking = false;
         }
      }
   }

   private void moveTowardsBlock(BlockPos target) {
      Vec3d playerPos = this.mc.player.getEntityPos();
      Vec3d targetPos = Vec3d.ofCenter(target);
      Vec3d direction = targetPos.subtract(playerPos).normalize();
      double yaw = Math.toDegrees(Math.atan2(-direction.x, direction.z));
      this.mc.player.setYaw((float)yaw);
      this.mc.options.forwardKey.setPressed(true);
   }

   private void releaseMovementKeys() {
      if (this.mc.options != null) {
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.jumpKey.setPressed(false);
      }
   }

   private void releaseAllKeys() {
      if (this.mc.options != null) {
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.jumpKey.setPressed(false);
         this.mc.options.sneakKey.setPressed(false);
         this.mc.options.attackKey.setPressed(false);
      }
   }

   private void handleGoingToChest() {
      if (this.targetChest == null) {
         this.targetChest = this.findNearestEnderChest();
         if (this.targetChest == null) {
            this.info("No ender chest found nearby!", new Object[0]);
            this.currentState = SpawnerProtect.State.DISCONNECTING;
            return;
         }

         this.info("Found ender chest at %s", new Object[]{this.targetChest});
      }

      this.moveTowardsBlock(this.targetChest);
      if (this.mc.player.getBlockPos().getSquaredDistance(this.targetChest) <= 9.0) {
         this.currentState = SpawnerProtect.State.OPENING_CHEST;
         this.chestOpenAttempts = 0;
         this.releaseMovementKeys();
         this.info("Reached ender chest. Attempting to open...", new Object[0]);
      }
   }

   private BlockPos findNearestEnderChest() {
      BlockPos playerPos = this.mc.player.getBlockPos();
      BlockPos nearestChest = null;
      double nearestDistance = Double.MAX_VALUE;

      for (BlockPos pos : BlockPos.iterate(playerPos.method_10069(-16, -8, -16), playerPos.method_10069(16, 8, 16))) {
         if (this.mc.world.getBlockState(pos).getBlock() == Blocks.field_10443) {
            double distance = pos.getSquaredDistance(this.mc.player.getEntityPos());
            if (distance < nearestDistance) {
               nearestDistance = distance;
               nearestChest = pos.toImmutable();
            }
         }
      }

      return nearestChest;
   }

   private void handleOpeningChest() {
      if (this.targetChest == null) {
         this.currentState = SpawnerProtect.State.GOING_TO_CHEST;
      } else {
         if (this.chestOpenAttempts < 20) {
            this.lookAtBlock(this.targetChest);
         }

         if (this.chestOpenAttempts % 5 == 0 && this.mc.interactionManager != null && this.mc.player != null) {
            this.mc
               .interactionManager
               .interactBlock(
                  this.mc.player,
                  Hand.field_5808,
                  new BlockHitResult(Vec3d.ofCenter(this.targetChest), Direction.field_11036, this.targetChest, false)
               );
            this.info("Attempting to open ender chest (attempt %d)", new Object[]{this.chestOpenAttempts / 5 + 1});
         }

         this.chestOpenAttempts++;
         if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
            this.currentState = SpawnerProtect.State.DEPOSITING_ITEMS;
            this.chestOpened = true;
            this.lastProcessedSlot = -1;
            this.info("Ender chest opened successfully!", new Object[0]);
         }

         if (this.chestOpenAttempts > 200) {
            ChatUtils.error("Failed to open ender chest after multiple attempts!", new Object[0]);
            this.currentState = SpawnerProtect.State.DISCONNECTING;
         }
      }
   }

   private void handleDepositingItems() {
      if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler handler)) {
         this.currentState = SpawnerProtect.State.OPENING_CHEST;
         this.chestOpened = false;
         this.chestOpenAttempts = 0;
      } else if (!this.hasItemsToDeposit()) {
         this.itemsDepositedSuccessfully = true;
         this.info("All items deposited successfully! Transferred %d spawners to ender chest.", new Object[]{this.spawnersTransferred});
         this.mc.player.closeHandledScreen();
         this.currentState = SpawnerProtect.State.DISCONNECTING;
      } else {
         this.transferItemsToChest(handler);
      }
   }

   private boolean hasItemsToDeposit() {
      for (int i = 0; i < 36; i++) {
         ItemStack stack = this.mc.player.getInventory().getStack(i);
         if (!stack.isEmpty() && stack.getItem() != Items.AIR) {
            return true;
         }
      }

      return false;
   }

   private void transferItemsToChest(GenericContainerScreenHandler handler) {
      int totalSlots = handler.slots.size();
      int chestSlots = totalSlots - 36;
      int playerInventoryStart = chestSlots;
      int startSlot = Math.max(this.lastProcessedSlot + 1, chestSlots);

      for (int i = 0; i < 36; i++) {
         int slotId = playerInventoryStart + (startSlot - playerInventoryStart + i) % 36;
         ItemStack stack = handler.getSlot(slotId).getStack();
         if (!stack.isEmpty() && stack.getItem() != Items.AIR) {
            if (stack.getItem() == Items.SPAWNER) {
               this.spawnersTransferred = this.spawnersTransferred + stack.getCount();
               this.info("Transferring %d spawners from slot %d (Total transferred: %d)", new Object[]{stack.getCount(), slotId, this.spawnersTransferred});
            } else {
               this.info("Transferring item from slot %d: %s", new Object[]{slotId, stack.getItem().toString()});
            }

            if (this.mc.interactionManager != null) {
               this.mc.interactionManager.clickSlot(handler.syncId, slotId, 0, SlotActionType.QUICK_MOVE, this.mc.player);
            }

            this.lastProcessedSlot = slotId;
            return;
         }
      }

      if (this.lastProcessedSlot >= playerInventoryStart) {
         this.lastProcessedSlot = playerInventoryStart - 1;
      }
   }

   private void handleDisconnecting() {
      this.releaseAllKeys();
      this.sendWebhookNotification();
      String disconnectMessage = "Player detected " + this.detectedPlayer;
      this.info("%s", new Object[]{disconnectMessage});
      if (this.mc.getNetworkHandler() != null && this.mc.getNetworkHandler().getConnection() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal(disconnectMessage));
      }

      if (this.mc.world != null) {
         this.mc.world.disconnect(net.minecraft.text.Text.empty());
      }

      this.resetState();
      this.toggle();
   }

   private void sendWebhookNotification() {
      if ((Boolean)this.webhook.get() && this.webhookUrl.get() != null && !((String)this.webhookUrl.get()).trim().isEmpty()) {
         String webhookUrlValue = ((String)this.webhookUrl.get()).trim();
         long discordTimestamp = this.detectionTime / 1000L;
         String messageContent = this.selfPing.get() && this.discordId.get() != null && !((String)this.discordId.get()).trim().isEmpty()
            ? String.format("<@%s>", ((String)this.discordId.get()).trim())
            : "";
         String embedJson = this.createWebhookPayload(messageContent, discordTimestamp);
         new Thread(
               () -> {
                  try {
                     HttpClient client = HttpClient.newHttpClient();
                     HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(webhookUrlValue))
                        .header("Content-Type", "application/json")
                        .POST(BodyPublishers.ofString(embedJson))
                        .build();
                     HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
                     if (response.statusCode() >= 200 && response.statusCode() < 300) {
                        this.info("Webhook notification sent successfully!", new Object[0]);
                     } else {
                        ChatUtils.error("Failed to send webhook notification. Status: %d", new Object[]{response.statusCode()});
                     }
                  } catch (Exception var6) {
                     ChatUtils.error("Failed to send webhook notification: %s", new Object[]{var6.getMessage()});
                  }
               }
            )
            .start();
      } else {
         this.info("Webhook disabled or URL not configured.", new Object[0]);
      }
   }

   private String createWebhookPayload(String messageContent, long discordTimestamp) {
      String description = String.format(
         "**Player Detected:** %s\n**Detection Time:** <t:%d:R>\n**Spawners Transferred to Ender Chest:** %d\n**Items Deposited:** %s\n**Disconnected:** Yes",
         this.escapeJson(this.detectedPlayer),
         discordTimestamp,
         this.spawnersTransferred,
         this.itemsDepositedSuccessfully ? "Success" : "Failed"
      );
      return String.format(
         "{\n    \"username\": \"Zinc addon\",\n    \"content\": \"%s\",\n    \"embeds\": [{\n        \"title\": \"SpawnerProtect Alert\",\n        \"description\": \"%s\",\n        \"color\": 16766720,\n        \"timestamp\": \"%s\",\n        \"footer\": {\n            \"text\": \"Sent by Zinc addon\"\n        }\n    }]\n}",
         this.escapeJson(messageContent),
         description,
         Instant.now().toString()
      );
   }

   private String escapeJson(String input) {
      return input == null ? "" : input.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
   }

   public void onDeactivate() {
      this.releaseAllKeys();
      this.info("SpawnerProtect deactivated.", new Object[0]);
   }

   private static enum State {
      IDLE,
      GOING_TO_SPAWNERS,
      MINING_SPAWNER,
      GOING_TO_CHEST,
      OPENING_CHEST,
      DEPOSITING_ITEMS,
      DISCONNECTING,
      POSITION_DISPLACED,
      AWAITING_RECALIBRATION;

      private State() {
      }
   }
}
