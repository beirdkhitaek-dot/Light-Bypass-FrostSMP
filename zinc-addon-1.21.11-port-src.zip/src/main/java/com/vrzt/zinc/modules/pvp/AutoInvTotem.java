package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Items;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.lwjgl.glfw.GLFW;

public class AutoInvTotem extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> targetHotbarSlot = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("hotbar-slot")).description("The hotbar slot (1-9) to refill.")).defaultValue(1))
            .min(1)
            .max(9)
            .build()
      );
   private int delayTimer;
   private AutoInvTotem.Stage stage = AutoInvTotem.Stage.Idle;

   public AutoInvTotem() {
      super(ZincAddon.pvp, "auto-inv-totem", "5-Step Refill with Safety Stop.");
   }

   public void onActivate() {
      this.delayTimer = 0;
      this.stage = AutoInvTotem.Stage.Idle;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.getNetworkHandler() != null) {
         int totalTotems = this.countAllTotems();
         if (totalTotems <= 2) {
            if (this.stage != AutoInvTotem.Stage.Idle && this.mc.currentScreen instanceof InventoryScreen) {
               this.mc.player.closeHandledScreen();
            }

            this.stage = AutoInvTotem.Stage.Idle;
         } else {
            boolean offhandEmpty = !this.mc.player.getOffHandStack().isOf(Items.field_8288);
            int targetIdx = (Integer)this.targetHotbarSlot.get() - 1;
            boolean hotbarNeedsRefill = !this.mc.player.getInventory().getStack(targetIdx).isOf(Items.field_8288);
            switch (this.stage) {
               case Idle:
                  if (offhandEmpty || hotbarNeedsRefill) {
                     this.stage = AutoInvTotem.Stage.Step1_Tap;
                  }
                  break;
               case Step1_Tap:
                  if (offhandEmpty) {
                     int hotbarTotem = this.findHotbarTotem();
                     if (hotbarTotem != -1) {
                        this.simulatePhysicalTap(hotbarTotem);
                        this.delayTimer = 1;
                     }
                  }

                  this.stage = AutoInvTotem.Stage.Step2_Open;
                  break;
               case Step2_Open:
                  if (this.mc.currentScreen == null && this.hasSpareTotem()) {
                     this.mc.setScreen(new InventoryScreen(this.mc.player));
                     this.stage = AutoInvTotem.Stage.Step3_Offhand;
                     this.delayTimer = 1;
                  } else if (this.mc.currentScreen instanceof InventoryScreen) {
                     this.stage = AutoInvTotem.Stage.Step3_Offhand;
                  } else {
                     this.stage = AutoInvTotem.Stage.Idle;
                  }
                  break;
               case Step3_Offhand:
                  if (offhandEmpty && this.hasSpareTotem()) {
                     this.handleReplenish(true, false);
                     this.delayTimer = 1;
                  }

                  this.stage = AutoInvTotem.Stage.Step4_Hotbar;
                  break;
               case Step4_Hotbar:
                  if (hotbarNeedsRefill && this.hasSpareTotem()) {
                     this.handleReplenish(false, true);
                     this.delayTimer = 1;
                  }

                  this.stage = AutoInvTotem.Stage.Step5_Close;
                  break;
               case Step5_Close:
                  if (this.mc.currentScreen instanceof InventoryScreen) {
                     this.mc.player.closeHandledScreen();
                  }

                  this.stage = AutoInvTotem.Stage.Idle;
                  this.delayTimer = 1;
            }
         }
      }
   }

   private void handleReplenish(boolean offhand, boolean hotbar) {
      int totemSlot = this.findTotemInInventoryOnly();
      if (totemSlot != -1) {
         this.simulateMouseOverSlot(totemSlot);
         if (offhand) {
            this.executeKeybindSwap(totemSlot, 40);
         } else if (hotbar) {
            this.executeKeybindSwap(totemSlot, (Integer)this.targetHotbarSlot.get() - 1);
         }
      }
   }

   private void simulatePhysicalTap(int slot) {
      int glfwKey = 49 + slot;
      long handle = this.mc.getWindow().getHandle();
      this.mc.keyboard.onKey(handle, 1, new net.minecraft.client.input.KeyInput(glfwKey, 0, 0));
      this.mc.keyboard.onKey(handle, 0, new net.minecraft.client.input.KeyInput(glfwKey, 0, 0));
   }

   private void simulateMouseOverSlot(int slotId) {
      if (this.mc.currentScreen instanceof InventoryScreen inv) {
         Slot slot = ((PlayerScreenHandler)inv.getScreenHandler()).getSlot(slotId);
         if (slot != null) {
            int guiLeft = (inv.width - 176) / 2;
            int guiTop = (inv.height - 166) / 2;
            double mouseX = guiLeft + slot.x + 10;
            double mouseY = guiTop + slot.y + 10;
            long handle = this.mc.getWindow().getHandle();
            double scale = (double)this.mc.getWindow().getWidth() / inv.width;
            GLFW.glfwSetCursorPos(handle, mouseX * scale, mouseY * scale);
         }
      }
   }

   private void executeKeybindSwap(int slotId, int button) {
      if (this.mc.currentScreen instanceof InventoryScreen inv) {
         this.mc.interactionManager.clickSlot(((PlayerScreenHandler)inv.getScreenHandler()).syncId, slotId, button, SlotActionType.SWAP, this.mc.player);
      }
   }

   private int countAllTotems() {
      int count = 0;

      for (int i = 0; i < 36; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8288)) {
            count++;
         }
      }

      if (this.mc.player.getOffHandStack().isOf(Items.field_8288)) {
         count++;
      }

      return count;
   }

   private int findHotbarTotem() {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8288)) {
            return i;
         }
      }

      return -1;
   }

   private int findTotemInInventoryOnly() {
      if (this.mc.player.currentScreenHandler == null) {
         return -1;
      } else {
         for (Slot slot : this.mc.player.currentScreenHandler.slots) {
            if (slot.id >= 9 && slot.id <= 35 && slot.getStack().isOf(Items.field_8288)) {
               return slot.id;
            }
         }

         return -1;
      }
   }

   private boolean hasSpareTotem() {
      for (int i = 9; i < 36; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8288)) {
            return true;
         }
      }

      return false;
   }

   private static enum Stage {
      Idle,
      Step1_Tap,
      Step2_Open,
      Step3_Offhand,
      Step4_Hotbar,
      Step5_Close;

      private Stage() {
      }
   }
}
