# Zinc Addon - 1.21.11 port (v1.0.0)

Port of **Zinc Addon** by vrzt (GPL-3.0) from Minecraft 1.21.4 to **1.21.11** for Meteor Client.
The original source was not available, so this was rebuilt from the decompiled 1.21.4 jar:
Minecraft names were translated to 1.21.11 Yarn names and the API changes were patched by hand.

**Status: not compiled or run yet.** The first GitHub Actions build may show a few compile errors.
Send me the build log and I will fix them.

## How it builds
`./gradlew build` first runs `resolveMappings` (needs `python3`, present on GitHub runners and Codespaces).
It fills in registry/enum names (Blocks.*, Items.*, Direction.* ...) from the Yarn mappings jar.
It is idempotent and rewrites the sources in place. Commit the result if you want clean sources.

## Changes for 1.21.11
- Keyboard/mouse input uses `KeyInput` / `Click` (ZincFreecam, CustomCrosshair, onKey calls).
- `DrawContext` matrices are 2D (`pushMatrix`, `popMatrix`); `Renderer2D.render()` takes no matrix.
- NBT reads return `Optional` (CustomCrosshair).
- `GameProfile` is a record (`name()`, `id()`).
- Inventory: `getSelectedSlot()`, `setSelectedSlot()`, `getMainStacks()`, armor via `getEquippedStack`.
- Swords/axes via `ItemTags`, mace via `Items.MACE` (UdTriggerBot).
- `Session` constructor has no `AccountType`.
- `world.disconnect(Text)` takes a reason.
- Experience bar hiding moved to a new `ExperienceBarMixin`.
- Capes now use a `CapeFeatureRendererMixin` (local player only).
- **Removed:** the freecam fog tweak (`BackgroundRendererMixin`), because the fog renderer was rewritten.

## Things to watch at runtime
- `zinc.mixins.json` has `defaultRequire: 0`, so a broken mixin target logs a warning instead of crashing.
  Check `latest.log` for "Mixin ... failed". Set it back to 1 once everything applies.
- `CapeFeatureRendererMixin` assumes `PlayerEntityRenderState.name` exists.
- DonutSMP-specific modules depend on that server's menus and chat text and may need tuning.
