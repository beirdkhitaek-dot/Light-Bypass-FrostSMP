package com.vrzt.zinc.mixins;

import com.vrzt.zinc.commands.PayCommand;
import com.vrzt.zinc.modules.Render.CustomCrosshair;
import com.vrzt.zinc.modules.Render.FakeScoreboard;
import com.vrzt.zinc.modules.Zinc.HideScoreboard;
import com.vrzt.zinc.modules.pvp.NameProtectV2;
import com.vrzt.zinc.utils.ScoreboardUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.util.Formatting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public abstract class InGameHudMixin {
   @Shadow
   @Final
   private MinecraftClient client;

   public InGameHudMixin() {
   }

   @Shadow
   private void renderScoreboardSidebar(DrawContext context, ScoreboardObjective objective) {
      throw new AssertionError();
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("TAIL")}
   )
   private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      CustomCrosshair crosshair = (CustomCrosshair)Modules.get().get(CustomCrosshair.class);
      if (crosshair != null && crosshair.isActive()) {
         crosshair.renderMixin(context);
      }
   }

   @Inject(
      method = {"renderCrosshair(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (Modules.get().isActive(CustomCrosshair.class)) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"renderHotbar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderHotbar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (module != null && module.isActive() && (Boolean)module.hideHotbar.get()) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"renderArmor(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/entity/player/PlayerEntity;IIII)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void onRenderArmor(DrawContext context, PlayerEntity player, int y, int lines, int lineHeight, int x, CallbackInfo ci) {
      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (module != null && module.isActive() && (Boolean)module.hideArmor.get()) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"setOverlayMessage(Lnet/minecraft/text/Text;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSetOverlayMessage(Text message, boolean tinted, CallbackInfo ci) {
      if (System.currentTimeMillis() < PayCommand.lockUntil) {
         String content = message.getString();
         if (!content.contains("You paid")) {
            ci.cancel();
            return;
         }
      }

      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (module != null && module.isActive() && (Boolean)module.protectOverlay.get() && message != null) {
         String original = message.getString();
         String protectedString = module.replaceNameInText(original);
         if (!original.equals(protectedString)) {
            this.client.inGameHud.setOverlayMessage(Text.literal(protectedString), tinted);
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderScoreboardSidebar(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
      HideScoreboard hideScoreboard = (HideScoreboard)Modules.get().get(HideScoreboard.class);
      if (hideScoreboard != null && hideScoreboard.isActive()) {
         ci.cancel();
      }

      FakeScoreboard fakeScoreboard = (FakeScoreboard)Modules.get().get(FakeScoreboard.class);
      if (fakeScoreboard != null && fakeScoreboard.isActive()) {
         ci.cancel();
         this.renderFakeScoreboard(context, fakeScoreboard);
      }
   }

   private Text parseColorCodes(String text) {
      if (text != null && !text.isEmpty()) {
         MutableText result = Text.literal("");
         Pattern pattern = Pattern.compile("&#([0-9A-Fa-f]{6})|([§&])([0-9a-fk-or])");
         Matcher matcher = pattern.matcher(text);
         int lastEnd = 0;
         int currentColor = 16777215;
         boolean bold = false;
         boolean italic = false;
         boolean underline = false;

         boolean strikethrough;
         for (strikethrough = false; matcher.find(); lastEnd = matcher.end()) {
            if (matcher.start() > lastEnd) {
               String segment = text.substring(lastEnd, matcher.start());
               MutableText segmentText = Text.literal(segment);
               boolean b = bold;
               boolean i = italic;
               boolean u = underline;
               boolean s = strikethrough;
               int c = currentColor;
               segmentText.styled(style -> {
                  style = style.withColor(c);
                  if (b) {
                     style = style.withBold(true);
                  }

                  if (i) {
                     style = style.withItalic(true);
                  }

                  if (u) {
                     style = style.withUnderline(true);
                  }

                  if (s) {
                     style = style.withStrikethrough(true);
                  }

                  return style;
               });
               result.append(segmentText);
            }

            if (matcher.group(1) != null) {
               currentColor = Integer.parseInt(matcher.group(1), 16);
               strikethrough = false;
               underline = false;
               italic = false;
               bold = false;
            } else if (matcher.group(2) != null && matcher.group(3) != null) {
               char c = matcher.group(3).charAt(0);
               Formatting formatting = Formatting.byCode(c);
               if (formatting != null) {
                  if (formatting.isColor()) {
                     Integer color = formatting.getColorValue();
                     currentColor = color != null ? color : 16777215;
                     strikethrough = false;
                     underline = false;
                     italic = false;
                     bold = false;
                  } else {
                     switch (c) {
                        case 'l':
                           bold = true;
                           break;
                        case 'm':
                           strikethrough = true;
                           break;
                        case 'n':
                           underline = true;
                           break;
                        case 'o':
                           italic = true;
                        case 'p':
                        case 'q':
                        default:
                           break;
                        case 'r':
                           currentColor = 16777215;
                           strikethrough = false;
                           underline = false;
                           italic = false;
                           bold = false;
                     }
                  }
               }
            }
         }

         if (lastEnd < text.length()) {
            String segment = text.substring(lastEnd);
            MutableText segmentText = Text.literal(segment);
            int color = currentColor;
            boolean b = bold;
            boolean i = italic;
            boolean u = underline;
            boolean s = strikethrough;
            segmentText.styled(style -> {
               style = style.withColor(color);
               if (b) {
                  style = style.withBold(true);
               }

               if (i) {
                  style = style.withItalic(true);
               }

               if (u) {
                  style = style.withUnderline(true);
               }

               if (s) {
                  style = style.withStrikethrough(true);
               }

               return style;
            });
            result.append(segmentText);
         }

         return result;
      } else {
         return Text.literal("");
      }
   }

   private void renderFakeScoreboard(DrawContext context, FakeScoreboard module) {
      MinecraftClient client = MinecraftClient.getInstance();
      TextRenderer textRenderer = client.textRenderer;
      int screenWidth = context.getScaledWindowWidth();
      int screenHeight = context.getScaledWindowHeight();
      Text title = this.parseColorCodes("&#007cf9&lD&#0089f9&lo&#0096f9&ln&#00a3f9&lu&#00b0f9&lt&#00bdf9 &#00b0f9&lS&#00bcf9&lM&#00c6f9&lP");
      String moneyValue = module.shouldShowRealMoney() ? ScoreboardUtils.getMoney() : module.getMoneyValue();
      String shardsValue = module.shouldShowRealShards() ? ScoreboardUtils.getShards() : module.getShardsValue();
      String killsValue = module.shouldShowRealKills() ? ScoreboardUtils.getKills() : module.getKillsValue();
      String deathsValue = module.shouldShowRealDeaths() ? ScoreboardUtils.getDeaths() : module.getDeathsValue();
      String keyAllValue = module.shouldShowRealKeyall() ? ScoreboardUtils.getKeyallTimer() : module.getKeyallValue();
      String playtimeValue = module.shouldShowRealPlaytime() ? ScoreboardUtils.getPlaytime() : module.getPlaytimeValue();
      String teamValue = module.shouldShowRealTeam() ? ScoreboardUtils.getTeam() : module.getTeamValue();
      String regionValue = ScoreboardUtils.getRegion(module.shouldHideRegion());
      String pingValue = ScoreboardUtils.getPing();
      String[] lines;
      if (teamValue.isEmpty()) {
         lines = new String[]{
            "",
            "&#00FC00&l$ &fMoney &#00FC00" + moneyValue,
            "&#A303F9★ &fShards &#A303F9" + shardsValue,
            "&#FC0000\ud83d\udde1 &fKills &#FC0000" + killsValue,
            "&#F97603☠ &fDeaths &#F97603" + deathsValue,
            "&#00A4FC⌛ &fKeyall &#00A4FC" + keyAllValue,
            "&#FCE300⌚ &fPlaytime &#FCE300" + playtimeValue,
            "",
            "&7" + regionValue + " &7(&#00A4FC" + pingValue + "ms&7)"
         };
      } else {
         lines = new String[]{
            "",
            "&#00FC00&l$ &fMoney &#00FC00" + moneyValue,
            "&#A303F9★ &fShards &#A303F9" + shardsValue,
            "&#FC0000\ud83d\udde1 &fKills &#FC0000" + killsValue,
            "&#F97603☠ &fDeaths &#F97603" + deathsValue,
            "&#00A4FC⌛ &fKeyall &#00A4FC" + keyAllValue,
            "&#FCE300⌚ &fPlaytime &#FCE300" + playtimeValue,
            "&#00A4FC\ud83e\ude93 &fTeam &#00A4FC" + teamValue,
            "",
            "&7" + regionValue + " &7(&#00A4FC" + pingValue + "ms&7)"
         };
      }

      int maxWidth = 0;

      for (String line : lines) {
         int width = textRenderer.getWidth(this.parseColorCodes(line));
         if (width > maxWidth) {
            maxWidth = width;
         }
      }

      int titleWidth = textRenderer.getWidth(title);
      if (titleWidth > maxWidth) {
         maxWidth = titleWidth;
      }

      int lineHeight = 9;
      int boardHeight = lines.length * lineHeight;
      int x = screenWidth - maxWidth - 2;
      int y = screenHeight / 2 - (boardHeight + lineHeight) / 2;
      context.fill(x - 2, y, x + maxWidth, y + lineHeight, 1711276032);
      context.drawText(textRenderer, title, x + maxWidth / 2 - titleWidth / 2, y + 1, 16777215, false);
      context.fill(x - 2, y + lineHeight, x + maxWidth, y + lineHeight + boardHeight, 1342177280);
      int currentY = y + lineHeight;

      for (String linex : lines) {
         context.drawText(textRenderer, this.parseColorCodes(linex), x, currentY, 16777215, false);
         currentY += lineHeight;
      }
   }
}
