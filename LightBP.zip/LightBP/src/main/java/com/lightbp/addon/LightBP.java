package com.lightbp.addon;

import com.lightbp.addon.modules.LightEsp;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LightBP extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("LightBP");
    public static final Category CATEGORY = new Category("LightBP");

    @Override
    public void onInitialize() {
        LOG.info("Initializing LightBP");
        Modules.get().add(new LightEsp(CATEGORY));
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.lightbp.addon";
    }
}
