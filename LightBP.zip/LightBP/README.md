# LightBP

Meteor Client addon for Minecraft 1.21.11 (Fabric). Adds the **LightESP** module:
highlights light sources (torches, lanterns, glowstone...) or any lit space.

## Build
Requires Java 21.

    ./gradlew build

The jar is created in `build/libs/`. Put it in `.minecraft/mods/` together with
Fabric Loader 0.18+ and the Meteor Client jar for 1.21.11.

If the Gradle wrapper files are missing, run `gradle wrapper --gradle-version 9.2.0`
once (or copy `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar`
from https://github.com/MeteorDevelopment/meteor-addon-template).
