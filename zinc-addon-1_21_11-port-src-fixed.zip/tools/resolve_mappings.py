#!/usr/bin/env python3
"""
Replaces leftover intermediary names (field_123, method_456, comp_789, class_12)
in the sources with their Yarn names, using the Yarn tiny-v2 mappings jar that
Gradle already downloads for the build.

usage: resolve_mappings.py <yarn-v2.jar> <source-dir>
Safe to run repeatedly: when nothing is left to resolve it changes nothing.
"""
import os
import re
import sys
import zipfile

TOKEN = re.compile(r'\b(?:field|method|comp|class)_\d+\b')


def load(jar_path):
    with zipfile.ZipFile(jar_path) as z:
        with z.open('mappings/mappings.tiny') as f:
            lines = f.read().decode('utf-8').splitlines()
    header = lines[0].split('\t')
    assert header[0] == 'tiny' and header[1] == '2', 'expected tiny v2 mappings'
    names = {}
    for line in lines[1:]:
        if not line:
            continue
        p = line.split('\t')
        if p[0] == 'c' and len(p) >= 3:
            inter = p[1].split('/')[-1].split('$')[-1]
            named = (p[2] if p[2] else p[1]).split('/')[-1].split('$')[-1]
            if inter.startswith('class_'):
                names[inter] = named
        elif p[0] == '' and len(p) >= 5 and p[1] in ('f', 'm'):
            inter, named = p[3], p[4]
            if inter and named and inter != named:
                names[inter] = named
    return names


def main():
    jar, src = sys.argv[1], sys.argv[2]
    names = None
    changed_files = 0
    replaced = 0
    unresolved = set()
    for dp, _, fs in os.walk(src):
        for f in fs:
            if not f.endswith('.java'):
                continue
            path = os.path.join(dp, f)
            text = open(path, encoding='utf-8').read()
            if not TOKEN.search(text):
                continue
            if names is None:
                names = load(jar)

            def rep(m):
                nonlocal replaced
                tok = m.group(0)
                n = names.get(tok)
                if n is None:
                    unresolved.add(tok)
                    return tok
                replaced += 1
                return n

            new = TOKEN.sub(rep, text)
            if new != text:
                open(path, 'w', encoding='utf-8').write(new)
                changed_files += 1
    print(f'[resolve_mappings] replaced {replaced} names in {changed_files} files')
    if unresolved:
        print('[resolve_mappings] unresolved (left as-is): ' + ', '.join(sorted(unresolved)))


if __name__ == '__main__':
    main()
