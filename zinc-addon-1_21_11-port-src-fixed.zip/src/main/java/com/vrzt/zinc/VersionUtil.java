package com.vrzt.zinc;

import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.client.network.ClientPlayerEntity;

public class VersionUtil {
   public VersionUtil() {
   }

   public static ItemStack getArmorStack(ClientPlayerEntity player, int slot) {
      return player == null ? ItemStack.EMPTY : player.getEquippedStack(slot == 0 ? net.minecraft.entity.EquipmentSlot.FEET : slot == 1 ? net.minecraft.entity.EquipmentSlot.LEGS : slot == 2 ? net.minecraft.entity.EquipmentSlot.CHEST : net.minecraft.entity.EquipmentSlot.HEAD);
   }

   public static ItemStack getArmorStackByType(ClientPlayerEntity player, int armorType) {
      return player == null ? ItemStack.EMPTY : player.getInventory().getStack(armorType);
   }

   public static int getSelectedSlot(ClientPlayerEntity player) {
      return player != null ? player.getInventory().getSelectedSlot() : 0;
   }

   public static void setSelectedSlot(ClientPlayerEntity player, int slot) {
      if (player != null) {
         player.getInventory().setSelectedSlot(slot);
      }
   }

   public static double getPrevX(Entity entity) {
      return entity != null ? entity.lastRenderX : 0.0;
   }

   public static double getPrevY(Entity entity) {
      return entity != null ? entity.lastRenderY : 0.0;
   }

   public static double getPrevZ(Entity entity) {
      return entity != null ? entity.lastRenderZ : 0.0;
   }

   public static DefaultedList<ItemStack> getMainInventory(ClientPlayerEntity player) {
      return player != null && player.getInventory() != null ? player.getInventory().getMainStacks() : DefaultedList.ofSize(0, ItemStack.EMPTY);
   }
}
