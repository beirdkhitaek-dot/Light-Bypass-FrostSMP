package com.vrzt.zinc.mixininterface;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MinecraftClient.class})
public interface IMinecraftClient {
   @Accessor("session")
   void setSession(Session var1);

   @Invoker("doAttack")
   boolean zinc$doAttack();

   @Invoker("doItemUse")
   void zinc$doItemUse();
}
