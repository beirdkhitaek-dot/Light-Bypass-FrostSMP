package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class CrateBuyer extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<CrateBuyer.ItemType> WhatToBuy = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Item Type")).description("What item to buy from the crates")).defaultValue(CrateBuyer.ItemType.All))
            .build()
      );
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("delay"))
                  .description("Delay between clicks in ticks."))
               .defaultValue(5))
            .min(1)
            .max(20)
            .sliderMax(20)
            .build()
      );
   private int tickCounter = 0;
   private int warningCooldown = 0;
   private int currentStep = 0;
   private int currentItemIndex = 0;
   private boolean hasClickedOnce = false;
   private static final int HELMET_SLOT = 10;
   private static final int CHESTPLATE_SLOT = 11;
   private static final int LEGGINGS_SLOT = 12;
   private static final int BOOTS_SLOT = 13;
   private static final int SWORD_SLOT = 14;
   private static final int PICKAXE_SLOT = 15;
   private static final int SHOVEL_SLOT = 16;
   private static final int CONFIRM_SLOT_DEFAULT = 15;
   private static final int CONFIRM_SLOT_SHOVEL = 15;

   public CrateBuyer() {
      super(ZincAddon.Zinc, "CrateBuyer", "Automatically buys items from the common crate");
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.interactionManager != null) {
         if (this.warningCooldown > 0) {
            this.warningCooldown--;
         }

         if (!(this.mc.currentScreen instanceof HandledScreen<?> screen)) {
            if (this.isActive() && this.warningCooldown == 0) {
               this.warning("You need to be on the crate screen to use this module.", new Object[0]);
               this.warningCooldown = 20;
            }
         } else if (!this.hasClickedOnce && !this.isValidCrateScreen(screen)) {
            if (this.warningCooldown == 0) {
               this.warning("This doesn't appear to be a valid crate screen. Closing screen.", new Object[0]);
               this.warningCooldown = 20;
               this.mc.setScreen(null);
            }
         } else {
            this.tickCounter++;
            if (this.tickCounter >= (Integer)this.delay.get()) {
               this.tickCounter = 0;
               if (this.WhatToBuy.get() == CrateBuyer.ItemType.All) {
                  this.handleAllItems(screen);
               } else {
                  this.handleSingleItem(screen);
               }
            }
         }
      }
   }

   private boolean isValidCrateScreen(HandledScreen<?> screen) {
      for (int i = 0; i <= 9; i++) {
         if (!screen.getScreenHandler().getSlot(i).getStack().isOf(Items.GRAY_STAINED_GLASS_PANE)) {
            return false;
         }
      }

      for (int ix = 17; ix <= 26; ix++) {
         if (!screen.getScreenHandler().getSlot(ix).getStack().isOf(Items.GRAY_STAINED_GLASS_PANE)) {
            return false;
         }
      }

      return true;
   }

   private void handleAllItems(HandledScreen<?> screen) {
      CrateBuyer.ItemType[] items = new CrateBuyer.ItemType[]{
         CrateBuyer.ItemType.Helmet,
         CrateBuyer.ItemType.Chestplate,
         CrateBuyer.ItemType.Leggings,
         CrateBuyer.ItemType.Boots,
         CrateBuyer.ItemType.Sword,
         CrateBuyer.ItemType.Pickaxe,
         CrateBuyer.ItemType.Shovel
      };
      if (this.currentStep == 0) {
         int itemSlot = this.getItemSlot(items[this.currentItemIndex]);
         this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, itemSlot, 0, SlotActionType.PICKUP, this.mc.player);
         this.hasClickedOnce = true;
         this.currentStep = 1;
      } else {
         int confirmSlot = this.getConfirmSlot(items[this.currentItemIndex]);
         this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, confirmSlot, 0, SlotActionType.PICKUP, this.mc.player);
         this.currentStep = 0;
         this.currentItemIndex++;
         if (this.currentItemIndex >= items.length) {
            this.currentItemIndex = 0;
         }
      }
   }

   private void handleSingleItem(HandledScreen<?> screen) {
      if (this.currentStep == 0) {
         int itemSlot = this.getItemSlot((CrateBuyer.ItemType)this.WhatToBuy.get());
         this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, itemSlot, 0, SlotActionType.PICKUP, this.mc.player);
         this.hasClickedOnce = true;
         this.currentStep = 1;
      } else {
         int confirmSlot = this.getConfirmSlot((CrateBuyer.ItemType)this.WhatToBuy.get());
         this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, confirmSlot, 0, SlotActionType.PICKUP, this.mc.player);
         this.currentStep = 0;
      }
   }

   private int getItemSlot(CrateBuyer.ItemType itemType) {
      switch (itemType) {
         case Helmet:
            return 10;
         case Chestplate:
            return 11;
         case Leggings:
            return 12;
         case Boots:
            return 13;
         case Sword:
            return 14;
         case Pickaxe:
            return 15;
         case Shovel:
            return 16;
         default:
            return 10;
      }
   }

   private int getConfirmSlot(CrateBuyer.ItemType itemType) {
      return itemType == CrateBuyer.ItemType.Shovel ? 15 : 15;
   }

   public void onActivate() {
      this.tickCounter = 0;
      this.warningCooldown = 0;
      this.currentStep = 0;
      this.currentItemIndex = 0;
      this.hasClickedOnce = false;
      this.info("CrateBuyer activated. Mode: " + ((CrateBuyer.ItemType)this.WhatToBuy.get()).toString(), new Object[0]);
   }

   public void onDeactivate() {
      this.currentStep = 0;
      this.currentItemIndex = 0;
      this.hasClickedOnce = false;
   }

   public static enum ItemType {
      All,
      Helmet,
      Chestplate,
      Leggings,
      Boots,
      Sword,
      Pickaxe,
      Shovel;

      private ItemType() {
      }
   }
}
