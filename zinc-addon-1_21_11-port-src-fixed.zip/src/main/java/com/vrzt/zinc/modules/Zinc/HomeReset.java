package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;

public class HomeReset extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> chatFeedback = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("chat-feedback")).description("Show chat messages when running commands")).defaultValue(true))
            .build()
      );
   private final Setting<Integer> homeSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("home-slot"))
                  .description("Which home slot to reset (1–5)."))
               .defaultValue(1))
            .min(1)
            .max(5)
            .build()
      );

   public HomeReset() {
      super(ZincAddon.Zinc, "home-reset", "Automatically runs /delhome and /sethome for a selected slot.");
   }

   public void onActivate() {
      if (this.mc.player != null && this.mc.world != null) {
         int slot = (Integer)this.homeSlot.get();
         this.mc.execute(() -> {
            this.sendServerCommand("/delhome " + slot);
            new Thread(() -> {
               try {
                  Thread.sleep(1000L);
               } catch (InterruptedException var3) {
                  var3.printStackTrace();
               }

               this.mc.execute(() -> {
                  this.sendServerCommand("/sethome " + slot);
                  if ((Boolean)this.chatFeedback.get()) {
                     ChatUtils.info("§aHome " + slot + " deleted and set successfully!", new Object[0]);
                  }

                  this.toggle();
               });
            }, "HomeReset-DelayThread").start();
         });
      }
   }

   private void sendServerCommand(String command) {
      ChatUtils.sendPlayerMsg(command);
   }
}
