package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class ShopBuyer extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> delay = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("delay")).description("Delay between actions in ticks.")).defaultValue(15)).min(1).max(100).build());
   private final Setting<String> itemList = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("items"))
                  .description("Comma-separated list of items to buy."))
               .defaultValue("Obsidian,EndCrystal,Glowstone,ExperienceBottle,GoldenApple,RespawnAnchor,"))
            .build()
      );
   private final Setting<Boolean> autoDrop = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("auto-drop"))
                  .description("Automatically drop purchased items."))
               .defaultValue(true))
            .build()
      );
   private int delayCounter = 0;
   private boolean inPvpCategory = false;
   private boolean inBuyingScreen = false;
   private final List<ShopBuyer.ItemType> itemQueue = new ArrayList<>();

   public ShopBuyer() {
      super(ZincAddon.pvp, "ShopBuyer", "Automatically buys selected items from PVP shop category.");
   }

   public void onActivate() {
      this.delayCounter = 0;
      this.inPvpCategory = false;
      this.inBuyingScreen = false;
      this.itemQueue.clear();

      for (String name : ((String)this.itemList.get()).split(",")) {
         try {
            this.itemQueue.add(ShopBuyer.ItemType.valueOf(name.trim()));
         } catch (IllegalArgumentException var6) {
         }
      }
   }

   public void onDeactivate() {
      this.delayCounter = 0;
      this.inPvpCategory = false;
      this.inBuyingScreen = false;
      this.itemQueue.clear();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null) {
         if (this.delayCounter > 0) {
            this.delayCounter--;
         } else {
            ScreenHandler currentScreenHandler = this.mc.player.currentScreenHandler;
            if (!(currentScreenHandler instanceof GenericContainerScreenHandler containerHandler)) {
               ChatUtils.sendPlayerMsg("/shop");
               this.delayCounter = (Integer)this.delay.get();
               this.resetState();
            } else {
               int rows = containerHandler.getRows();
               this.updateScreenState(currentScreenHandler, rows);
               if (rows == 3) {
                  if (this.isBuyingScreen(currentScreenHandler)) {
                     this.handleBuyingScreen(currentScreenHandler);
                     return;
                  }

                  if (this.isPvpCategoryScreen(currentScreenHandler)) {
                     this.handlePvpCategory(currentScreenHandler);
                     return;
                  }

                  if (this.isMainShopScreen(currentScreenHandler)) {
                     this.handleMainShop(currentScreenHandler);
                     return;
                  }
               }

               this.resetState();
            }
         }
      }
   }

   private void updateScreenState(ScreenHandler handler, int rows) {
      if (this.isBuyingScreen(handler)) {
         this.inBuyingScreen = true;
      } else if (this.isPvpCategoryScreen(handler)) {
         this.inPvpCategory = true;
         this.inBuyingScreen = false;
      } else if (this.isMainShopScreen(handler)) {
         this.inPvpCategory = false;
         this.inBuyingScreen = false;
      }
   }

   private boolean isMainShopScreen(ScreenHandler handler) {
      return handler.getSlot(13).getStack().isOf(Items.field_8288) && !this.isBuyingScreen(handler);
   }

   private boolean isPvpCategoryScreen(ScreenHandler handler) {
      return handler.getSlot(9).getStack().isOf(Items.OBSIDIAN)
         || handler.getSlot(10).getStack().isOf(Items.field_8301)
         || handler.getSlot(11).getStack().isOf(Items.RESPAWN_ANCHOR)
         || handler.getSlot(12).getStack().isOf(Items.GLOWSTONE);
   }

   private boolean isBuyingScreen(ScreenHandler handler) {
      for (int i = 0; i < handler.slots.size(); i++) {
         if (handler.getSlot(i).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
            return true;
         }
      }

      return false;
   }

   private void handleMainShop(ScreenHandler handler) {
      this.mc.interactionManager.clickSlot(handler.syncId, 13, 0, SlotActionType.PICKUP, this.mc.player);
      this.delayCounter = (Integer)this.delay.get();
      this.inPvpCategory = true;
   }

   private void handlePvpCategory(ScreenHandler handler) {
      if (this.itemQueue.isEmpty()) {
         this.mc.player.closeHandledScreen();
         this.resetState();
      } else {
         ShopBuyer.ItemType currentItem = this.itemQueue.get(0);
         int slot = this.getItemSlot(currentItem);
         if (slot != -1 && this.isCorrectItemInSlot(handler, slot, currentItem)) {
            this.clickItem(handler, slot);
            this.itemQueue.remove(0);
         }
      }
   }

   private int getItemSlot(ShopBuyer.ItemType itemType) {
      switch (itemType) {
         case Obsidian:
            return 9;
         case EndCrystal:
            return 10;
         case RespawnAnchor:
            return 11;
         case Glowstone:
            return 12;
         case TotemOfUndying:
            return 13;
         case EnderPearl:
            return 14;
         case GoldenApple:
            return 15;
         case ExperienceBottle:
            return 16;
         case SlowFallingArrow:
            return 17;
         default:
            return -1;
      }
   }

   private boolean isCorrectItemInSlot(ScreenHandler handler, int slot, ShopBuyer.ItemType itemType) {
      switch (itemType) {
         case Obsidian:
            return handler.getSlot(slot).getStack().isOf(Items.OBSIDIAN);
         case EndCrystal:
            return handler.getSlot(slot).getStack().isOf(Items.field_8301);
         case RespawnAnchor:
            return handler.getSlot(slot).getStack().isOf(Items.RESPAWN_ANCHOR);
         case Glowstone:
            return handler.getSlot(slot).getStack().isOf(Items.GLOWSTONE);
         case TotemOfUndying:
            return handler.getSlot(slot).getStack().isOf(Items.field_8288);
         case EnderPearl:
            return handler.getSlot(slot).getStack().isOf(Items.field_8634);
         case GoldenApple:
            return handler.getSlot(slot).getStack().isOf(Items.field_8463);
         case ExperienceBottle:
            return handler.getSlot(slot).getStack().isOf(Items.field_8287);
         case SlowFallingArrow:
            return handler.getSlot(slot).getStack().isOf(Items.field_8087);
         default:
            return false;
      }
   }

   private void handleBuyingScreen(ScreenHandler handler) {
      for (int i = 0; i < handler.slots.size(); i++) {
         if (handler.getSlot(i).getStack().isOf(Items.LIME_STAINED_GLASS_PANE) && handler.getSlot(i).getStack().getCount() == 64) {
            this.mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.PICKUP, this.mc.player);
            this.delayCounter = (Integer)this.delay.get();
            return;
         }
      }

      for (int ix = 0; ix < handler.slots.size(); ix++) {
         if (handler.getSlot(ix).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
            this.mc.interactionManager.clickSlot(handler.syncId, ix, 0, SlotActionType.PICKUP, this.mc.player);
            this.delayCounter = (Integer)this.delay.get();
            if ((Boolean)this.autoDrop.get()) {
               this.mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.field_12970, BlockPos.ORIGIN, Direction.field_11033));
            }

            this.mc.player.closeHandledScreen();
            this.resetState();
            return;
         }
      }
   }

   private void clickItem(ScreenHandler handler, int slot) {
      this.mc.interactionManager.clickSlot(handler.syncId, slot, 0, SlotActionType.PICKUP, this.mc.player);
      this.delayCounter = (Integer)this.delay.get();
      this.inBuyingScreen = true;
   }

   private void resetState() {
      this.inPvpCategory = false;
      this.inBuyingScreen = false;
   }

   public static enum ItemType {
      Obsidian,
      EndCrystal,
      RespawnAnchor,
      Glowstone,
      TotemOfUndying,
      EnderPearl,
      GoldenApple,
      ExperienceBottle,
      SlowFallingArrow;

      private ItemType() {
      }
   }
}
