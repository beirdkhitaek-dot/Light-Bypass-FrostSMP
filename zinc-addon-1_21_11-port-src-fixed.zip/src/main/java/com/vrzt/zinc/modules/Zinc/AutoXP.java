package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

public class AutoXP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> preferredSlot = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("preferred-hotbar-slot"))
                  .description("Which hotbar slot to keep XP bottles in (0 = leftmost, 8 = rightmost)."))
               .defaultValue(7))
            .min(0)
            .max(8)
            .sliderMax(8)
            .build()
      );
   private final Setting<Boolean> alertOnMove = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("alert-on-move"))
                  .description("Send a chat message when XP bottles are moved/refilled into hotbar."))
               .defaultValue(true))
            .build()
      );
   private int tickDelay = 0;

   public AutoXP() {
      super(ZincAddon.Zinc, "auto-xp", "Keeps XP bottles in a preferred hotbar slot, refilling them automatically from inventory.");
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         if (this.tickDelay > 0) {
            this.tickDelay--;
         } else {
            int targetSlot = (Integer)this.preferredSlot.get();
            ItemStack targetStack = this.mc.player.getInventory().getStack(targetSlot);
            if (targetStack.isEmpty() || targetStack.getItem() != Items.field_8287) {
               int xpSlot = this.findXPBottleSlot();
               if (xpSlot != -1) {
                  this.moveToHotbar(xpSlot, targetSlot);
                  this.tickDelay = 5;
                  if ((Boolean)this.alertOnMove.get()) {
                     this.mc.player.sendMessage(Text.literal("[AutoXP] Refilled XP bottles into hotbar slot " + targetSlot + "."), false);
                  }
               }
            }
         }
      }
   }

   private int findXPBottleSlot() {
      for (int i = 9; i < this.mc.player.getInventory().size(); i++) {
         if (this.mc.player.getInventory().getStack(i).getItem() == Items.field_8287) {
            return i;
         }
      }

      return -1;
   }

   private void moveToHotbar(int invSlot, int hotbarSlot) {
      int screenInvSlot = invSlot < 9 ? 36 + invSlot : invSlot;
      int screenHotbarSlot = 36 + hotbarSlot;
      this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, screenInvSlot, 0, SlotActionType.PICKUP, this.mc.player);
      this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, screenHotbarSlot, 0, SlotActionType.PICKUP, this.mc.player);
      this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, screenInvSlot, 0, SlotActionType.PICKUP, this.mc.player);
   }
}
