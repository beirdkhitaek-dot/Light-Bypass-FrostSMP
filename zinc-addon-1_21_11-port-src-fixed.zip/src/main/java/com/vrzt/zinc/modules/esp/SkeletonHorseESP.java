package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import com.vrzt.zinc.utils.zinc.ZincToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SkeletonHorseEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

public class SkeletonHorseESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgRender = this.settings.createGroup("Render");
   private final SettingGroup sgwebhook = this.settings.createGroup("Webhook");
   private final Setting<Boolean> showTracers = this.sgRender
      .add(((Builder)((Builder)((Builder)new Builder().name("Show Tracers")).description("Draw tracer lines to skeleton horses")).defaultValue(true)).build());
   private final Setting<SettingColor> tracerColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("Tracer Color"))
                  .description("Color of the tracer lines"))
               .defaultValue(new SettingColor(255, 255, 255, 127))
               .visible(this.showTracers::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgwebhook
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Webhook")).description("Send webhook notifications when skeleton horses are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("Webhook URL"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgwebhook
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("Self Ping")).description("Ping yourself in the webhook message")).defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgwebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("Discord ID"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private final Setting<Boolean> enableDisconnect = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Disconnect")).description("Automatically disconnect when skeleton horses are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<SkeletonHorseESP.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-mode"))
                  .description("How to notify when skeleton horses are detected"))
               .defaultValue(SkeletonHorseESP.Mode.Both))
            .build()
      );
   private final Setting<Boolean> toggleOnFind = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Toggle when found"))
                  .description("Automatically toggles the module when a skeleton horse is detected"))
               .defaultValue(false))
            .build()
      );
   private final Set<Integer> detectedHorses = new HashSet<>();
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public SkeletonHorseESP() {
      super(ZincAddon.esp, "SkeletonHorseESP", "Detects skeleton horses (Skeleton Traps) in the world");
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         Set<Integer> currentHorses = new HashSet<>();
         int horseCount = 0;
         Color color = new Color((Color)this.tracerColor.get());

         for (Entity entity : this.mc.world.getEntities()) {
            if (entity instanceof SkeletonHorseEntity horse) {
               currentHorses.add(entity.getId());
               horseCount++;
               if ((Boolean)this.showTracers.get()) {
                  double x = MathHelper.lerp(event.tickDelta, entity.lastX, entity.getX());
                  double y = MathHelper.lerp(event.tickDelta, entity.lastY, entity.getY());
                  double z = MathHelper.lerp(event.tickDelta, entity.lastZ, entity.getZ());
                  double height = horse.getBoundingBox().maxY - horse.getBoundingBox().minY;
                  event.renderer
                     .line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z, x, y + height / 2.0, z, color);
               }
            }
         }

         if (!currentHorses.isEmpty() && !currentHorses.equals(this.detectedHorses)) {
            Set<Integer> newHorses = new HashSet<>(currentHorses);
            newHorses.removeAll(this.detectedHorses);
            if (!newHorses.isEmpty()) {
               this.detectedHorses.addAll(newHorses);
               this.handleDetection(horseCount);
            }
         } else if (currentHorses.isEmpty()) {
            this.detectedHorses.clear();
         }
      }
   }

   private void handleDetection(int count) {
      String message = count == 1 ? "Skeleton Horse detected!" : String.format("%d Skeleton Horses detected!", count);
      switch ((SkeletonHorseESP.Mode)this.notificationMode.get()) {
         case Chat:
            this.info("(highlight)%s", new Object[]{message});
            break;
         case Toast:
            this.mc
               .getToastManager()
               .add(
                  new SkeletonHorseESP.SkeletonHorseToast(
                     Items.SKELETON_SKULL.getDefaultStack(), Text.literal("SkeletonHorseESP"), Text.literal(count + " Skeleton Horses")
                  )
               );
            break;
         case Both:
            this.info("(highlight)%s", new Object[]{message});
            this.mc
               .getToastManager()
               .add(
                  new SkeletonHorseESP.SkeletonHorseToast(
                     Items.SKELETON_SKULL.getDefaultStack(), Text.literal("SkeletonHorseESP"), Text.literal(count + " Skeleton Horses")
                  )
               );
      }

      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(count);
      }

      if ((Boolean)this.toggleOnFind.get()) {
         this.toggle();
      }

      if ((Boolean)this.enableDisconnect.get()) {
         this.disconnectFromServer(message);
      }
   }

   private void sendWebhookNotification(int count) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (!url.isEmpty()) {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Singleplayer";
                  String messageContent = this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()
                     ? String.format("<@%s>", ((String)this.discordId.get()).trim())
                     : "";
                  String horseText = count == 1 ? "Skeleton Horse" : "Skeleton Horses";
                  String coordinates = this.mc.player != null
                     ? String.format(
                        "X: %.0f, Y: %.0f, Z: %.0f", this.mc.player.getX(), this.mc.player.getY(), this.mc.player.getZ()
                     )
                     : "Unknown";
                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"SkeletonHorseESP\",\"avatar_url\":\"https://minecraft.wiki/images/a/a3/Skeleton_Horse_JE3_BE2.png\",\"embeds\":[{\"title\":\"\ud83d\udc80 Skeleton Horse Alert\",\"description\":\"%d %s detected!\",\"color\":12632256,\"thumbnail\":{\"url\":\"https://minecraft.wiki/images/a/a3/Skeleton_Horse_JE3_BE2.png\"},\"fields\":[{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Coordinates\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Sent by zinc\"}}]}",
                     messageContent,
                     count,
                     horseText,
                     serverInfo.replace("\"", "\\\""),
                     coordinates.replace("\"", "\\\""),
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .build();
                  this.httpClient.send(request, BodyHandlers.ofString());
               } catch (Exception var9) {
               }
            }
         );
      }
   }

   private void disconnectFromServer(String reason) {
      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal(reason));
      }
   }

   public void onActivate() {
      this.detectedHorses.clear();
   }

   public void onDeactivate() {
      this.detectedHorses.clear();
   }

   public String getInfoString() {
      return this.detectedHorses.isEmpty() ? null : String.valueOf(this.detectedHorses.size());
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }

   private static class SkeletonHorseToast extends ZincToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public SkeletonHorseToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int white = -1;
         context.fill(0, 0, 160, 1, white);
         context.fill(0, 31, 160, 32, white);
         context.fill(0, 1, 1, 31, white);
         context.fill(159, 1, 160, 31, white);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, 16777215, false);
         }
      }
   }
}
