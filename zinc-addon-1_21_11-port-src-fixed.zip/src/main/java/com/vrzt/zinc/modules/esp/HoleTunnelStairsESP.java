package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.renderer.Renderer3D;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Axis;

public class HoleTunnelStairsESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgHParams = this.settings.createGroup("Hole Parameters");
   private final SettingGroup sgTParams = this.settings.createGroup("Tunnel Parameters");
   private final SettingGroup sgSParams = this.settings.createGroup("Stairs Parameters");
   private final SettingGroup sgRender = this.settings.createGroup("Rendering");
   private final Setting<HoleTunnelStairsESP.DetectionMode> detectionMode = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Detection Mode")).description("Choose what to detect: holes, tunnels, stairs, or all."))
               .defaultValue(HoleTunnelStairsESP.DetectionMode.ALL))
            .build()
      );
   private final Setting<Integer> maxChunks = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Chunks to process/tick"))
                  .description("Amount of Chunks to process per tick"))
               .defaultValue(10))
            .min(1)
            .sliderRange(1, 100)
            .build()
      );
   private final Setting<Boolean> airBlocks = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Detect only Air blocks as passable."))
                  .description("Only marks tunnels or holes if their blocks are air as oppose to if the blocks are passable."))
               .defaultValue(false))
            .build()
      );
   private final Setting<Integer> minY = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Detection Y Minimum OffSet"))
                  .description("Scans blocks above or at this this many blocks from minimum build limit."))
               .min(0)
               .sliderRange(0, 319)
               .defaultValue(0))
            .build()
      );
   private final Setting<Integer> maxY = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Detection Y Maximum OffSet"))
                  .description("Scans blocks below or at this this many blocks from maximum build limit."))
               .min(0)
               .sliderRange(0, 319)
               .defaultValue(0))
            .build()
      );
   private final Setting<Integer> minHoleDepth = this.sgHParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Hole Depth"))
                  .description("Minimum depth for a hole to be detected"))
               .defaultValue(4))
            .min(1)
            .sliderMax(20)
            .build()
      );
   private final Setting<Integer> minTunnelLength = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Tunnel Length"))
                  .description("Minimum length for a tunnel to be detected"))
               .defaultValue(3))
            .min(1)
            .sliderMax(20)
            .build()
      );
   private final Setting<Integer> minTunnelHeight = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Tunnel Height"))
                  .description("Minimum height of the tunnels to be detected"))
               .defaultValue(2))
            .min(1)
            .sliderMax(10)
            .build()
      );
   private final Setting<Integer> maxTunnelHeight = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Max Tunnel Height"))
                  .description("Maximum height of the tunnels to be detected"))
               .defaultValue(3))
            .min(2)
            .sliderMax(10)
            .build()
      );
   private final Setting<Boolean> diagonals = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Detect Diagonal Tunnels."))
                  .description("Detects diagonal tunnels when tunnels are selected to be detected."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> minDiagonalLength = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("Min Diagonal Tunnel Length"))
                     .description("Minimum length for diagonal tunnels to be detected"))
                  .defaultValue(3))
               .min(1)
               .sliderMax(20)
               .visible(this.diagonals::get))
            .build()
      );
   private final Setting<Integer> minDiagonalWidth = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("Min Diagonal Tunnel Width"))
                     .description("Minimum width for diagonal tunnels to be detected"))
                  .defaultValue(2))
               .min(2)
               .sliderMax(10)
               .visible(this.diagonals::get))
            .build()
      );
   private final Setting<Integer> maxDiagonalWidth = this.sgTParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("Max Diagonal Tunnel Width"))
                     .description("Maximum width for diagonal tunnels to be detected"))
                  .defaultValue(4))
               .min(2)
               .sliderMax(10)
               .visible(this.diagonals::get))
            .build()
      );
   private final Setting<Integer> minStaircaseLength = this.sgSParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Staircase Length"))
                  .description("Minimum length for a staircase to be detected"))
               .defaultValue(3))
            .min(1)
            .sliderMax(20)
            .build()
      );
   private final Setting<Integer> minStaircaseHeight = this.sgSParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Staircase Height"))
                  .description("Minimum height of the staircase to be detected"))
               .defaultValue(3))
            .min(2)
            .sliderMax(10)
            .build()
      );
   private final Setting<Integer> maxStaircaseHeight = this.sgSParams
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Max Staircase Height"))
                  .description("Maximum height of the staircase to be detected"))
               .defaultValue(5))
            .min(2)
            .sliderMax(10)
            .build()
      );
   private final Setting<ShapeMode> shapeMode = this.sgRender
      .add(((Builder)((Builder)((Builder)new Builder().name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
   private final Setting<SettingColor> holeLineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("1x1-hole-line-color"))
               .description("The color of the lines for 1x1 holes being rendered."))
            .defaultValue(new SettingColor(255, 0, 0, 95))
            .build()
      );
   private final Setting<SettingColor> holeSideColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("1x1-hole-side-color"))
               .description("The color of the sides for 1x1 holes being rendered."))
            .defaultValue(new SettingColor(255, 0, 0, 30))
            .build()
      );
   private final Setting<SettingColor> hole3x1LineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("3x1-hole-line-color"))
               .description("The color of the lines for 3x1 holes being rendered."))
            .defaultValue(new SettingColor(255, 165, 0, 95))
            .build()
      );
   private final Setting<SettingColor> hole3x1SideColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("3x1-hole-side-color"))
               .description("The color of the sides for 3x1 holes being rendered."))
            .defaultValue(new SettingColor(255, 165, 0, 30))
            .build()
      );
   private final Setting<SettingColor> tunnelLineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("tunnel-line-color"))
               .description("The color of the lines for the tunnels being rendered."))
            .defaultValue(new SettingColor(0, 0, 255, 95))
            .build()
      );
   private final Setting<SettingColor> tunnelSideColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("tunnel-side-color"))
               .description("The color of the sides for the tunnels being rendered."))
            .defaultValue(new SettingColor(0, 0, 255, 30))
            .build()
      );
   private final Setting<SettingColor> staircaseLineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("staircase-line-color"))
               .description("The color of the lines for the staircases being rendered."))
            .defaultValue(new SettingColor(255, 0, 255, 95))
            .build()
      );
   private final Setting<SettingColor> staircaseSideColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("staircase-side-color"))
               .description("The color of the sides for the staircases being rendered."))
            .defaultValue(new SettingColor(255, 0, 255, 30))
            .build()
      );
   private static final Direction[] DIRECTIONS = new Direction[]{
      Direction.field_11034, Direction.field_11039, Direction.field_11043, Direction.field_11035
   };
   private final Long2ObjectMap<HoleTunnelStairsESP.TChunk> chunks = new Long2ObjectOpenHashMap();
   private final Queue<Chunk> chunkQueue = new LinkedList<>();
   private final Set<Box> holes = Collections.newSetFromMap(new ConcurrentHashMap<>());
   private final Set<Box> tunnels = Collections.newSetFromMap(new ConcurrentHashMap<>());
   private final Set<Box> staircases = Collections.newSetFromMap(new ConcurrentHashMap<>());
   private final Set<Box> holes3x1 = Collections.newSetFromMap(new ConcurrentHashMap<>());

   public HoleTunnelStairsESP() {
      super(ZincAddon.esp, "HoleTunnelStairESP", "Finds and highlights holes and tunnels and stairs.");
   }

   public Set<Box> getHoles() {
      return new HashSet<>(this.holes);
   }

   public void onDeactivate() {
      this.chunks.clear();
      this.chunkQueue.clear();
      this.holes.clear();
      this.tunnels.clear();
      this.staircases.clear();
      this.holes3x1.clear();
   }

   @EventHandler
   private void onTick(Post event) {
      synchronized (this.chunks) {
         ObjectIterator var3 = this.chunks.values().iterator();

         while (var3.hasNext()) {
            HoleTunnelStairsESP.TChunk tChunk = (HoleTunnelStairsESP.TChunk)var3.next();
            tChunk.marked = false;
         }

         for (Chunk chunk : Utils.chunks(true)) {
            long key = ChunkPos.toLong(chunk.getPos().x, chunk.getPos().z);
            if (this.chunks.containsKey(key)) {
               ((HoleTunnelStairsESP.TChunk)this.chunks.get(key)).marked = true;
            } else if (!this.chunkQueue.contains(chunk)) {
               this.chunkQueue.add(chunk);
            }
         }

         this.processChunkQueue();
         this.chunks.values().removeIf(tChunk -> !tChunk.marked);
      }

      this.removeBoxesOutsideRenderDistance();
   }

   private void removeBoxesOutsideRenderDistance() {
      Set<WorldChunk> chunkSet = new HashSet<>();

      for (Chunk chunk : Utils.chunks(true)) {
         if (chunk instanceof WorldChunk) {
            chunkSet.add((WorldChunk)chunk);
         }
      }

      this.removeBoxesOutsideRenderDistance(this.holes, chunkSet);
      this.removeBoxesOutsideRenderDistance(this.tunnels, chunkSet);
      this.removeBoxesOutsideRenderDistance(this.staircases, chunkSet);
      this.removeBoxesOutsideRenderDistance(this.holes3x1, chunkSet);
   }

   private void removeBoxesOutsideRenderDistance(Set<Box> boxSet, Set<WorldChunk> worldChunks) {
      boxSet.removeIf(
         box -> {
            BlockPos boxPos = new BlockPos(
               (int)Math.floor(box.getCenter().getX()),
               (int)Math.floor(box.getCenter().getY()),
               (int)Math.floor(box.getCenter().getZ())
            );

            assert this.mc.world != null;

            return !worldChunks.contains(this.mc.world.getChunk(boxPos));
         }
      );
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      switch ((HoleTunnelStairsESP.DetectionMode)this.detectionMode.get()) {
         case ALL:
            this.renderHoles(event.renderer);
            this.renderTunnels(event.renderer);
            this.renderStaircases(event.renderer);
            this.render3x1Holes(event.renderer);
            break;
         case HOLES_AND_TUNNELS:
            this.renderHoles(event.renderer);
            this.renderTunnels(event.renderer);
            this.render3x1Holes(event.renderer);
            break;
         case HOLES_AND_STAIRCASES:
            this.renderHoles(event.renderer);
            this.renderStaircases(event.renderer);
            this.render3x1Holes(event.renderer);
            break;
         case TUNNELS_AND_STAIRCASES:
            this.renderTunnels(event.renderer);
            this.renderStaircases(event.renderer);
            break;
         case HOLES:
            this.renderHoles(event.renderer);
            this.render3x1Holes(event.renderer);
            break;
         case TUNNELS:
            this.renderTunnels(event.renderer);
            break;
         case STAIRCASES:
            this.renderStaircases(event.renderer);
            break;
         case HOLES_3X1_AND_TUNNELS:
            this.renderHoles(event.renderer);
            this.render3x1Holes(event.renderer);
            this.renderTunnels(event.renderer);
      }
   }

   private void renderHoles(Renderer3D renderer) {
      for (Box box : this.holes) {
         renderer.box(
            box.minX,
            box.minY,
            box.minZ,
            box.maxX,
            box.maxY,
            box.maxZ,
            (Color)this.holeSideColor.get(),
            (Color)this.holeLineColor.get(),
            (ShapeMode)this.shapeMode.get(),
            0
         );
      }
   }

   private void render3x1Holes(Renderer3D renderer) {
      for (Box box : this.holes3x1) {
         renderer.box(
            box.minX,
            box.minY,
            box.minZ,
            box.maxX,
            box.maxY,
            box.maxZ,
            (Color)this.hole3x1SideColor.get(),
            (Color)this.hole3x1LineColor.get(),
            (ShapeMode)this.shapeMode.get(),
            0
         );
      }
   }

   private void renderTunnels(Renderer3D renderer) {
      for (Box box : this.tunnels) {
         renderer.box(
            box.minX,
            box.minY,
            box.minZ,
            box.maxX,
            box.maxY,
            box.maxZ,
            (Color)this.tunnelSideColor.get(),
            (Color)this.tunnelLineColor.get(),
            (ShapeMode)this.shapeMode.get(),
            0
         );
      }
   }

   private void renderStaircases(Renderer3D renderer) {
      for (Box box : this.staircases) {
         renderer.box(
            box.minX,
            box.minY,
            box.minZ,
            box.maxX,
            box.maxY,
            box.maxZ,
            (Color)this.staircaseSideColor.get(),
            (Color)this.staircaseLineColor.get(),
            (ShapeMode)this.shapeMode.get(),
            0
         );
      }
   }

   private void processChunkQueue() {
      int maxChunksPerTick = (Integer)this.maxChunks.get();
      int processed = 0;

      while (!this.chunkQueue.isEmpty() && processed < maxChunksPerTick) {
         Chunk chunk = this.chunkQueue.poll();
         if (chunk != null) {
            HoleTunnelStairsESP.TChunk tChunk = new HoleTunnelStairsESP.TChunk(chunk.getPos().x, chunk.getPos().z);
            this.chunks.put(tChunk.getKey(), tChunk);
            MeteorExecutor.execute(() -> this.searchChunk(chunk, tChunk));
            processed++;
         }
      }
   }

   private void searchChunk(Chunk chunk, HoleTunnelStairsESP.TChunk tChunk) {
      ChunkSection[] sections = chunk.getSectionArray();
      int Ymin = this.mc.world.getBottomY() + (Integer)this.minY.get();
      int Ymax = this.mc.world.getTopYInclusive() - (Integer)this.maxY.get();
      int Y = this.mc.world.getBottomY();

      for (ChunkSection section : sections) {
         if (section != null && !section.isEmpty()) {
            for (int z = 0; z < 16; z++) {
               for (int x = 0; x < 16; x++) {
                  for (int y = 0; y < 16; y++) {
                     int currentY = Y + y;
                     if (currentY > Ymin && currentY < Ymax) {
                        BlockPos pos = chunk.getPos().getBlockPos(x, currentY, z);
                        if (this.isPassableBlock(pos)) {
                           switch ((HoleTunnelStairsESP.DetectionMode)this.detectionMode.get()) {
                              case ALL:
                                 this.checkHole(pos, this.holes);
                                 this.check3x1Hole(pos, this.holes3x1);
                                 this.checkTunnel(pos);
                                 if ((Boolean)this.diagonals.get()) {
                                    this.checkDiagonalTunnel(pos);
                                 }

                                 this.checkStaircase(pos);
                                 break;
                              case HOLES_AND_TUNNELS:
                                 this.checkHole(pos, this.holes);
                                 this.check3x1Hole(pos, this.holes3x1);
                                 this.checkTunnel(pos);
                                 if ((Boolean)this.diagonals.get()) {
                                    this.checkDiagonalTunnel(pos);
                                 }
                                 break;
                              case HOLES_AND_STAIRCASES:
                                 this.checkHole(pos, this.holes);
                                 this.check3x1Hole(pos, this.holes3x1);
                                 this.checkStaircase(pos);
                                 break;
                              case TUNNELS_AND_STAIRCASES:
                                 this.checkTunnel(pos);
                                 if ((Boolean)this.diagonals.get()) {
                                    this.checkDiagonalTunnel(pos);
                                 }

                                 this.checkStaircase(pos);
                                 break;
                              case HOLES:
                                 this.checkHole(pos, this.holes);
                                 this.check3x1Hole(pos, this.holes3x1);
                                 break;
                              case TUNNELS:
                                 this.checkTunnel(pos);
                                 if ((Boolean)this.diagonals.get()) {
                                    this.checkDiagonalTunnel(pos);
                                 }
                                 break;
                              case STAIRCASES:
                                 this.checkStaircase(pos);
                                 break;
                              case HOLES_3X1_AND_TUNNELS:
                                 this.checkHole(pos, this.holes);
                                 this.check3x1Hole(pos, this.holes3x1);
                                 this.checkTunnel(pos);
                                 if ((Boolean)this.diagonals.get()) {
                                    this.checkDiagonalTunnel(pos);
                                 }
                           }
                        }
                     }
                  }
               }
            }
         }

         Y += 16;
      }
   }

   private void checkHole(BlockPos pos, Set<Box> holes) {
      if (this.isValidHoleSection(pos)) {
         Mutable currentPos = pos.mutableCopy();

         while (this.isValidHoleSection(currentPos)) {
            currentPos.move(Direction.field_11036);
         }

         if (currentPos.getY() - pos.getY() >= (Integer)this.minHoleDepth.get()) {
            Box holeBox = new Box(
               pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, currentPos.getY(), pos.getZ() + 1
            );
            if (!holes.contains(holeBox) && holes.stream().noneMatch(existingHole -> existingHole.intersects(holeBox))) {
               holes.add(holeBox);
            }
         }
      }
   }

   private void check3x1Hole(BlockPos pos, Set<Box> holes3x1) {
      if (this.isValid3x1HoleSectionX(pos)) {
         Mutable currentPos = pos.mutableCopy();

         while (this.isValid3x1HoleSectionX(currentPos)) {
            currentPos.move(Direction.field_11036);
         }

         if (currentPos.getY() - pos.getY() >= (Integer)this.minHoleDepth.get()) {
            Box holeBox = new Box(
               pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 3, currentPos.getY(), pos.getZ() + 1
            );
            if (!holes3x1.contains(holeBox) && holes3x1.stream().noneMatch(existingHole -> existingHole.intersects(holeBox))) {
               holes3x1.add(holeBox);
            }
         }
      }

      if (this.isValid3x1HoleSectionZ(pos)) {
         Mutable currentPos = pos.mutableCopy();

         while (this.isValid3x1HoleSectionZ(currentPos)) {
            currentPos.move(Direction.field_11036);
         }

         if (currentPos.getY() - pos.getY() >= (Integer)this.minHoleDepth.get()) {
            Box holeBox = new Box(
               pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, currentPos.getY(), pos.getZ() + 3
            );
            if (!holes3x1.contains(holeBox) && holes3x1.stream().noneMatch(existingHole -> existingHole.intersects(holeBox))) {
               holes3x1.add(holeBox);
            }
         }
      }
   }

   private boolean isValidHoleSection(BlockPos pos) {
      return this.isPassableBlock(pos)
         && !this.isPassableBlock(pos.north())
         && !this.isPassableBlock(pos.south())
         && !this.isPassableBlock(pos.east())
         && !this.isPassableBlock(pos.west());
   }

   private boolean isValid3x1HoleSectionX(BlockPos pos) {
      return this.isPassableBlock(pos)
         && this.isPassableBlock(pos.east())
         && this.isPassableBlock(pos.east(2))
         && !this.isPassableBlock(pos.north())
         && !this.isPassableBlock(pos.south())
         && !this.isPassableBlock(pos.east(3))
         && !this.isPassableBlock(pos.west())
         && !this.isPassableBlock(pos.east().north())
         && !this.isPassableBlock(pos.east().south())
         && !this.isPassableBlock(pos.east(2).north())
         && !this.isPassableBlock(pos.east(2).south());
   }

   private boolean isValid3x1HoleSectionZ(BlockPos pos) {
      return this.isPassableBlock(pos)
         && this.isPassableBlock(pos.south())
         && this.isPassableBlock(pos.south(2))
         && !this.isPassableBlock(pos.east())
         && !this.isPassableBlock(pos.west())
         && !this.isPassableBlock(pos.south(3))
         && !this.isPassableBlock(pos.north())
         && !this.isPassableBlock(pos.south().east())
         && !this.isPassableBlock(pos.south().west())
         && !this.isPassableBlock(pos.south(2).east())
         && !this.isPassableBlock(pos.south(2).west());
   }

   private void checkTunnel(BlockPos pos) {
      for (Direction dir : DIRECTIONS) {
         Mutable currentPos = pos.mutableCopy();
         int stepCount = 0;
         BlockPos startPos = null;
         BlockPos endPos = null;
         int maxHeight = 0;
         if (startPos == null && this.isTunnelSection(currentPos, dir)) {
            startPos = currentPos.toImmutable();
         }

         while (this.isTunnelSection(currentPos, dir)) {
            maxHeight = Math.max(maxHeight, this.getTunnelHeight(currentPos));
            endPos = currentPos.toImmutable();
            currentPos.move(dir);
            stepCount++;
         }

         if (stepCount >= (Integer)this.minTunnelLength.get()
            && maxHeight >= (Integer)this.minTunnelHeight.get()
            && maxHeight <= (Integer)this.maxTunnelHeight.get()) {
            Box tunnelBox = new Box(
               Math.min(startPos.getX(), endPos.getX()),
               startPos.getY(),
               Math.min(startPos.getZ(), endPos.getZ()),
               Math.max(startPos.getX(), endPos.getX()) + 1,
               startPos.getY() + maxHeight,
               Math.max(startPos.getZ(), endPos.getZ()) + 1
            );
            if (!this.tunnels.contains(tunnelBox) && this.tunnels.stream().noneMatch(existingTunnel -> existingTunnel.intersects(tunnelBox))) {
               this.tunnels.add(tunnelBox);
            }
         }
      }
   }

   private boolean isTunnelSection(BlockPos pos, Direction dir) {
      int height = this.getTunnelHeight(pos);
      if (height >= (Integer)this.minTunnelHeight.get() && height <= (Integer)this.maxTunnelHeight.get()) {
         if (!this.isPassableBlock(pos.method_10074()) && !this.isPassableBlock(pos.up(height))) {
            Direction[] perpDirs = dir.getAxis() == Axis.field_11048
               ? new Direction[]{Direction.field_11043, Direction.field_11035}
               : new Direction[]{Direction.field_11034, Direction.field_11039};

            for (Direction perpDir : perpDirs) {
               for (int i = 0; i < height; i++) {
                  if (this.isPassableBlock(pos.up(i).method_10093(perpDir))) {
                     return false;
                  }
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void checkDiagonalTunnel(BlockPos pos) {
      for (Direction dir : DIRECTIONS) {
         for (int i = (Integer)this.minDiagonalWidth.get() - 1; i < this.maxDiagonalWidth.get(); i++) {
            Mutable currentPos = pos.mutableCopy();
            int stepCount = 0;
            List<Box> potentialBoxes = new ArrayList<>();
            Direction checkingDir = dir;

            for (boolean turnRight = true; this.isDiagonalTunnelSection(currentPos, checkingDir); stepCount++) {
               int height = this.getTunnelHeight(currentPos);
               Box tunnelBox = new Box(
                  currentPos.getX(),
                  currentPos.getY(),
                  currentPos.getZ(),
                  currentPos.getX() + 1,
                  currentPos.getY() + height,
                  currentPos.getZ() + 1
               );
               if (!potentialBoxes.contains(tunnelBox) && !potentialBoxes.stream().anyMatch(existingDiagonal -> existingDiagonal.intersects(tunnelBox))) {
                  potentialBoxes.add(tunnelBox);
               }

               if (turnRight) {
                  checkingDir = checkingDir.rotateYClockwise();
                  currentPos.move(checkingDir.rotateYClockwise(), i);
                  turnRight = false;
               } else {
                  checkingDir = checkingDir.rotateYCounterclockwise();
                  currentPos.move(checkingDir.rotateYCounterclockwise(), i);
                  turnRight = true;
               }
            }

            if (stepCount / (Integer)this.minDiagonalWidth.get() >= (Integer)this.minDiagonalLength.get()) {
               potentialBoxes.forEach(potentialBox -> {
                  if (!this.tunnels.contains(potentialBox) && this.tunnels.stream().noneMatch(existingDiagonal -> existingDiagonal.intersects(potentialBox))) {
                     this.tunnels.add(potentialBox);
                  }
               });
            }
         }
      }
   }

   private boolean isDiagonalTunnelSection(BlockPos pos, Direction dir) {
      int height = this.getTunnelHeight(pos);
      if (height >= (Integer)this.minTunnelHeight.get() && height <= (Integer)this.maxTunnelHeight.get()) {
         if (!this.isPassableBlock(pos.method_10074()) && !this.isPassableBlock(pos.up(height))) {
            boolean wasPassableBlockFound = false;

            for (int i = 0; i < height; i++) {
               if (this.isPassableBlock(pos.up(i).method_10093(dir))) {
                  wasPassableBlockFound = true;
               }
            }

            return !wasPassableBlockFound;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private int getTunnelHeight(BlockPos pos) {
      int height = 0;

      while (this.isPassableBlock(pos.up(height)) && height < this.maxTunnelHeight.get()) {
         height++;
      }

      return height;
   }

   private void checkStaircase(BlockPos pos) {
      for (Direction dir : DIRECTIONS) {
         Mutable currentPos = pos.mutableCopy();
         int stepCount = 0;

         List<Box> potentialStaircaseBoxes;
         for (potentialStaircaseBoxes = new ArrayList<>(); this.isStaircaseSection(currentPos, dir); stepCount++) {
            int height = this.getStaircaseHeight(currentPos);
            Box stairsBox = new Box(
               currentPos.getX(),
               currentPos.getY(),
               currentPos.getZ(),
               currentPos.getX() + 1,
               currentPos.getY() + height,
               currentPos.getZ() + 1
            );
            if (!potentialStaircaseBoxes.contains(stairsBox)
               && !potentialStaircaseBoxes.stream().anyMatch(existingStaircase -> existingStaircase.intersects(stairsBox))) {
               potentialStaircaseBoxes.add(stairsBox);
            }

            currentPos.move(dir);
            currentPos.move(Direction.field_11036);
         }

         for (Box stairsBox : potentialStaircaseBoxes) {
            if (stepCount >= (Integer)this.minStaircaseLength.get()
               && !this.staircases.contains(stairsBox)
               && !this.staircases.stream().anyMatch(existingStaircase -> existingStaircase.intersects(stairsBox))) {
               this.staircases.add(stairsBox);
            }
         }
      }
   }

   private int getStaircaseHeight(BlockPos pos) {
      int height = 0;

      while (this.isPassableBlock(pos.up(height)) && height < this.maxStaircaseHeight.get()) {
         height++;
      }

      return height;
   }

   private boolean isStaircaseSection(BlockPos pos, Direction dir) {
      int height = this.getStaircaseHeight(pos);
      if (height >= (Integer)this.minStaircaseHeight.get() && height <= (Integer)this.maxStaircaseHeight.get()) {
         if (!this.isPassableBlock(pos.method_10074()) && !this.isPassableBlock(pos.up(height))) {
            Direction[] perpDirs = dir.getAxis() == Axis.field_11048
               ? new Direction[]{Direction.field_11043, Direction.field_11035}
               : new Direction[]{Direction.field_11034, Direction.field_11039};

            for (Direction perpDir : perpDirs) {
               for (int i = 0; i < height; i++) {
                  if (this.isPassableBlock(pos.up(i).method_10093(perpDir))) {
                     return false;
                  }
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isPassableBlock(BlockPos pos) {
      BlockState state = this.mc.world.getBlockState(pos);
      if ((Boolean)this.airBlocks.get()) {
         return state.isAir();
      } else {
         VoxelShape shape = state.getCollisionShape(this.mc.world, pos);
         return shape.isEmpty() || !VoxelShapes.fullCube().equals(shape);
      }
   }

   public static enum DetectionMode {
      ALL,
      HOLES_AND_TUNNELS,
      HOLES_AND_STAIRCASES,
      TUNNELS_AND_STAIRCASES,
      HOLES,
      TUNNELS,
      STAIRCASES,
      HOLES_3X1_AND_TUNNELS;

      private DetectionMode() {
      }
   }

   private class TChunk {
      private final int x;
      private final int z;
      public boolean marked;

      public TChunk(int x, int z) {
         this.x = x;
         this.z = z;
         this.marked = true;
      }

      public long getKey() {
         return ChunkPos.toLong(this.x, this.z);
      }
   }
}
