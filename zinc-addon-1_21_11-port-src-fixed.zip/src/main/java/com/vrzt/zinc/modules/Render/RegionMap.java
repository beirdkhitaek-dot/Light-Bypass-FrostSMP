package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.math.MatrixStack;

public class RegionMap extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgColors = this.settings.createGroup("Colors");
   private final Setting<Integer> mapPosX = this.sgGeneral.add(((Builder)((Builder)new Builder().name("x")).defaultValue(15)).sliderMax(1920).build());
   private final Setting<Integer> mapPosY = this.sgGeneral.add(((Builder)((Builder)new Builder().name("y")).defaultValue(15)).sliderMax(1080).build());
   private final Setting<Integer> cellSize = this.sgGeneral.add(((Builder)((Builder)new Builder().name("cell-size")).defaultValue(22)).range(10, 50).build());
   private final Setting<Integer> cellGap = this.sgGeneral.add(((Builder)((Builder)new Builder().name("cell-gap")).defaultValue(2)).range(0, 10).build());
   private final Setting<Double> playerScale = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
               .name("player-scale"))
            .defaultValue(1.0)
            .min(0.5)
            .sliderMax(3.0)
            .build()
      );
   private final Setting<SettingColor> bgColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("background"))
            .defaultValue(new SettingColor(20, 20, 20, 160))
            .build()
      );
   private final Setting<SettingColor> outlineColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("outline"))
            .defaultValue(new SettingColor(120, 120, 120, 200))
            .build()
      );
   private final RegionMap.MapDataManager mapData = new RegionMap.MapDataManager();

   public RegionMap() {
      super(ZincAddon.Render, "Region Map", "DonutSMP region map with directional triangle indicator.");
   }

   @EventHandler
   private void onRender2D(Render2DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         MatrixStack matrices = null; // unused: Renderer2D no longer needs a matrix stack
         int x = (Integer)this.mapPosX.get();
         int y = (Integer)this.mapPosY.get();
         int size = (Integer)this.cellSize.get();
         int gap = (Integer)this.cellGap.get();
         int mapSize = this.mapData.getMapSize();
         int totalGridSize = mapSize * (size + gap) - gap;
         int padding = 8;
         int infoSpace = 110;
         this.drawStyledBox(matrices, x - padding, y - padding, totalGridSize + padding * 2, totalGridSize + padding * 2 + infoSpace);
         Renderer2D.COLOR.begin();

         for (int row = 0; row < mapSize; row++) {
            for (int col = 0; col < mapSize; col++) {
               RegionMap.RegionInfo info = this.mapData.getRegionInfo(row * mapSize + col);
               if (info != null) {
                  Color c = this.mapData.getRegionColor(info.regionType);
                  Renderer2D.COLOR.quad(x + col * (size + gap), y + row * (size + gap), size, size, c);
               }
            }
         }

         Renderer2D.COLOR.render();
         TextRenderer.get().begin(0.65, false, true);

         for (int row = 0; row < mapSize; row++) {
            for (int colx = 0; colx < mapSize; colx++) {
               RegionMap.RegionInfo info = this.mapData.getRegionInfo(row * mapSize + colx);
               if (info != null) {
                  String text = String.valueOf(info.regionId);
                  float tx = x + colx * (size + gap) + size / 2.0F - (float)(TextRenderer.get().getWidth(text) * 0.65 / 2.0);
                  float ty = y + row * (size + gap) + size / 2.0F - (float)(TextRenderer.get().getHeight() * 0.65 / 2.0);
                  TextRenderer.get().render(text, tx, ty, Color.WHITE, false);
               }
            }
         }

         TextRenderer.get().end();
         this.renderPlayerPin(matrices, x, y, size, gap);
         this.renderInternalInfo(matrices, x, y + totalGridSize + 10);
      }
   }

   private void drawStyledBox(MatrixStack matrices, int x, int y, int w, int h) {
      Renderer2D.COLOR.begin();
      Renderer2D.COLOR.quad(x, y, w, h, (Color)this.bgColor.get());
      Color out = (Color)this.outlineColor.get();
      Renderer2D.COLOR.quad(x, y, w, 1.0, out);
      Renderer2D.COLOR.quad(x, y + h - 1, w, 1.0, out);
      Renderer2D.COLOR.quad(x, y, 1.0, h, out);
      Renderer2D.COLOR.quad(x + w - 1, y, 1.0, h, out);
      Renderer2D.COLOR.render();
   }

   private void renderPlayerPin(MatrixStack matrices, int x, int y, int size, int gap) {
      Vec3d pos = this.mc.player.getEntityPos();
      int[] gp = this.mapData.worldToGrid(pos.x, pos.z);
      if (gp[0] >= 0 && gp[0] < this.mapData.getMapSize() && gp[1] >= 0 && gp[1] < this.mapData.getMapSize()) {
         double[] cp = this.mapData.worldToCellPosition(pos.x, pos.z);
         float px = x + gp[0] * (size + gap) + (float)(cp[0] * size);
         float py = y + gp[1] * (size + gap) + (float)(cp[1] * size);
         double scale = (Double)this.playerScale.get();
         float triHeight = (float)(10.0 * scale);
         float triWidth = (float)(7.0 * scale);
         double angle = Math.toRadians(this.mc.player.getYaw() + 180.0F);
         float x1 = px + (float)(Math.sin(angle) * (triHeight / 1.5F));
         float y1 = py - (float)(Math.cos(angle) * (triHeight / 1.5F));
         double leftAngle = angle + Math.toRadians(145.0);
         double rightAngle = angle - Math.toRadians(145.0);
         float x2 = px + (float)(Math.sin(leftAngle) * triWidth);
         float y2 = py - (float)(Math.cos(leftAngle) * triWidth);
         float x3 = px + (float)(Math.sin(rightAngle) * triWidth);
         float y3 = py - (float)(Math.cos(rightAngle) * triWidth);
         Renderer2D.COLOR.begin();
         Renderer2D.COLOR.triangle(x1, y1, x2, y2, x3, y3, Color.WHITE);
         Renderer2D.COLOR.render();
      }
   }

   private void renderInternalInfo(MatrixStack matrices, int x, int y) {
      TextRenderer.get().begin(0.85, false, true);
      Color purple = new Color(200, 100, 255);
      String posStr = String.format(
         "Pos: %d, %d, %d", (int)this.mc.player.getX(), (int)this.mc.player.getY(), (int)this.mc.player.getZ()
      );
      TextRenderer.get().render(posStr, x, y, purple);
      int regId = this.mapData.getRegionAt(this.mc.player.getX(), this.mc.player.getZ());
      String regName = this.mapData.getRegionTypeName(this.mc.player.getX(), this.mc.player.getZ());
      TextRenderer.get().render("Region: " + (regId == -1 ? "N/A" : regId) + " (" + regName + ")", x, y + 12, purple);
      int ly = y + 32;
      String[] names = this.mapData.getRegionTypeNames();
      Color[] colors = this.mapData.getRegionTypeColors();

      for (int i = 0; i < names.length; i++) {
         Renderer2D.COLOR.begin();
         Renderer2D.COLOR.quad(x, ly + i * 12, 9.0, 9.0, colors[i]);
         Renderer2D.COLOR.render();
         TextRenderer.get().render(names[i], x + 14, ly + i * 12 - 1, Color.WHITE);
      }

      TextRenderer.get().end();
   }

   private static class MapDataManager {
      private static final int MAP_SIZE = 9;
      private static final double REGION_SIZE = 50000.0;
      private static final double MAP_OFFSET = 225000.0;
      private final Map<Integer, RegionMap.RegionInfo> regionMap = new HashMap<>();
      private final String[] regionTypeNames = new String[]{"EU Central", "EU West", "NA East", "NA West", "Asia", "Oceania"};
      private final Color[] regionTypeColors = new Color[]{
         new Color(159, 206, 99, 255),
         new Color(0, 166, 99, 255),
         new Color(79, 173, 234, 255),
         new Color(47, 110, 186, 255),
         new Color(245, 194, 66, 255),
         new Color(252, 136, 3, 255)
      };

      public MapDataManager() {
         int[][] layout = new int[][]{
            {82, 5},
            {100, 3},
            {101, 3},
            {102, 3},
            {103, 2},
            {104, 2},
            {105, 2},
            {106, 2},
            {91, 2},
            {83, 5},
            {44, 3},
            {75, 3},
            {42, 3},
            {41, 2},
            {40, 2},
            {39, 2},
            {38, 2},
            {92, 2},
            {84, 5},
            {45, 3},
            {14, 3},
            {13, 3},
            {12, 2},
            {11, 2},
            {10, 2},
            {37, 2},
            {93, 2},
            {85, 5},
            {46, 5},
            {74, 5},
            {3, 3},
            {2, 2},
            {1, 2},
            {25, 2},
            {36, 2},
            {94, 2},
            {86, 4},
            {47, 4},
            {72, 4},
            {71, 4},
            {5, 2},
            {4, 2},
            {24, 2},
            {35, 2},
            {95, 2},
            {87, 4},
            {51, 1},
            {17, 1},
            {9, 0},
            {8, 0},
            {7, 0},
            {23, 0},
            {34, 0},
            {96, 2},
            {88, 4},
            {54, 1},
            {18, 1},
            {61, 0},
            {62, 0},
            {21, 0},
            {22, 0},
            {33, 0},
            {97, 0},
            {89, 0},
            {26, 1},
            {27, 0},
            {28, 0},
            {29, 0},
            {30, 0},
            {59, 0},
            {32, 0},
            {98, 0},
            {90, 0},
            {107, 1},
            {108, 1},
            {109, 1},
            {110, 1},
            {111, 1},
            {112, 1},
            {113, 1},
            {99, 0}
         };

         for (int i = 0; i < layout.length; i++) {
            this.regionMap.put(i, new RegionMap.RegionInfo(layout[i][0], layout[i][1]));
         }
      }

      public RegionMap.RegionInfo getRegionInfo(int idx) {
         return this.regionMap.get(idx);
      }

      public int getMapSize() {
         return 9;
      }

      public Color getRegionColor(int type) {
         return this.regionTypeColors[type];
      }

      public String[] getRegionTypeNames() {
         return this.regionTypeNames;
      }

      public Color[] getRegionTypeColors() {
         return this.regionTypeColors;
      }

      public int getRegionAt(double x, double z) {
         int[] gp = this.worldToGrid(x, z);
         return gp[0] >= 0 && gp[0] < 9 && gp[1] >= 0 && gp[1] < 9 ? this.regionMap.get(gp[1] * 9 + gp[0]).regionId : -1;
      }

      public String getRegionTypeName(double x, double z) {
         int[] gp = this.worldToGrid(x, z);
         return gp[0] >= 0 && gp[0] < 9 && gp[1] >= 0 && gp[1] < 9 ? this.regionTypeNames[this.regionMap.get(gp[1] * 9 + gp[0]).regionType] : "Unknown";
      }

      public int[] worldToGrid(double x, double z) {
         return new int[]{(int)((x + 225000.0) / 50000.0), (int)((z + 225000.0) / 50000.0)};
      }

      public double[] worldToCellPosition(double x, double z) {
         return new double[]{(x + 225000.0) % 50000.0 / 50000.0, (z + 225000.0) % 50000.0 / 50000.0};
      }
   }

   private static class RegionInfo {
      final int regionId;
      final int regionType;

      RegionInfo(int id, int type) {
         this.regionId = id;
         this.regionType = type;
      }
   }
}
