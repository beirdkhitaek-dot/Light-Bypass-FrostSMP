package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.SpawnerBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;

public class SpawnerOrder extends Module {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private SpawnerOrder.State currentState;
   private int tickCounter;
   private int waitCounter;
   private BlockPos targetSpawner;
   private final List<BlockPos> spawners;
   private int spawnerIndex;
   private final int spawnerPagesToProcess = 1;
   private int currentSpawnerPageCounter;
   private final SettingGroup sgGeneral;
   private long lastDropTime;
   private final int ACTION_DELAY_TICKS = 3;
   private final int CYCLE_DELAY_SECONDS = 60;

   public SpawnerOrder() {
      super(ZincAddon.Zinc, "Spawner-Order", "Order All Spawner Loot (Bones & Arrows) — NO CAMERA MOVEMENT.");
      this.currentState = SpawnerOrder.State.INVENTORY_CHECK;
      this.tickCounter = 0;
      this.waitCounter = 0;
      this.targetSpawner = null;
      this.spawners = new ArrayList<>();
      this.spawnerIndex = 0;
      this.currentSpawnerPageCounter = 0;
      this.sgGeneral = this.settings.getDefaultGroup();
      this.lastDropTime = 0L;
   }

   private boolean isGreenGlass(ItemStack stack) {
      return stack.getItem() == Items.GREEN_STAINED_GLASS_PANE || stack.getItem() == Items.LIME_STAINED_GLASS_PANE;
   }

   public void onActivate() {
      this.currentState = SpawnerOrder.State.INVENTORY_CHECK;
      this.tickCounter = 0;
      this.lastDropTime = System.currentTimeMillis();
      this.spawners.clear();
      this.spawnerIndex = 0;
      this.targetSpawner = null;
      this.currentSpawnerPageCounter = 0;
      ChatUtils.info("SpawnerOrder activated — Selling Bones and Arrows", new Object[0]);
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.tickCounter++;
         this.waitCounter++;
         if (this.tickCounter >= 3 && this.hasItemsToSell() && !this.isOrderState(this.currentState)) {
            this.currentState = SpawnerOrder.State.ORDER_COMMAND;
            this.tickCounter = 0;
         } else if (this.shouldStartNewCycle()) {
            this.startNewCycle();
         } else if (this.tickCounter >= 3) {
            this.executeCurrentState();
            this.tickCounter = 0;
         }
      }
   }

   private boolean isOrderState(SpawnerOrder.State state) {
      return state == SpawnerOrder.State.ORDER_COMMAND
         || state == SpawnerOrder.State.OPENING_ORDER
         || state == SpawnerOrder.State.CLICKING_SLOT0
         || state == SpawnerOrder.State.DEPOSITING_ITEMS
         || state == SpawnerOrder.State.WAITING_CONFIRM_GUI
         || state == SpawnerOrder.State.CONFIRMING_SALE
         || state == SpawnerOrder.State.CLOSING_ORDER
         || state == SpawnerOrder.State.WAITING_FOR_CLOSE;
   }

   private boolean shouldStartNewCycle() {
      if (this.currentState != SpawnerOrder.State.WAITING_CYCLE) {
         return false;
      } else {
         long currentTime = System.currentTimeMillis();
         long cycleInterval = 60000L;
         return currentTime - this.lastDropTime >= cycleInterval;
      }
   }

   private void startNewCycle() {
      this.currentState = SpawnerOrder.State.INVENTORY_CHECK;
      this.tickCounter = 0;
      this.waitCounter = 0;
      this.spawners.clear();
      this.spawnerIndex = 0;
      this.targetSpawner = null;
      this.lastDropTime = System.currentTimeMillis();
      this.currentSpawnerPageCounter = 0;
   }

   private void executeCurrentState() {
      switch (this.currentState) {
         case INVENTORY_CHECK:
            this.handleInventoryCheck();
            break;
         case SCANNING:
            this.handleScanning();
            break;
         case MOVING:
            this.handleMoving();
            break;
         case OPENING:
            this.handleOpening();
            break;
         case DROPPING:
            this.handleDropping();
            break;
         case WAITING_CLOSE:
            this.handleWaitingClose();
            break;
         case CLOSING_GUI:
            this.handleClosingGui();
            break;
         case ORDER_COMMAND:
            this.handleOrderCommand();
            break;
         case OPENING_ORDER:
            this.handleOpeningOrder();
            break;
         case CLICKING_SLOT0:
            this.handleClickingSlot0();
            break;
         case DEPOSITING_ITEMS:
            this.handleDepositingItems();
            break;
         case WAITING_CONFIRM_GUI:
            this.handleWaitingConfirmGui();
            break;
         case CONFIRMING_SALE:
            this.handleConfirmingSale();
            break;
         case CLOSING_ORDER:
            this.handleClosingOrder();
            break;
         case WAITING_FOR_CLOSE:
            this.handleWaitingForClose();
            break;
         case WAITING_CYCLE:
            this.handleWaitingCycle();
      }
   }

   private void handleInventoryCheck() {
      this.currentState = this.hasItemsToSell() ? SpawnerOrder.State.ORDER_COMMAND : SpawnerOrder.State.SCANNING;
   }

   private boolean isTargetItem(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         String name = stack.getItem().getName().getString().toLowerCase();
         return name.contains("bone") || name.contains("arrow");
      }
   }

   private boolean hasItemsToSell() {
      for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
         if (this.isTargetItem(this.mc.player.getInventory().getStack(i))) {
            return true;
         }
      }

      return false;
   }

   private void handleScanning() {
      this.scanForSpawners();
      if (this.spawners.isEmpty()) {
         this.currentState = this.hasItemsToSell() ? SpawnerOrder.State.ORDER_COMMAND : SpawnerOrder.State.WAITING_CYCLE;
      } else {
         this.targetSpawner = this.spawners.get(0);
         this.spawnerIndex = 0;
         this.currentState = SpawnerOrder.State.MOVING;
      }
   }

   private void handleMoving() {
      if (this.targetSpawner == null) {
         this.currentState = SpawnerOrder.State.SCANNING;
      } else {
         double distance = this.mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(this.targetSpawner));
         if (distance <= 4.5) {
            this.currentState = SpawnerOrder.State.OPENING;
         }
      }
   }

   private void handleOpening() {
      if (this.mc.currentScreen instanceof GenericContainerScreen) {
         this.currentState = SpawnerOrder.State.DROPPING;
         this.currentSpawnerPageCounter = 0;
      } else if (this.targetSpawner != null) {
         this.interactWithBlock(this.targetSpawner);
      }
   }

   private void handleDropping() {
      if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
         GenericContainerScreenHandler handler = (GenericContainerScreenHandler)screen.getScreenHandler();
         if (handler.slots.size() > 53 && this.currentSpawnerPageCounter < 1) {
            this.mc.interactionManager.clickSlot(handler.syncId, 50, 0, SlotActionType.QUICK_MOVE, this.mc.player);
            this.currentSpawnerPageCounter++;
            this.waitCounter = 0;
         } else {
            this.currentState = SpawnerOrder.State.WAITING_CLOSE;
            this.waitCounter = 0;
         }
      } else {
         this.currentState = SpawnerOrder.State.OPENING;
      }
   }

   private void handleWaitingClose() {
      if (this.waitCounter >= 10) {
         this.currentState = SpawnerOrder.State.CLOSING_GUI;
      }
   }

   private void handleClosingGui() {
      if (this.mc.currentScreen != null) {
         this.mc.player.closeHandledScreen();
      }

      this.spawnerIndex++;
      if (this.spawnerIndex < this.spawners.size()) {
         this.targetSpawner = this.spawners.get(this.spawnerIndex);
         this.currentState = SpawnerOrder.State.MOVING;
      } else {
         this.currentState = SpawnerOrder.State.ORDER_COMMAND;
      }

      this.waitCounter = 0;
   }

   private void handleOrderCommand() {
      boolean hasBones = false;
      boolean hasArrows = false;

      for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
         ItemStack stack = this.mc.player.getInventory().getStack(i);
         String name = stack.getItem().getName().getString().toLowerCase();
         if (name.contains("bone")) {
            hasBones = true;
         }

         if (name.contains("arrow")) {
            hasArrows = true;
         }
      }

      if (hasArrows) {
         ChatUtils.sendPlayerMsg("/order arrows");
         this.currentState = SpawnerOrder.State.OPENING_ORDER;
      } else if (hasBones) {
         ChatUtils.sendPlayerMsg("/order bones");
         this.currentState = SpawnerOrder.State.OPENING_ORDER;
      } else {
         this.currentState = SpawnerOrder.State.WAITING_CYCLE;
      }

      this.waitCounter = 0;
   }

   private void handleOpeningOrder() {
      if (this.mc.currentScreen instanceof GenericContainerScreen) {
         this.currentState = SpawnerOrder.State.CLICKING_SLOT0;
         this.waitCounter = 0;
      } else if (this.waitCounter > 40) {
         this.currentState = SpawnerOrder.State.ORDER_COMMAND;
         this.waitCounter = 0;
      }
   }

   private void handleClickingSlot0() {
      if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
         GenericContainerScreenHandler handler = (GenericContainerScreenHandler)screen.getScreenHandler();
         if (!handler.slots.isEmpty()) {
            this.mc.interactionManager.clickSlot(handler.syncId, 0, 0, SlotActionType.PICKUP, this.mc.player);
            this.currentState = SpawnerOrder.State.DEPOSITING_ITEMS;
            this.waitCounter = 0;
         }
      }
   }

   private void handleDepositingItems() {
      if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
         GenericContainerScreenHandler handler = (GenericContainerScreenHandler)screen.getScreenHandler();
         boolean deposited = false;

         for (int i = 0; i < handler.slots.size(); i++) {
            Slot slot = (Slot)handler.slots.get(i);
            if (slot.inventory == this.mc.player.getInventory() && this.isTargetItem(slot.getStack())) {
               this.mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, this.mc.player);
               deposited = true;
            }
         }

         if (deposited) {
            this.mc.player.closeHandledScreen();
            this.currentState = SpawnerOrder.State.WAITING_CONFIRM_GUI;
            this.waitCounter = 0;
         } else if (this.waitCounter > 40) {
            this.mc.player.closeHandledScreen();
            this.currentState = SpawnerOrder.State.WAITING_FOR_CLOSE;
            this.waitCounter = 0;
         }
      }
   }

   private void handleWaitingConfirmGui() {
      if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
         GenericContainerScreenHandler handler = (GenericContainerScreenHandler)screen.getScreenHandler();
         if (handler.slots.size() > 15 && this.isGreenGlass(handler.getSlot(15).getStack())) {
            this.currentState = SpawnerOrder.State.CONFIRMING_SALE;
            this.waitCounter = 0;
            return;
         }
      }

      if (this.waitCounter > 60) {
         this.currentState = SpawnerOrder.State.WAITING_FOR_CLOSE;
         this.waitCounter = 0;
      }
   }

   private void handleConfirmingSale() {
      if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
         GenericContainerScreenHandler handler = (GenericContainerScreenHandler)screen.getScreenHandler();
         if (handler.slots.size() > 15 && this.isGreenGlass(handler.getSlot(15).getStack())) {
            this.mc.interactionManager.clickSlot(handler.syncId, 15, 0, SlotActionType.PICKUP, this.mc.player);
            this.waitCounter = 0;
            this.currentState = SpawnerOrder.State.WAITING_FOR_CLOSE;
            return;
         }
      }

      this.currentState = SpawnerOrder.State.WAITING_FOR_CLOSE;
      this.waitCounter = 0;
   }

   private void handleClosingOrder() {
      if (this.mc.currentScreen != null) {
         this.mc.player.closeHandledScreen();
      }

      this.currentState = SpawnerOrder.State.WAITING_FOR_CLOSE;
      this.waitCounter = 0;
   }

   private void handleWaitingForClose() {
      if (this.mc.currentScreen == null) {
         if (this.hasItemsToSell()) {
            this.currentState = SpawnerOrder.State.ORDER_COMMAND;
         } else {
            this.currentState = SpawnerOrder.State.WAITING_CYCLE;
            this.lastDropTime = System.currentTimeMillis();
         }

         this.waitCounter = 0;
      } else if (this.waitCounter > 40) {
         this.mc.player.closeHandledScreen();
         this.waitCounter = 0;
         if (this.hasItemsToSell()) {
            this.currentState = SpawnerOrder.State.ORDER_COMMAND;
         } else {
            this.currentState = SpawnerOrder.State.WAITING_CYCLE;
            this.lastDropTime = System.currentTimeMillis();
         }
      }
   }

   private void handleWaitingCycle() {
      if (this.mc.currentScreen != null) {
         this.mc.player.closeHandledScreen();
      }
   }

   private void scanForSpawners() {
      this.spawners.clear();
      BlockPos playerPos = this.mc.player.getBlockPos();
      int radius = 5;

      for (int x = -radius; x <= radius; x++) {
         for (int y = -radius; y <= radius; y++) {
            for (int z = -radius; z <= radius; z++) {
               BlockPos pos = playerPos.method_10069(x, y, z);
               if (this.mc.world.getBlockState(pos).getBlock() instanceof SpawnerBlock) {
                  this.spawners.add(pos);
               }
            }
         }
      }
   }

   private void interactWithBlock(BlockPos pos) {
      try {
         BlockHitResult hitResult = new BlockHitResult(Vec3d.ofCenter(pos), this.mc.player.getHorizontalFacing(), pos, false);
         this.mc.interactionManager.interactBlock(this.mc.player, Hand.field_5808, hitResult);
      } catch (Exception var3) {
      }
   }

   public String getInfoString() {
      if (!this.isActive()) {
         return null;
      } else {
         long timeRemaining = Math.max(0L, (60000L - (System.currentTimeMillis() - this.lastDropTime)) / 1000L);
         return this.currentState.name().replace("_", " ") + " | Next: " + timeRemaining + "s";
      }
   }

   private static enum State {
      INVENTORY_CHECK,
      SCANNING,
      MOVING,
      OPENING,
      DROPPING,
      WAITING_CLOSE,
      CLOSING_GUI,
      ORDER_COMMAND,
      OPENING_ORDER,
      CLICKING_SLOT0,
      DEPOSITING_ITEMS,
      WAITING_CONFIRM_GUI,
      CONFIRMING_SALE,
      CLOSING_ORDER,
      WAITING_FOR_CLOSE,
      WAITING_CYCLE;

      private State() {
      }
   }
}
