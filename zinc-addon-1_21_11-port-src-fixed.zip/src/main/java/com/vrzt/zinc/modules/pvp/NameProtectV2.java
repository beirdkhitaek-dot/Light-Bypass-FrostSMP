package com.vrzt.zinc.modules.pvp;

import com.mojang.authlib.GameProfile;
import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.client.network.PlayerListEntry;

public class NameProtectV2 extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgHiding = this.settings.createGroup("UI Hiding");
   public final Setting<Boolean> hideSelf = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("protect-self")).description("Protect your own identity.")).defaultValue(true)).build());
   public final Setting<Boolean> replaceName = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("replace-name")).description("Replace the name instead of hiding it entirely.")).defaultValue(true))
            .build()
      );
   public final Setting<String> customName = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("custom-name"))
                     .description("The name to display instead of the real one."))
                  .defaultValue("Protected"))
               .visible(this.replaceName::get))
            .build()
      );
   public final Setting<Boolean> protectTab = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("protect-tab")).description("Apply name protection to the Tab list.")).defaultValue(true)).build());
   public final Setting<Boolean> protectChat = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("protect-chat")).description("Replace names in the chat window.")).defaultValue(true)).build());
   public final Setting<Boolean> protectOverlay = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("protect-overlay")).description("Replace names in the text appearing above your hotbar."))
               .defaultValue(true))
            .build()
      );
   public final Setting<Double> range = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("range"))
               .description("Distance to protect player identities in the 3D world."))
            .defaultValue(64.0)
            .min(0.0)
            .sliderMax(128.0)
            .build()
      );
   public final Setting<Boolean> hideFriends = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("protect-friends")).description("Whether to protect friends' identities as well."))
               .defaultValue(false))
            .build()
      );
   public final Setting<Boolean> hideSkins = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("hide-skins")).description("Replaces player skins with default Steve/Alex skins."))
               .defaultValue(false))
            .build()
      );
   public final Setting<Boolean> hideHotbar = this.sgHiding
      .add(((Builder)((Builder)((Builder)new Builder().name("hide-hotbar")).description("Completely hides the hotbar via Mixin.")).defaultValue(false)).build());
   public final Setting<Boolean> hideExp = this.sgHiding
      .add(((Builder)((Builder)((Builder)new Builder().name("hide-experience")).description("Hides the experience bar.")).defaultValue(false)).build());
   public final Setting<Boolean> hideArmor = this.sgHiding
      .add(((Builder)((Builder)((Builder)new Builder().name("hide-armor")).description("Hides the armor bar above the health.")).defaultValue(false)).build());

   public NameProtectV2() {
      super(ZincAddon.pvp, "name-protect-v2", "Global Privacy: Protects everyone in World, Tab, and Chat.");
   }

   public String replaceNameInText(String input) {
      if (this.isActive() && input != null && !input.isEmpty()) {
         String result = input;
         String replacement = (String)this.customName.get();
         if ((Boolean)this.hideSelf.get()) {
            result = input.replace(this.mc.getSession().getUsername(), replacement);
         }

         if (this.mc.getNetworkHandler() != null) {
            for (PlayerListEntry entry : this.mc.getNetworkHandler().getPlayerList()) {
               String name = entry.getProfile().name();
               if (name != null
                  && !name.isEmpty()
                  && !name.equals(this.mc.getSession().getUsername())
                  && (!Friends.get().isFriend(entry) || (Boolean)this.hideFriends.get())) {
                  result = result.replace(name, replacement);
               }
            }
         }

         return result;
      } else {
         return input;
      }
   }

   public boolean shouldProtect(PlayerEntity player) {
      if (this.isActive() && this.mc.player != null && player != null) {
         if (this.mc.getNetworkHandler() != null) {
            PlayerListEntry entry = this.mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            boolean isBedrock = player.getUuidAsString().startsWith("00000000-0000-0000");
            if (entry == null && !isBedrock) {
               return false;
            }
         }

         if (player == this.mc.player) {
            return (Boolean)this.hideSelf.get();
         } else {
            return Friends.get().isFriend(player) ? (Boolean)this.hideFriends.get() : this.mc.player.distanceTo(player) <= (Double)this.range.get();
         }
      } else {
         return false;
      }
   }

   public boolean shouldHideSkin(PlayerEntity player) {
      return this.isActive() && (Boolean)this.hideSkins.get() && this.shouldProtect(player);
   }

   public Text getTabNameFromEntry(PlayerListEntry entry) {
      if (this.isActive() && (Boolean)this.protectTab.get() && entry != null) {
         GameProfile profile = entry.getProfile();
         if ((Boolean)this.hideSelf.get() && profile.name().equals(this.mc.getSession().getUsername())) {
            return Text.literal((String)this.customName.get());
         } else if (Friends.get().isFriend(entry)) {
            return this.hideFriends.get() ? Text.literal((String)this.customName.get()) : null;
         } else {
            return Text.literal((String)this.customName.get());
         }
      } else {
         return null;
      }
   }

   public Text getRenderText(PlayerEntity player) {
      if (this.shouldProtect(player)) {
         return this.replaceName.get() ? Text.literal((String)this.customName.get()) : null;
      } else {
         return player.getDisplayName();
      }
   }
}
