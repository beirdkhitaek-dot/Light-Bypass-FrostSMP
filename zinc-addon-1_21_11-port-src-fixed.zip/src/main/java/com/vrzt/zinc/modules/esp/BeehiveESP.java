package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.block.BeehiveBlock;

public class BeehiveESP extends Module {
   private final SettingGroup sgGeneral = this.settings.createGroup("General");
   private final Setting<SettingColor> beehiveColor = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("beehive-color")).description("Full beehive box color"))
            .defaultValue(new SettingColor(255, 215, 0, 100))
            .build()
      );
   private final Setting<ShapeMode> beehiveShapeMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("Beehive box render mode"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> tracers = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("tracers"))
                  .description("Draw tracers to full beehives"))
               .defaultValue(false))
            .build()
      );
   private final Setting<SettingColor> tracerColor = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("tracer-color")).description("Beehive tracer color"))
               .defaultValue(new SettingColor(255, 215, 0, 200))
               .visible(this.tracers::get))
            .build()
      );
   private final Setting<Boolean> beehiveChat = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("chat-feedback"))
                  .description("Announce beehives in chat"))
               .defaultValue(true))
            .build()
      );
   private final SettingGroup sgFiltering = this.settings.createGroup("Honey Levels");
   private final Setting<Boolean> includeLevel0 = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("level-0"))
                  .description("Include empty beehives (0% honey)"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> includeLevel1 = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("level-1"))
                  .description("Include beehives with 20% honey"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> includeLevel2 = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("level-2"))
                  .description("Include beehives with 40% honey"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> includeLevel3 = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("level-3"))
                  .description("Include beehives with 60% honey"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> includeLevel4 = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("level-4"))
                  .description("Include beehives with 80% honey"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> includeLevel5 = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("level-5"))
                  .description("Include full beehives (100% honey - harvestable)"))
               .defaultValue(true))
            .build()
      );
   private final SettingGroup sgHiveTypes = this.settings.createGroup("Hive Types");
   private final Setting<Boolean> includeBeehives = this.sgHiveTypes
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("beehives"))
                  .description("Include crafted beehives"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> includeBeeNests = this.sgHiveTypes
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("bee-nests"))
                  .description("Include natural bee nests"))
               .defaultValue(true))
            .build()
      );
   private final SettingGroup sgRange = this.settings.createGroup("Range");
   private final Setting<Integer> minY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("min-y"))
                  .description("Minimum Y level to scan for beehives"))
               .defaultValue(50))
            .min(-64)
            .max(128)
            .sliderRange(-64, 128)
            .build()
      );
   private final Setting<Integer> maxY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("max-y"))
                  .description("Maximum Y level to scan for beehives"))
               .defaultValue(200))
            .min(-64)
            .max(320)
            .sliderRange(-64, 320)
            .build()
      );
   private final SettingGroup sgThreading = this.settings.createGroup("Threading");
   private final Setting<Boolean> useThreading = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("enable-threading"))
                  .description("Use multi-threading for chunk scanning (better performance)"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> threadPoolSize = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("thread-pool-size"))
                     .description("Number of threads to use for scanning"))
                  .defaultValue(2))
               .min(1)
               .max(8)
               .sliderRange(1, 8)
               .visible(this.useThreading::get))
            .build()
      );
   private final Setting<Boolean> limitChatSpam = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("limit-chat-spam"))
                     .description("Reduce chat spam when using threading"))
                  .defaultValue(true))
               .visible(this.useThreading::get))
            .build()
      );
   private final Set<BlockPos> beehivePositions = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;

   public BeehiveESP() {
      super(ZincAddon.esp, "BeehiveESP", "ESP for beehives and bee nests when full of honey with threading and tracer support.");
   }

   public void onActivate() {
      if (this.mc.world != null) {
         if ((Boolean)this.useThreading.get()) {
            this.threadPool = Executors.newFixedThreadPool((Integer)this.threadPoolSize.get());
         }

         this.beehivePositions.clear();
         if ((Boolean)this.useThreading.get()) {
            for (Chunk chunk : Utils.chunks()) {
               if (chunk instanceof WorldChunk worldChunk) {
                  this.threadPool.submit(() -> this.scanChunkForBeehives(worldChunk));
               }
            }
         } else {
            for (Chunk chunkx : Utils.chunks()) {
               if (chunkx instanceof WorldChunk worldChunk) {
                  this.scanChunkForBeehives(worldChunk);
               }
            }
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.shutdown();
         this.threadPool = null;
      }

      this.beehivePositions.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if ((Boolean)this.useThreading.get() && this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunkForBeehives(event.chunk()));
      } else {
         this.scanChunkForBeehives(event.chunk());
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      BlockPos pos = event.pos;
      BlockState state = event.newState;
      Runnable updateTask = () -> {
         boolean isBeehive = this.isValidBeehive(state, pos.getY());
         if (isBeehive) {
            boolean wasAdded = this.beehivePositions.add(pos);
            if (wasAdded && (Boolean)this.beehiveChat.get() && (!(Boolean)this.useThreading.get() || !(Boolean)this.limitChatSpam.get())) {
               int honeyLevel = this.getHoneyLevel(state);
               String hiveType = this.getHiveTypeName(state);
               String honeyDescription = this.getHoneyLevelDescription(honeyLevel);
               this.info("§e[§6Beehive ESP§e] §6" + hiveType + " " + honeyDescription + " at " + pos.toShortString(), new Object[0]);
            }
         } else {
            this.beehivePositions.remove(pos);
         }
      };
      if ((Boolean)this.useThreading.get() && this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(updateTask);
      } else {
         updateTask.run();
      }
   }

   private void scanChunkForBeehives(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();
      int xStart = cpos.getStartX();
      int zStart = cpos.getStartZ();
      int yMin = Math.max(chunk.getBottomY(), (Integer)this.minY.get());
      int yMax = Math.min(chunk.getBottomY() + chunk.getHeight(), (Integer)this.maxY.get());
      Set<BlockPos> chunkBeehives = new HashSet<>();
      int foundCount = 0;

      for (int x = xStart; x < xStart + 16; x++) {
         for (int z = zStart; z < zStart + 16; z++) {
            for (int y = yMin; y < yMax; y++) {
               BlockPos pos = new BlockPos(x, y, z);
               BlockState state = chunk.getBlockState(pos);
               if (this.isValidBeehive(state, y)) {
                  chunkBeehives.add(pos);
                  foundCount++;
               }
            }
         }
      }

      this.beehivePositions.removeIf(posx -> {
         ChunkPos blockChunk = new ChunkPos(posx);
         return blockChunk.equals(cpos) && !chunkBeehives.contains(posx);
      });
      int newBlocks = 0;

      for (BlockPos pos : chunkBeehives) {
         if (this.beehivePositions.add(pos)) {
            newBlocks++;
         }
      }

      if ((Boolean)this.beehiveChat.get() && foundCount > 0) {
         if ((Boolean)this.useThreading.get() && (Boolean)this.limitChatSpam.get()) {
            if (newBlocks > 0) {
               this.info("§e[§6Beehive ESP§e] §6Chunk " + cpos.x + "," + cpos.z + "§e: §6" + newBlocks + " new beehives found", new Object[0]);
            }
         } else if (!(Boolean)this.useThreading.get()) {
            for (BlockPos posx : chunkBeehives) {
               if (!this.beehivePositions.contains(posx)) {
                  BlockState state = chunk.getBlockState(posx);
                  int honeyLevel = this.getHoneyLevel(state);
                  String hiveType = this.getHiveTypeName(state);
                  String honeyDescription = this.getHoneyLevelDescription(honeyLevel);
                  this.info("§e[§6Beehive ESP§e] §6" + hiveType + " " + honeyDescription + " at " + posx.toShortString(), new Object[0]);
               }
            }
         }
      }
   }

   private boolean isValidBeehive(BlockState state, int y) {
      if (y >= (Integer)this.minY.get() && y <= (Integer)this.maxY.get()) {
         boolean isBeehive = (Boolean)this.includeBeehives.get() && state.isOf(Blocks.field_20422);
         boolean isBeeNest = (Boolean)this.includeBeeNests.get() && state.isOf(Blocks.field_20421);
         if (!isBeehive && !isBeeNest) {
            return false;
         } else {
            int honeyLevel = this.getHoneyLevel(state);
            if ((Boolean)this.includeLevel0.get() && honeyLevel == 0) {
               return true;
            } else if ((Boolean)this.includeLevel1.get() && honeyLevel == 1) {
               return true;
            } else if ((Boolean)this.includeLevel2.get() && honeyLevel == 2) {
               return true;
            } else if ((Boolean)this.includeLevel3.get() && honeyLevel == 3) {
               return true;
            } else {
               return this.includeLevel4.get() && honeyLevel == 4 ? true : (Boolean)this.includeLevel5.get() && honeyLevel == 5;
            }
         }
      } else {
         return false;
      }
   }

   private int getHoneyLevel(BlockState state) {
      return !state.isOf(Blocks.field_20422) && !state.isOf(Blocks.field_20421)
         ? -1
         : (Integer)state.get(BeehiveBlock.HONEY_LEVEL);
   }

   private String getHiveTypeName(BlockState state) {
      if (state.isOf(Blocks.field_20422)) {
         return "Beehive";
      } else {
         return state.isOf(Blocks.field_20421) ? "Bee Nest" : "Hive";
      }
   }

   private String getHoneyLevelDescription(int honeyLevel) {
      switch (honeyLevel) {
         case 0:
            return "(Empty - 0%)";
         case 1:
            return "(20% Honey)";
         case 2:
            return "(40% Honey)";
         case 3:
            return "(60% Honey)";
         case 4:
            return "(80% Honey)";
         case 5:
            return "(Full - 100% - HARVESTABLE)";
         default:
            return "(Unknown Level)";
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null) {
         Vec3d playerPos = this.mc.player.getLerpedPos(event.tickDelta);
         Color side = new Color((Color)this.beehiveColor.get());
         Color outline = new Color((Color)this.beehiveColor.get());
         Color tracerColorValue = new Color((Color)this.tracerColor.get());
         int renderDistance = (Integer)this.mc.options.getViewDistance().getValue() * 16;

         for (BlockPos pos : this.beehivePositions) {
            if (this.isWithinRenderDistance(playerPos, pos, renderDistance)) {
               BlockState state = this.mc.world.getBlockState(pos);
               int honeyLevel = this.getHoneyLevel(state);
               float intensity = (honeyLevel + 1) / 6.0F;
               Color levelAdjustedSide;
               Color levelAdjustedOutline;
               switch (honeyLevel) {
                  case 0:
                     levelAdjustedSide = new Color((int)(side.r * 0.2F), (int)(side.g * 0.2F), (int)(side.b * 0.2F), side.a);
                     levelAdjustedOutline = new Color((int)(outline.r * 0.2F), (int)(outline.g * 0.2F), (int)(outline.b * 0.2F), outline.a);
                     break;
                  case 1:
                     levelAdjustedSide = new Color((int)(side.r * 0.4F), (int)(side.g * 0.4F), (int)(side.b * 0.4F), side.a);
                     levelAdjustedOutline = new Color((int)(outline.r * 0.4F), (int)(outline.g * 0.4F), (int)(outline.b * 0.4F), outline.a);
                     break;
                  case 2:
                     levelAdjustedSide = new Color((int)(side.r * 0.6F), (int)(side.g * 0.6F), (int)(side.b * 0.6F), side.a);
                     levelAdjustedOutline = new Color((int)(outline.r * 0.6F), (int)(outline.g * 0.6F), (int)(outline.b * 0.6F), outline.a);
                     break;
                  case 3:
                     levelAdjustedSide = new Color((int)(side.r * 0.8F), (int)(side.g * 0.8F), (int)(side.b * 0.8F), side.a);
                     levelAdjustedOutline = new Color((int)(outline.r * 0.8F), (int)(outline.g * 0.8F), (int)(outline.b * 0.8F), outline.a);
                     break;
                  case 4:
                     levelAdjustedSide = side;
                     levelAdjustedOutline = outline;
                     break;
                  case 5:
                     levelAdjustedSide = new Color(
                        Math.min(255, (int)(side.r * 1.3F)), Math.min(255, (int)(side.g * 1.3F)), Math.min(255, (int)(side.b * 1.1F)), side.a
                     );
                     levelAdjustedOutline = new Color(
                        Math.min(255, (int)(outline.r * 1.3F)), Math.min(255, (int)(outline.g * 1.3F)), Math.min(255, (int)(outline.b * 1.1F)), outline.a
                     );
                     break;
                  default:
                     levelAdjustedSide = side;
                     levelAdjustedOutline = outline;
               }

               event.renderer.box(pos, levelAdjustedSide, levelAdjustedOutline, (ShapeMode)this.beehiveShapeMode.get(), 0);
               if ((Boolean)this.tracers.get()) {
                  Vec3d blockCenter = Vec3d.ofCenter(pos);
                  Vec3d startPos;
                  if (this.mc.options.getPerspective().isFirstPerson()) {
                     Vec3d lookDirection = this.mc.player.getRotationVector();
                     startPos = new Vec3d(
                        playerPos.x + lookDirection.x * 0.5,
                        playerPos.y + this.mc.player.getEyeHeight(this.mc.player.getPose()) + lookDirection.y * 0.5,
                        playerPos.z + lookDirection.z * 0.5
                     );
                  } else {
                     startPos = new Vec3d(
                        playerPos.x, playerPos.y + this.mc.player.getEyeHeight(this.mc.player.getPose()), playerPos.z
                     );
                  }

                  event.renderer
                     .line(
                        startPos.x,
                        startPos.y,
                        startPos.z,
                        blockCenter.x,
                        blockCenter.y,
                        blockCenter.z,
                        tracerColorValue
                     );
               }
            }
         }
      }
   }

   private boolean isWithinRenderDistance(Vec3d playerPos, BlockPos blockPos, int renderDistance) {
      double dx = playerPos.x - blockPos.getX() - 0.5;
      double dz = playerPos.z - blockPos.getZ() - 0.5;
      double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
      return horizontalDistance <= renderDistance;
   }
}
