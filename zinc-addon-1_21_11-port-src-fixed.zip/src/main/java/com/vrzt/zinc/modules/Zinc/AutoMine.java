package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoMine extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<AutoMine.TunnelMode> mode = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("tunnel-mode")).defaultValue(AutoMine.TunnelMode.TwoByOne)).build());
   private Vec3d lastPos = Vec3d.ZERO;
   private Vec3d strafeTrackerPos = Vec3d.ZERO;
   private long lastMoveTime = 0L;
   private int strafeTimer = 0;
   private int strafeDirection = 0;
   private double nextStrafeDistance = 12.0;

   public AutoMine() {
      super(ZincAddon.Zinc, "auto-mine", "Miner that shuffles every 10-15 blocks. Manual aiming.");
   }

   public void onActivate() {
      this.lastPos = this.mc.player != null ? this.mc.player.getEntityPos() : Vec3d.ZERO;
      this.strafeTrackerPos = this.lastPos;
      this.lastMoveTime = System.currentTimeMillis();
      this.generateNextStrafeDistance();
   }

   public void onDeactivate() {
      this.mc.options.attackKey.setPressed(false);
      this.mc.options.forwardKey.setPressed(false);
      this.mc.options.jumpKey.setPressed(false);
      this.mc.options.leftKey.setPressed(false);
      this.mc.options.rightKey.setPressed(false);
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.world != null && this.mc.player != null) {
         this.mc.options.attackKey.setPressed(true);
         this.mc.options.forwardKey.setPressed(true);
         this.updateStrafe();
         this.handleJumpLogic();
      }
   }

   private void updateStrafe() {
      if (this.strafeTimer > 0) {
         this.strafeTimer--;
         this.mc.options.leftKey.setPressed(this.strafeDirection == -1);
         this.mc.options.rightKey.setPressed(this.strafeDirection == 1);
      } else {
         this.mc.options.leftKey.setPressed(false);
         this.mc.options.rightKey.setPressed(false);
         this.strafeDirection = 0;
         double distance = this.mc.player.getEntityPos().distanceTo(this.strafeTrackerPos);
         if (distance >= this.nextStrafeDistance) {
            this.strafeTimer = (int)(Math.random() * 8.0) + 5;
            this.strafeDirection = Math.random() > 0.5 ? 1 : -1;
            this.strafeTrackerPos = this.mc.player.getEntityPos();
            this.generateNextStrafeDistance();
         }
      }
   }

   private void generateNextStrafeDistance() {
      this.nextStrafeDistance = 10.0 + Math.random() * 5.0;
   }

   private void handleJumpLogic() {
      BlockPos underFeet = this.mc.player.getBlockPos().method_10074();
      boolean isFalling = this.mc.world.getBlockState(underFeet).isAir() && this.mc.player.isOnGround();
      if (this.mc.player.getEntityPos().distanceTo(this.lastPos) > 0.05) {
         this.lastPos = this.mc.player.getEntityPos();
         this.lastMoveTime = System.currentTimeMillis();
      }

      boolean isStuck = System.currentTimeMillis() - this.lastMoveTime > 3000L;
      if (isFalling || isStuck && this.mc.player.isOnGround()) {
         this.mc.options.jumpKey.setPressed(true);
         if (isStuck) {
            this.lastMoveTime = System.currentTimeMillis();
         }
      } else {
         this.mc.options.jumpKey.setPressed(false);
      }
   }

   public static enum TunnelMode {
      OneByOne("1x1"),
      TwoByOne("2x1");

      private final String title;

      private TunnelMode(String title) {
         this.title = title;
      }

      @Override
      public String toString() {
         return this.title;
      }
   }
}
