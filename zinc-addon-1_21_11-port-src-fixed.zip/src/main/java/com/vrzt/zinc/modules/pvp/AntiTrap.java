package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;

public class AntiTrap extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> removeExisting = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("remove-existing")).description("Remove existing trap entities when enabled.")).defaultValue(true))
            .build()
      );
   private final Setting<Boolean> preventSpawn = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("prevent-spawn")).description("Prevent new trap entities from spawning.")).defaultValue(true))
            .build()
      );
   private final Setting<Boolean> armorStands = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("armor-stands")).description("Target armor stands.")).defaultValue(true)).build());
   private final Setting<Boolean> chestMinecarts = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("chest-minecarts")).description("Target chest minecarts.")).defaultValue(true)).build());

   public AntiTrap() {
      super(ZincAddon.pvp, "AntiTrap", "Allows you to escape from armor stands and chest minecarts.");
   }

   public void onActivate() {
      if ((Boolean)this.removeExisting.get()) {
         this.removeTrapEntities();
      }
   }

   @EventHandler
   private void onEntityAdded(EntityAddedEvent event) {
      if ((Boolean)this.preventSpawn.get()) {
         Entity entity = event.entity;
         if (this.isTrapEntity(entity)) {
            entity.discard();
         }
      }
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.world != null) {
         if (this.mc.player.age % 20 == 0) {
            List<Entity> toRemove = new ArrayList<>();

            for (Entity entity : this.mc.world.getEntities()) {
               if (this.isTrapEntity(entity)) {
                  toRemove.add(entity);
               }
            }

            for (Entity entityx : toRemove) {
               entityx.discard();
            }
         }
      }
   }

   private void removeTrapEntities() {
      if (this.mc.world != null) {
         List<Entity> trapEntities = new ArrayList<>();

         for (Entity entity : this.mc.world.getEntities()) {
            if (this.isTrapEntity(entity)) {
               trapEntities.add(entity);
            }
         }

         for (Entity entityx : trapEntities) {
            entityx.discard();
         }

         if (!trapEntities.isEmpty()) {
            this.info("Removed %d trap entities", new Object[]{trapEntities.size()});
         }
      }
   }

   private boolean isTrapEntity(Entity entity) {
      if (entity == null) {
         return false;
      } else {
         EntityType<?> type = entity.getType();
         return this.armorStands.get() && type == EntityType.field_6131 ? true : (Boolean)this.chestMinecarts.get() && type == EntityType.field_6126;
      }
   }
}
