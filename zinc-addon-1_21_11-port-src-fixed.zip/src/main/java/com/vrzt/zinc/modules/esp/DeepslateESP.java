package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;

public class DeepslateESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgFiltering = this.settings.createGroup("Filtering");
   private final SettingGroup sgThreading = this.settings.createGroup("Threading");
   private final Setting<SettingColor> deepslateColor = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("esp-color")).description("Deepslate box color")).defaultValue(new SettingColor(0, 200, 255, 100)).build());
   private final Setting<ShapeMode> shapeMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("Deepslate box render mode"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> tracers = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("tracers"))
                  .description("Draw tracers to deepslate blocks"))
               .defaultValue(false))
            .build()
      );
   private final Setting<SettingColor> tracerColor = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("tracer-color")).description("Deepslate tracer color"))
               .defaultValue(new SettingColor(0, 200, 255, 200))
               .visible(this.tracers::get))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("chat-feedback"))
                  .description("Announce deepslate in chat"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> minY = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("min-y"))
                  .description("Minimum Y level to scan for deepslate"))
               .defaultValue(8))
            .min(-64)
            .max(320)
            .sliderRange(-64, 320)
            .build()
      );
   private final Setting<Integer> maxY = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("max-y"))
                  .description("Maximum Y level to scan for deepslate"))
               .defaultValue(128))
            .min(-64)
            .max(320)
            .sliderRange(-64, 320)
            .build()
      );
   private final Setting<Boolean> useThreading = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("enable-threading"))
                  .description("Use multi-threading for chunk scanning."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> threadPoolSize = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("thread-pool-size"))
                     .description("Number of threads to use for scanning"))
                  .defaultValue(2))
               .min(1)
               .max(8)
               .visible(this.useThreading::get))
            .build()
      );
   private final Setting<Boolean> limitChatSpam = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("limit-chat-spam"))
                     .description("Reduce chat spam when using threading"))
                  .defaultValue(true))
               .visible(this.useThreading::get))
            .build()
      );
   private final Set<BlockPos> deepslatePositions = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;

   public DeepslateESP() {
      super(ZincAddon.esp, "DeepslateESP", "ESP for deepslate blocks above normal generation levels.");
   }

   public void onActivate() {
      if ((Boolean)this.useThreading.get()) {
         this.threadPool = Executors.newFixedThreadPool((Integer)this.threadPoolSize.get());
      }

      this.deepslatePositions.clear();

      for (Chunk chunk : Utils.chunks()) {
         if (chunk instanceof WorldChunk wc) {
            if ((Boolean)this.useThreading.get()) {
               this.threadPool.submit(() -> this.scanChunk(wc));
            } else {
               this.scanChunk(wc);
            }
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdown();
         this.threadPool = null;
      }

      this.deepslatePositions.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if ((Boolean)this.useThreading.get() && this.threadPool != null) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      } else {
         this.scanChunk(event.chunk());
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      Runnable updateTask = () -> {
         if (this.isDeepslateInRange(event.newState, event.pos.getY())) {
            if (this.deepslatePositions.add(event.pos.toImmutable()) && (Boolean)this.chatFeedback.get() && !(Boolean)this.limitChatSpam.get()) {
               this.info("Deepslate detected at (highlight)%s", new Object[]{event.pos.toShortString()});
            }
         } else {
            this.deepslatePositions.remove(event.pos);
         }
      };
      if ((Boolean)this.useThreading.get() && this.threadPool != null) {
         this.threadPool.submit(updateTask);
      } else {
         updateTask.run();
      }
   }

   private void scanChunk(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();
      int newBlocks = 0;

      for (int x = cpos.getStartX(); x < cpos.getStartX() + 16; x++) {
         for (int z = cpos.getStartZ(); z < cpos.getStartZ() + 16; z++) {
            for (int y = Math.max(chunk.getBottomY(), (Integer)this.minY.get()); y <= Math.min(320, (Integer)this.maxY.get()); y++) {
               BlockPos pos = new BlockPos(x, y, z);
               if (this.isDeepslateInRange(chunk.getBlockState(pos), y) && this.deepslatePositions.add(pos.toImmutable())) {
                  newBlocks++;
               }
            }
         }
      }

      if ((Boolean)this.chatFeedback.get() && newBlocks > 0 && (Boolean)this.limitChatSpam.get()) {
         this.info("Found (highlight)%d§f new deepslate blocks in chunk (highlight)%d, %d", new Object[]{newBlocks, cpos.x, cpos.z});
      }
   }

   private boolean isDeepslateInRange(BlockState state, int y) {
      return y >= (Integer)this.minY.get() && y <= (Integer)this.maxY.get() && state.isOf(Blocks.field_28888);
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      Color side = new Color((Color)this.deepslateColor.get());
      Color line = new Color((Color)this.deepslateColor.get());
      Color tColor = new Color((Color)this.tracerColor.get());

      for (BlockPos pos : this.deepslatePositions) {
         event.renderer.box(pos, side, line, (ShapeMode)this.shapeMode.get(), 0);
         if ((Boolean)this.tracers.get()) {
            event.renderer
               .line(
                  RenderUtils.center.x,
                  RenderUtils.center.y,
                  RenderUtils.center.z,
                  pos.getX() + 0.5,
                  pos.getY() + 0.5,
                  pos.getZ() + 0.5,
                  tColor
               );
         }
      }
   }
}
