package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;

public class HideScoreboard extends Module {
   private ScoreboardObjective savedObjective = null;

   public HideScoreboard() {
      super(ZincAddon.Render, "hide-scoreboard", "Hides the sidebar scoreboard.");
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.world != null) {
         Scoreboard scoreboard = this.mc.world.getScoreboard();
         ScoreboardObjective current = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.field_45157);
         if (current != null) {
            if (this.savedObjective == null) {
               this.savedObjective = current;
            }

            scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.field_45157, null);
         }
      }
   }

   public void onDeactivate() {
      if (this.mc.world != null && this.savedObjective != null) {
         this.mc.world.getScoreboard().setObjectiveSlot(ScoreboardDisplaySlot.field_45157, this.savedObjective);
         this.savedObjective = null;
      }
   }
}
