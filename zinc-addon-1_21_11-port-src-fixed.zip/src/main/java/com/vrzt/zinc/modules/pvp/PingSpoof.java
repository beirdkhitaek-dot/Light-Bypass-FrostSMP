package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;

public class PingSpoof extends Module {
   final List<PingSpoof.PacketEntry> entries = new ArrayList<>();
   final List<Packet<?>> dontRepeat = new ArrayList<>();
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<PingSpoof.Mode> mode = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("mode")).description("The mode to use.")).defaultValue(PingSpoof.Mode.Spoof)).build());
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("delay"))
                  .description("The delay."))
               .defaultValue(50))
            .min(0)
            .sliderMax(1000)
            .build()
      );

   public PingSpoof() {
      super(ZincAddon.pvp, "Ping-Spoof", "Spoof your ping to the given value");
   }

   public void onActivate() {
      this.entries.clear();
      this.dontRepeat.clear();
   }

   @EventHandler
   private void onsendpacket(Send event) {
      if (!this.dontRepeat.contains(event.packet) && this.shouldDelayPacket(event.packet)) {
         event.setCancelled(true);
         this.entries.add(new PingSpoof.PacketEntry(event.packet, ((Integer)this.delay.get()).intValue(), System.currentTimeMillis()));
      } else {
         this.dontRepeat.remove(event.packet);
      }
   }

   boolean shouldDelayPacket(Packet<?> p) {
      return this.mode.get() == PingSpoof.Mode.Delay ? true : p instanceof KeepAliveC2SPacket;
   }

   @EventHandler
   private void ontick(Pre event) {
      if (this.mc.getNetworkHandler() == null) {
         this.toggle();
      } else {
         long c = System.currentTimeMillis();

         for (PingSpoof.PacketEntry entry : this.entries.toArray(new PingSpoof.PacketEntry[0])) {
            if (entry.entryTime + entry.delay <= c) {
               this.dontRepeat.add(entry.packet);
               this.entries.remove(entry);
               this.mc.getNetworkHandler().sendPacket(entry.packet);
            }
         }
      }
   }

   public static enum Mode {
      Delay,
      Spoof;

      private Mode() {
      }
   }

   record PacketEntry(Packet<?> packet, double delay, long entryTime) {
   }
}
