package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoSell extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<AutoSell.SellMode> mode = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("mode")).description("Whether to whitelist or blacklist the selected items."))
               .defaultValue(AutoSell.SellMode.Whitelist))
            .build()
      );
   private final Setting<List<Item>> itemList = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)new meteordevelopment.meteorclient.settings.ItemListSetting.Builder()
                     .name("items"))
                  .description("Items to sell."))
               .defaultValue(List.of(Items.SEA_PICKLE)))
            .build()
      );
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("delay"))
                  .description("Delay in ticks between actions."))
               .defaultValue(1))
            .min(0)
            .max(20)
            .sliderMax(20)
            .build()
      );
   private int delayCounter;
   private boolean shouldReopen = false;

   public AutoSell() {
      super(ZincAddon.Zinc, "AutoSell", "Automatically sells items.");
   }

   public void onActivate() {
      this.delayCounter = 20;
      this.shouldReopen = false;
   }

   public void onDeactivate() {
      this.shouldReopen = false;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.interactionManager != null) {
         if (this.delayCounter > 0) {
            this.delayCounter--;
         } else if (this.shouldReopen) {
            this.mc.getNetworkHandler().sendChatCommand("sell");
            this.shouldReopen = false;
            this.delayCounter = (Integer)this.delay.get();
         } else {
            this.handleSellMode();
         }
      }
   }

   private void handleSellMode() {
      ScreenHandler currentScreenHandler = this.mc.player.currentScreenHandler;
      if (!(currentScreenHandler instanceof GenericContainerScreenHandler)) {
         this.mc.getNetworkHandler().sendChatCommand("sell");
         this.delayCounter = 20;
      } else if (this.areAllSellSlotsOccupied(currentScreenHandler)) {
         this.info("All sell menu slots (0-35) are occupied. Closing and reopening menu.", new Object[0]);
         this.mc.player.closeHandledScreen();
         this.shouldReopen = true;
         this.delayCounter = (Integer)this.delay.get();
      } else {
         int totalSlots = currentScreenHandler.slots.size();
         boolean foundItemToSell = false;

         for (int slot = 36; slot < totalSlots; slot++) {
            ItemStack stack = currentScreenHandler.getSlot(slot).getStack();
            if (!stack.isEmpty()) {
               Item itemInSlot = stack.getItem();
               if (this.shouldSellItem(itemInSlot)) {
                  foundItemToSell = true;
                  this.mc.interactionManager.clickSlot(currentScreenHandler.syncId, slot, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.delayCounter = (Integer)this.delay.get();
                  return;
               }
            }
         }

         if (!foundItemToSell) {
            this.info("All items sold. Closing GUI.", new Object[0]);
            this.mc.player.closeHandledScreen();
            this.toggle();
            this.delayCounter = 40;
         }
      }
   }

   private boolean areAllSellSlotsOccupied(ScreenHandler screenHandler) {
      for (int slot = 0; slot <= 35; slot++) {
         if (slot >= screenHandler.slots.size()) {
            return false;
         }

         ItemStack stack = screenHandler.getSlot(slot).getStack();
         if (stack.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private boolean shouldSellItem(Item item) {
      List<Item> selectedItems = (List<Item>)this.itemList.get();
      return this.mode.get() == AutoSell.SellMode.Whitelist ? selectedItems.contains(item) : !selectedItems.contains(item);
   }

   public static enum SellMode {
      Whitelist,
      Blacklist;

      private SellMode() {
      }
   }
}
