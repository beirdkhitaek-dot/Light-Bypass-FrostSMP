package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.client.option.KeyBinding;

public class KeyPearl extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<KeyPearl.Mode> activationMode = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("activation-mode")).defaultValue(KeyPearl.Mode.Keybind)).build());
   private final Setting<Keybind> activateKey = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()
                     .name("activate-key"))
                  .defaultValue(Keybind.fromKey(71)))
               .visible(() -> this.activationMode.get() == KeyPearl.Mode.Keybind))
            .build()
      );
   private final Setting<Boolean> switchBack = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("switch-back"))
               .defaultValue(true))
            .build()
      );
   private int prevSlot = -1;
   private int pearlSlot = -1;
   private boolean prevPressed = false;
   private KeyBinding activeHotbarKey = null;
   private int timer = 0;
   private boolean isRunning = false;

   public KeyPearl() {
      super(ZincAddon.pvp, "key-pearl", "Hardware Scroll Pearl: 3-tick sequence execution.");
   }

   public void onActivate() {
      this.resetSequence();
   }

   public void onDeactivate() {
      this.releaseKeys();
      this.resetSequence();
   }

   private void resetSequence() {
      this.isRunning = false;
      this.timer = 0;
      this.prevPressed = false;
      this.prevSlot = -1;
      this.pearlSlot = -1;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.interactionManager != null) {
         boolean isPressed = this.isActivated();
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (risingEdge && this.mc.currentScreen == null && !this.isRunning) {
            this.pearlSlot = this.findPearlSlot();
            if (this.pearlSlot != -1) {
               this.prevSlot = this.mc.player.getInventory().getSelectedSlot();
               this.isRunning = true;
               this.timer = 0;
            }
         }

         if (this.isRunning) {
            this.handleSequence();
         }
      }
   }

   private void handleSequence() {
      this.timer++;
      switch (this.timer) {
         case 1:
            this.hardwareSwap(this.pearlSlot);
            break;
         case 2:
            if (this.mc.player.getInventory().getSelectedSlot() == this.pearlSlot) {
               this.mc.options.useKey.setPressed(true);
               ((IMinecraftClient)this.mc).zinc$doItemUse();
               this.mc.options.useKey.setPressed(false);
            }
            break;
         case 3:
            if ((Boolean)this.switchBack.get() && this.prevSlot != -1) {
               this.hardwareSwap(this.prevSlot);
            }

            this.finish();
      }

      if (this.timer > 3) {
         this.finish();
      }
   }

   private void finish() {
      this.releaseKeys();
      this.isRunning = false;
      this.timer = 0;
   }

   private int findPearlSlot() {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8634)) {
            return i;
         }
      }

      return -1;
   }

   private void hardwareSwap(int slot) {
      if (slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();
         int current = this.mc.player.getInventory().getSelectedSlot();
         if (current != slot) {
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
            this.mc.player.getInventory().setSelectedSlot(slot);
         }
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }

      if (this.mc.options != null) {
         this.mc.options.useKey.setPressed(false);
      }
   }

   private boolean isActivated() {
      return switch ((KeyPearl.Mode)this.activationMode.get()) {
         case Keybind -> ((Keybind)this.activateKey.get()).isPressed();
         case RightClick -> this.mc.options.useKey.isPressed();
         case LeftClick -> this.mc.options.attackKey.isPressed();
      };
   }

   public static enum Mode {
      Keybind,
      RightClick,
      LeftClick;

      private Mode() {
      }
   }
}
