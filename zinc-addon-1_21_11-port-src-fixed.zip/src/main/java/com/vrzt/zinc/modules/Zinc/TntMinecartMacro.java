package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.BlockHitResult;

public class TntMinecartMacro extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<TntMinecartMacro.Mode> activationMode = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("activation-mode")).defaultValue(TntMinecartMacro.Mode.Keybind)).build());
   private final Setting<Keybind> activateKey = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()
                     .name("activate-key"))
                  .defaultValue(Keybind.fromKey(82)))
               .visible(() -> this.activationMode.get() == TntMinecartMacro.Mode.Keybind))
            .build()
      );
   private final Setting<Integer> railSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("rail-slot"))
               .defaultValue(1))
            .min(1)
            .max(9)
            .build()
      );
   private final Setting<Integer> tntMinecartSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("tnt-minecart-slot"))
               .defaultValue(2))
            .min(1)
            .max(9)
            .build()
      );
   private final Setting<Integer> bowSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("bow-slot"))
               .defaultValue(3))
            .min(1)
            .max(9)
            .build()
      );
   private final Setting<Integer> returnSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("return-slot"))
               .defaultValue(1))
            .min(1)
            .max(9)
            .build()
      );
   public TntMinecartMacro.State state = TntMinecartMacro.State.IDLE;
   private BlockPos targetPos = null;
   private TntMinecartEntity targetMinecart = null;
   private int bowChargeTicks = 0;
   private int delay = 0;
   private int timeoutTicks = 0;
   private boolean prevPressed = false;
   private KeyBinding activeHotbarKey = null;
   private static final int HARDCODED_BOW_CHARGE = 5;
   private static final int MAX_TIMEOUT = 60;

   public TntMinecartMacro() {
      super(ZincAddon.pvp, "tnt-minecart-macro", "Hardware Scroll TNT Macro using Zinc invokers.");
   }

   public void onDeactivate() {
      this.releaseKeys();
      this.resetState();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         boolean isPressed = this.isActivated();
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (this.state == TntMinecartMacro.State.IDLE) {
            if (risingEdge) {
               this.startSequence();
            }
         } else {
            this.timeoutTicks++;
            if (this.timeoutTicks > 60) {
               this.resetState();
            } else {
               switch (this.state) {
                  case PLACING_RAIL:
                     this.hardwareFullSwap((Integer)this.railSlot.get() - 1);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.state = TntMinecartMacro.State.PLACING_MINECART;
                     this.delay = 1;
                     break;
                  case PLACING_MINECART:
                     if (this.delay > 0) {
                        this.delay--;
                        return;
                     }

                     this.hardwareFullSwap((Integer)this.tntMinecartSlot.get() - 1);
                     BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(this.targetPos), Direction.field_11036, this.targetPos, false);
                     this.mc.interactionManager.interactBlock(this.mc.player, Hand.field_5808, hit);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.state = TntMinecartMacro.State.DRAWING_BOW;
                     this.delay = 2;
                     break;
                  case DRAWING_BOW:
                     if (this.delay > 0) {
                        this.delay--;
                        return;
                     }

                     this.findPlacedMinecart();
                     if (this.targetMinecart == null) {
                        return;
                     }

                     this.hardwareFullSwap((Integer)this.bowSlot.get() - 1);
                     this.mc.options.useKey.setPressed(true);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.state = TntMinecartMacro.State.SHOOTING;
                     this.bowChargeTicks = 0;
                     break;
                  case SHOOTING:
                     this.bowChargeTicks++;
                     if (this.targetMinecart != null && this.targetMinecart.isAlive()) {
                        Rotations.rotate(Rotations.getYaw(this.targetMinecart), Rotations.getPitch(this.targetMinecart));
                     }

                     if (this.bowChargeTicks >= 5) {
                        this.mc.options.useKey.setPressed(false);
                        if (this.mc.interactionManager != null) {
                           this.mc.interactionManager.stopUsingItem(this.mc.player);
                        }

                        this.state = TntMinecartMacro.State.RETURNING;
                        this.delay = 1;
                     }
                     break;
                  case RETURNING:
                     if (this.delay > 0) {
                        this.delay--;
                        return;
                     }

                     this.hardwareFullSwap((Integer)this.returnSlot.get() - 1);
                     if (isPressed) {
                        this.startSequence();
                     } else {
                        this.resetState();
                     }
               }
            }
         }
      }
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }

      this.mc.options.useKey.setPressed(false);
   }

   private void startSequence() {
      this.timeoutTicks = 0;
      if (this.mc.crosshairTarget instanceof BlockHitResult blockHit) {
         this.targetPos = blockHit.getBlockPos().method_10093(blockHit.getSide());
         this.state = TntMinecartMacro.State.PLACING_RAIL;
      } else {
         this.resetState();
      }
   }

   private boolean isActivated() {
      return switch ((TntMinecartMacro.Mode)this.activationMode.get()) {
         case Keybind -> ((Keybind)this.activateKey.get()).isPressed();
         case RightClick -> this.mc.options.useKey.isPressed();
         case LeftClick -> this.mc.options.attackKey.isPressed();
      };
   }

   private void findPlacedMinecart() {
      for (Entity e : this.mc.world.getEntities()) {
         if (e instanceof TntMinecartEntity && e.getBlockPos().getSquaredDistance(this.targetPos) < 2.0) {
            this.targetMinecart = (TntMinecartEntity)e;
            return;
         }
      }
   }

   private void resetState() {
      this.state = TntMinecartMacro.State.IDLE;
      this.targetPos = null;
      this.targetMinecart = null;
      this.bowChargeTicks = 0;
      this.delay = 0;
      this.timeoutTicks = 0;
      this.releaseKeys();
   }

   public static enum Mode {
      Keybind,
      RightClick,
      LeftClick;

      private Mode() {
      }
   }

   public static enum State {
      IDLE,
      PLACING_RAIL,
      PLACING_MINECART,
      DRAWING_BOW,
      SHOOTING,
      RETURNING;

      private State() {
      }
   }
}
