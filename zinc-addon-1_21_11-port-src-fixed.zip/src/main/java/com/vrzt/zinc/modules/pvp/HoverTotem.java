package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixins.HandledScreenMixin;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Items;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

public class HoverTotem extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> hotbarSlot = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("hotbar-slot")).description("The hotbar slot to move the totem to if offhand is full."))
               .defaultValue(1))
            .min(1)
            .max(9)
            .build()
      );
   private int hoverTimer = 0;
   private final int HARDCODED_DELAY = 1;
   private Slot lastHovered = null;
   private boolean wasHoldingTotem = true;

   public HoverTotem() {
      super(ZincAddon.pvp, "HoverTotem", "Pop -> Instant Physical Tap (No Lock).");
   }

   public void onActivate() {
      if (this.mc.player != null) {
         this.wasHoldingTotem = this.isHoldingTotem();
      }

      this.reset();
   }

   public void onDeactivate() {
      this.reset();
   }

   private void reset() {
      this.hoverTimer = 0;
      this.lastHovered = null;
   }

   @EventHandler
   private void onTickPre(Pre event) {
      if (this.mc.player != null) {
         boolean currentlyHolding = this.isHoldingTotem();
         int totalTotems = this.getTotalTotemCount();
         if (this.wasHoldingTotem && !currentlyHolding && totalTotems > 1) {
            int totemSlot = this.findHotbarTotem();
            if (totemSlot != -1) {
               this.simulatePhysicalTap(totemSlot);
            }
         }

         this.wasHoldingTotem = currentlyHolding;
         if (this.mc.currentScreen == null) {
            this.reset();
         } else if (this.mc.currentScreen instanceof InventoryScreen invScreen) {
            Slot hovered = ((HandledScreenMixin)invScreen).zinc$getFocusedSlot();
            if (hovered == null || !hovered.hasStack() || !hovered.getStack().isOf(Items.field_8288)) {
               this.reset();
            } else if (hovered != this.lastHovered) {
               this.lastHovered = hovered;
               this.hoverTimer = 0;
            } else {
               this.hoverTimer++;
               if (this.hoverTimer >= 1) {
                  if (this.mc.player.getOffHandStack().isEmpty()) {
                     this.executeKeybindSwap(hovered.id, 40);
                  } else {
                     int targetIdx = (Integer)this.hotbarSlot.get() - 1;
                     if (!this.mc.player.getInventory().getStack(targetIdx).isOf(Items.field_8288)) {
                        this.executeKeybindSwap(hovered.id, targetIdx);
                     }
                  }

                  this.reset();
               }
            }
         } else {
            this.reset();
         }
      }
   }

   private void simulatePhysicalTap(int slot) {
      int glfwKey = 49 + slot;
      long handle = this.mc.getWindow().getHandle();
      ((com.vrzt.zinc.mixins.IKeyboardAccessor)this.mc.keyboard).invokeOnKey(handle, 1, new net.minecraft.client.input.KeyInput(glfwKey, 0, 0));
      ((com.vrzt.zinc.mixins.IKeyboardAccessor)this.mc.keyboard).invokeOnKey(handle, 0, new net.minecraft.client.input.KeyInput(glfwKey, 0, 0));
   }

   private void executeKeybindSwap(int slotId, int button) {
      if (this.mc.interactionManager != null && this.mc.player.currentScreenHandler != null) {
         this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, slotId, button, SlotActionType.SWAP, this.mc.player);
      }
   }

   private int getTotalTotemCount() {
      int count = 0;
      if (this.mc.player.getOffHandStack().isOf(Items.field_8288)) {
         count++;
      }

      for (int i = 0; i < 36; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8288)) {
            count++;
         }
      }

      return count;
   }

   private int findHotbarTotem() {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8288)) {
            return i;
         }
      }

      return -1;
   }

   private boolean isHoldingTotem() {
      return this.mc.player.getOffHandStack().isOf(Items.field_8288) || this.mc.player.getMainHandStack().isOf(Items.field_8288);
   }
}
