package com.vrzt.zinc.modules.Render;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Formatting;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;

public class ShowMoney extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<String> apiKey = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("api-key")).description("Your DonutSMP API key.")).defaultValue("")).build());
   private final Setting<Boolean> showSelf = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("show-self"))
                  .description("Show your own info tag."))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> showInChat = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("show-in-chat"))
                  .description("Append player info to chat messages."))
               .defaultValue(true))
            .build()
      );
   private final Map<String, ShowMoney.PlayerData> playerCache = new ConcurrentHashMap<>();
   private final Set<String> pendingRequests = ConcurrentHashMap.newKeySet();
   private final Set<String> failedRequests = ConcurrentHashMap.newKeySet();
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
   private final MinecraftClient mc = MinecraftClient.getInstance();

   public ShowMoney() {
      super(ZincAddon.Render, "show-money", "Displays money, Donut+, and Bedrock status.");
   }

   @EventHandler
   private void onReceiveMessage(ReceiveMessageEvent event) {
      if ((Boolean)this.showInChat.get() && !((String)this.apiKey.get()).isEmpty()) {
         String rawText = event.getMessage().getString();
         Pattern pattern = Pattern.compile("(?:^|\\s)([\\.\\*a-zA-Z0-9_]{3,16}):");
         Matcher matcher = pattern.matcher(rawText);
         if (matcher.find()) {
            String playerName = matcher.group(1);
            ShowMoney.PlayerData data = this.playerCache.get(playerName);
            if (data != null) {
               MutableText original = event.getMessage().copy();
               if (data.isDonutPlus) {
                  original.append(Text.literal(" [D+]").formatted(new Formatting[]{Formatting.field_1075, Formatting.field_1067}));
               }

               if (data.isBedrock) {
                  original.append(Text.literal(" [BR]").formatted(Formatting.field_1080));
               }

               String balanceTag = " [" + this.formatMoney(data.money) + "]";
               Formatting moneyColor = data.money >= 1000000000L ? Formatting.field_1065 : Formatting.field_1060;
               original.append(Text.literal(balanceTag).formatted(moneyColor));
               event.setMessage(original);
            } else {
               this.checkAndFetch(playerName);
            }
         }
      }
   }

   private void checkAndFetch(String name) {
      if (!this.playerCache.containsKey(name) && !this.pendingRequests.contains(name) && !this.failedRequests.contains(name)) {
         this.fetchPlayerData(name);
      }
   }

   private void fetchPlayerData(String playerName) {
      this.pendingRequests.add(playerName);
      HttpRequest request = HttpRequest.newBuilder()
         .uri(URI.create("https://api.donutsmp.net/v1/stats/" + playerName))
         .header("Authorization", "Bearer " + (String)this.apiKey.get())
         .GET()
         .build();
      this.httpClient
         .sendAsync(request, BodyHandlers.ofString())
         .thenAccept(
            response -> {
               this.pendingRequests.remove(playerName);
               if (response.statusCode() == 200) {
                  try {
                     JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                     JsonObject result = json.getAsJsonObject("result");
                     if (result != null) {
                        long money = result.has("money") ? result.get("money").getAsLong() : 0L;
                        boolean isPlus = result.has("donut_plus") && result.get("donut_plus").getAsBoolean()
                           || result.has("is_donut_plus") && result.get("is_donut_plus").getAsBoolean();
                        boolean isBedrock = playerName.startsWith(".")
                           || playerName.startsWith("*")
                           || result.has("platform") && result.get("platform").getAsString().equalsIgnoreCase("bedrock");
                        this.playerCache.put(playerName, new ShowMoney.PlayerData(money, isPlus, isBedrock));
                     }
                  } catch (Exception var9) {
                  }
               } else {
                  this.failedRequests.add(playerName);
               }
            }
         );
   }

   private String formatMoney(long money) {
      if (money >= 1000000000L) {
         return String.format("%.1fB$", money / 1.0E9);
      } else if (money >= 1000000L) {
         return String.format("%.1fM$", money / 1000000.0);
      } else {
         return money >= 1000L ? String.format("%.1fk$", money / 1000.0) : money + "$";
      }
   }

   private static class PlayerData {
      long money;
      boolean isDonutPlus;
      boolean isBedrock;

      PlayerData(long money, boolean isDonutPlus, boolean isBedrock) {
         this.money = money;
         this.isDonutPlus = isDonutPlus;
         this.isBedrock = isBedrock;
      }
   }
}
