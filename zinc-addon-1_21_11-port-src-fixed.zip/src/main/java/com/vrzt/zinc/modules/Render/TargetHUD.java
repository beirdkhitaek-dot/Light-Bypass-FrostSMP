package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.modules.pvp.NameProtectV2;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.gui.PlayerSkinDrawer;

public class TargetHUD extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgRender = this.settings.createGroup("Render");
   private final Setting<Integer> posX = this.sgGeneral.add(((Builder)((Builder)new Builder().name("x")).defaultValue(10)).min(0).sliderMax(1920).build());
   private final Setting<Integer> posY = this.sgGeneral.add(((Builder)((Builder)new Builder().name("y")).defaultValue(10)).min(0).sliderMax(1080).build());
   private final Setting<Double> scale = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder().name("scale"))
            .defaultValue(1.0)
            .min(0.5)
            .sliderMax(3.0)
            .build()
      );
   private final Setting<Boolean> playersOnly = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("players-only"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> bgColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("background"))
            .defaultValue(new SettingColor(0, 0, 0, 150))
            .build()
      );
   private final Setting<SettingColor> outlineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("outline"))
            .defaultValue(new SettingColor(255, 255, 255, 200))
            .build()
      );
   private LivingEntity target;
   private long lastHitTime;
   private float alpha;
   private float slide;
   private float healthAnim;
   private static final long TIMEOUT = 6000L;
   private static final double EXPLOSION_RANGE = 6.0;
   private static final int WIDTH = 150;
   private static final int HEIGHT = 52;
   private static final int FACE = 22;
   private static final int PAD = 5;

   public TargetHUD() {
      super(ZincAddon.Render, "TargetHUD", "Target HUD with NameProtect Integration");
   }

   public void onDeactivate() {
      this.target = null;
      this.alpha = 0.0F;
      this.slide = 0.0F;
      this.healthAnim = 0.0F;
   }

   @EventHandler
   private void onAttack(AttackEntityEvent e) {
      if (e.entity instanceof LivingEntity living) {
         if (living != this.mc.player) {
            if (!(Boolean)this.playersOnly.get() || living instanceof PlayerEntity) {
               this.setTarget(living);
            }
         }
      }
   }

   @EventHandler
   private void onPacket(Receive e) {
      if (this.mc.world != null && this.mc.player != null) {
         if (e.packet instanceof ExplosionS2CPacket p) {
            this.updateTargetNear(p.comp_2883());
         }
      }
   }

   private void updateTargetNear(Vec3d pos) {
      if (this.mc.player != null && this.mc.world != null) {
         PlayerEntity nearest = this.mc.world.getClosestPlayer(pos.x, pos.y, pos.z, 6.0, p -> p != this.mc.player);
         if (nearest != null) {
            this.setTarget(nearest);
         }
      }
   }

   private void setTarget(LivingEntity e) {
      this.target = e;
      this.lastHitTime = System.currentTimeMillis();
      this.healthAnim = e.getHealth() + e.getAbsorptionAmount();
   }

   @EventHandler
   private void onRender(Render2DEvent e) {
      if (this.mc.player != null && this.mc.world != null && this.target != null) {
         boolean visible = this.target.isAlive() && !this.target.isRemoved() && System.currentTimeMillis() - this.lastHitTime < 6000L;
         this.alpha = MathHelper.lerp(0.15F, this.alpha, visible ? 1.0F : 0.0F);
         this.slide = MathHelper.lerp(0.15F, this.slide, visible ? 1.0F : 0.0F);
         if (this.alpha < 0.01F) {
            if (!visible) {
               this.target = null;
            }
         } else {
            float hp = Math.max(0.0F, this.target.getHealth() + this.target.getAbsorptionAmount());
            this.healthAnim = MathHelper.lerp(0.2F, this.healthAnim, hp);
            DrawContext ctx = e.drawContext;
            ctx.getMatrices().pushMatrix();
            float slideOffset = (1.0F - this.slide) * -40.0F;
            ctx.getMatrices().translate(((Integer)this.posX.get()).intValue() + slideOffset, ((Integer)this.posY.get()).intValue());
            ctx.getMatrices().scale(((Double)this.scale.get()).floatValue(), ((Double)this.scale.get()).floatValue());
            this.drawHud(ctx);
            ctx.getMatrices().popMatrix();
         }
      }
   }

   private void drawHud(DrawContext ctx) {
      int bg = Color.fromRGBA(
         ((SettingColor)this.bgColor.get()).r,
         ((SettingColor)this.bgColor.get()).g,
         ((SettingColor)this.bgColor.get()).b,
         (int)(((SettingColor)this.bgColor.get()).a * this.alpha)
      );
      int outline = Color.fromRGBA(
         ((SettingColor)this.outlineColor.get()).r,
         ((SettingColor)this.outlineColor.get()).g,
         ((SettingColor)this.outlineColor.get()).b,
         (int)(((SettingColor)this.outlineColor.get()).a * this.alpha)
      );
      ctx.fill(0, 0, 150, 52, bg);
      this.drawOutline(ctx, 0, 0, 150, 52, outline);
      NameProtectV2 nameProtect = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      String displayName = this.target.getName().getString();
      boolean protectedTarget = false;
      if (this.target instanceof PlayerEntity player && nameProtect != null && nameProtect.isActive() && nameProtect.shouldProtect(player)) {
         protectedTarget = true;
         Text protText = nameProtect.getRenderText(player);
         displayName = protText != null ? protText.getString() : "Hidden";
      }

      PlayerListEntry entry = this.mc.getNetworkHandler() != null ? this.mc.getNetworkHandler().getPlayerListEntry(this.target.getUuid()) : null;
      if (entry != null) {
         if (protectedTarget && (Boolean)nameProtect.hideSkins.get()) {
            PlayerSkinDrawer.draw(ctx, DefaultSkinHelper.getSkinTextures(entry.getProfile()), 5, 5, 22);
         } else {
            PlayerSkinDrawer.draw(ctx, entry.getSkinTextures(), 5, 5, 22);
         }
      }

      int textX = 33;
      ctx.drawText(this.mc.textRenderer, displayName, textX, 5, -1, true);
      float health = Math.max(0.0F, this.target.getHealth());
      float absorption = this.target.getAbsorptionAmount();
      float maxHealth = Math.max(1.0F, this.target.getMaxHealth());
      float healthRatio = MathHelper.clamp(health / maxHealth, 0.0F, 1.0F);
      float absRatio = MathHelper.clamp(absorption / maxHealth, 0.0F, 1.0F);
      int barW = 150 - textX - 5;
      int barY = 17;
      int barH = 5;
      int hpColor = 0xFF000000 | MathHelper.hsvToRgb(healthRatio / 3.0F, 1.0F, 1.0F);
      ctx.fill(textX, barY, textX + barW, barY + barH, 1426063360);
      int healthEnd = textX + (int)(barW * healthRatio);
      ctx.fill(textX, barY, healthEnd, barY + barH, hpColor);
      if (absorption > 0.0F) {
         int absEnd = Math.min(healthEnd + (int)(barW * absRatio), textX + barW);
         ctx.fill(healthEnd, barY, absEnd, barY + barH, -10496);
      }

      int x = 5;
      int y = 30;
      EquipmentSlot[] slots = new EquipmentSlot[]{
         EquipmentSlot.field_6173, EquipmentSlot.field_6171, EquipmentSlot.field_6169, EquipmentSlot.field_6174, EquipmentSlot.field_6172, EquipmentSlot.field_6166
      };

      for (EquipmentSlot slot : slots) {
         ItemStack stack = this.target.getEquippedStack(slot);
         if (!stack.isEmpty()) {
            ctx.drawItem(stack, x, y);
            x += 18;
         }
      }
   }

   private void drawOutline(DrawContext ctx, int x1, int y1, int x2, int y2, int c) {
      ctx.fill(x1 - 1, y1 - 1, x2 + 1, y1, c);
      ctx.fill(x1 - 1, y2, x2 + 1, y2 + 1, c);
      ctx.fill(x1 - 1, y1, x1, y2, c);
      ctx.fill(x2, y1, x2 + 1, y2, c);
   }
}
