package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public class RoninHat extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Double> scale = this.sgGeneral.add(((Builder)new Builder().name("scale")).defaultValue(1.0).min(0.5).sliderMax(2.0).build());
   private final Setting<Double> yOffset = this.sgGeneral.add(((Builder)new Builder().name("y-offset")).defaultValue(0.15).min(-1.0).sliderMax(1.0).build());
   private final Setting<Integer> segments = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("smoothness"))
               .defaultValue(32))
            .min(8)
            .sliderMax(64)
            .build()
      );
   private final Setting<SettingColor> hatColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("hat-color"))
            .defaultValue(new SettingColor(180, 160, 120, 200))
            .build()
      );

   public RoninHat() {
      super(ZincAddon.Render, "ronin-hat", "A Samurai hat that stays locked to the head model.");
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.world != null && this.mc.player != null) {
         for (PlayerEntity player : this.mc.world.getPlayers()) {
            if (player != this.mc.player || !this.mc.options.getPerspective().isFirstPerson()) {
               this.renderHat(event, player);
            }
         }
      }
   }

   private void renderHat(Render3DEvent event, PlayerEntity player) {
      float delta = event.tickDelta;
      double x = MathHelper.lerp(delta, player.lastRenderX, player.getX());
      double y = MathHelper.lerp(delta, player.lastRenderY, player.getY());
      double z = MathHelper.lerp(delta, player.lastRenderZ, player.getZ());
      float yaw = player.getHeadYaw();
      float pitch = player.getPitch();
      double eyeHeight = player.getEyeHeight(player.getPose());
      Vec3d pivot = new Vec3d(x, y + eyeHeight, z);
      if (player.isSneaking()) {
         pivot = pivot.add(0.0, -0.125, 0.0);
      }

      this.drawHat(event, pivot, yaw, pitch);
   }

   private void drawHat(Render3DEvent event, Vec3d pivot, float yaw, float pitch) {
      int segs = (Integer)this.segments.get();
      double s = (Double)this.scale.get();
      double r = 0.45 * s;
      double h = 0.22 * s;
      double vOff = (Double)this.yOffset.get();
      SettingColor color = (SettingColor)this.hatColor.get();
      SettingColor lineCol = new SettingColor(color.r, color.g, color.b, 255);
      Vec3d tip = this.rotate(new Vec3d(0.0, vOff + h, 0.0), yaw, pitch).add(pivot);

      for (int i = 0; i < segs; i++) {
         double angle1 = (double)i / segs * Math.PI * 2.0;
         double angle2 = (double)(i + 1) / segs * Math.PI * 2.0;
         Vec3d p1Rel = new Vec3d(Math.cos(angle1) * r, vOff, Math.sin(angle1) * r);
         Vec3d p2Rel = new Vec3d(Math.cos(angle2) * r, vOff, Math.sin(angle2) * r);
         Vec3d p1 = this.rotate(p1Rel, yaw, pitch).add(pivot);
         Vec3d p2 = this.rotate(p2Rel, yaw, pitch).add(pivot);
         event.renderer
            .quad(
               p1.x,
               p1.y,
               p1.z,
               p2.x,
               p2.y,
               p2.z,
               tip.x,
               tip.y,
               tip.z,
               tip.x,
               tip.y,
               tip.z,
               color
            );
         event.renderer.line(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, lineCol);
         event.renderer.line(p1.x, p1.y, p1.z, tip.x, tip.y, tip.z, lineCol);
      }
   }

   private Vec3d rotate(Vec3d vec, float yaw, float pitch) {
      float p = (float)Math.toRadians(pitch);
      float y = (float)Math.toRadians(-yaw);
      double cosP = Math.cos(p);
      double sinP = Math.sin(p);
      double y1 = vec.y * cosP - vec.z * sinP;
      double z1 = vec.y * sinP + vec.z * cosP;
      double cosY = Math.cos(y);
      double sinY = Math.sin(y);
      double x2 = vec.x * cosY + z1 * sinY;
      double z2 = -vec.x * sinY + z1 * cosY;
      return new Vec3d(x2, y1, z2);
   }
}
