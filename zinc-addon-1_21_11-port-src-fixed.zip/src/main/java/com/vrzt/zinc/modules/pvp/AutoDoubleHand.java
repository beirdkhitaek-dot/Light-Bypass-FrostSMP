package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;

public class AutoDoubleHand extends Module {
   private boolean wasHoldingTotem = true;
   private boolean needsToSwitch = false;
   private int targetSlot = -1;

   public AutoDoubleHand() {
      super(ZincAddon.pvp, "Auto-Double-Hand", "Simulates physical key presses to switch to a totem after popping.");
   }

   public void onActivate() {
      if (this.mc.player != null) {
         this.wasHoldingTotem = this.mc.player.getOffHandStack().isOf(Items.field_8288);
      }

      this.needsToSwitch = false;
      this.targetSlot = -1;
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null) {
         boolean holdingNow = this.mc.player.getOffHandStack().isOf(Items.field_8288);
         if (this.wasHoldingTotem && !holdingNow) {
            int slot = this.findHotbarTotem();
            if (slot != -1) {
               this.targetSlot = slot;
               this.needsToSwitch = true;
            }
         }

         if (this.needsToSwitch) {
            this.simulateKeySwitch(this.targetSlot);
            this.needsToSwitch = false;
         }

         this.wasHoldingTotem = holdingNow;
      }
   }

   private void simulateKeySwitch(int slot) {
      if (this.mc.getWindow() != null && this.mc.keyboard != null) {
         int glfwKey = switch (slot) {
            case 0 -> 49;
            case 1 -> 50;
            case 2 -> 51;
            case 3 -> 52;
            case 4 -> 53;
            case 5 -> 54;
            case 6 -> 55;
            case 7 -> 56;
            case 8 -> 57;
            default -> -1;
         };
         if (glfwKey != -1) {
            ((com.vrzt.zinc.mixins.IKeyboardAccessor)this.mc.keyboard).invokeOnKey(this.mc.getWindow().getHandle(), 1, new net.minecraft.client.input.KeyInput(glfwKey, 0, 0));
            ((com.vrzt.zinc.mixins.IKeyboardAccessor)this.mc.keyboard).invokeOnKey(this.mc.getWindow().getHandle(), 0, new net.minecraft.client.input.KeyInput(glfwKey, 0, 0));
         }
      }
   }

   private int findHotbarTotem() {
      if (this.mc.player == null) {
         return -1;
      } else {
         for (int i = 0; i < 9; i++) {
            if (this.mc.player.getInventory().getStack(i).isOf(Items.field_8288)) {
               return i;
            }
         }

         return -1;
      }
   }
}
