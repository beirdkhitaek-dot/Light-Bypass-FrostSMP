package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.world.ChunkOcclusionEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import org.joml.Vector3d;

public class ZincFreecam extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Double> speed = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("speed")).description("Camera movement speed.")).defaultValue(1.0).min(0.1).sliderMax(5.0).build());
   public final Vector3d pos = new Vector3d();
   public final Vector3d prevPos = new Vector3d();
   public float yaw;
   public float pitch;
   public float prevYaw;
   public float prevPitch;
   private boolean forward;
   private boolean backward;
   private boolean left;
   private boolean right;
   private boolean up;
   private boolean down;

   public ZincFreecam() {
      super(ZincAddon.Render, "ZincFreecam", "Smooth Flat-Movement Freecam.");
   }

   public void onActivate() {
      if (this.mc.player != null) {
         Vec3d eyePos = this.mc.gameRenderer.getCamera().getCameraPos();
         this.pos.set(eyePos.x, eyePos.y, eyePos.z);
         this.prevPos.set(this.pos);
         this.yaw = this.mc.player.getYaw();
         this.pitch = this.mc.player.getPitch();
         this.prevYaw = this.yaw;
         this.prevPitch = this.pitch;
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.backKey.setPressed(false);
         this.mc.options.leftKey.setPressed(false);
         this.mc.options.rightKey.setPressed(false);
         this.mc.options.jumpKey.setPressed(false);
         this.mc.options.sneakKey.setPressed(false);
         this.mc.options.sprintKey.setPressed(false);
         this.mc.player.setSprinting(false);
         this.unpress();
         if (this.mc.worldRenderer != null) {
            this.mc.worldRenderer.reload();
         }
      }
   }

   public void onDeactivate() {
      if (this.mc.worldRenderer != null) {
         this.mc.worldRenderer.reload();
      }
   }

   private void unpress() {
      this.forward = this.backward = this.left = this.right = this.up = this.down = false;
   }

   @EventHandler
   private void onChunkOcclusion(ChunkOcclusionEvent event) {
      event.cancel();
   }

   public void changeLookDirection(double dx, double dy) {
      double s = (Double)this.mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
      double multiplier = s * s * s * 8.0;
      this.yaw += (float)(dx * multiplier * 0.15);
      this.pitch += (float)(dy * multiplier * 0.15);
      this.pitch = MathHelper.clamp(this.pitch, -90.0F, 90.0F);
   }

   @EventHandler
   private void onTick(Pre event) {
      this.prevPos.set(this.pos);
      this.prevYaw = this.yaw;
      this.prevPitch = this.pitch;
      Vec3d fwd = Vec3d.fromPolar(0.0F, this.yaw);
      Vec3d side = Vec3d.fromPolar(0.0F, this.yaw + 90.0F);
      double s = (Double)this.speed.get() * (this.mc.options.sprintKey.isPressed() ? 2.0 : 1.0) * 0.2;
      double x = 0.0;
      double y = 0.0;
      double z = 0.0;
      if (this.forward) {
         x += fwd.x * s;
         z += fwd.z * s;
      }

      if (this.backward) {
         x -= fwd.x * s;
         z -= fwd.z * s;
      }

      if (this.right) {
         x += side.x * s;
         z += side.z * s;
      }

      if (this.left) {
         x -= side.x * s;
         z -= side.z * s;
      }

      if (this.up) {
         y += s;
      }

      if (this.down) {
         y -= s;
      }

      this.pos.add(x, y, z);
   }

   public double getX(float t) {
      return MathHelper.lerp(t, this.prevPos.x, this.pos.x);
   }

   public double getY(float t) {
      return MathHelper.lerp(t, this.prevPos.y, this.pos.y);
   }

   public double getZ(float t) {
      return MathHelper.lerp(t, this.prevPos.z, this.pos.z);
   }

   public float getYaw(float t) {
      return MathHelper.lerp(t, this.prevYaw, this.yaw);
   }

   public float getPitch(float t) {
      return MathHelper.lerp(t, this.prevPitch, this.pitch);
   }

   @EventHandler
   private void onKey(KeyEvent event) {
      if (this.mc.currentScreen == null) {
         boolean isPressed = !event.action.toString().contains("Release");
         if (this.mc.options.forwardKey.matchesKey(event.input)) {
            this.forward = isPressed;
         } else if (this.mc.options.backKey.matchesKey(event.input)) {
            this.backward = isPressed;
         } else if (this.mc.options.leftKey.matchesKey(event.input)) {
            this.left = isPressed;
         } else if (this.mc.options.rightKey.matchesKey(event.input)) {
            this.right = isPressed;
         } else if (this.mc.options.jumpKey.matchesKey(event.input)) {
            this.up = isPressed;
         } else {
            if (!this.mc.options.sneakKey.matchesKey(event.input)) {
               return;
            }

            this.down = isPressed;
         }

         event.cancel();
      }
   }
}
