package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.client.option.KeyBinding;

public class SwordAxeWindJump extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> returnSlot = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("return-slot")).description("The hotbar slot to return to.")).defaultValue(1)).min(1).max(9).build()
      );
   private boolean prevPressed = false;
   private int timer = -1;
   private KeyBinding activeHotbarKey = null;

   public SwordAxeWindJump() {
      super(ZincAddon.pvp, "wind-jump-macro", "Right-Click: Swap to Wind Charge -> Jump + Use -> Return. Supports Mace.");
   }

   public void onDeactivate() {
      this.releaseKeys();
      this.timer = -1;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         boolean isPressed = this.mc.options.useKey.isPressed();
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (this.timer != -1) {
            this.handleSequence();
         } else {
            if (risingEdge && this.isCombatItem(this.mc.player.getMainHandStack())) {
               int windSlot = this.findSlot(Items.field_49098);
               if (windSlot != -1) {
                  this.timer = 0;
                  this.handleSequence();
               }
            }
         }
      }
   }

   private void handleSequence() {
      switch (this.timer) {
         case 0:
            int windSlot = this.findSlot(Items.field_49098);
            if (windSlot == -1) {
               this.timer = -1;
               return;
            }

            this.hardwareFullSwap(windSlot);
            this.mc.options.jumpKey.setPressed(true);
            break;
         case 1:
            this.mc.options.jumpKey.setPressed(false);
            break;
         case 2:
            this.releaseKeys();
            this.hardwareFullSwap((Integer)this.returnSlot.get() - 1);
            this.timer = -1;
            return;
      }

      this.timer++;
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }

      this.mc.options.jumpKey.setPressed(false);
   }

   private boolean isCombatItem(ItemStack stack) {
      String name = stack.getItem().toString().toLowerCase();
      return name.contains("sword") || name.contains("axe") || name.contains("mace");
   }

   private int findSlot(Item item) {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(item)) {
            return i;
         }
      }

      return -1;
   }
}
