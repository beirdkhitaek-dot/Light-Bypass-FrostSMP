package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import com.vrzt.zinc.utils.zinc.ZincToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class PillagerESP extends Module {
   private final SettingGroup sgGeneral = this.settings.createGroup("General");
   private final SettingGroup sgESP = this.settings.createGroup("ESP");
   private final SettingGroup sgTracers = this.settings.createGroup("Tracers");
   private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
   private final Setting<Integer> maxDistance = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("max-distance")).description("Maximum distance to render pillagers")).defaultValue(128))
            .range(16, 256)
            .sliderRange(16, 256)
            .build()
      );
   private final Setting<Boolean> showCount = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("show-count"))
                  .description("Show pillager count in chat"))
               .defaultValue(true))
            .build()
      );
   private final Setting<PillagerESP.NotificationMode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-mode"))
                  .description("How to notify when pillagers are detected"))
               .defaultValue(PillagerESP.NotificationMode.Both))
            .build()
      );
   private final Setting<Boolean> toggleOnFind = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("toggle-when-found"))
                  .description("Automatically toggles the module when pillagers are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> enableDisconnect = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("disconnect"))
                  .description("Automatically disconnect when pillagers are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<SettingColor> espColor = this.sgESP
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("esp-color"))
               .description("Color of pillager ESP"))
            .defaultValue(new SettingColor(255, 0, 0, 100))
            .build()
      );
   private final Setting<ShapeMode> shapeMode = this.sgESP
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("How the ESP shapes are rendered"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> tracersEnabled = this.sgTracers
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("tracers-enabled"))
                  .description("Enable tracers to pillagers"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> tracerColor = this.sgTracers
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("tracer-color"))
                  .description("Color of tracers"))
               .defaultValue(new SettingColor(255, 0, 0, 255))
               .visible(this.tracersEnabled::get))
            .build()
      );
   private final Setting<PillagerESP.TracersMode> tracersMode = this.sgTracers
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("tracers-mode"))
                     .description("How tracers are rendered"))
                  .defaultValue(PillagerESP.TracersMode.Line))
               .visible(this.tracersEnabled::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("webhook"))
                  .description("Send webhook notifications when pillagers are detected"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("webhook-url"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("self-ping"))
                     .description("Ping yourself in the webhook message"))
                  .defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("discord-id"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private final List<PillagerEntity> pillagers = new ArrayList<>();
   private final Set<Integer> detectedPillagers = new HashSet<>();
   private int lastPillagerCount = 0;
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public PillagerESP() {
      super(ZincAddon.esp, "PillagerESP", "ESP for pillagers with tracers, webhook notifications and info display");
   }

   public void onActivate() {
      this.pillagers.clear();
      this.detectedPillagers.clear();
      this.lastPillagerCount = 0;
   }

   public void onDeactivate() {
      this.pillagers.clear();
      this.detectedPillagers.clear();
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && event.renderer != null) {
         try {
            this.pillagers.clear();
            Set<Integer> currentPillagers = new HashSet<>();

            for (Entity entity : this.mc.world.getEntities()) {
               if (entity instanceof PillagerEntity pillager) {
                  double distance = this.mc.player.distanceTo(pillager);
                  if (distance <= ((Integer)this.maxDistance.get()).intValue()) {
                     this.pillagers.add(pillager);
                     currentPillagers.add(entity.getId());
                  }
               }
            }

            if ((Boolean)this.showCount.get() && this.pillagers.size() != this.lastPillagerCount) {
               if (this.pillagers.size() > 0) {
                  String pillagerText = this.pillagers.size() == 1 ? "pillager" : "pillagers";
                  String message = this.pillagers.size() + " " + pillagerText + " nearby";
                  switch ((PillagerESP.NotificationMode)this.notificationMode.get()) {
                     case Chat:
                        this.info("§5[§dPillagerESP§5] §c" + message, new Object[0]);
                        break;
                     case Toast:
                        this.mc
                           .getToastManager()
                           .add(
                              new PillagerESP.PillagerToast(
                                 Items.field_8399.getDefaultStack(),
                                 Text.literal("PillagerESP"),
                                 Text.literal(this.pillagers.size() + " pillager" + (this.pillagers.size() != 1 ? "s" : ""))
                              )
                           );
                        break;
                     case Both:
                        this.info("§5[§dPillagerESP§5] §c" + message, new Object[0]);
                        this.mc
                           .getToastManager()
                           .add(
                              new PillagerESP.PillagerToast(
                                 Items.field_8399.getDefaultStack(),
                                 Text.literal("PillagerESP"),
                                 Text.literal(this.pillagers.size() + " pillager" + (this.pillagers.size() != 1 ? "s" : ""))
                              )
                           );
                  }
               }

               this.lastPillagerCount = this.pillagers.size();
            }

            if (!currentPillagers.isEmpty() && !currentPillagers.equals(this.detectedPillagers)) {
               Set<Integer> newPillagers = new HashSet<>(currentPillagers);
               newPillagers.removeAll(this.detectedPillagers);
               if (!newPillagers.isEmpty()) {
                  this.detectedPillagers.addAll(newPillagers);
                  this.handlePillagerDetection(this.pillagers.size());
               }
            } else if (currentPillagers.isEmpty()) {
               this.detectedPillagers.clear();
            }

            for (PillagerEntity pillagerx : this.pillagers) {
               if (pillagerx != null && pillagerx.isAlive()) {
                  try {
                     this.renderPillager(pillagerx, event);
                  } catch (Exception var8) {
                  }
               }
            }
         } catch (Exception var9) {
         }
      }
   }

   private void handlePillagerDetection(int pillagerCount) {
      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(pillagerCount);
      }

      if ((Boolean)this.toggleOnFind.get()) {
         this.toggle();
      }

      if ((Boolean)this.enableDisconnect.get()) {
         String message = pillagerCount == 1 ? "Pillager detected!" : String.format("%d pillagers detected!", pillagerCount);
         this.disconnectFromServer(message);
      }
   }

   private void sendWebhookNotification(int pillagerCount) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (url.isEmpty()) {
         this.warning("Webhook URL not configured!", new Object[0]);
      } else {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
                  String messageContent = "";
                  if ((Boolean)this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()) {
                     messageContent = String.format("<@%s>", ((String)this.discordId.get()).trim());
                  }

                  String pillagerText = pillagerCount == 1 ? "pillager" : "pillagers";
                  String description = String.format("%d %s detected", pillagerCount, pillagerText);
                  String coordinates = "Unknown";
                  if (this.mc.player != null) {
                     coordinates = String.format(
                        "X: %.0f, Y: %.0f, Z: %.0f", this.mc.player.getX(), this.mc.player.getY(), this.mc.player.getZ()
                     );
                  }

                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"PillagerESP\",\"avatar_url\":\"https://minecraft.wiki/images/4/4b/Pillager_JE2_BE2.png\",\"embeds\":[{\"title\":\"⚔️ Pillager Alert\",\"description\":\"%s\",\"color\":16711680,\"thumbnail\":{\"url\":\"https://minecraft.wiki/images/4/4b/Pillager_JE2_BE2.png\"},\"fields\":[{\"name\":\"Count\",\"value\":\"%d\",\"inline\":true},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Coordinates\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Sent by zinc\"}}]}",
                     messageContent.replace("\"", "\\\""),
                     description.replace("\"", "\\\""),
                     pillagerCount,
                     serverInfo.replace("\"", "\\\""),
                     coordinates.replace("\"", "\\\""),
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .timeout(Duration.ofSeconds(30L))
                     .build();
                  HttpResponse<String> response = this.httpClient.send(request, BodyHandlers.ofString());
                  if (response.statusCode() == 204) {
                     this.info("Webhook notification sent successfully", new Object[0]);
                  } else {
                     this.error("Webhook failed with status: " + response.statusCode(), new Object[0]);
                  }
               } catch (InterruptedException | IOException var11) {
                  this.error("Failed to send webhook: " + var11.getMessage(), new Object[0]);
               }
            }
         );
      }
   }

   private void disconnectFromServer(String reason) {
      if (this.mc.world != null && this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal(reason));
         this.info("Disconnected from server - " + reason, new Object[0]);
      }
   }

   private void renderPillager(PillagerEntity pillager, Render3DEvent event) {
      if (this.mc.player != null) {
         Vec3d pos = pillager.getEntityPos();
         Box box = pillager.getBoundingBox();
         this.renderESP(pillager, box, event);
         if ((Boolean)this.tracersEnabled.get()) {
            this.renderTracers(pillager, pos, event);
         }
      }
   }

   private void renderESP(PillagerEntity pillager, Box box, Render3DEvent event) {
      Color color = new Color((Color)this.espColor.get());
      event.renderer.box(box, color, color, (ShapeMode)this.shapeMode.get(), 0);
   }

   private void renderTracers(PillagerEntity pillager, Vec3d pos, Render3DEvent event) {
      if (this.mc.player != null) {
         Color color = new Color((Color)this.tracerColor.get());
         Vec3d pillagerCenter = Vec3d.ofCenter(
            new BlockPos((int)pos.x, (int)(pos.y + pillager.getHeight() / 2.0F), (int)pos.z)
         );
         switch ((PillagerESP.TracersMode)this.tracersMode.get()) {
            case Line:
               event.renderer
                  .line(
                     RenderUtils.center.x,
                     RenderUtils.center.y,
                     RenderUtils.center.z,
                     pillagerCenter.x,
                     pillagerCenter.y,
                     pillagerCenter.z,
                     color
                  );
               break;
            case Dot:
               Box dotBox = new Box(
                  pillagerCenter.x - 0.1,
                  pillagerCenter.y - 0.1,
                  pillagerCenter.z - 0.1,
                  pillagerCenter.x + 0.1,
                  pillagerCenter.y + 0.1,
                  pillagerCenter.z + 0.1
               );
               event.renderer.box(dotBox, color, color, ShapeMode.Both, 0);
               break;
            case Both:
               event.renderer
                  .line(
                     RenderUtils.center.x,
                     RenderUtils.center.y,
                     RenderUtils.center.z,
                     pillagerCenter.x,
                     pillagerCenter.y,
                     pillagerCenter.z,
                     color
                  );
               Box dotBox2 = new Box(
                  pillagerCenter.x - 0.1,
                  pillagerCenter.y - 0.1,
                  pillagerCenter.z - 0.1,
                  pillagerCenter.x + 0.1,
                  pillagerCenter.y + 0.1,
                  pillagerCenter.z + 0.1
               );
               event.renderer.box(dotBox2, color, color, ShapeMode.Both, 0);
         }
      }
   }

   public String getInfoString() {
      return String.valueOf(this.pillagers.size());
   }

   public static enum NotificationMode {
      Chat,
      Toast,
      Both;

      private NotificationMode() {
      }
   }

   private static class PillagerToast extends ZincToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public PillagerToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int red = -65536;
         context.fill(0, 0, 160, 1, red);
         context.fill(0, 31, 160, 32, red);
         context.fill(0, 1, 1, 31, red);
         context.fill(159, 1, 160, 31, red);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, 16711680, false);
         }
      }
   }

   public static enum TracersMode {
      Line,
      Dot,
      Both;

      private TracersMode() {
      }
   }
}
