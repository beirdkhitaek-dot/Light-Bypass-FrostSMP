package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class ShulkerDropper extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> delay = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("delay")).description("Delay between actions in ticks.")).defaultValue(1)).min(0).max(20).build());
   private int delayCounter = 0;

   public ShulkerDropper() {
      super(ZincAddon.Zinc, "ShulkerDropper", "Automatically buys shulkers from shop and drops them.");
   }

   public void onActivate() {
      this.delayCounter = 0;
   }

   public void onDeactivate() {
      this.delayCounter = 0;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null) {
         if (this.delayCounter > 0) {
            this.delayCounter--;
         } else {
            ScreenHandler currentScreenHandler = this.mc.player.currentScreenHandler;
            if (!(currentScreenHandler instanceof GenericContainerScreenHandler containerHandler)) {
               ChatUtils.sendPlayerMsg("/shop");
               this.delayCounter = 20;
            } else if (containerHandler.getRows() == 3) {
               if (currentScreenHandler.getSlot(11).getStack().isOf(Items.END_STONE)
                  && currentScreenHandler.getSlot(11).getStack().getCount() == 1) {
                  this.mc.interactionManager.clickSlot(currentScreenHandler.syncId, 11, 0, SlotActionType.PICKUP, this.mc.player);
                  this.delayCounter = 20;
               } else if (currentScreenHandler.getSlot(17).getStack().isOf(Items.SHULKER_BOX)) {
                  this.mc.interactionManager.clickSlot(currentScreenHandler.syncId, 17, 0, SlotActionType.PICKUP, this.mc.player);
                  this.delayCounter = 20;
               } else {
                  if (currentScreenHandler.getSlot(13).getStack().isOf(Items.SHULKER_BOX)) {
                     this.mc.interactionManager.clickSlot(currentScreenHandler.syncId, 23, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                     this.delayCounter = (Integer)this.delay.get();
                     this.mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.field_12975, BlockPos.ORIGIN, Direction.field_11033));
                  }
               }
            }
         }
      }
   }
}
