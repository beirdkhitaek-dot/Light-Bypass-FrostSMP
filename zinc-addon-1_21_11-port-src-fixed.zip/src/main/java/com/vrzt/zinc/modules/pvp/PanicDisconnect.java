package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.KeybindSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

public class PanicDisconnect extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Keybind> disconnectKey;
   private final Setting<String> disconnectMessage;
   private final MinecraftClient mc = MinecraftClient.getInstance();

   public PanicDisconnect() {
      super(ZincAddon.Zinc, "panic-disconnect", "Instantly disconnects from the server when the bound key is pressed.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.disconnectKey = this.sgGeneral
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("panic-key")).description("Press this key to immediately disconnect."))
                  .defaultValue(Keybind.fromKey(46)))
               .action(this::onKeyPress)
               .build()
         );
      this.disconnectMessage = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("disconnect-message"))
                     .description("Message shown when disconnecting."))
                  .defaultValue("Panic disconnect triggered."))
               .build()
         );
   }

   private void onKeyPress() {
      if (this.isActive() && this.mc.getNetworkHandler() != null) {
         this.disconnect();
      }
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.getNetworkHandler() != null && this.mc.player != null) {
         if (((Keybind)this.disconnectKey.get()).isPressed()) {
            this.disconnect();
         }
      }
   }

   private void disconnect() {
      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.of((String)this.disconnectMessage.get()));
      }

      this.toggle();
   }
}
