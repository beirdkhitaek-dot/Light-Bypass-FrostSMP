package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import com.vrzt.zinc.utils.zinc.ZincToast;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;

public class RainNoti extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgWebhook = this.settings.createGroup("Webhook");
   private final Setting<Boolean> sendNotifications = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("notifications")).description("Send in-game notifications when it starts raining or thundering."))
               .defaultValue(true))
            .build()
      );
   private final Setting<RainNoti.Mode> notificationMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("notification-mode"))
                     .description("The mode to use for notifications."))
                  .defaultValue(RainNoti.Mode.Both))
               .visible(this.sendNotifications::get))
            .build()
      );
   private final Setting<Boolean> enableWebhook = this.sgWebhook
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("webhook")).description("Send webhook notifications when it starts raining or thundering"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("webhook-url"))
                     .description("Discord webhook URL"))
                  .defaultValue(""))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgWebhook
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("self-ping")).description("Ping yourself in the webhook message")).defaultValue(false))
               .visible(this.enableWebhook::get))
            .build()
      );
   private final Setting<String> discordId = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("discord-id"))
                     .description("Your Discord user ID for pinging"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private boolean wasRaining = false;
   private boolean wasThundering = false;
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public RainNoti() {
      super(ZincAddon.Zinc, "rain-noti", "Notifies when it starts raining or thundering in-game.");
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.world != null) {
         boolean raining = this.mc.world.isRaining();
         boolean thundering = this.mc.world.isThundering();
         if (raining && !this.wasRaining && !thundering) {
            this.notifyRainStart(false);
         }

         if (thundering && !this.wasThundering) {
            this.notifyRainStart(true);
         }

         this.wasRaining = raining;
         this.wasThundering = thundering;
      }
   }

   private void notifyRainStart(boolean thunder) {
      String type = thunder ? "Thunderstorm" : "Rain";
      String message = "It has started " + (thunder ? "thundering!" : "raining!");
      if ((Boolean)this.sendNotifications.get()) {
         switch ((RainNoti.Mode)this.notificationMode.get()) {
            case Chat:
               this.info("It has started " + (thunder ? "thundering!" : "raining!"), new Object[0]);
               break;
            case Toast:
               this.mc
                  .getToastManager()
                  .add(
                     (Toast)(thunder
                        ? new RainNoti.ThunderToast(
                           Items.LIGHTNING_ROD.getDefaultStack(), Text.literal("Weather Alert"), Text.literal("Thunderstorm!")
                        )
                        : new RainNoti.RainToast(
                           Items.field_8705.getDefaultStack(), Text.literal("Weather Alert"), Text.literal("Rain!")
                        ))
                  );
               break;
            case Both:
               this.info("It has started " + (thunder ? "thundering!" : "raining!"), new Object[0]);
               this.mc
                  .getToastManager()
                  .add(
                     (Toast)(thunder
                        ? new RainNoti.ThunderToast(
                           Items.LIGHTNING_ROD.getDefaultStack(), Text.literal("Weather Alert"), Text.literal("Thunderstorm")
                        )
                        : new RainNoti.RainToast(Items.field_8705.getDefaultStack(), Text.literal("Weather Alert"), Text.literal("Rain")))
                  );
         }
      }

      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(thunder);
      }
   }

   private void sendWebhookNotification(boolean thunder) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (url.isEmpty()) {
         this.warning("Webhook URL not configured!", new Object[0]);
      } else {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String messageContent = "";
                  if ((Boolean)this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()) {
                     messageContent = String.format("<@%s>", ((String)this.discordId.get()).trim());
                  }

                  String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Singleplayer";
                  String jsonPayload = String.format(
                     "{\"content\":\"%s\",\"username\":\"RainNoti\",\"embeds\":[{\"title\":\"%s Started!\",\"description\":\"It has started %s in-game.\",\"color\":3447003,\"fields\":[{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"RainNoti\"}}]}",
                     messageContent,
                     thunder ? "⚡ Thunderstorm" : "\ud83c\udf27 Rain",
                     thunder ? "thundering" : "raining",
                     serverInfo,
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(url))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(jsonPayload))
                     .timeout(Duration.ofSeconds(30L))
                     .build();
                  HttpResponse<String> response = this.httpClient.send(request, BodyHandlers.ofString());
                  if (response.statusCode() == 204) {
                     this.info("Webhook notification sent successfully", new Object[0]);
                  } else {
                     this.error("Webhook failed with status: " + response.statusCode(), new Object[0]);
                  }
               } catch (Exception var8) {
                  this.error("Failed to send webhook: " + var8.getMessage(), new Object[0]);
               }
            }
         );
      }
   }

   public WWidget getWidget(GuiTheme theme) {
      WVerticalList list = theme.verticalList();
      WButton reset = (WButton)list.add(theme.button("Reset Weather State")).widget();
      reset.action = () -> {
         this.wasRaining = false;
         this.wasThundering = false;
         this.info("Weather state reset.", new Object[0]);
      };
      return list;
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }

   private static class RainToast extends ZincToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public RainToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int blue = -12490271;
         context.fill(0, 0, 160, 1, blue);
         context.fill(0, 31, 160, 32, blue);
         context.fill(0, 1, 1, 31, blue);
         context.fill(159, 1, 160, 31, blue);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, -12490271, false);
         }
      }
   }

   private static class ThunderToast extends ZincToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public ThunderToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int yellow = -10496;
         context.fill(0, 0, 160, 1, yellow);
         context.fill(0, 31, 160, 32, yellow);
         context.fill(0, 1, 1, 31, yellow);
         context.fill(159, 1, 160, 31, yellow);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, -10496, false);
         }
      }
   }
}
