package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.text.Text;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;

public class ClusterFinder extends Module {
   private final SettingGroup sgGeneral = this.settings.createGroup("General");
   private final SettingGroup sgNotifications = this.settings.createGroup("Notifications");
   private final Setting<SettingColor> chunkColor = this.sgGeneral
      .add(((Builder)new Builder().name("chunk-color")).defaultValue(new SettingColor(180, 50, 230, 60)).build());
   private final Setting<Boolean> showToast = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("show-toast"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> playSound = this.sgNotifications
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("play-sound"))
               .defaultValue(true))
            .build()
      );
   private static final double CHUNK_HEIGHT = 64.0;
   private static final double CHUNK_THICKNESS = 0.5;
   private static final int CLUSTER_THRESHOLD = 5;
   private static final int THREAD_POOL_SIZE = 2;
   private final Set<ChunkPos> flaggedChunks = ConcurrentHashMap.newKeySet();
   private final Map<ChunkPos, Long> lastNotificationTimes = new ConcurrentHashMap<>();
   private final Queue<Long> recentNotifications = new ConcurrentLinkedQueue<>();
   private ExecutorService threadPool;
   private boolean active = false;

   public ClusterFinder() {
      super(ZincAddon.esp, "ClusterFinder", "Finds Amethyst Clusters.");
   }

   public void onActivate() {
      this.active = true;
      this.threadPool = Executors.newFixedThreadPool(2);
      this.flaggedChunks.clear();

      for (Chunk chunk : Utils.chunks()) {
         if (chunk instanceof WorldChunk wc) {
            this.threadPool.submit(() -> this.scanChunk(wc));
         }
      }
   }

   public void onDeactivate() {
      this.active = false;
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
      }
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.threadPool != null) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      }
   }

   private void scanChunk(WorldChunk chunk) {
      if (this.active && chunk != null) {
         ChunkPos cpos = chunk.getPos();
         int count = 0;
         int topY = chunk.getBottomY() + chunk.getHeight();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               for (int y = chunk.getBottomY(); y < topY; y++) {
                  BlockState state = chunk.getBlockState(new BlockPos(cpos.getStartX() + x, y, cpos.getStartZ() + z));
                  if (state.isOf(Blocks.field_27161)) {
                     count++;
                  }
               }
            }
         }

         if (count >= 5 && this.flaggedChunks.add(cpos)) {
            int finalCount = count;
            this.mc
               .execute(
                  () -> {
                     if ((Boolean)this.showToast.get()) {
                        this.mc
                           .getToastManager()
                           .add(
                              new ClusterFinder.ClusterToast(
                                 new ItemStack(Items.AMETHYST_CLUSTER),
                                 Text.literal("Cluster Found"),
                                 Text.literal("Count " + finalCount)
                              )
                           );
                     }

                     if ((Boolean)this.playSound.get()) {
                        this.mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.field_26980, 1.0F, 1.5F));
                     }
                  }
               );
         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      Color color = new Color((Color)this.chunkColor.get());

      for (ChunkPos cp : this.flaggedChunks) {
         Box box = new Box(cp.getStartX(), 64.0, cp.getStartZ(), cp.getEndX() + 1, 64.5, cp.getEndZ() + 1);
         event.renderer.box(box, color, color, ShapeMode.Both, 0);
      }
   }

   private static class ClusterToast implements Toast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;
      private long startTime = -1L;
      private Visibility visibility = Visibility.field_2210;

      public ClusterToast(ItemStack icon, Text title, Text description) {
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public Visibility getVisibility() {
         return this.visibility;
      }

      public void update(ToastManager manager, long currentTime) {
         if (this.startTime == -1L) {
            this.startTime = currentTime;
         }

         if (currentTime - this.startTime >= 5000L) {
            this.visibility = Visibility.field_2209;
         }
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int purple = -6736897;
         context.fill(0, 0, 160, 1, purple);
         context.fill(0, 31, 160, 32, purple);
         context.fill(0, 1, 1, 31, purple);
         context.fill(159, 1, 160, 31, purple);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16776960, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, 16777215, false);
         }
      }
   }
}
