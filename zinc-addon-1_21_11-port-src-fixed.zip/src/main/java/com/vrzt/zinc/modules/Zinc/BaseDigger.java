package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BlockPosSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class BaseDigger extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgRender = this.settings.createGroup("Render");
   private final Setting<BlockPos> pos1 = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("pos-1")).defaultValue(new BlockPos(0, 0, 0))).onChanged(blockPos -> this.resetLogic())).build());
   private final Setting<BlockPos> pos2 = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("pos-2")).defaultValue(new BlockPos(0, 0, 0))).onChanged(blockPos -> this.resetLogic())).build());
   private final Setting<SettingColor> sideColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("side-color"))
            .defaultValue(new SettingColor(255, 255, 255, 50))
            .build()
      );
   private final Setting<SettingColor> lineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("line-color"))
            .defaultValue(new SettingColor(255, 255, 255, 255))
            .build()
      );
   private final List<BlockPos> blocksToMine = new ArrayList<>();
   private BlockPos currentTarget = null;
   private Vec3d lastPos = Vec3d.ZERO;
   private int stationaryTicks = 0;
   private int stuckTicks = 0;
   private long nextBlockTick = 0L;

   public BaseDigger() {
      super(ZincAddon.Zinc, "BaseDigger", "Sequential spiral mining with legit rotations. Ignores Bedrock.");
   }

   private void resetLogic() {
      this.currentTarget = null;
      this.blocksToMine.clear();
      this.stuckTicks = 0;
      this.stationaryTicks = 0;
      this.nextBlockTick = 0L;
      if (this.mc.player != null) {
         this.lastPos = this.mc.player.getEntityPos();
      }

      if (this.isActive()) {
         this.refreshPath();
      }
   }

   public void onActivate() {
      this.resetLogic();
      this.info("BaseDigger §aStarted§7.", new Object[0]);
   }

   public void onDeactivate() {
      this.stopInput();
      this.resetLogic();
      this.info("BaseDigger §cStopped§7.", new Object[0]);
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         if (System.currentTimeMillis() >= this.nextBlockTick) {
            if (this.currentTarget != null
               && (
                  this.mc.world.getBlockState(this.currentTarget).isAir()
                     || this.mc.world.getBlockState(this.currentTarget).isOf(Blocks.field_9987)
               )) {
               this.currentTarget = null;
            }

            if (this.currentTarget == null) {
               if (this.blocksToMine.isEmpty()) {
                  this.info("BaseDigger §bCompleted§7!", new Object[0]);
                  this.toggle();
                  return;
               }

               while (!this.blocksToMine.isEmpty()) {
                  BlockPos next = this.blocksToMine.remove(0);
                  if (!this.mc.world.getBlockState(next).isAir() && !this.mc.world.getBlockState(next).isOf(Blocks.field_9987)) {
                     this.currentTarget = next;
                     this.nextBlockTick = System.currentTimeMillis() + ThreadLocalRandom.current().nextLong(10L, 35L);
                     break;
                  }
               }
            }

            if (this.currentTarget != null && !this.mc.world.getBlockState(this.currentTarget).isAir()) {
               this.rotateTo(Vec3d.ofCenter(this.currentTarget));
               if (this.isLookingAt(this.currentTarget)) {
                  this.mc.options.attackKey.setPressed(true);
               }
            } else {
               this.mc.options.attackKey.setPressed(false);
            }

            this.mc.options.forwardKey.setPressed(true);
            if (this.mc.player.getEntityPos().distanceTo(this.lastPos) < 0.001) {
               this.stuckTicks++;
               this.stationaryTicks++;
            } else {
               this.stuckTicks = 0;
               this.stationaryTicks = 0;
            }

            if (this.stationaryTicks >= 60) {
               this.mc.player.jump();
               this.stationaryTicks = 0;
            }

            if (this.stuckTicks >= 10 && this.stuckTicks < 60) {
               this.handleObstruction();
            }

            this.lastPos = this.mc.player.getEntityPos();
         }
      }
   }

   private void rotateTo(Vec3d target) {
      if (this.currentTarget != null && !this.mc.world.getBlockState(this.currentTarget).isAir()) {
         double diffX = target.x - this.mc.player.getX();
         double diffY = target.y - this.mc.player.getEyeY();
         double diffZ = target.z - this.mc.player.getZ();
         double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
         float targetYaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
         float targetPitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
         float yawDelta = this.getAngleDelta(this.mc.player.getYaw(), targetYaw);
         float pitchDelta = this.getAngleDelta(this.mc.player.getPitch(), targetPitch);
         float speedMultiplier = Math.max(0.15F, Math.min(1.0F, (Math.abs(yawDelta) + Math.abs(pitchDelta)) / 35.0F));
         float legitSpeed = (float)(ThreadLocalRandom.current().nextDouble(25.0, 45.0) * speedMultiplier);
         float jitter = (float)(ThreadLocalRandom.current().nextGaussian() * 0.12);
         this.mc
            .player
            .setYaw(this.mc.player.getYaw() + (yawDelta > 0.0F ? Math.min(yawDelta, legitSpeed) : Math.max(yawDelta, -legitSpeed)) + jitter);
         this.mc
            .player
            .setPitch(
               this.mc.player.getPitch() + (pitchDelta > 0.0F ? Math.min(pitchDelta, legitSpeed) : Math.max(pitchDelta, -legitSpeed)) + jitter
            );
      }
   }

   private float getAngleDelta(float current, float target) {
      float delta = (target - current) % 360.0F;
      if (delta > 180.0F) {
         delta -= 360.0F;
      }

      if (delta < -180.0F) {
         delta += 360.0F;
      }

      return delta;
   }

   private boolean isLookingAt(BlockPos target) {
      double diffX = target.getX() + 0.5 - this.mc.player.getX();
      double diffZ = target.getZ() + 0.5 - this.mc.player.getZ();
      float targetYaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
      return Math.abs(this.getAngleDelta(this.mc.player.getYaw(), targetYaw)) < 45.0F;
   }

   private void handleObstruction() {
      BlockPos p = this.mc.player.getBlockPos();
      Direction f = this.mc.player.getHorizontalFacing();
      BlockPos[] checkArea = new BlockPos[]{p.method_10093(f).up(), p.method_10093(f), p.up().up()};

      for (BlockPos bp : checkArea) {
         if (!this.mc.world.getBlockState(bp).isAir() && !this.mc.world.getBlockState(bp).isOf(Blocks.field_9987)) {
            if (!this.blocksToMine.contains(bp)) {
               this.blocksToMine.add(0, bp);
            }

            return;
         }
      }
   }

   private void refreshPath() {
      this.blocksToMine.clear();
      BlockPos p1 = (BlockPos)this.pos1.get();
      BlockPos p2 = (BlockPos)this.pos2.get();
      if (p1 != null && p2 != null && this.mc.world != null) {
         int xMin = Math.min(p1.getX(), p2.getX());
         int yMin = Math.min(p1.getY(), p2.getY());
         int zMin = Math.min(p1.getZ(), p2.getZ());
         int xMax = Math.max(p1.getX(), p2.getX());
         int yMax = Math.max(p1.getY(), p2.getY());
         int zMax = Math.max(p1.getZ(), p2.getZ());

         for (int y = yMax; y >= yMin; y--) {
            int left = xMin;
            int right = xMax;
            int top = zMin;
            int bottom = zMax;

            while (left <= right && top <= bottom) {
               for (int x = left; x <= right; x++) {
                  this.addIfValid(new BlockPos(x, y, top));
               }

               for (int z = ++top; z <= bottom; z++) {
                  this.addIfValid(new BlockPos(right, y, z));
               }

               right--;
               if (top <= bottom) {
                  for (int x = right; x >= left; x--) {
                     this.addIfValid(new BlockPos(x, y, bottom));
                  }

                  bottom--;
               }

               if (left <= right) {
                  for (int z = bottom; z >= top; z--) {
                     this.addIfValid(new BlockPos(left, y, z));
                  }

                  left++;
               }
            }
         }
      }
   }

   private void addIfValid(BlockPos bp) {
      if (!this.mc.world.getBlockState(bp).isAir()
         && !this.mc.world.getBlockState(bp).isOf(Blocks.field_9987)
         && !this.blocksToMine.contains(bp)) {
         this.blocksToMine.add(bp);
      }
   }

   private void stopInput() {
      if (this.mc.options != null) {
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.attackKey.setPressed(false);
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.pos1.get() != null && this.pos2.get() != null) {
         Box area = new Box(
            Math.min(((BlockPos)this.pos1.get()).getX(), ((BlockPos)this.pos2.get()).getX()),
            Math.min(((BlockPos)this.pos1.get()).getY(), ((BlockPos)this.pos2.get()).getY()),
            Math.min(((BlockPos)this.pos1.get()).getZ(), ((BlockPos)this.pos2.get()).getZ()),
            Math.max(((BlockPos)this.pos1.get()).getX(), ((BlockPos)this.pos2.get()).getX()) + 1,
            Math.max(((BlockPos)this.pos1.get()).getY(), ((BlockPos)this.pos2.get()).getY()) + 1,
            Math.max(((BlockPos)this.pos1.get()).getZ(), ((BlockPos)this.pos2.get()).getZ()) + 1
         );
         event.renderer.box(area, (Color)this.sideColor.get(), (Color)this.lineColor.get(), ShapeMode.Both, 0);
         if (this.currentTarget != null && !this.mc.world.getBlockState(this.currentTarget).isAir()) {
            event.renderer.box(this.currentTarget, new Color(255, 0, 0, 100), new Color(255, 0, 0, 255), ShapeMode.Both, 0);
         }
      }
   }
}
