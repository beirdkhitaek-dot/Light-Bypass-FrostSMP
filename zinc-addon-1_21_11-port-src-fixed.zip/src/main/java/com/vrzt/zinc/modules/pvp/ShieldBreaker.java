package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.option.KeyBinding;

public class ShieldBreaker extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> autoActivate = this.sgGeneral.add(((Builder)((Builder)new Builder().name("auto-activate")).defaultValue(true)).build());
   private final Setting<Integer> axeSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("axe-slot"))
               .defaultValue(2))
            .min(1)
            .max(9)
            .build()
      );
   private final Setting<Integer> returnSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("return-slot"))
               .defaultValue(1))
            .min(1)
            .max(9)
            .build()
      );
   public ShieldBreaker.State state = ShieldBreaker.State.READY;
   private int timer = 0;
   private KeyBinding activeHotbarKey = null;

   public ShieldBreaker() {
      super(ZincAddon.pvp, "shield-breaker", "High-priority axe swap - Ground Only.");
   }

   public boolean isBreaking() {
      return this.state != ShieldBreaker.State.READY;
   }

   public void onActivate() {
      this.state = ShieldBreaker.State.READY;
      this.timer = 0;
   }

   public void onDeactivate() {
      this.releaseKeys();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.currentScreen == null) {
         if (this.timer > 0) {
            this.timer--;
         } else {
            switch (this.state) {
               case READY:
                  if (!this.mc.player.isOnGround()) {
                     return;
                  }

                  if (!(Boolean)this.autoActivate.get() && !this.mc.options.attackKey.isPressed()) {
                     return;
                  }

                  PlayerEntity target = this.getTarget();
                  if (target != null && target.isBlocking()) {
                     this.hardwareFullSwap((Integer)this.axeSlot.get() - 1);
                     this.simulateAttack();
                     this.state = ShieldBreaker.State.BREAKING;
                     this.timer = 1;
                  }
                  break;
               case BREAKING:
                  this.hardwareFullSwap((Integer)this.returnSlot.get() - 1);
                  this.state = ShieldBreaker.State.COOLING;
                  this.timer = 2;
                  break;
               case COOLING:
                  this.state = ShieldBreaker.State.READY;
            }
         }
      }
   }

   private void simulateAttack() {
      ((IMinecraftClient)this.mc).zinc$doAttack();
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double dir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               dir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, dir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }
   }

   private PlayerEntity getTarget() {
      return this.mc.targetedEntity instanceof PlayerEntity p && !Friends.get().isFriend(p) && p.isAlive() && this.mc.player.distanceTo(p) <= 3.8 ? p : null;
   }

   public static enum State {
      READY,
      BREAKING,
      COOLING;

      private State() {
      }
   }
}
