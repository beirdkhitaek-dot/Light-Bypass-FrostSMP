package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;

public class FakeScoreboard extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<String> money = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("money")).description("Money value to display")).defaultValue("Zinc on top")).build());
   private final Setting<String> shards = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("shards")).description("Shards value")).defaultValue("2.3K")).build());
   private final Setting<String> kills = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("kills")).description("Kills count")).defaultValue("503")).build());
   private final Setting<String> deaths = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("deaths")).description("Deaths count")).defaultValue("421")).build());
   private final Setting<String> keyAll = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("key-all")).description("Keyall timer")).defaultValue("67m 67s")).build());
   private final Setting<String> playtime = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("playtime")).description("Playtime duration")).defaultValue("22d 9h")).build());
   private final Setting<String> team = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("team")).description("Team name")).defaultValue("Zinc Addon")).build());
   private final Setting<Boolean> realMoney = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-money"))
                  .description("Show real money from scoreboard"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> realShards = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-shards"))
                  .description("Show real shards from scoreboard"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> realKills = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-kills"))
                  .description("Show real kills from scoreboard"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> realDeaths = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-deaths"))
                  .description("Show real deaths from scoreboard"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> realKey = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-keyall"))
                  .description("Show real keyall timer from scoreboard"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> realPlaytime = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-playtime"))
                  .description("Show real playtime from scoreboard"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> realTeam = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("real-team"))
                  .description("Show real team name from scoreboard"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> hideRegion = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("hide-region"))
                  .description("Hide the real region name"))
               .defaultValue(false))
            .build()
      );

   public FakeScoreboard() {
      super(ZincAddon.Render, "fake-scoreboard", "Shows a fake scoreboard with custom values.");
   }

   public String getMoneyValue() {
      return (String)this.money.get();
   }

   public String getShardsValue() {
      return (String)this.shards.get();
   }

   public String getKillsValue() {
      return (String)this.kills.get();
   }

   public String getDeathsValue() {
      return (String)this.deaths.get();
   }

   public String getKeyallValue() {
      return (String)this.keyAll.get();
   }

   public String getPlaytimeValue() {
      return (String)this.playtime.get();
   }

   public String getTeamValue() {
      return (String)this.team.get();
   }

   public boolean shouldShowRealMoney() {
      return (Boolean)this.realMoney.get();
   }

   public boolean shouldShowRealShards() {
      return (Boolean)this.realShards.get();
   }

   public boolean shouldShowRealKills() {
      return (Boolean)this.realKills.get();
   }

   public boolean shouldShowRealDeaths() {
      return (Boolean)this.realDeaths.get();
   }

   public boolean shouldShowRealKeyall() {
      return (Boolean)this.realKey.get();
   }

   public boolean shouldShowRealPlaytime() {
      return (Boolean)this.realPlaytime.get();
   }

   public boolean shouldShowRealTeam() {
      return (Boolean)this.realTeam.get();
   }

   public boolean shouldHideRegion() {
      return (Boolean)this.hideRegion.get();
   }
}
