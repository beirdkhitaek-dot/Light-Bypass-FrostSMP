package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.util.hit.HitResult.Type;

public class UdTriggerBot extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgWeapons = this.settings.createGroup("Weapons");
   private final Setting<UdTriggerBot.CombatMode> mode = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("combat-mode")).defaultValue(UdTriggerBot.CombatMode.V1_9_PLUS)).build());
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("base-delay"))
               .defaultValue(1))
            .min(0)
            .sliderMax(10)
            .build()
      );
   private final Setting<Integer> randomDelay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("random-delay"))
               .defaultValue(1))
            .min(0)
            .sliderMax(5)
            .build()
      );
   private final Setting<Boolean> critOnly = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("crit-only"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> swords = this.sgWeapons
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("swords"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> axes = this.sgWeapons
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("axes"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> maces = this.sgWeapons
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("maces"))
               .defaultValue(true))
            .build()
      );
   private int ticksSinceLastHit;
   private int currentTargetDelay;

   public UdTriggerBot() {
      super(ZincAddon.pvp, "ud-trigger-bot", "Hardware-level triggerbot with hardcoded shield/eat/height pauses.");
   }

   public void onActivate() {
      this.ticksSinceLastHit = 0;
      this.currentTargetDelay = 0;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.currentScreen == null) {
         if (this.mc.player.isUsingItem()) {
            ItemStack activeItem = this.mc.player.getActiveItem();
            if (activeItem.contains(DataComponentTypes.field_50075) || activeItem.isOf(Items.field_8574)) {
               return;
            }
         }

         this.ticksSinceLastHit++;
         if (this.mc.crosshairTarget instanceof EntityHitResult hit && hit.getType() == Type.field_1331) {
            Entity target = hit.getEntity();
            if (this.isValidTarget(target)) {
               PlayerEntity playerTarget = (PlayerEntity)target;
               if (playerTarget.isBlocking()) {
                  return;
               }

               if (this.ticksSinceLastHit >= (Integer)this.delay.get() + this.currentTargetDelay) {
                  ItemStack hand = this.mc.player.getMainHandStack();
                  if (!this.isValidWeapon(hand)) {
                     return;
                  }

                  if ((Boolean)this.critOnly.get()) {
                     boolean isFalling = this.mc.player.getVelocity().y < -0.01
                        && !this.mc.player.isOnGround()
                        && !this.mc.player.isClimbing()
                        && !this.mc.player.isTouchingWater()
                        && !this.mc.player.hasStatusEffect(StatusEffects.field_5919)
                        && this.mc.player.getVehicle() == null;
                     if (!isFalling) {
                        return;
                     }
                  }

                  boolean canAttack = this.mode.get() == UdTriggerBot.CombatMode.V1_8 || this.mc.player.getAttackCooldownProgress(0.5F) >= 0.9F;
                  if (canAttack) {
                     ((IMinecraftClient)this.mc).zinc$doAttack();
                     this.ticksSinceLastHit = 0;
                     this.currentTargetDelay = ThreadLocalRandom.current().nextInt(0, (Integer)this.randomDelay.get() + 1);
                  }
               }
            }
         }
      }
   }

   private boolean isValidTarget(Entity entity) {
      return !(entity instanceof PlayerEntity p)
         ? false
         : p.isAlive() && !Friends.get().isFriend(p) && p != this.mc.player && this.mc.player.distanceTo(p) <= 3.0;
   }

   private boolean isValidWeapon(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      }
      if ((Boolean)this.swords.get() && stack.isIn(net.minecraft.registry.tag.ItemTags.SWORDS)) {
         return true;
      }
      if ((Boolean)this.axes.get() && stack.isIn(net.minecraft.registry.tag.ItemTags.AXES)) {
         return true;
      }
      return (Boolean)this.maces.get() && stack.isOf(net.minecraft.item.Items.MACE);
   }


   public static enum CombatMode {
      V1_8,
      V1_9_PLUS;

      private CombatMode() {
      }
   }
}
