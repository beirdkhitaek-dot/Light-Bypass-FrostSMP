package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;

public class OneByOneHoles extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<SettingColor> holeColor = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("hole-color")).description("Color for 1x1x1 holes")).defaultValue(new SettingColor(255, 0, 0, 100)).build());
   private final Setting<ShapeMode> shapeMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("Render mode for 1x1x1 holes"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> tracers = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("tracers"))
                  .description("Draw tracers to 1x1x1 holes"))
               .defaultValue(false))
            .build()
      );
   private final Setting<SettingColor> tracerColor = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("tracer-color")).description("1x1x1 hole tracer color"))
               .defaultValue(new SettingColor(255, 0, 0, 200))
               .visible(this.tracers::get))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Chat Feedback"))
                  .description("Log hole detections in chat."))
               .defaultValue(false))
            .build()
      );
   private final Set<BlockPos> oneByOneHoles = ConcurrentHashMap.newKeySet();

   public OneByOneHoles() {
      super(ZincAddon.esp, "1x1x1-holes", "Highlights 1x1x1 air holes that are likely player-made.");
   }

   public void onActivate() {
      this.oneByOneHoles.clear();
      if (this.mc.world != null) {
         for (Chunk chunk : Utils.chunks()) {
            if (chunk instanceof WorldChunk wc) {
               this.scanChunk(wc);
            }
         }
      }
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      this.scanChunk(event.chunk());
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      this.updateHoleState(event.pos);

      for (Direction direction : Direction.values()) {
         this.updateHoleState(event.pos.method_10093(direction));
      }
   }

   private void updateHoleState(BlockPos pos) {
      if (this.isOneByOneHole(pos)) {
         if (this.oneByOneHoles.add(pos.toImmutable()) && (Boolean)this.chatFeedback.get()) {
            this.info("1x1x1 hole detected at: (highlight)%s, %s, %s", new Object[]{pos.getX(), pos.getY(), pos.getZ()});
         }
      } else {
         this.oneByOneHoles.remove(pos);
      }
   }

   private void scanChunk(WorldChunk chunk) {
      int startX = chunk.getPos().getStartX();
      int startZ = chunk.getPos().getStartZ();
      int endX = chunk.getPos().getEndX();
      int endZ = chunk.getPos().getEndZ();

      for (int x = startX; x < endX; x++) {
         for (int z = startZ; z < endZ; z++) {
            for (int y = chunk.getBottomY() + 1; y < chunk.getBottomY() + chunk.getHeight(); y++) {
               BlockPos pos = new BlockPos(x, y, z);
               if (this.isOneByOneHole(pos)) {
                  this.oneByOneHoles.add(pos.toImmutable());
               }
            }
         }
      }
   }

   private boolean isOneByOneHole(BlockPos pos) {
      if (this.mc.world == null || pos.getY() <= this.mc.world.getBottomY() + 1) {
         return false;
      } else if (!this.mc.world.getBlockState(pos).isAir()) {
         return false;
      } else {
         for (Direction direction : Direction.values()) {
            BlockPos neighborPos = pos.method_10093(direction);
            BlockState state = this.mc.world.getBlockState(neighborPos);
            if (state.isOf(Blocks.field_27161)
               || state.isOf(Blocks.field_27160)
               || state.isOf(Blocks.field_27162)
               || state.isOf(Blocks.field_27163)
               || state.isOf(Blocks.field_27164)) {
               return false;
            }

            if (!state.isSolidBlock(this.mc.world, neighborPos)) {
               return false;
            }
         }

         for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
               for (int z = -1; z <= 1; z++) {
                  if ((x != 0 || y != 0 || z != 0) && this.mc.world.getBlockState(pos.method_10069(x, y, z)).isAir()) {
                     return false;
                  }
               }
            }
         }

         return true;
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null) {
         Color side = new Color((Color)this.holeColor.get());
         Color outline = new Color((Color)this.holeColor.get());
         Color tColor = new Color((Color)this.tracerColor.get());

         for (BlockPos pos : this.oneByOneHoles) {
            event.renderer.box(pos, side, outline, (ShapeMode)this.shapeMode.get(), 0);
            if ((Boolean)this.tracers.get()) {
               event.renderer
                  .line(
                     RenderUtils.center.x,
                     RenderUtils.center.y,
                     RenderUtils.center.z,
                     pos.getX() + 0.5,
                     pos.getY() + 0.5,
                     pos.getZ() + 0.5,
                     tColor
                  );
            }
         }
      }
   }

   public void onDeactivate() {
      this.oneByOneHoles.clear();
   }
}
