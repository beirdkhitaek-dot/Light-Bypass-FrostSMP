package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import java.util.HashSet;
import java.util.Set;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

public class CustomCrosshair extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   public final Setting<SettingColor> color = this.sgGeneral.add(((Builder)new Builder().name("color")).defaultValue(new SettingColor(255, 255, 255)).build());
   public final Setting<Integer> pixelScale = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("scale"))
               .defaultValue(2))
            .min(1)
            .sliderMax(10)
            .build()
      );
   public final Set<String> pixels = new HashSet<>();

   public CustomCrosshair() {
      super(ZincAddon.Render, "custom-crosshair", "Draw your own crosshair.");
   }

   public WWidget getWidget(GuiTheme theme) {
      WButton button = theme.button("Open Editor");
      button.action = () -> this.mc.setScreen(new CustomCrosshair.CrosshairEditorScreen(this));
      return button;
   }

   public void renderMixin(DrawContext context) {
      if (!this.pixels.isEmpty() && !this.mc.options.hudHidden) {
         float centerX = this.mc.getWindow().getScaledWidth() / 2.0F;
         float centerY = this.mc.getWindow().getScaledHeight() / 2.0F;
         int scale = (Integer)this.pixelScale.get();
         int packedColor = ((SettingColor)this.color.get()).getPacked();

         for (String pixel : this.pixels) {
            String[] coords = pixel.split(",");
            int x = Integer.parseInt(coords[0]);
            int y = Integer.parseInt(coords[1]);
            int renderX = (int)(centerX + x * scale - scale / 2.0F);
            int renderY = (int)(centerY + y * scale - scale / 2.0F);
            context.fill(renderX, renderY, renderX + scale, renderY + scale, packedColor);
         }
      }
   }

   public NbtCompound toTag() {
      NbtCompound tag = super.toTag();
      NbtList list = new NbtList();

      for (String pixel : this.pixels) {
         list.add(NbtString.of(pixel));
      }

      tag.put("pixels", list);
      return tag;
   }

   public Module fromTag(NbtCompound tag) {
      super.fromTag(tag);
      this.pixels.clear();
      NbtList list = tag.getListOrEmpty("pixels");
      for (int i = 0; i < list.size(); i++) {
         list.getString(i).ifPresent(this.pixels::add);
      }

      return this;
   }

   private static class CrosshairEditorScreen extends Screen {
      private final CustomCrosshair module;
      private final int gridHalfSize = 20;
      private final int cellSize = 15;

      public CrosshairEditorScreen(CustomCrosshair module) {
         super(Text.of("Crosshair Editor"));
         this.module = module;
      }

      public void render(DrawContext context, int mouseX, int mouseY, float delta) {
         super.render(context, mouseX, mouseY, delta);
         int centerX = this.width / 2;
         int centerY = this.height / 2;
         context.fill(0, 0, this.width, this.height, -1879048192);

         for (int x = -20; x <= 20; x++) {
            for (int y = -20; y <= 20; y++) {
               int xPos = centerX + x * 15 - 7;
               int yPos = centerY + y * 15 - 7;
               int gridCol = x == 0 && y == 0 ? -2130771968 : 1090519039;
               context.fill(xPos, yPos, xPos + 15 - 1, yPos + 15 - 1, gridCol);
               if (this.module.pixels.contains(x + "," + y)) {
                  context.fill(xPos, yPos, xPos + 15 - 1, yPos + 15 - 1, ((SettingColor)this.module.color.get()).getPacked());
               }
            }
         }

         context.drawCenteredTextWithShadow(this.textRenderer, "LMB: Draw | RMB: Erase | C: Clear", this.width / 2, 10, -1);
      }

      public boolean mouseClicked(net.minecraft.client.gui.Click click, boolean doubled) {
         this.handleInput(click.x(), click.y(), click.button());
         return super.mouseClicked(click, doubled);
      }

      public boolean mouseDragged(net.minecraft.client.gui.Click click, double deltaX, double deltaY) {
         this.handleInput(click.x(), click.y(), click.button());
         return super.mouseDragged(click, deltaX, deltaY);
      }

      private void handleInput(double mouseX, double mouseY, int button) {
         int centerX = this.width / 2;
         int centerY = this.height / 2;
         int gridX = (int)Math.floor((mouseX - centerX + 7.5) / 15.0);
         int gridY = (int)Math.floor((mouseY - centerY + 7.5) / 15.0);
         if (Math.abs(gridX) <= 20 && Math.abs(gridY) <= 20) {
            if (button == 0) {
               this.module.pixels.add(gridX + "," + gridY);
            } else if (button == 1) {
               this.module.pixels.remove(gridX + "," + gridY);
            }
         }
      }

      public boolean keyPressed(net.minecraft.client.input.KeyInput input) {
         if (input.key() == 67) {
            this.module.pixels.clear();
            return true;
         } else {
            return super.keyPressed(input);
         }
      }

      public boolean shouldPause() {
         return false;
      }
   }
}
