package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;

public class VineESP extends Module {
   private final SettingGroup sgRender = this.settings.getDefaultGroup();
   private final SettingGroup sgRange = this.settings.createGroup("Range");
   private final SettingGroup sgThreading = this.settings.createGroup("Threading");
   private final Setting<SettingColor> espColor = this.sgRender
      .add(((Builder)((Builder)new Builder().name("ESP Color")).description("Color for the ESP boxes")).defaultValue(new SettingColor(0, 255, 0, 100)).build());
   private final Setting<ShapeMode> shapeMode = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("Shape Mode"))
                  .description("Rendering mode for the ESP boxes"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> showTracers = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Show Tracers"))
                  .description("Draw tracer lines to grounded vines"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> tracerColor = this.sgRender
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Tracer Color")).description("Color for the tracer lines"))
               .defaultValue(new SettingColor(0, 255, 0, 200))
               .visible(this.showTracers::get))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Chat Feedback"))
                  .description("Announce vine detections in chat"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> minVineLength = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Vine Length"))
                  .description("Minimum vine length to highlight"))
               .defaultValue(20))
            .min(15)
            .max(35)
            .sliderMax(35)
            .build()
      );
   private final Setting<Integer> minY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Min Y"))
                  .description("Minimum Y level to scan for vines"))
               .defaultValue(-64))
            .min(-64)
            .max(128)
            .sliderRange(-64, 128)
            .build()
      );
   private final Setting<Integer> maxY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Max Y"))
                  .description("Maximum Y level to scan for vines"))
               .defaultValue(320))
            .min(-64)
            .max(320)
            .sliderRange(-64, 320)
            .build()
      );
   private final Setting<Integer> renderDistance = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Render Distance"))
                  .description("Maximum distance to show ESP (in blocks)"))
               .defaultValue(128))
            .min(32)
            .max(512)
            .sliderRange(32, 512)
            .build()
      );
   private final Setting<Boolean> useThreading = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("Enable Threading"))
                  .description("Use multi-threading for chunk scanning (better performance)"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> threadPoolSize = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("Thread Pool Size"))
                     .description("Number of threads to use for scanning"))
                  .defaultValue(2))
               .min(1)
               .max(8)
               .sliderRange(1, 8)
               .visible(this.useThreading::get))
            .build()
      );
   private final Setting<Boolean> limitChatSpam = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("Limit Chat Spam"))
                     .description("Reduce chat spam when using threading"))
                  .defaultValue(true))
               .visible(this.useThreading::get))
            .build()
      );
   private final Setting<Integer> cleanupInterval = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("Cleanup Interval"))
                  .description("How often to clean up far away vines (ticks)"))
               .defaultValue(100))
            .min(20)
            .max(1000)
            .sliderRange(20, 500)
            .build()
      );
   private final Set<BlockPos> groundedVines = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;
   private int tickCounter = 0;
   private long lastCleanupTime = 0L;

   public VineESP() {
      super(ZincAddon.esp, "Vine ESP", "ESP for vines that touch the ground.");
   }

   public void onActivate() {
      if (this.mc.world != null) {
         if ((Boolean)this.useThreading.get()) {
            this.threadPool = Executors.newFixedThreadPool((Integer)this.threadPoolSize.get());
         }

         this.groundedVines.clear();
         this.tickCounter = 0;
         this.lastCleanupTime = 0L;
         this.scanAllChunks();
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
         this.threadPool = null;
      }

      this.groundedVines.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if ((Boolean)this.useThreading.get() && this.threadPool != null) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      } else {
         this.scanChunk(event.chunk());
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      Runnable updateTask = () -> {
         if (this.isGroundedVine(event.newState, event.pos)) {
            if (this.groundedVines.add(event.pos.toImmutable())
               && (Boolean)this.chatFeedback.get()
               && (!(Boolean)this.useThreading.get() || !(Boolean)this.limitChatSpam.get())) {
               this.info("§aVineESP§f: Found vine at §a%s", new Object[]{event.pos.toShortString()});
            }
         } else {
            this.groundedVines.remove(event.pos);
         }
      };
      if ((Boolean)this.useThreading.get() && this.threadPool != null) {
         this.threadPool.submit(updateTask);
      } else {
         updateTask.run();
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null) {
         this.tickCounter++;
         if (this.tickCounter >= (Integer)this.cleanupInterval.get()) {
            this.cleanupFarVines();
            this.tickCounter = 0;
         }

         Color sideColor = new Color((Color)this.espColor.get());
         Color lineColor = new Color((Color)this.espColor.get());
         Color tColor = new Color((Color)this.tracerColor.get());
         double distSq = Math.pow(((Integer)this.renderDistance.get()).intValue(), 2.0);

         for (BlockPos pos : this.groundedVines) {
            double d = this.mc.player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (!(d > distSq)) {
               event.renderer.box(pos, sideColor, lineColor, (ShapeMode)this.shapeMode.get(), 0);
               if ((Boolean)this.showTracers.get()) {
                  event.renderer
                     .line(
                        RenderUtils.center.x,
                        RenderUtils.center.y,
                        RenderUtils.center.z,
                        pos.getX() + 0.5,
                        pos.getY() + 0.5,
                        pos.getZ() + 0.5,
                        tColor
                     );
               }
            }
         }
      }
   }

   private void scanAllChunks() {
      for (Chunk chunk : Utils.chunks()) {
         if (chunk instanceof WorldChunk wc) {
            if ((Boolean)this.useThreading.get() && this.threadPool != null) {
               this.threadPool.submit(() -> this.scanChunk(wc));
            } else {
               this.scanChunk(wc);
            }
         }
      }
   }

   private void scanChunk(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();
      int yMin = Math.max(chunk.getBottomY(), (Integer)this.minY.get());
      int yMax = Math.min(chunk.getBottomY() + chunk.getHeight(), (Integer)this.maxY.get());

      for (int x = 0; x < 16; x++) {
         for (int z = 0; z < 16; z++) {
            for (int y = yMin; y < yMax; y++) {
               BlockPos pos = new BlockPos(cpos.getStartX() + x, y, cpos.getStartZ() + z);
               if (this.isGroundedVineChunk(chunk, pos)
                  && this.groundedVines.add(pos.toImmutable())
                  && (Boolean)this.chatFeedback.get()
                  && !(Boolean)this.limitChatSpam.get()) {
                  this.info("§aVineESP§f: Found vine at §a%s", new Object[]{pos.toShortString()});
               }
            }
         }
      }
   }

   private void cleanupFarVines() {
      if (this.mc.player != null) {
         double distSq = Math.pow((Integer)this.renderDistance.get() + 16, 2.0);
         this.groundedVines.removeIf(pos -> this.mc.player.squaredDistanceTo(pos.getX(), pos.getY(), pos.getZ()) > distSq);
      }
   }

   private boolean isGroundedVine(BlockState state, BlockPos pos) {
      if (state.isOf(Blocks.field_10597) && pos.getY() >= (Integer)this.minY.get() && pos.getY() <= (Integer)this.maxY.get()) {
         BlockState below = this.mc.world.getBlockState(pos.method_10074());
         return !below.isAir()
            && below.isSolidBlock(this.mc.world, pos.method_10074())
            && !below.isOf(Blocks.field_10597)
            && this.getVineLength(pos) >= (Integer)this.minVineLength.get();
      } else {
         return false;
      }
   }

   private boolean isGroundedVineChunk(WorldChunk chunk, BlockPos pos) {
      if (chunk.getBlockState(pos).isOf(Blocks.field_10597)
         && pos.getY() >= (Integer)this.minY.get()
         && pos.getY() <= (Integer)this.maxY.get()) {
         BlockState below = chunk.getBlockState(pos.method_10074());
         return !below.isAir()
            && below.isSolidBlock(this.mc.world, pos.method_10074())
            && !below.isOf(Blocks.field_10597)
            && this.getVineLengthChunk(chunk, pos) >= (Integer)this.minVineLength.get();
      } else {
         return false;
      }
   }

   private int getVineLength(BlockPos start) {
      int len = 1;

      for (BlockPos curr = start.up(); this.mc.world.getBlockState(curr).isOf(Blocks.field_10597); curr = curr.up()) {
         len++;
      }

      return len;
   }

   private int getVineLengthChunk(WorldChunk chunk, BlockPos start) {
      int len = 1;

      for (BlockPos curr = start.up(); chunk.getBlockState(curr).isOf(Blocks.field_10597); curr = curr.up()) {
         len++;
      }

      return len;
   }
}
