package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import com.vrzt.zinc.utils.zinc.ZincToast;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Block;
import net.minecraft.block.KelpBlock;
import net.minecraft.text.Text;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.Heightmap.Type;

public class KelpESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<SettingColor> kelpColor = this.sgGeneral
      .add(((Builder)new Builder().name("esp-color")).defaultValue(new SettingColor(0, 255, 0, 100)).build());
   private final Setting<ShapeMode> kelpShapeMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                  .name("shape-mode"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Integer> minKelpColumns = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("min-kelp-columns"))
               .defaultValue(20))
            .min(1)
            .build()
      );
   private final Setting<Integer> minTopsAt62 = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("min-tops-at-y62"))
               .defaultValue(18))
            .min(1)
            .build()
      );
   private final Set<ChunkPos> flaggedKelpChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> notifiedChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;

   public KelpESP() {
      super(ZincAddon.esp, "KelpESP", "Highlights near-perfect kelp farm chunks using threaded scanning.");
   }

   public void onActivate() {
      this.clearData();
      this.threadPool = Executors.newFixedThreadPool(2);
      if (this.mc.world != null) {
         for (Chunk chunk : Utils.chunks()) {
            if (chunk instanceof WorldChunk worldChunk) {
               this.threadPool.submit(() -> this.scanChunk(worldChunk));
            }
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
      }

      this.clearData();
   }

   private void clearData() {
      this.flaggedKelpChunks.clear();
      this.notifiedChunks.clear();
      this.scannedChunks.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (event.newState.getBlock() instanceof KelpBlock || event.oldState.getBlock() instanceof KelpBlock) {
         ChunkPos cp = new ChunkPos(event.pos);
         this.scannedChunks.remove(cp);
         if (this.threadPool != null && !this.threadPool.isShutdown() && this.mc.world.getChunk(event.pos) instanceof WorldChunk wc) {
            this.threadPool.submit(() -> this.scanChunk(wc));
         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.world != null) {
         Color side = new Color((Color)this.kelpColor.get());
         Color line = new Color(side).a(255);

         for (ChunkPos pos : this.flaggedKelpChunks) {
            double x1 = pos.getStartX();
            double z1 = pos.getStartZ();
            event.renderer.box(x1, 62.9, z1, x1 + 16.0, 63.1, z1 + 16.0, side, line, (ShapeMode)this.kelpShapeMode.get(), 0);
         }
      }
   }

   private void scanChunk(Chunk chunk) {
      ChunkPos cpos = chunk.getPos();
      if (this.scannedChunks.add(cpos)) {
         int kelpColumns = 0;
         int kelpTopsAt62 = 0;
         Mutable mutable = new Mutable();

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               int surfaceY = chunk.getHeightmap(Type.field_13200).get(x, z);
               if (surfaceY >= 30 && surfaceY <= 62) {
                  mutable.set(cpos.getStartX() + x, surfaceY, cpos.getStartZ() + z);
                  Block block = chunk.getBlockState(mutable).getBlock();
                  if (block instanceof KelpBlock) {
                     kelpColumns++;
                     if (surfaceY == 62) {
                        kelpTopsAt62++;
                     }
                  }
               }
            }
         }

         if (kelpColumns >= (Integer)this.minKelpColumns.get() && kelpTopsAt62 >= (Integer)this.minTopsAt62.get()) {
            this.flaggedKelpChunks.add(cpos);
            if (this.notifiedChunks.add(cpos)) {
               this.sendFeedback(cpos, kelpTopsAt62, kelpColumns);
            }
         } else {
            this.flaggedKelpChunks.remove(cpos);
         }
      }
   }

   private void sendFeedback(ChunkPos cpos, int tops, int total) {
      this.mc
         .execute(
            () -> {
               if (this.mc.player != null) {
                  this.info("Perfect kelp chunk at [%d, %d] (%d/%d tops)", new Object[]{cpos.x, cpos.z, tops, total});
                  this.mc
                     .getToastManager()
                     .add(
                        new KelpESP.KelpToast(
                           new ItemStack(Items.KELP),
                           Text.of("KelpESP"),
                           Text.of("X: " + cpos.getCenterX() + " Z: " + cpos.getCenterZ())
                        )
                     );
               }
            }
         );
   }

   private static class KelpToast extends ZincToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public KelpToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -872415232);
         int green = -16711936;
         context.fill(0, 0, 160, 1, green);
         context.fill(0, 31, 160, 32, green);
         context.fill(0, 1, 1, 31, green);
         context.fill(159, 1, 160, 31, green);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, green, false);
         }
      }
   }
}
