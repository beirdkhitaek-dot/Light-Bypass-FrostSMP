package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ItemSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;

public class OrderDropper extends Module {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Item> targetItem = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("target-item")).description("Item to search for and drop from orders."))
               .defaultValue(Items.field_8477))
            .build()
      );
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("delay"))
                  .description("Delay between actions in milliseconds."))
               .defaultValue(300))
            .min(100)
            .sliderMin(100)
            .sliderMax(2000)
            .build()
      );
   private OrderDropper.Stage stage = OrderDropper.Stage.NONE;
   private long stageStart = 0L;
   private boolean foundTargetItem = false;

   public OrderDropper() {
      super(ZincAddon.Zinc, "OrderDropper", "Automatically processes orders and drops specified items.");
   }

   public void onActivate() {
      if (this.targetItem.get() == null) {
         this.error("No target item selected.", new Object[0]);
         this.toggle();
      } else {
         this.stage = OrderDropper.Stage.OPEN_ORDERS;
         this.stageStart = System.currentTimeMillis();
         this.foundTargetItem = false;
      }
   }

   public void onDeactivate() {
      this.stage = OrderDropper.Stage.NONE;
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null && this.mc.world != null) {
         long now = System.currentTimeMillis();
         switch (this.stage) {
            case NONE:
            default:
               break;
            case OPEN_ORDERS:
               ChatUtils.sendPlayerMsg("/order");
               this.stage = OrderDropper.Stage.WAIT_ORDERS_GUI;
               this.stageStart = now;
               break;
            case WAIT_ORDERS_GUI:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (this.mc.currentScreen instanceof GenericContainerScreen) {
                  this.stage = OrderDropper.Stage.CLICK_SLOT_51;
                  this.stageStart = now;
               } else if (now - this.stageStart > 3000L) {
                  this.stage = OrderDropper.Stage.OPEN_ORDERS;
                  this.stageStart = now;
               }
               break;
            case CLICK_SLOT_51:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler handler = screen.getScreenHandler();
               if (handler.slots.size() > 51) {
                  this.mc.interactionManager.clickSlot(handler.syncId, 51, 0, SlotActionType.PICKUP, this.mc.player);
                  this.stage = OrderDropper.Stage.WAIT_SECOND_GUI;
                  this.stageStart = now;
               }
               break;
            case WAIT_SECOND_GUI:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (this.mc.currentScreen instanceof GenericContainerScreen) {
                  this.stage = OrderDropper.Stage.CLICK_TARGET_ITEM;
                  this.stageStart = now;
               } else if (now - this.stageStart > 3000L) {
                  this.stage = OrderDropper.Stage.OPEN_ORDERS;
                  this.stageStart = now;
               }
               break;
            case CLICK_TARGET_ITEM:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               if (this.targetItem.get() == null) {
                  this.error("Target item is null.", new Object[0]);
                  this.toggle();
                  return;
               }

               ScreenHandler handler2 = screen.getScreenHandler();
               this.foundTargetItem = false;

               for (int i = 0; i < handler2.slots.size(); i++) {
                  Slot slot = (Slot)handler2.slots.get(i);
                  if (slot.hasStack() && slot.getStack().getItem() == this.targetItem.get()) {
                     this.mc.interactionManager.clickSlot(handler2.syncId, i, 0, SlotActionType.PICKUP, this.mc.player);
                     this.stage = OrderDropper.Stage.WAIT_THIRD_GUI;
                     this.stageStart = now;
                     this.foundTargetItem = true;
                     break;
                  }
               }

               if (!this.foundTargetItem && now - this.stageStart > 4000L) {
                  this.stage = OrderDropper.Stage.CYCLE_PAUSE;
                  this.stageStart = now;
               }
               break;
            case WAIT_THIRD_GUI:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (this.mc.currentScreen instanceof GenericContainerScreen) {
                  this.stage = OrderDropper.Stage.CLICK_SLOT_13;
                  this.stageStart = now;
               } else if (now - this.stageStart > 3000L) {
                  this.stage = OrderDropper.Stage.OPEN_ORDERS;
                  this.stageStart = now;
               }
               break;
            case CLICK_SLOT_13:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler handler3 = screen.getScreenHandler();
               if (handler3.slots.size() > 13) {
                  Slot slot13 = (Slot)handler3.slots.get(13);
                  if (slot13.hasStack() && slot13.getStack().getItem() == Items.CHEST) {
                     this.mc.interactionManager.clickSlot(handler3.syncId, 13, 0, SlotActionType.PICKUP, this.mc.player);
                  } else if (handler3.slots.size() > 15) {
                     this.mc.interactionManager.clickSlot(handler3.syncId, 15, 0, SlotActionType.PICKUP, this.mc.player);
                  }

                  this.stage = OrderDropper.Stage.WAIT_ITEMS_GUI;
                  this.stageStart = now;
               }
               break;
            case WAIT_ITEMS_GUI:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (this.mc.currentScreen instanceof GenericContainerScreen) {
                  this.stage = OrderDropper.Stage.CLICK_SLOT_52;
                  this.stageStart = now;
               } else if (now - this.stageStart > 3000L) {
                  this.stage = OrderDropper.Stage.OPEN_ORDERS;
                  this.stageStart = now;
               }
               break;
            case CLICK_SLOT_52:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  return;
               }

               ScreenHandler handler4 = screen.getScreenHandler();
               if (handler4.slots.size() > 52) {
                  this.mc.interactionManager.clickSlot(handler4.syncId, 52, 0, SlotActionType.PICKUP, this.mc.player);
                  this.stage = OrderDropper.Stage.CLICK_SLOT_53;
                  this.stageStart = now;
               }
               break;
            case CLICK_SLOT_53:
               if (now - this.stageStart < ((Integer)this.delay.get()).intValue()) {
                  return;
               }

               if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
                  this.toggle();
                  return;
               }

               ScreenHandler handler5 = screen.getScreenHandler();
               if (handler5.slots.size() > 53) {
                  Slot nextPageSlot = (Slot)handler5.slots.get(53);
                  if (nextPageSlot.hasStack() && nextPageSlot.getStack().getItem() == Items.field_8107) {
                     this.mc.interactionManager.clickSlot(handler5.syncId, 53, 0, SlotActionType.PICKUP, this.mc.player);
                     this.stage = OrderDropper.Stage.CLICK_SLOT_52;
                     this.stageStart = now;
                  } else {
                     if (handler5.slots.size() > 52) {
                        this.mc.interactionManager.clickSlot(handler5.syncId, 52, 0, SlotActionType.PICKUP, this.mc.player);
                     }

                     this.toggle();
                  }
               }
               break;
            case CYCLE_PAUSE:
               if (now - this.stageStart > 2000L) {
                  this.stage = OrderDropper.Stage.OPEN_ORDERS;
                  this.stageStart = now;
               }
         }
      }
   }

   public String getInfoString() {
      return this.stage.toString().toLowerCase().replace("_", " ");
   }

   private static enum Stage {
      NONE,
      OPEN_ORDERS,
      WAIT_ORDERS_GUI,
      CLICK_SLOT_51,
      WAIT_SECOND_GUI,
      CLICK_TARGET_ITEM,
      WAIT_THIRD_GUI,
      CLICK_SLOT_13,
      WAIT_ITEMS_GUI,
      CLICK_SLOT_52,
      CLICK_SLOT_53,
      CYCLE_PAUSE;

      private Stage() {
      }
   }
}
