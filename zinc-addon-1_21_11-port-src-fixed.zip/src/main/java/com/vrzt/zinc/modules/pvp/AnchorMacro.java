package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.block.RespawnAnchorBlock;

public class AnchorMacro extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> safetySlot = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("safety-slot")).defaultValue(1)).min(1).max(9).build());
   private boolean isSimulating = false;
   private boolean glowstonePlaced = false;
   private KeyBinding activeKey = null;

   public AnchorMacro() {
      super(ZincAddon.pvp, "anchor-macro", "Zero-delay hardcoded logic.");
   }

   public void onDeactivate() {
      this.resetMacro();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         if (this.mc.crosshairTarget instanceof BlockHitResult blockHit && this.mc.world.getBlockState(blockHit.getBlockPos()).isOf(Blocks.field_23152)) {
            if (this.mc.options.useKey.isPressed() || this.isSimulating) {
               this.mc.options.useKey.setPressed(false);
               this.handleSimulatedLogic(blockHit);
            } else if (!this.isSimulating) {
               this.glowstonePlaced = false;
            }
         } else {
            this.resetMacro();
         }
      }
   }

   private void handleSimulatedLogic(BlockHitResult hit) {
      int charges = (Integer)this.mc.world.getBlockState(hit.getBlockPos()).get(RespawnAnchorBlock.CHARGES);
      int sSlot = (Integer)this.safetySlot.get() - 1;
      if (charges == 0 && !this.glowstonePlaced) {
         int glowstoneSlot = this.findItemSlot(Items.GLOWSTONE);
         if (glowstoneSlot != -1) {
            this.isSimulating = true;
            this.hardwareFullSwap(glowstoneSlot);
            ((IMinecraftClient)this.mc).zinc$doItemUse();
            this.glowstonePlaced = true;
         }
      } else if (charges > 0 || this.glowstonePlaced) {
         this.isSimulating = true;
         if (this.mc.player.getInventory().getSelectedSlot() != sSlot) {
            this.hardwareFullSwap(sSlot);
         } else {
            ((IMinecraftClient)this.mc).zinc$doItemUse();
            this.isSimulating = false;
            this.glowstonePlaced = false;
         }
      }
   }

   private void resetMacro() {
      if (this.activeKey != null) {
         this.activeKey.setPressed(false);
         this.activeKey = null;
      }

      this.isSimulating = false;
      this.glowstonePlaced = false;
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeKey != null) {
            this.activeKey.setPressed(false);
         }

         this.activeKey = this.mc.options.hotbarKeys[slot];
         this.activeKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safetyCount = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safetyCount < 10; safetyCount++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }
      }
   }

   private int findItemSlot(Item item) {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(item)) {
            return i;
         }
      }

      return -1;
   }
}
