package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;

public class Capes extends Module {
   public static String capeed;
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   public final Setting<Capes.Mode> mode = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("mode")).description("Select a cape.")).defaultValue(Capes.Mode.Minecon2011))
               .onChanged(v -> capeed = ((Capes.Mode)v).textureName))
            .build()
      );

   public Capes() {
      super(ZincAddon.Render, "capes", "Official Minecon and Zinc capes.");
   }

   public void onActivate() {
      capeed = ((Capes.Mode)this.mode.get()).textureName;
   }

   public void onDeactivate() {
      capeed = null;
   }

   public static enum Mode {
      Minecon2011("2011"),
      Minecon2012("2012"),
      Minecon2013("2013"),
      Minecon2015("2015"),
      Minecon2016("2016"),
      MojangOld("mojang_old"),
      MojangNew("mojang_new"),
      CustomCape1("custom_1"),
      CustomCape2("custom_2"),
      CustomCape3("custom_3");

      public final String textureName;

      private Mode(String textureName) {
         this.textureName = textureName;
      }

      @Override
      public String toString() {
         return this.name()
            .replace("Minecon", "Minecon ")
            .replace("MojangOld", "Old Mojang")
            .replace("MojangNew", "New Mojang")
            .replace("CustomCape", "Custom Cape ");
      }
   }
}
