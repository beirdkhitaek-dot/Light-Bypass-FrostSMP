package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos.Mutable;

public class CustomParticles extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgParticle = this.settings.createGroup("Particle Settings");
   private final SettingGroup sgOrbit = this.settings.createGroup("Orbit Settings");
   private final Setting<CustomParticles.Mode> mode = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("mode")).description("How particles are rendered.")).defaultValue(CustomParticles.Mode.Ambient))
            .build()
      );
   private final Setting<Integer> particleCount = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("count"))
                  .description("Number of particles to render."))
               .defaultValue(40))
            .min(1)
            .sliderMax(200)
            .build()
      );
   private final Setting<Boolean> checkAir = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("check-air"))
                  .description("Only render particles in air blocks."))
               .defaultValue(true))
            .build()
      );
   private final Setting<CustomParticles.ParticleType> particleType = this.sgParticle
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("type")).description("Shape of the particles."))
               .defaultValue(CustomParticles.ParticleType.Octahedron))
            .build()
      );
   private final Setting<Double> size = this.sgParticle
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("size"))
               .description("Size of the particles."))
            .defaultValue(0.12)
            .min(0.01)
            .sliderMax(0.5)
            .build()
      );
   private final Setting<SettingColor> color = this.sgParticle
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("color"))
               .description("Color of the particles."))
            .defaultValue(new SettingColor(180, 50, 255, 180))
            .build()
      );
   private final Setting<SettingColor> secondaryColor = this.sgParticle
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("secondary-color"))
                  .description("Secondary color for particle edges."))
               .defaultValue(new SettingColor(255, 100, 255, 150))
               .visible(() -> this.particleType.get() == CustomParticles.ParticleType.Sphere))
            .build()
      );
   private final Setting<Double> sphereResolution = this.sgParticle
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("sphere-resolution"))
                  .description("Resolution of sphere particles."))
               .defaultValue(12.0)
               .min(4.0)
               .sliderMax(32.0)
               .visible(() -> this.particleType.get() == CustomParticles.ParticleType.Sphere))
            .build()
      );
   private final Setting<Double> ambientSpread = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("spread"))
                  .description("Spread radius for ambient particles."))
               .defaultValue(15.0)
               .visible(() -> this.mode.get() == CustomParticles.Mode.Ambient))
            .build()
      );
   private final Setting<Double> driftSpeed = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("drift-speed"))
                  .description("Speed of particle drifting."))
               .defaultValue(0.01)
               .sliderMax(0.1)
               .visible(() -> this.mode.get() == CustomParticles.Mode.Ambient))
            .build()
      );
   private final Setting<Double> orbitRadius = this.sgOrbit
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("radius"))
                  .description("Orbit radius around players."))
               .defaultValue(1.5)
               .visible(() -> this.mode.get() == CustomParticles.Mode.Orbit))
            .build()
      );
   private final Setting<Double> orbitSpeed = this.sgOrbit
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("speed"))
                  .description("Orbit speed around players."))
               .defaultValue(1.5)
               .visible(() -> this.mode.get() == CustomParticles.Mode.Orbit))
            .build()
      );
   private final Setting<Double> orbitHeight = this.sgOrbit
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("height"))
                  .description("Vertical offset from player center."))
               .defaultValue(0.0)
               .sliderMin(-1.0)
               .sliderMax(2.0)
               .visible(() -> this.mode.get() == CustomParticles.Mode.Orbit))
            .build()
      );
   private final Setting<Double> orbitBob = this.sgOrbit
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("bobbing"))
                  .description("Amount of vertical bobbing motion."))
               .defaultValue(0.2)
               .min(0.0)
               .sliderMax(1.0)
               .visible(() -> this.mode.get() == CustomParticles.Mode.Orbit))
            .build()
      );
   private final Setting<Boolean> targetFriends = this.sgOrbit
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("target-friends"))
                     .description("Only orbit around friends."))
                  .defaultValue(false))
               .visible(() -> this.mode.get() == CustomParticles.Mode.Orbit))
            .build()
      );
   private final Setting<Boolean> targetSelf = this.sgOrbit
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("target-self"))
                     .description("Also orbit around yourself."))
                  .defaultValue(false))
               .visible(() -> this.mode.get() == CustomParticles.Mode.Orbit))
            .build()
      );
   private final List<CustomParticles.Particle> particles = new ArrayList<>();
   private final Random random = new Random();
   private final Mutable blockPos = new Mutable();

   public CustomParticles() {
      super(ZincAddon.Render, "custom-particles", "Customizable 3D particles with different shapes and behaviors.");
   }

   public void onActivate() {
      this.particles.clear();
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         if (this.mode.get() == CustomParticles.Mode.Ambient) {
            this.updateAmbient(event);
         } else {
            this.updateOrbit(event);
         }
      }
   }

   private void updateAmbient(Render3DEvent event) {
      while (this.particles.size() < this.particleCount.get()) {
         double px = this.mc.player.getX() + (this.random.nextDouble() - 0.5) * (Double)this.ambientSpread.get() * 2.0;
         double py = this.mc.player.getY() + this.random.nextDouble() * (Double)this.ambientSpread.get();
         double pz = this.mc.player.getZ() + (this.random.nextDouble() - 0.5) * (Double)this.ambientSpread.get() * 2.0;
         if (!(Boolean)this.checkAir.get() || this.mc.world.isAir(this.blockPos.set(px, py, pz))) {
            this.particles.add(new CustomParticles.Particle(px, py, pz, true));
         }
      }

      for (int i = 0; i < this.particles.size(); i++) {
         CustomParticles.Particle p = this.particles.get(i);
         p.tick();
         p.x = p.x + p.dx * (Double)this.driftSpeed.get();
         p.y = p.y + p.dy * (Double)this.driftSpeed.get();
         p.z = p.z + p.dz * (Double)this.driftSpeed.get();
         double distSq = this.mc.player.squaredDistanceTo(p.x, p.y, p.z);
         if (distSq > Math.pow((Double)this.ambientSpread.get(), 2.0)) {
            p.fadingOut = true;
         }

         if ((Boolean)this.checkAir.get() && !this.mc.world.isAir(this.blockPos.set(p.x, p.y, p.z))) {
            p.fadingOut = true;
         }

         if (p.fadingOut && p.scale <= 0.0) {
            this.particles.remove(i);
            i--;
         } else {
            this.renderParticle(event, p.x, p.y, p.z, p.scale);
         }
      }
   }

   private void updateOrbit(Render3DEvent event) {
      double time = System.currentTimeMillis() / 1000.0 * (Double)this.orbitSpeed.get();

      for (PlayerEntity player : this.mc.world.getPlayers()) {
         if ((player != this.mc.player || (Boolean)this.targetSelf.get()) && (!(Boolean)this.targetFriends.get() || Friends.get().isFriend(player))) {
            double px = MathHelper.lerp(event.tickDelta, player.lastRenderX, player.getX());
            double py = MathHelper.lerp(event.tickDelta, player.lastRenderY, player.getY()) + (Double)this.orbitHeight.get();
            double pz = MathHelper.lerp(event.tickDelta, player.lastRenderZ, player.getZ());

            for (int i = 0; i < this.particleCount.get(); i++) {
               double angle = time + (Math.PI * 2) / ((Integer)this.particleCount.get()).intValue() * i;
               double x = px + Math.cos(angle) * (Double)this.orbitRadius.get();
               double z = pz + Math.sin(angle) * (Double)this.orbitRadius.get();
               double y = py + Math.sin(time + i) * (Double)this.orbitBob.get();
               if (!(Boolean)this.checkAir.get() || this.mc.world.isAir(this.blockPos.set(x, y, z))) {
                  this.renderParticle(event, x, y, z, 1.0);
               }
            }
         }
      }
   }

   private void renderParticle(Render3DEvent event, double x, double y, double z, double scale) {
      double s = (Double)this.size.get() * scale;
      if (!(s <= 0.0)) {
         switch ((CustomParticles.ParticleType)this.particleType.get()) {
            case Octahedron:
               this.renderOctahedron(event, x, y, z, s, (Color)this.color.get());
               break;
            case Cube:
               this.renderCube(event, x, y, z, s, (Color)this.color.get());
               break;
            case Sphere:
               this.renderSphere(event, x, y, z, s, (Color)this.color.get(), (Color)this.secondaryColor.get());
         }
      }
   }

   private void renderOctahedron(Render3DEvent event, double x, double y, double z, double s, Color c) {
      event.renderer.line(x, y + s, z, x + s, y, z, c);
      event.renderer.line(x, y + s, z, x - s, y, z, c);
      event.renderer.line(x, y + s, z, x, y, z + s, c);
      event.renderer.line(x, y + s, z, x, y, z - s, c);
      event.renderer.line(x, y - s, z, x + s, y, z, c);
      event.renderer.line(x, y - s, z, x - s, y, z, c);
      event.renderer.line(x, y - s, z, x, y, z + s, c);
      event.renderer.line(x, y - s, z, x, y, z - s, c);
      event.renderer.line(x + s, y, z, x, y, z + s, c);
      event.renderer.line(x, y, z + s, x - s, y, z, c);
      event.renderer.line(x - s, y, z, x, y, z - s, c);
      event.renderer.line(x, y, z - s, x + s, y, z, c);
   }

   private void renderCube(Render3DEvent event, double x, double y, double z, double s, Color c) {
      double halfS = s / 2.0;
      event.renderer.line(x - halfS, y - halfS, z - halfS, x + halfS, y - halfS, z - halfS, c);
      event.renderer.line(x + halfS, y - halfS, z - halfS, x + halfS, y - halfS, z + halfS, c);
      event.renderer.line(x + halfS, y - halfS, z + halfS, x - halfS, y - halfS, z + halfS, c);
      event.renderer.line(x - halfS, y - halfS, z + halfS, x - halfS, y - halfS, z - halfS, c);
      event.renderer.line(x - halfS, y + halfS, z - halfS, x + halfS, y + halfS, z - halfS, c);
      event.renderer.line(x + halfS, y + halfS, z - halfS, x + halfS, y + halfS, z + halfS, c);
      event.renderer.line(x + halfS, y + halfS, z + halfS, x - halfS, y + halfS, z + halfS, c);
      event.renderer.line(x - halfS, y + halfS, z + halfS, x - halfS, y + halfS, z - halfS, c);
      event.renderer.line(x - halfS, y - halfS, z - halfS, x - halfS, y + halfS, z - halfS, c);
      event.renderer.line(x + halfS, y - halfS, z - halfS, x + halfS, y + halfS, z - halfS, c);
      event.renderer.line(x + halfS, y - halfS, z + halfS, x + halfS, y + halfS, z + halfS, c);
      event.renderer.line(x - halfS, y - halfS, z + halfS, x - halfS, y + halfS, z + halfS, c);
   }

   private void renderSphere(Render3DEvent event, double x, double y, double z, double radius, Color primary, Color secondary) {
      int segments = (int)((Double)this.sphereResolution.get()).doubleValue();
      double segmentAngle = (Math.PI * 2) / segments;

      for (int i = 0; i < segments; i++) {
         double angle1 = i * segmentAngle;
         double angle2 = (i + 1) % segments * segmentAngle;
         double x1 = x + Math.cos(angle1) * radius;
         double z1 = z + Math.sin(angle1) * radius;
         double x2 = x + Math.cos(angle2) * radius;
         double z2 = z + Math.sin(angle2) * radius;
         event.renderer.line(x1, y, z1, x2, y, z2, primary);
         double yTop = y + radius * 0.7;
         double yBottom = y - radius * 0.7;
         event.renderer.line(x1, yTop, z1, x2, yTop, z2, secondary);
         event.renderer.line(x1, yBottom, z1, x2, yBottom, z2, secondary);
      }

      for (int i = 0; i < segments; i += 2) {
         double angle = i * segmentAngle;
         double xPos = x + Math.cos(angle) * radius;
         double zPos = z + Math.sin(angle) * radius;
         event.renderer.line(xPos, y - radius * 0.7, zPos, xPos, y + radius * 0.7, zPos, secondary);
      }
   }

   public static enum Mode {
      Ambient,
      Orbit;

      private Mode() {
      }
   }

   private class Particle {
      double x;
      double y;
      double z;
      double dx;
      double dy;
      double dz;
      double scale = 0.0;
      boolean fadingOut = false;

      Particle(double x, double y, double z, boolean randomDrift) {
         this.x = x;
         this.y = y;
         this.z = z;
         if (randomDrift) {
            this.dx = CustomParticles.this.random.nextDouble() - 0.5;
            this.dy = CustomParticles.this.random.nextDouble() - 0.5;
            this.dz = CustomParticles.this.random.nextDouble() - 0.5;
         }
      }

      void tick() {
         if (this.fadingOut) {
            this.scale = Math.max(0.0, this.scale - 0.05);
         } else {
            this.scale = Math.min(1.0, this.scale + 0.02);
         }
      }
   }

   public static enum ParticleType {
      Octahedron,
      Cube,
      Sphere;

      private ParticleType() {
      }
   }
}
