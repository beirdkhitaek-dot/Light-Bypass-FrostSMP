package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class AimAssist extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<AimAssist.TargetMode> targetMode = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("target-mode")).description("How to select the player to aim at."))
               .defaultValue(AimAssist.TargetMode.Closest))
            .build()
      );
   private final Setting<Double> range = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("range"))
               .description("The maximum distance to lock onto a target."))
            .defaultValue(4.5)
            .min(0.0)
            .sliderMax(10.0)
            .build()
      );
   private final Setting<Boolean> ignoreFriends = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("ignore-friends"))
                  .description("Whether to ignore players on your friends list."))
               .defaultValue(true))
            .build()
      );
   private final Setting<AimAssist.TargetPart> part = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("aim-part")).description("Which part of the body to lock onto."))
               .defaultValue(AimAssist.TargetPart.Torso))
            .build()
      );
   private final Setting<Boolean> throughWalls = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("through-walls"))
                  .description("Whether to aim at players behind blocks."))
               .defaultValue(false))
            .build()
      );
   private final Setting<Double> speed = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("speed"))
               .description("How fast the aim assist moves toward the target."))
            .defaultValue(0.15)
            .min(0.0)
            .sliderMax(1.0)
            .build()
      );
   private PlayerEntity target = null;
   private PlayerEntity lastHitTarget = null;
   private double phase = 0.0;
   private static final float JITTER_SIZE = 1.0F;
   private static final double JITTER_SPEED = 0.205;

   public AimAssist() {
      super(ZincAddon.pvp, "aim-assist", "Bone-locking aim assist with customizable target modes.");
   }

   public void onActivate() {
      this.killLogic();
   }

   public void onDeactivate() {
      this.killLogic();
   }

   private void killLogic() {
      this.target = null;
      this.lastHitTarget = null;
      this.phase = 0.0;
   }

   @EventHandler
   private void onAttack(AttackEntityEvent event) {
      if (event.entity instanceof PlayerEntity player) {
         this.lastHitTarget = player;
      }
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null && this.mc.world != null) {
         if (this.targetMode.get() == AimAssist.TargetMode.Closest) {
            this.target = this.mc
               .world
               .getPlayers()
               .stream()
               .filter(p -> p != this.mc.player && p.isAlive())
               .filter(p -> this.mc.player.distanceTo(p) <= (Double)this.range.get())
               .filter(p -> !(Boolean)this.ignoreFriends.get() || !Friends.get().isFriend(p))
               .min(Comparator.comparingDouble(p -> this.mc.player.distanceTo(p)))
               .orElse(null);
         } else {
            if (this.lastHitTarget != null
               && (!this.lastHitTarget.isAlive() || this.mc.player.distanceTo(this.lastHitTarget) > (Double)this.range.get())) {
               this.lastHitTarget = null;
            }

            this.target = this.lastHitTarget;
         }

         if (this.target != null) {
            if ((Boolean)this.throughWalls.get() || this.mc.player.canSee(this.target)) {
               double currentBaseOffset = ((AimAssist.TargetPart)this.part.get()).offset;
               double deltaX = this.target.getX() - this.mc.player.getX();
               double deltaY = this.target.getY() + currentBaseOffset - (this.mc.player.getY() + this.mc.player.getStandingEyeHeight());
               double deltaZ = this.target.getZ() - this.mc.player.getZ();
               double distanceXZ = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
               float targetYaw = (float)Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0F;
               float targetPitch = (float)(-Math.toDegrees(Math.atan2(deltaY, distanceXZ)));
               this.phase += 0.205;
               if (this.phase > 4.0) {
                  this.phase = 0.0;
               }

               float jitterX = 0.0F;
               float jitterY = 0.0F;
               if (this.phase < 1.0) {
                  jitterX = (float)(-1.0 + this.phase * 2.0 * 1.0);
                  jitterY = 1.0F;
               } else if (this.phase < 2.0) {
                  jitterX = 1.0F;
                  jitterY = (float)(1.0 - (this.phase - 1.0) * 2.0 * 1.0);
               } else if (this.phase < 3.0) {
                  jitterX = (float)(1.0 - (this.phase - 2.0) * 2.0 * 1.0);
                  jitterY = -1.0F;
               } else {
                  jitterX = -1.0F;
                  jitterY = (float)(-1.0 + (this.phase - 3.0) * 2.0 * 1.0);
               }

               targetYaw += jitterX;
               targetPitch += jitterY;
               double currentSpeed = (Double)this.speed.get() + ThreadLocalRandom.current().nextDouble(-0.02, 0.02);
               float nextYaw = MathHelper.lerpAngleDegrees((float)currentSpeed, this.mc.player.getYaw(), targetYaw);
               float nextPitch = MathHelper.lerp((float)currentSpeed, this.mc.player.getPitch(), targetPitch);
               float sensitivity = ((Double)this.mc.options.getMouseSensitivity().getValue()).floatValue();
               float f = sensitivity * 0.6F + 0.2F;
               float gcd = f * f * f * 8.0F * 0.15F;
               nextYaw = this.mc.player.getYaw() + Math.round((nextYaw - this.mc.player.getYaw()) / gcd) * gcd;
               nextPitch = this.mc.player.getPitch() + Math.round((nextPitch - this.mc.player.getPitch()) / gcd) * gcd;
               this.mc.player.setYaw(nextYaw);
               this.mc.player.setPitch(MathHelper.clamp(nextPitch, -90.0F, 90.0F));
            }
         }
      }
   }

   public static enum TargetMode {
      Closest,
      LastHit;

      private TargetMode() {
      }
   }

   public static enum TargetPart {
      Head(1.5),
      Torso(1.0),
      Legs(0.4);

      public final double offset;

      private TargetPart(double offset) {
         this.offset = offset;
      }
   }
}
