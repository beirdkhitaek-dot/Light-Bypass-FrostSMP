package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.AbstractMap.SimpleEntry;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.block.BlockState;

public class CoveredHole extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgRender = this.settings.createGroup("Render");
   private final Setting<Boolean> chatNotifications = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("chat-notifications")).description("Send chat messages when covered holes are found"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> onlyPlayerCovered = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("only-player-covered")).description("Only detect holes that appear to be intentionally covered"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> maxThreads = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("max-threads"))
                  .description("Maximum number of threads to use for scanning"))
               .defaultValue(4))
            .min(1)
            .max(8)
            .build()
      );
   private final Setting<ShapeMode> shapeMode = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("How the shapes are rendered"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<SettingColor> lineColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("line-color"))
               .description("The color of the lines for covered holes"))
            .defaultValue(new SettingColor(255, 165, 0, 255))
            .build()
      );
   private final Setting<SettingColor> sideColor = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("side-color"))
               .description("The color of the sides for covered holes"))
            .defaultValue(new SettingColor(255, 165, 0, 50))
            .build()
      );
   private final Map<Box, CoveredHole.CoveredHoleInfo> coveredHoles = new ConcurrentHashMap<>();
   private final Set<Box> processedHoles = ConcurrentHashMap.newKeySet();
   private final Set<Box> pendingProcessing = ConcurrentHashMap.newKeySet();
   private final Set<Box> notifiedHoles = ConcurrentHashMap.newKeySet();
   private ExecutorService executorService;
   private final List<Future<Entry<Box, CoveredHole.CoveredHoleInfo>>> pendingTasks = new ArrayList<>();
   private final Map<BlockPos, Boolean> solidBlockCache = new ConcurrentHashMap<>();
   private final Map<BlockPos, BlockState> blockStateCache = new ConcurrentHashMap<>();
   private HoleTunnelStairsESP holeESP;
   private int tickCounter = 0;
   private volatile boolean isScanning = false;
   private long lastCacheClear = 0L;
   private long lastCheckTime = 0L;
   private String currentWorld = "";

   public CoveredHole() {
      super(ZincAddon.esp, "covered-hole", "Detects covered holes from HoleTunnelStairsESP with performance optimization.");
   }

   public void onActivate() {
      this.executorService = Executors.newFixedThreadPool((Integer)this.maxThreads.get());
      this.holeESP = (HoleTunnelStairsESP)Modules.get().get(HoleTunnelStairsESP.class);
      if (this.holeESP != null && this.holeESP.isActive()) {
         this.clearAllData();
         if (this.mc.world != null) {
            this.currentWorld = this.mc.world.getRegistryKey().getValue().toString();
         }
      } else {
         this.error("HoleTunnelStairsESP must be active for CoveredHole to work!", new Object[0]);
         this.toggle();
      }
   }

   public void onDeactivate() {
      this.shutdownExecutor();
      this.clearAllData();
   }

   private void clearAllData() {
      this.coveredHoles.clear();
      this.processedHoles.clear();
      this.pendingProcessing.clear();
      this.solidBlockCache.clear();
      this.blockStateCache.clear();
      this.pendingTasks.clear();
      this.notifiedHoles.clear();
      this.isScanning = false;
      this.tickCounter = 0;
      this.lastCacheClear = System.currentTimeMillis();
      this.lastCheckTime = 0L;
   }

   private void shutdownExecutor() {
      if (this.executorService != null) {
         this.isScanning = false;

         for (Future<?> task : this.pendingTasks) {
            task.cancel(true);
         }

         this.pendingTasks.clear();
         this.executorService.shutdown();

         try {
            if (!this.executorService.awaitTermination(500L, TimeUnit.MILLISECONDS)) {
               this.executorService.shutdownNow();
            }
         } catch (InterruptedException var3) {
            this.executorService.shutdownNow();
            Thread.currentThread().interrupt();
         }
      }
   }

   private void checkWorldChange() {
      if (this.mc.world == null) {
         this.currentWorld = "";
         this.clearAllData();
      } else {
         String newWorld = this.mc.world.getRegistryKey().getValue().toString();
         if (!newWorld.equals(this.currentWorld)) {
            this.currentWorld = newWorld;
            this.clearAllData();
         }
      }
   }

   @EventHandler
   private void onTick(Post event) {
      this.checkWorldChange();
      if (this.mc.world != null && this.mc.player != null) {
         if (this.holeESP != null && this.holeESP.isActive()) {
            this.tickCounter++;
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lastCacheClear > 5000L) {
               this.clearOldCacheEntries();
               this.lastCacheClear = currentTime;
            }

            if (currentTime - this.lastCheckTime > 5000L) {
               this.startAsyncScan();
               this.lastCheckTime = currentTime;
            }

            this.processCompletedTasks();
         } else {
            this.error("HoleTunnelStairsESP was disabled!", new Object[0]);
            this.toggle();
         }
      }
   }

   private void clearOldCacheEntries() {
      if (this.solidBlockCache.size() > 1000) {
         this.solidBlockCache.clear();
      }

      if (this.blockStateCache.size() > 1000) {
         this.blockStateCache.clear();
      }
   }

   private void startAsyncScan() {
      Set<Box> holes = this.getHolesFromHoleESP();
      if (holes != null && !holes.isEmpty()) {
         this.isScanning = true;
         List<Box> newHoles = new ArrayList<>();

         for (Box hole : holes) {
            if (!this.processedHoles.contains(hole) && !this.pendingProcessing.contains(hole)) {
               newHoles.add(hole);
               this.pendingProcessing.add(hole);
            }
         }

         int maxConcurrentTasks = Math.min(newHoles.size(), (Integer)this.maxThreads.get());

         for (int i = 0; i < maxConcurrentTasks; i++) {
            if (i < newHoles.size()) {
               Future<Entry<Box, CoveredHole.CoveredHoleInfo>> future = this.executorService.submit(new CoveredHole.HoleCheckTask(newHoles.get(i)));
               this.pendingTasks.add(future);
            }
         }

         this.coveredHoles.keySet().retainAll(holes);
         this.processedHoles.retainAll(holes);
         this.pendingProcessing.retainAll(holes);
      }
   }

   private void processCompletedTasks() {
      Iterator<Future<Entry<Box, CoveredHole.CoveredHoleInfo>>> iterator = this.pendingTasks.iterator();
      int processedCount = 0;
      int maxProcessPerTick = 3;

      while (iterator.hasNext() && processedCount < 3) {
         Future<Entry<Box, CoveredHole.CoveredHoleInfo>> task = iterator.next();
         if (task.isDone()) {
            try {
               Entry<Box, CoveredHole.CoveredHoleInfo> result = task.get(1L, TimeUnit.MILLISECONDS);
               if (result != null) {
                  this.coveredHoles.put(result.getKey(), result.getValue());
                  this.pendingProcessing.remove(result.getKey());
                  if ((Boolean)this.chatNotifications.get() && !this.notifiedHoles.contains(result.getKey())) {
                     Box hole = result.getKey();
                     BlockPos coverPos = result.getValue().coverPos;
                     int depth = (int)(hole.maxY - hole.minY);
                     this.info(String.format("Covered Hole found at %s (depth: %d)", coverPos.toShortString(), depth), new Object[0]);
                     this.notifiedHoles.add(result.getKey());
                  }
               }
            } catch (Exception var12) {
            } finally {
               iterator.remove();
               processedCount++;
            }
         }
      }

      if (this.pendingTasks.isEmpty()) {
         this.isScanning = false;
      }
   }

   private Set<Box> getHolesFromHoleESP() {
      try {
         return this.holeESP != null ? this.holeESP.getHoles() : Collections.emptySet();
      } catch (Exception var2) {
         return Collections.emptySet();
      }
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.world != null) {
         for (Entry<Box, CoveredHole.CoveredHoleInfo> entry : this.coveredHoles.entrySet()) {
            Box hole = entry.getKey();
            CoveredHole.CoveredHoleInfo info = entry.getValue();

            try {
               event.renderer
                  .box(
                     hole.minX,
                     hole.minY,
                     hole.minZ,
                     hole.maxX,
                     hole.maxY,
                     hole.maxZ,
                     (Color)this.sideColor.get(),
                     (Color)this.lineColor.get(),
                     (ShapeMode)this.shapeMode.get(),
                     0
                  );
               event.renderer
                  .box(
                     info.coverPos.getX(),
                     info.coverPos.getY(),
                     info.coverPos.getZ(),
                     info.coverPos.getX() + 1,
                     info.coverPos.getY() + 1,
                     info.coverPos.getZ() + 1,
                     (Color)this.sideColor.get(),
                     (Color)this.lineColor.get(),
                     (ShapeMode)this.shapeMode.get(),
                     0
                  );
            } catch (Exception var7) {
            }
         }
      }
   }

   private static class CoveredHoleInfo {
      public final BlockPos coverPos;
      public final Box holeBox;

      public CoveredHoleInfo(BlockPos coverPos, Box holeBox) {
         this.coverPos = coverPos;
         this.holeBox = holeBox;
      }
   }

   private class HoleCheckTask implements Callable<Entry<Box, CoveredHole.CoveredHoleInfo>> {
      private final Box hole;

      public HoleCheckTask(Box hole) {
         this.hole = hole;
      }

      public Entry<Box, CoveredHole.CoveredHoleInfo> call() {
         try {
            if (CoveredHole.this.mc.world == null) {
               return null;
            } else {
               BlockPos topPos = new BlockPos((int)this.hole.minX, (int)this.hole.maxY, (int)this.hole.minZ);
               if (this.isSolidBlockCached(topPos)) {
                  boolean isPlayerCovered = !(Boolean)CoveredHole.this.onlyPlayerCovered.get() || this.isLikelyPlayerCovered(topPos, this.hole);
                  if (isPlayerCovered) {
                     return new SimpleEntry<>(this.hole, new CoveredHole.CoveredHoleInfo(topPos, this.hole));
                  }
               }

               return null;
            }
         } catch (Exception var3) {
            return null;
         }
      }

      private boolean isLikelyPlayerCovered(BlockPos coverPos, Box hole) {
         try {
            BlockState coverBlock = this.getBlockStateCached(coverPos);
            if (coverBlock == null) {
               return false;
            } else if (this.isCommonBuildingBlock(coverBlock)) {
               return true;
            } else {
               int matchingBlocks = 0;
               BlockPos[] checkPositions = new BlockPos[]{
                  coverPos.north(), coverPos.south(), coverPos.east(), coverPos.west()
               };

               for (BlockPos pos : checkPositions) {
                  BlockState state = this.getBlockStateCached(pos);
                  if (state != null && state.getBlock() == coverBlock.getBlock()) {
                     matchingBlocks++;
                  }
               }

               return matchingBlocks < 2;
            }
         } catch (Exception var11) {
            return false;
         }
      }

      private boolean isCommonBuildingBlock(BlockState state) {
         if (state == null) {
            return false;
         } else {
            String blockName = state.getBlock().getTranslationKey().toLowerCase();
            return blockName.contains("cobblestone")
               || blockName.contains("stone_brick")
               || blockName.contains("plank")
               || blockName.contains("log")
               || blockName.contains("wool")
               || blockName.contains("concrete")
               || blockName.contains("terracotta")
               || blockName.contains("glass");
         }
      }

      private boolean isSolidBlockCached(BlockPos pos) {
         return CoveredHole.this.mc.world == null ? false : CoveredHole.this.solidBlockCache.computeIfAbsent(pos, p -> {
            try {
               BlockState state = CoveredHole.this.mc.world.getBlockState(p);
               return state != null && state.isSolidBlock(CoveredHole.this.mc.world, p);
            } catch (Exception var3) {
               return false;
            }
         });
      }

      private BlockState getBlockStateCached(BlockPos pos) {
         return CoveredHole.this.mc.world == null ? null : CoveredHole.this.blockStateCache.computeIfAbsent(pos, p -> {
            try {
               return CoveredHole.this.mc.world.getBlockState(p);
            } catch (Exception var3) {
               return null;
            }
         });
      }
   }
}
