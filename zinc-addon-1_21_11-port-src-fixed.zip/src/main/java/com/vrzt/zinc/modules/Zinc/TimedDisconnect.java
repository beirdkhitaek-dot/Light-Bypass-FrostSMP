package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.text.Text;

public class TimedDisconnect extends Module {
   private int timer;

   public TimedDisconnect() {
      super(ZincAddon.Zinc, "timed-disconnect", "Disconnects you every 3 minutes.");
   }

   public void onActivate() {
      this.timer = 0;
      AutoReconnect autoReconnect = (AutoReconnect)Modules.get().get(AutoReconnect.class);
      if (autoReconnect != null && !autoReconnect.isActive()) {
         autoReconnect.toggle();
         this.info("Auto Reconnect has been enabled.", new Object[0]);
      }
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.timer++;
         if (this.timer >= 3600) {
            this.timer = 0;
            this.mc.player.networkHandler.getConnection().disconnect(Text.literal("Timed Disconnect (3 Minute Cycle)"));
         }
      }
   }
}
