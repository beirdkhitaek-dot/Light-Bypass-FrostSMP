package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class JumpESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> selfOnly = this.sgGeneral.add(((Builder)((Builder)new Builder().name("self-only")).defaultValue(true)).build());
   private final Setting<Double> maxScale = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder().name("max-scale"))
            .defaultValue(2.5)
            .min(0.5)
            .sliderMax(10.0)
            .build()
      );
   private final Setting<Double> thickness = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder().name("thickness"))
            .defaultValue(0.1)
            .min(0.01)
            .sliderMax(1.0)
            .build()
      );
   private final Setting<Integer> duration = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("duration"))
               .defaultValue(1000))
            .min(100)
            .sliderMax(5000)
            .build()
      );
   private final Setting<SettingColor> color = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("color"))
            .defaultValue(new SettingColor(255, 255, 255, 200))
            .build()
      );
   private final List<JumpESP.JumpAnimation> animations = new ArrayList<>();
   private final Map<UUID, Boolean> playerGroundStates = new HashMap<>();

   public JumpESP() {
      super(ZincAddon.Render, "jump-esp", "Improved expanding rings for everyone.");
   }

   public void onActivate() {
      this.animations.clear();
      this.playerGroundStates.clear();
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.world != null) {
         for (PlayerEntity player : this.mc.world.getPlayers()) {
            if (!(Boolean)this.selfOnly.get() || player == this.mc.player) {
               UUID uuid = player.getUuid();
               boolean isOnGround = player.isOnGround();
               if (!this.playerGroundStates.containsKey(uuid)) {
                  this.playerGroundStates.put(uuid, isOnGround);
               } else {
                  boolean wasOnGround = this.playerGroundStates.get(uuid);
                  if (wasOnGround && !isOnGround && player.getVelocity().y > 0.0) {
                     this.createAnimation(player.getEntityPos());
                  }

                  this.playerGroundStates.put(uuid, isOnGround);
               }
            }
         }
      }
   }

   private void createAnimation(Vec3d pos) {
      this.animations.add(new JumpESP.JumpAnimation(pos, System.currentTimeMillis()));
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      long now = System.currentTimeMillis();
      this.animations.removeIf(animx -> now - animx.startTime > ((Integer)this.duration.get()).intValue());

      for (JumpESP.JumpAnimation anim : this.animations) {
         long age = now - anim.startTime;
         double progress = (double)age / ((Integer)this.duration.get()).intValue();
         double currentRadius = progress * (Double)this.maxScale.get();
         int alpha = (int)((1.0 - progress) * ((SettingColor)this.color.get()).a);
         if (alpha > 0) {
            SettingColor renderColor = new SettingColor(
               ((SettingColor)this.color.get()).r, ((SettingColor)this.color.get()).g, ((SettingColor)this.color.get()).b, alpha
            );
            this.renderRing(event, anim.pos, currentRadius, renderColor);
         }
      }
   }

   private void renderRing(Render3DEvent event, Vec3d pos, double radius, SettingColor color) {
      int segments = 64;
      double t = (Double)this.thickness.get();

      for (int i = 0; i < segments; i++) {
         double angle1 = Math.toRadians(i * 360.0 / segments);
         double angle2 = Math.toRadians((i + 1) * 360.0 / segments);
         double x1 = pos.x + Math.cos(angle1) * (radius + t);
         double z1 = pos.z + Math.sin(angle1) * (radius + t);
         double x2 = pos.x + Math.cos(angle2) * (radius + t);
         double z2 = pos.z + Math.sin(angle2) * (radius + t);
         double ix1 = pos.x + Math.cos(angle1) * radius;
         double iz1 = pos.z + Math.sin(angle1) * radius;
         double ix2 = pos.x + Math.cos(angle2) * radius;
         double iz2 = pos.z + Math.sin(angle2) * radius;
         event.renderer
            .quad(x1, pos.y + 0.02, z1, ix1, pos.y + 0.02, iz1, ix2, pos.y + 0.02, iz2, x2, pos.y + 0.02, z2, color);
      }
   }

   private static class JumpAnimation {
      public final Vec3d pos;
      public final long startTime;

      public JumpAnimation(Vec3d pos, long startTime) {
         this.pos = pos;
         this.startTime = startTime;
      }
   }
}
