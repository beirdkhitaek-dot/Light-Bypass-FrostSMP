package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class SkeletonESP extends Module {
   private final SettingGroup sgGeneral = this.settings.createGroup("General");
   private final SettingGroup sgColors = this.settings.createGroup("Colors");
   private final Setting<Double> verticalOffset = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("vertical-offset")).description("Fixed vertical offset for skeleton placement."))
            .defaultValue(1.35)
            .min(1.0)
            .max(1.6)
            .sliderRange(1.0, 1.6)
            .build()
      );
   private final Setting<Double> horizontalOffset = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("horizontal-offset")).description("Horizontal width of shoulders/arms."))
            .defaultValue(0.25)
            .min(0.0)
            .max(0.5)
            .sliderRange(0.0, 0.5)
            .build()
      );
   private final Setting<Boolean> useVisibilityColors = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("visibility-colors"))
                  .description("Green if visible, Red if occluded."))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> visibleColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("visible-color"))
                  .description("Color when the player is visible."))
               .defaultValue(new SettingColor(0, 255, 0, 255))
               .visible(this.useVisibilityColors::get))
            .build()
      );
   private final Setting<SettingColor> occludedColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("occluded-color"))
                  .description("Color when the player is hidden."))
               .defaultValue(new SettingColor(255, 0, 0, 255))
               .visible(this.useVisibilityColors::get))
            .build()
      );
   private final Setting<SettingColor> defaultColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("default-color"))
                  .description("Default color of the skeleton."))
               .defaultValue(new SettingColor(255, 255, 255, 255))
               .visible(() -> !(Boolean)this.useVisibilityColors.get()))
            .build()
      );

   public SkeletonESP() {
      super(ZincAddon.Render, "skeleton-esp", "Renders static player skeletons with visibility check.");
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         for (AbstractClientPlayerEntity player : this.mc.world.getPlayers()) {
            if ((this.mc.options.getPerspective() != Perspective.field_26664 || player != this.mc.player) && player.isAlive()) {
               Vec3d basePos = player.getLerpedPos(event.tickDelta);
               Color skeletonColor;
               if ((Boolean)this.useVisibilityColors.get()) {
                  boolean canSee = this.mc.player.canSee(player);
                  skeletonColor = canSee ? new Color((Color)this.visibleColor.get()) : new Color((Color)this.occludedColor.get());
               } else {
                  skeletonColor = new Color((Color)this.defaultColor.get());
               }

               double yawRad = Math.toRadians(-player.bodyYaw);
               Vec3d chestBase = this.calculateChestBase(basePos, player);
               Vec3d leftShoulder = chestBase.add(new Vec3d(-(Double)this.horizontalOffset.get(), 0.0, 0.0).rotateY((float)yawRad));
               Vec3d rightShoulder = chestBase.add(new Vec3d((Double)this.horizontalOffset.get(), 0.0, 0.0).rotateY((float)yawRad));
               Vec3d leftArmEnd = leftShoulder.add(new Vec3d(0.0, -0.6, 0.0).rotateY((float)yawRad));
               Vec3d rightArmEnd = rightShoulder.add(new Vec3d(0.0, -0.6, 0.0).rotateY((float)yawRad));
               Vec3d spineStart = this.calculateHipPosition(basePos, player);
               double hipWidth = (Double)this.horizontalOffset.get() * 0.6;
               Vec3d leftHip = spineStart.add(new Vec3d(-hipWidth, 0.0, 0.0).rotateY((float)yawRad));
               Vec3d rightHip = spineStart.add(new Vec3d(hipWidth, 0.0, 0.0).rotateY((float)yawRad));
               Vec3d leftFoot = leftHip.add(new Vec3d(0.0, -0.7, 0.0).rotateY((float)yawRad));
               Vec3d rightFoot = rightHip.add(new Vec3d(0.0, -0.7, 0.0).rotateY((float)yawRad));
               event.renderer
                  .line(
                     spineStart.x,
                     spineStart.y,
                     spineStart.z,
                     chestBase.x,
                     chestBase.y,
                     chestBase.z,
                     skeletonColor
                  );
               event.renderer
                  .line(
                     leftShoulder.x,
                     leftShoulder.y,
                     leftShoulder.z,
                     rightShoulder.x,
                     rightShoulder.y,
                     rightShoulder.z,
                     skeletonColor
                  );
               event.renderer
                  .line(
                     leftShoulder.x,
                     leftShoulder.y,
                     leftShoulder.z,
                     leftArmEnd.x,
                     leftArmEnd.y,
                     leftArmEnd.z,
                     skeletonColor
                  );
               event.renderer
                  .line(
                     rightShoulder.x,
                     rightShoulder.y,
                     rightShoulder.z,
                     rightArmEnd.x,
                     rightArmEnd.y,
                     rightArmEnd.z,
                     skeletonColor
                  );
               event.renderer
                  .line(
                     leftHip.x, leftHip.y, leftHip.z, rightHip.x, rightHip.y, rightHip.z, skeletonColor
                  );
               event.renderer
                  .line(
                     leftHip.x, leftHip.y, leftHip.z, leftFoot.x, leftFoot.y, leftFoot.z, skeletonColor
                  );
               event.renderer
                  .line(
                     rightHip.x,
                     rightHip.y,
                     rightHip.z,
                     rightFoot.x,
                     rightFoot.y,
                     rightFoot.z,
                     skeletonColor
                  );
            }
         }
      }
   }

   private Vec3d calculateChestBase(Vec3d basePos, AbstractClientPlayerEntity player) {
      double yOffset = (Double)this.verticalOffset.get();
      if (player.isSneaking()) {
         yOffset -= 0.2;
      }

      return basePos.add(0.0, yOffset, 0.0);
   }

   private Vec3d calculateHipPosition(Vec3d basePos, AbstractClientPlayerEntity player) {
      double yOffset = 0.7;
      if (player.isSneaking()) {
         yOffset -= 0.2;
      }

      return basePos.add(0.0, yOffset, 0.0);
   }
}
