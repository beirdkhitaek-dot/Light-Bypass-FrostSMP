package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;

public class PlayerRadar extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> xOffset = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("x-offset")).defaultValue(135)).min(0).sliderMax(1920).build());
   private final Setting<Integer> yOffset = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("y-offset")).defaultValue(135)).min(0).sliderMax(1080).build());
   private final Setting<Double> scale = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
               .name("radar-radius"))
            .defaultValue(100.0)
            .min(10.0)
            .sliderMax(500.0)
            .build()
      );
   private final Setting<Double> range = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
               .name("tracking-range"))
            .defaultValue(100.0)
            .min(10.0)
            .sliderMax(500.0)
            .build()
      );
   private final Setting<SettingColor> bgColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
               .name("background-color"))
            .defaultValue(new SettingColor(20, 20, 20, 150))
            .build()
      );
   private final Setting<SettingColor> outlineColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
               .name("outline-color"))
            .defaultValue(new SettingColor(255, 255, 255, 255))
            .build()
      );
   private final Setting<SettingColor> selfColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("self-color"))
            .defaultValue(new SettingColor(0, 255, 255, 255))
            .build()
      );
   private final Setting<Integer> headSize = this.sgGeneral.add(((Builder)((Builder)new Builder().name("head-size")).defaultValue(8)).min(4).max(32).build());

   public PlayerRadar() {
      super(ZincAddon.Render, "player-radar", "Rotating radar with a triangle indicator for self.");
   }

   @EventHandler
   private void onRender2D(Render2DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         double centerX = ((Integer)this.xOffset.get()).intValue();
         double centerY = ((Integer)this.yOffset.get()).intValue();
         double radius = (Double)this.scale.get();
         float yaw = this.mc.player.getYaw();
         Renderer2D.COLOR.begin();
         this.drawFilledCircle(centerX, centerY, radius, (Color)this.bgColor.get());
         this.drawRotatingGrid(centerX, centerY, radius, yaw, (Color)this.outlineColor.get());
         this.drawCircleOutline(centerX, centerY, radius, (Color)this.outlineColor.get());
         Renderer2D.COLOR.render();

         for (PlayerEntity player : this.mc.world.getPlayers()) {
            if (player != this.mc.player && !player.isInvisible()) {
               this.renderOnRadar(event.drawContext, player, centerX, centerY, radius, yaw);
            }
         }

         Renderer2D.COLOR.begin();
         this.drawSelfTriangle(centerX, centerY, (Color)this.selfColor.get());
         Renderer2D.COLOR.render();
      }
   }

   private void renderOnRadar(DrawContext context, PlayerEntity player, double centerX, double centerY, double radius, float playerYaw) {
      double diffX = player.getX() - this.mc.player.getX();
      double diffZ = player.getZ() - this.mc.player.getZ();
      double distance = Math.sqrt(diffX * diffX + diffZ * diffZ);
      if (!(distance > (Double)this.range.get())) {
         double angle = Math.atan2(diffZ, diffX) - Math.toRadians(playerYaw + 90.0F);
         double drawDistance = distance / (Double)this.range.get() * radius;
         int x = (int)(centerX + Math.cos(angle) * drawDistance);
         int y = (int)(centerY + Math.sin(angle) * drawDistance);
         this.renderPlayerHead(context, player, x, y);
      }
   }

   private void drawSelfTriangle(double x, double y, Color color) {
      double size = ((Integer)this.headSize.get()).intValue() / 1.5;
      Renderer2D.COLOR.triangle(x, y - size, x - size, y + size, x + size, y + size, color);
   }

   private void drawRotatingGrid(double x, double y, double r, float yaw, Color color) {
      Color faded = new Color(color.r, color.g, color.b, 40);
      double angle = Math.toRadians(yaw + 90.0F);
      double cos = Math.cos(angle) * r;
      double sin = Math.sin(angle) * r;
      Renderer2D.COLOR.line(x - cos, y - sin, x + cos, y + sin, faded);
      Renderer2D.COLOR.line(x + sin, y - cos, x - sin, y + cos, faded);
   }

   private void renderPlayerHead(DrawContext context, PlayerEntity player, int x, int y) {
      int size = (Integer)this.headSize.get();
      int halfSize = size / 2;
      PlayerSkinDrawer.draw(context, (player instanceof net.minecraft.client.network.AbstractClientPlayerEntity acp ? acp.getSkin() : net.minecraft.client.util.DefaultSkinHelper.getSkinTextures(player.getGameProfile())), x - halfSize, y - halfSize, size);
   }

   private void drawFilledCircle(double x, double y, double r, Color color) {
      for (int i = 0; i < 360; i += 10) {
         double rad1 = Math.toRadians(i);
         double rad2 = Math.toRadians(i + 10);
         Renderer2D.COLOR.triangle(x, y, x + Math.cos(rad1) * r, y + Math.sin(rad1) * r, x + Math.cos(rad2) * r, y + Math.sin(rad2) * r, color);
      }
   }

   private void drawCircleOutline(double x, double y, double r, Color color) {
      for (int i = 0; i < 360; i += 5) {
         double rad1 = Math.toRadians(i);
         double rad2 = Math.toRadians(i + 5);
         Renderer2D.COLOR.line(x + Math.cos(rad1) * r, y + Math.sin(rad1) * r, x + Math.cos(rad2) * r, y + Math.sin(rad2) * r, color);
      }
   }
}
