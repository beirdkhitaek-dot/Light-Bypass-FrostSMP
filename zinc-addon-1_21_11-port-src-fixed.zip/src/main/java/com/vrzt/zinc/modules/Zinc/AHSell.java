package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.VersionUtil;
import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AHSell extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<String> sellPrice = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("sell-price")).description("The price to list each hotbar item for. Supports K/M/B."))
               .defaultValue("30k"))
            .build()
      );
   private final Setting<Integer> confirmDelay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("confirm-delay"))
                  .description("Delay in ticks before clicking the confirm button."))
               .defaultValue(10))
            .min(0)
            .max(100)
            .sliderMax(20)
            .build()
      );
   private final Setting<Boolean> notifications = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("notifications"))
                  .description("Show chat notifications."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> enableFilter = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("enable-item-filter"))
                  .description("Only sell selected item type from the hotbar."))
               .defaultValue(false))
            .build()
      );
   private final Setting<Item> filterItem = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ItemSetting.Builder)((meteordevelopment.meteorclient.settings.ItemSetting.Builder)((meteordevelopment.meteorclient.settings.ItemSetting.Builder)new meteordevelopment.meteorclient.settings.ItemSetting.Builder()
                     .name("filter-item"))
                  .description("Only this item will be sold when filter is enabled."))
               .defaultValue(Items.field_8477))
            .build()
      );
   private int delayCounter = 0;
   private boolean awaitingConfirmation = false;
   private int currentSlot = 0;

   public AHSell() {
      super(ZincAddon.Zinc, "ah-sell", "Automatically sells all hotbar items using /ah sell.");
   }

   public void onActivate() {
      if (!this.isValidPrice((String)this.sellPrice.get())) {
         if ((Boolean)this.notifications.get()) {
            this.error("Invalid price format: " + (String)this.sellPrice.get(), new Object[0]);
         }

         this.toggle();
      } else if (!this.hasSellableItemsInHotbar()) {
         if ((Boolean)this.notifications.get()) {
            this.error("No sellable items found in hotbar.", new Object[0]);
         }

         this.toggle();
      } else {
         this.currentSlot = 0;
         this.attemptSellCurrentSlot();
      }
   }

   public void onDeactivate() {
      this.awaitingConfirmation = false;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.awaitingConfirmation && this.mc.player != null) {
         if (this.delayCounter > 0) {
            this.delayCounter--;
         } else {
            if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler handler && handler.getRows() == 3) {
               ItemStack confirmButton = handler.getSlot(15).getStack();
               if (!confirmButton.isEmpty()) {
                  this.mc.interactionManager.clickSlot(handler.syncId, 15, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  if ((Boolean)this.notifications.get()) {
                     this.info("Sold item in hotbar slot " + this.currentSlot + ".", new Object[0]);
                  }
               }

               this.awaitingConfirmation = false;
               this.moveToNextSlot();
            }
         }
      }
   }

   @EventHandler
   private void onChatMessage(ReceiveMessageEvent event) {
      String msg = event.getMessage().getString();
      if (msg.contains("You have too many listed items.")) {
         if ((Boolean)this.notifications.get()) {
            this.warning("Sell limit reached! Disabling module.", new Object[0]);
         }

         this.toggle();
      }
   }

   private void attemptSellCurrentSlot() {
      if (this.currentSlot > 8) {
         if ((Boolean)this.notifications.get()) {
            this.info("Finished processing hotbar. Disabling module.", new Object[0]);
         }

         this.toggle();
      } else {
         VersionUtil.setSelectedSlot(this.mc.player, this.currentSlot);
         ItemStack stack = this.mc.player.getInventory().getStack(this.currentSlot);
         if (!(Boolean)this.enableFilter.get() || !stack.isEmpty() && stack.isOf((Item)this.filterItem.get())) {
            if (stack.isEmpty()) {
               this.moveToNextSlot();
            } else {
               String price = ((String)this.sellPrice.get()).trim();
               double parsedPrice = this.parsePrice(price);
               if (parsedPrice <= 0.0) {
                  if ((Boolean)this.notifications.get()) {
                     this.error("Invalid price format: " + price, new Object[0]);
                  }

                  this.toggle();
               } else {
                  if ((Boolean)this.notifications.get()) {
                     this.info("Sending /ah sell %s for slot %d", new Object[]{this.formatPrice(parsedPrice), this.currentSlot});
                  }

                  this.mc.getNetworkHandler().sendChatCommand("ah sell " + price);
                  this.delayCounter = (Integer)this.confirmDelay.get();
                  this.awaitingConfirmation = true;
               }
            }
         } else {
            if ((Boolean)this.notifications.get()) {
               this.info("Skipping slot " + this.currentSlot + " (does not match filter).", new Object[0]);
            }

            this.moveToNextSlot();
         }
      }
   }

   private void moveToNextSlot() {
      this.currentSlot++;
      this.attemptSellCurrentSlot();
   }

   private boolean hasSellableItemsInHotbar() {
      for (int slot = 0; slot <= 8; slot++) {
         ItemStack stack = this.mc.player.getInventory().getStack(slot);
         if (!stack.isEmpty()) {
            if (!(Boolean)this.enableFilter.get()) {
               return true;
            }

            if (stack.isOf((Item)this.filterItem.get())) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean isValidPrice(String priceStr) {
      return this.parsePrice(priceStr) > 0.0;
   }

   private double parsePrice(String priceStr) {
      if (priceStr != null && !priceStr.isEmpty()) {
         String cleaned = priceStr.trim().toUpperCase();
         double multiplier = 1.0;
         if (cleaned.endsWith("B")) {
            multiplier = 1.0E9;
            cleaned = cleaned.substring(0, cleaned.length() - 1);
         } else if (cleaned.endsWith("M")) {
            multiplier = 1000000.0;
            cleaned = cleaned.substring(0, cleaned.length() - 1);
         } else if (cleaned.endsWith("K")) {
            multiplier = 1000.0;
            cleaned = cleaned.substring(0, cleaned.length() - 1);
         }

         try {
            return Double.parseDouble(cleaned) * multiplier;
         } catch (NumberFormatException var6) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   private String formatPrice(double price) {
      if (price >= 1.0E9) {
         return String.format("%.2fB", price / 1.0E9);
      } else if (price >= 1000000.0) {
         return String.format("%.2fM", price / 1000000.0);
      } else {
         return price >= 1000.0 ? String.format("%.2fK", price / 1000.0) : String.format("%.2f", price);
      }
   }
}
