package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class ChestAndShulkerStealer extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private int tickCounter = 0;
   private int currentSlotIndex = 0;

   public ChestAndShulkerStealer() {
      super(ZincAddon.pvp, "chest-and-shulker-stealer", "Automatic simulated stealer.");
   }

   public void onActivate() {
      this.currentSlotIndex = 0;
      this.tickCounter = 0;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.interactionManager != null && this.mc.currentScreen instanceof HandledScreen<?> screen) {
         int containerSize = this.getContainerSize();
         if (containerSize > 0) {
            if (this.tickCounter > 0) {
               this.tickCounter--;
            } else {
               while (this.currentSlotIndex < containerSize) {
                  Slot slot = screen.getScreenHandler().getSlot(this.currentSlotIndex);
                  if (slot != null && !slot.getStack().isEmpty()) {
                     this.simulateMouseMovement(screen, slot);
                     this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, slot.id, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                     this.tickCounter = ThreadLocalRandom.current().nextInt(1, 4);
                     this.currentSlotIndex++;
                     return;
                  }

                  this.currentSlotIndex++;
               }

               if (this.currentSlotIndex >= containerSize) {
                  this.currentSlotIndex = 0;
               }
            }
         }
      }
   }

   private void simulateMouseMovement(HandledScreen<?> screen, Slot slot) {
      int x = (screen.width - 176) / 2;
      int y = (screen.height - 166) / 2;
      double mouseX = x + slot.x + 8;
      double mouseY = y + slot.y + 8;
      screen.mouseMoved(mouseX, mouseY);
   }

   private int getContainerSize() {
      if (this.mc.player != null && this.mc.player.currentScreenHandler != null) {
         if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler handler) {
            return handler.getInventory().size();
         } else {
            return this.mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler ? 27 : 0;
         }
      } else {
         return 0;
      }
   }
}
