package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import java.util.UUID;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public class TargetESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Double> lerpSpeed = this.sgGeneral.add(((Builder)new Builder().name("follow-speed")).defaultValue(0.15).sliderMax(1.0).build());
   private final Setting<Double> width = this.sgGeneral.add(((Builder)new Builder().name("width")).defaultValue(0.4).sliderMax(1.0).build());
   private final Setting<Double> height = this.sgGeneral.add(((Builder)new Builder().name("height")).defaultValue(0.6).sliderMax(2.0).build());
   private final Setting<SettingColor> color = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("color"))
            .defaultValue(new SettingColor(255, 255, 255, 255))
            .build()
      );
   private final Setting<SettingColor> sideColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder().name("side-color"))
            .defaultValue(new SettingColor(255, 255, 255, 50))
            .build()
      );
   private UUID targetID;
   private Vec3d renderPos = new Vec3d(0.0, 0.0, 0.0);
   private long lastHitTime;
   private final long FADE_MS = 5000L;

   public TargetESP() {
      super(ZincAddon.Render, "target-esp", "A clean ESP that fades out after 5 seconds of inactivity.");
   }

   @EventHandler
   private void onAttack(AttackEntityEvent e) {
      if (e.entity instanceof PlayerEntity) {
         this.targetID = e.entity.getUuid();
         this.lastHitTime = System.currentTimeMillis();
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.targetID != null) {
         long timePassed = System.currentTimeMillis() - this.lastHitTime;
         if (timePassed >= 5000L) {
            this.targetID = null;
         } else {
            double fadeAlpha = 1.0 - timePassed / 5000.0;
            PlayerEntity target = null;

            for (PlayerEntity p : this.mc.world.getPlayers()) {
               if (p.getUuid().equals(this.targetID)) {
                  target = p;
                  break;
               }
            }

            if (target != null && !target.isRemoved()) {
               double tx = MathHelper.lerp(event.tickDelta, target.lastRenderX, target.getX());
               double ty = MathHelper.lerp(event.tickDelta, target.lastRenderY, target.getY()) + target.getHeight() * 0.5;
               double tz = MathHelper.lerp(event.tickDelta, target.lastRenderZ, target.getZ());
               this.renderPos = new Vec3d(
                  MathHelper.lerp((Double)this.lerpSpeed.get(), this.renderPos.x, tx),
                  MathHelper.lerp((Double)this.lerpSpeed.get(), this.renderPos.y, ty),
                  MathHelper.lerp((Double)this.lerpSpeed.get(), this.renderPos.z, tz)
               );
            }

            this.drawCleanESP(event, this.renderPos, fadeAlpha);
         }
      }
   }

   private void drawCleanESP(Render3DEvent event, Vec3d pos, double alphaMult) {
      double w = (Double)this.width.get() / 2.0;
      double h = (Double)this.height.get() / 2.0;
      Color cMain = new Color(
         ((SettingColor)this.color.get()).r,
         ((SettingColor)this.color.get()).g,
         ((SettingColor)this.color.get()).b,
         (int)(((SettingColor)this.color.get()).a * alphaMult)
      );
      Color cSide = new Color(
         ((SettingColor)this.sideColor.get()).r,
         ((SettingColor)this.sideColor.get()).g,
         ((SettingColor)this.sideColor.get()).b,
         (int)(((SettingColor)this.sideColor.get()).a * alphaMult)
      );
      event.renderer
         .box(
            pos.x - w,
            pos.y - h,
            pos.z - w,
            pos.x + w,
            pos.y + h,
            pos.z + w,
            cSide,
            cMain,
            ShapeMode.Both,
            0
         );
      event.renderer.line(pos.x - w, pos.y - h, pos.z - w, pos.x - w, pos.y + h, pos.z - w, cMain);
      event.renderer.line(pos.x + w, pos.y - h, pos.z + w, pos.x + w, pos.y + h, pos.z + w, cMain);
      event.renderer.line(pos.x - w, pos.y - h, pos.z + w, pos.x - w, pos.y + h, pos.z + w, cMain);
      event.renderer.line(pos.x + w, pos.y - h, pos.z - w, pos.x + w, pos.y + h, pos.z - w, cMain);
   }
}
