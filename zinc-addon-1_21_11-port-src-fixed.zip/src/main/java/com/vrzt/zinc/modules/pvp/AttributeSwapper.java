package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;

public class AttributeSwapper extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> targetSlot = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("target-slot")).defaultValue(3)).min(1).max(9).build());
   private final Setting<Integer> returnSlot = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("return-slot")).defaultValue(1)).min(1).max(9).build());
   public int timer = 0;

   public AttributeSwapper() {
      super(ZincAddon.pvp, "attribute-swapper", "Yields to StunMace. Auto-disables over 2 blocks high.");
   }

   public void onActivate() {
      this.forceReset();
   }

   public void onDeactivate() {
      this.forceReset();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null) {
         if (this.timer > 0) {
            this.timer--;
            if (this.timer == 0) {
               this.executeInstantHardwareSwap((Integer)this.returnSlot.get() - 1);
            }
         }
      }
   }

   public void forceReset() {
      this.timer = 0;
      this.releaseHotbarKeys();
   }

   private void handleSwapLogic() {
      int targetIdx = (Integer)this.targetSlot.get() - 1;
      if (this.mc.player.getInventory().getSelectedSlot() != targetIdx) {
         this.executeInstantHardwareSwap(targetIdx);
         this.timer = 2;
      }
   }

   private boolean isTargetBlocking() {
      return !(this.mc.targetedEntity instanceof PlayerEntity target) ? false : !Friends.get().isFriend(target) && target.isBlocking();
   }

   private void executeInstantHardwareSwap(int target) {
      if (this.mc.player != null && target >= 0 && target <= 8) {
         int current = this.mc.player.getInventory().getSelectedSlot();
         if (current != target) {
            this.releaseHotbarKeys();
            IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
            long window = this.mc.getWindow().getHandle();
            double dir = target > current ? -1.0 : 1.0;
            if (Math.abs(target - current) > 4) {
               dir *= -1.0;
            }

            this.mc.options.hotbarKeys[target].setPressed(true);
            mouse.invokeOnMouseScroll(window, 0.0, dir);
            this.mc.player.getInventory().setSelectedSlot(target);
         }
      }
   }

   public void releaseHotbarKeys() {
      for (int i = 0; i < 9; i++) {
         this.mc.options.hotbarKeys[i].setPressed(false);
      }
   }
}
