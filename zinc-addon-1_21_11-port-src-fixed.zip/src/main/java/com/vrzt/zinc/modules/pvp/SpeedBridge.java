package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.BlockItem;
import net.minecraft.util.math.BlockPos;

public class SpeedBridge extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> autoPlace = this.sgGeneral.add(((Builder)((Builder)new Builder().name("auto-place")).defaultValue(true)).build());
   private boolean isCrouchingForBridge = false;
   private int placeTimer = 0;

   public SpeedBridge() {
      super(ZincAddon.pvp, "speed-bridge", "Ninja bridge: 70°+ pitch trigger using Zinc mixin invokers.");
   }

   public void onDeactivate() {
      this.releaseKeys();
      this.isCrouchingForBridge = false;
      this.placeTimer = 0;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         boolean isLookingDown = this.mc.player.getPitch() >= 70.0F;
         if (this.mc.player.isOnGround() && isLookingDown) {
            if (!(this.mc.player.getMainHandStack().getItem() instanceof BlockItem)) {
               if (this.isCrouchingForBridge) {
                  this.stopSneaking();
               }
            } else {
               BlockPos pos = BlockPos.ofFloored(
                  this.mc.player.getX(), this.mc.player.getY() - 0.1, this.mc.player.getZ()
               );
               boolean overAir = this.mc.world.getBlockState(pos).isAir();
               if (overAir) {
                  this.mc.options.sneakKey.setPressed(true);
                  this.isCrouchingForBridge = true;
                  if ((Boolean)this.autoPlace.get() && this.placeTimer >= 4) {
                     this.mc.options.useKey.setPressed(true);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.placeTimer = 0;
                  }
               } else if (this.isCrouchingForBridge) {
                  this.stopSneaking();
               }

               if (this.placeTimer == 1) {
                  this.mc.options.useKey.setPressed(false);
               }

               if (this.placeTimer < 4) {
                  this.placeTimer++;
               }
            }
         } else {
            if (this.isCrouchingForBridge) {
               this.stopSneaking();
            }
         }
      }
   }

   private void stopSneaking() {
      if (this.mc.options != null) {
         this.mc.options.sneakKey.setPressed(false);
      }

      this.isCrouchingForBridge = false;
   }

   private void releaseKeys() {
      if (this.mc.options != null) {
         this.mc.options.sneakKey.setPressed(false);
         this.mc.options.useKey.setPressed(false);
      }
   }
}
