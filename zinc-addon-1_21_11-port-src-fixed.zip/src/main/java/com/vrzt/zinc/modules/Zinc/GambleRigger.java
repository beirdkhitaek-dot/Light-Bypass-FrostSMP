package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.KeybindSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeverBlock;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.component.DataComponentTypes;

public class GambleRigger extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Keybind> activateKey = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("activate-key")).defaultValue(Keybind.fromKey(82))).build());
   private final Setting<Item> leftItem = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ItemSetting.Builder)((meteordevelopment.meteorclient.settings.ItemSetting.Builder)((meteordevelopment.meteorclient.settings.ItemSetting.Builder)new meteordevelopment.meteorclient.settings.ItemSetting.Builder()
                     .name("left-item"))
                  .description("The item that represents the 'Left' side."))
               .defaultValue(Items.field_8407))
            .build()
      );
   private final Setting<Item> rightItem = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ItemSetting.Builder)((meteordevelopment.meteorclient.settings.ItemSetting.Builder)((meteordevelopment.meteorclient.settings.ItemSetting.Builder)new meteordevelopment.meteorclient.settings.ItemSetting.Builder()
                     .name("right-item"))
                  .description("The item that represents the 'Right' side."))
               .defaultValue(Items.field_8407))
            .build()
      );
   private final Setting<GambleRigger.Mode> winnerSide = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                  .name("winner-side"))
               .defaultValue(GambleRigger.Mode.Left))
            .build()
      );
   private final Setting<Boolean> disableColors = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("disable-colors"))
               .defaultValue(false))
            .build()
      );
   private final int tieChance = 15;
   private String currentLeftName = "§a7";
   private String currentRightName = "§c2";
   private boolean isRigging = false;
   private boolean keyPressedLastTick = false;

   public GambleRigger() {
      super(ZincAddon.Zinc, "Gamble Rigger", "Rigged items limited to one specific item type per side.");
   }

   public void onActivate() {
      this.isRigging = false;
      this.keyPressedLastTick = false;
      this.resetNumbers();
   }

   public void onDeactivate() {
      this.restoreItems();
      this.isRigging = false;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null) {
         boolean keyCurrentlyPressed = ((Keybind)this.activateKey.get()).isPressed();
         if (keyCurrentlyPressed && !this.keyPressedLastTick) {
            this.isRigging = !this.isRigging;
            if (this.isRigging) {
               this.resetNumbers();
            } else {
               this.restoreItems();
            }
         }

         this.keyPressedLastTick = keyCurrentlyPressed;
         if (this.isRigging) {
            boolean leftRigged = false;
            boolean rightRigged = false;

            for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
               ItemStack stack = this.mc.player.getInventory().getStack(i);
               if (!stack.isEmpty()) {
                  Item item = stack.getItem();
                  boolean isLeftMatch = item == this.leftItem.get();
                  boolean isRightMatch = item == this.rightItem.get();
                  if (isLeftMatch || isRightMatch) {
                     if (isLeftMatch && isRightMatch) {
                        if (!leftRigged) {
                           this.rigStack(stack, this.currentLeftName);
                           leftRigged = true;
                        } else if (!rightRigged) {
                           this.rigStack(stack, this.currentRightName);
                           rightRigged = true;
                        }
                     } else if (isLeftMatch && !leftRigged) {
                        this.rigStack(stack, this.currentLeftName);
                        leftRigged = true;
                     } else if (isRightMatch && !rightRigged) {
                        this.rigStack(stack, this.currentRightName);
                        rightRigged = true;
                     }
                  }
               }
            }
         }
      }
   }

   private void rigStack(ItemStack stack, String name) {
      stack.set(DataComponentTypes.field_50071, 1);
      stack.set(DataComponentTypes.field_49631, Text.literal(name));
   }

   @EventHandler
   private void onPacketReceive(Receive event) {
      if (this.isRigging && this.mc.world != null) {
         if (event.packet instanceof BlockUpdateS2CPacket p
            && this.mc.world.getBlockState(p.getPos()).getBlock() == Blocks.field_10363
            && (Boolean)p.getState().get(LeverBlock.POWERED)) {
            this.resetNumbers();
         }
      }
   }

   private void restoreItems() {
      if (this.mc.player != null) {
         for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
            ItemStack stack = this.mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && (stack.getItem() == this.leftItem.get() || stack.getItem() == this.rightItem.get())) {
               stack.remove(DataComponentTypes.field_49631);
               stack.set(DataComponentTypes.field_50071, stack.getItem().getMaxCount());
            }
         }
      }
   }

   private void resetNumbers() {
      List<Integer> existingInDispenser = new ArrayList<>();
      List<Integer> available = new ArrayList<>();
      if (this.mc.player.currentScreenHandler != null) {
         for (Slot slot : this.mc.player.currentScreenHandler.slots) {
            if (slot.id >= 0 && slot.id <= 8) {
               ItemStack stack = slot.getStack();
               if (!stack.isEmpty()) {
                  try {
                     String name = stack.getName().getString().replaceAll("§.", "");
                     existingInDispenser.add(Integer.parseInt(name.trim()));
                  } catch (Exception var9) {
                  }
               }
            }
         }
      }

      for (int i = 1; i <= 9; i++) {
         if (!existingInDispenser.contains(i)) {
            available.add(i);
         }
      }

      if (available.size() < 2) {
         for (int ix = 1; ix <= 9; ix++) {
            available.add(ix);
         }
      }

      Collections.shuffle(available);
      if (ThreadLocalRandom.current().nextInt(0, 101) <= 15) {
         int tieNum = available.get(0);
         String tieColor = this.disableColors.get() ? "§f" : "§6";
         this.currentLeftName = tieColor + tieNum;
         this.currentRightName = tieColor + tieNum;
      } else {
         int n1 = available.get(0);
         int n2 = available.get(1);
         int winNum = Math.max(n1, n2);
         int loseNum = Math.min(n1, n2);
         String colorW = this.disableColors.get() ? "§f" : "§a";
         String colorL = this.disableColors.get() ? "§f" : "§c";
         if (this.winnerSide.get() == GambleRigger.Mode.Left) {
            this.currentLeftName = colorW + winNum;
            this.currentRightName = colorL + loseNum;
         } else {
            this.currentLeftName = colorL + loseNum;
            this.currentRightName = colorW + winNum;
         }
      }
   }

   public static enum Mode {
      Left,
      Right;

      private Mode() {
      }
   }
}
