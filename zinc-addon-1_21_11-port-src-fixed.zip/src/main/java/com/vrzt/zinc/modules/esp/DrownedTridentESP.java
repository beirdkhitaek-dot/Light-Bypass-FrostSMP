package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.stream.StreamSupport;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.DrownedEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class DrownedTridentESP extends Module {
   private final SettingGroup sgRender = this.settings.createGroup("Rendering");
   private final Setting<SettingColor> color = this.sgRender
      .add(
         ((Builder)((Builder)new Builder().name("color")).description("Color of the ESP box and lines."))
            .defaultValue(new SettingColor(50, 255, 100, 200))
            .build()
      );
   private final Setting<Double> lineWidth = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("line-width"))
               .description("Thickness of the outline lines."))
            .defaultValue(1.5)
            .min(0.5)
            .sliderRange(0.5, 5.0)
            .build()
      );
   private final Setting<DrownedTridentESP.RenderMode> mode = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("mode"))
                  .description("How the ESP should be rendered."))
               .defaultValue(DrownedTridentESP.RenderMode.Both))
            .build()
      );
   private final Setting<Boolean> tracers = this.sgRender
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("tracers"))
                  .description("Draw tracers from the player to Drowned holding tridents."))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> tracerColor = this.sgRender
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("tracer-color")).description("Color of the tracers."))
               .defaultValue(new SettingColor(255, 50, 50, 200))
               .visible(this.tracers::get))
            .build()
      );

   public DrownedTridentESP() {
      super(ZincAddon.esp, "drowned-trident-esp", "Highlights Drowned mobs holding tridents with optional tracers.");
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         Vec3d playerPos = this.mc.player.getLerpedPos(event.tickDelta);
         StreamSupport.<Entity>stream(this.mc.world.getEntities().spliterator(), false)
            .filter(entity -> entity instanceof DrownedEntity)
            .map(entity -> (DrownedEntity)entity)
            .filter(this::isHoldingTrident)
            .forEach(
               drowned -> {
                  Box box = drowned.getBoundingBox();
                  Color fillColor = new Color((Color)this.color.get());
                  Color lineColor = new Color((Color)this.color.get());
                  if (this.mode.get() == DrownedTridentESP.RenderMode.Box || this.mode.get() == DrownedTridentESP.RenderMode.Both) {
                     event.renderer.box(box, fillColor, lineColor, ShapeMode.Sides, 0);
                  }

                  if (this.mode.get() == DrownedTridentESP.RenderMode.Lines || this.mode.get() == DrownedTridentESP.RenderMode.Both) {
                     event.renderer.box(box, fillColor, lineColor, ShapeMode.Lines, 0);
                  }

                  if ((Boolean)this.tracers.get()) {
                     Vec3d entityPos = drowned.getEntityPos().add(0.0, drowned.getHeight() / 2.0, 0.0);
                     Vec3d startPos;
                     if (this.mc.options.getPerspective().isFirstPerson()) {
                        Vec3d lookDir = this.mc.player.getRotationVector();
                        startPos = playerPos.add(0.0, this.mc.player.getEyeHeight(this.mc.player.getPose()), 0.0)
                           .add(lookDir.multiply(0.5));
                     } else {
                        startPos = playerPos.add(0.0, this.mc.player.getEyeHeight(this.mc.player.getPose()), 0.0);
                     }

                     Color tracerCol = new Color((Color)this.tracerColor.get());
                     event.renderer
                        .line(
                           startPos.x,
                           startPos.y,
                           startPos.z,
                           entityPos.x,
                           entityPos.y,
                           entityPos.z,
                           tracerCol
                        );
                  }
               }
            );
      }
   }

   private boolean isHoldingTrident(DrownedEntity drowned) {
      return drowned.getStackInHand(Hand.field_5808).getItem() == Items.field_8547
         || drowned.getStackInHand(Hand.field_5810).getItem() == Items.field_8547;
   }

   public static enum RenderMode {
      Lines,
      Box,
      Both;

      private RenderMode() {
      }
   }
}
