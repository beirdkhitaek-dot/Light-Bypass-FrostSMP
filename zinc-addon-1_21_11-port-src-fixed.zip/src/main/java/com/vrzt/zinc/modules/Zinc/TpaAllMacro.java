package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class TpaAllMacro extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<TpaAllMacro.TpaType> tpaType = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("tpa-type")).description("Command to use.")).defaultValue(TpaAllMacro.TpaType.TPA)).build());
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("delay"))
                  .description("Ticks between command sends."))
               .defaultValue(20))
            .min(20)
            .sliderMax(200)
            .build()
      );
   private final Setting<Boolean> useGui = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("use-gui"))
                  .description("Click the confirmation GUI automatically."))
               .defaultValue(true))
            .build()
      );
   private final Setting<List<String>> blacklist = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)new meteordevelopment.meteorclient.settings.StringListSetting.Builder()
                     .name("blacklist"))
                  .description("Players to skip."))
               .defaultValue(List.of("x", "x", "x")))
            .build()
      );
   private int tickCounter = 0;
   private boolean waitingForConfirm = false;
   private long guiWaitStart = 0L;
   private static final long GUI_TIMEOUT_MS = 5000L;
   private final List<String> onlinePlayers = new ArrayList<>();
   private int currentIndex = 0;

   public TpaAllMacro() {
      super(ZincAddon.Zinc, "TpaAllMacro", "Cycles through all online players and sends /tpa or /tpahere with optional GUI confirmation.");
   }

   public void onActivate() {
      this.tickCounter = 0;
      this.waitingForConfirm = false;
      this.guiWaitStart = 0L;
      this.currentIndex = 0;
      this.onlinePlayers.clear();
      this.info("Starting TPA Macro loop.", new Object[0]);
   }

   public void onDeactivate() {
      this.waitingForConfirm = false;
      this.guiWaitStart = 0L;
      this.info("TPA Macro deactivated.", new Object[0]);
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.interactionManager != null) {
         if (this.onlinePlayers.isEmpty() || this.currentIndex >= this.onlinePlayers.size()) {
            this.onlinePlayers.clear();
            this.mc.player.networkHandler.getPlayerList().forEach(info -> {
               String name = info.getProfile().name();
               if (!Objects.equals(name, this.mc.player.getGameProfile().name()) && !((List)this.blacklist.get()).contains(name)) {
                  this.onlinePlayers.add(name);
               }
            });
            this.currentIndex = 0;
            if (this.onlinePlayers.isEmpty()) {
               this.warning("No valid players online.", new Object[0]);
               return;
            }
         }

         if ((Boolean)this.useGui.get()) {
            if (this.waitingForConfirm && this.mc.currentScreen instanceof HandledScreen) {
               this.clickConfirmButtonIfPresent();
               return;
            }

            if (this.waitingForConfirm && this.guiWaitStart > 0L && System.currentTimeMillis() - this.guiWaitStart > 5000L) {
               ChatUtils.warning("GUI timeout. Retrying...", new Object[0]);
               this.waitingForConfirm = false;
               this.guiWaitStart = 0L;
            }
         }

         if (!this.waitingForConfirm) {
            this.tickCounter++;
            if (this.tickCounter >= (Integer)this.delay.get()) {
               String target = this.onlinePlayers.get(this.currentIndex++);
               String command = (this.tpaType.get() == TpaAllMacro.TpaType.TPA ? "/tpa " : "/tpahere ") + target;
               ChatUtils.sendPlayerMsg(command);
               ChatUtils.info("\ud83d\udce8 Sent: " + command, new Object[0]);
               if ((Boolean)this.useGui.get()) {
                  this.waitingForConfirm = true;
                  this.guiWaitStart = System.currentTimeMillis();
               }

               this.tickCounter = 0;
            }
         }
      }
   }

   private void clickConfirmButtonIfPresent() {
      if (this.mc.currentScreen instanceof HandledScreen<?> screen) {
         ScreenHandler var6 = screen.getScreenHandler();

         for (int i = 0; i < var6.slots.size(); i++) {
            ItemStack stack = var6.getSlot(i).getStack();
            String key = stack.getItem().getTranslationKey().toLowerCase();
            if (key.contains("stained_glass_pane") && key.contains("lime")) {
               this.mc.interactionManager.clickSlot(var6.syncId, i, 0, SlotActionType.PICKUP, this.mc.player);
               ChatUtils.info("\ud83d\udfe2 Confirm button clicked (slot " + i + ").", new Object[0]);
               this.mc.player.closeHandledScreen();
               this.waitingForConfirm = false;
               this.guiWaitStart = 0L;
               return;
            }
         }

         ChatUtils.warning("No confirmation button found in GUI.", new Object[0]);
      }
   }

   public static enum TpaType {
      TPA,
      TPAHERE;

      private TpaType() {
      }
   }
}
