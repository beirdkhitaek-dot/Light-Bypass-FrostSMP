package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.VersionUtil;
import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;

public class AutoTreeFarmer extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgRefill = this.settings.createGroup("Order Refill");
   private final SettingGroup sgAutoFeatures = this.settings.createGroup("Auto Features");
   private final Setting<AutoTreeFarmer.SaplingType> saplingType = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("sapling-type")).description("Type of sapling to farm."))
               .defaultValue(AutoTreeFarmer.SaplingType.SPRUCE))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("chat-feedback"))
                  .description("Send chat messages about module status."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> autoDrop = this.sgAutoFeatures
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("auto-drop"))
                  .description("Automatically drop unwanted items (logs and sticks)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> enableOrderRefill = this.sgRefill
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("enable-order-refill"))
                  .description("Enable automatic refilling from /order system."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> refillAmount = this.sgRefill
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("refill-amount"))
                  .description("Number of stacks to take from orders (max 30)."))
               .defaultValue(1))
            .min(1)
            .max(30)
            .sliderMax(30)
            .build()
      );
   private final Setting<Integer> maxRefillRetries = this.sgRefill
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("max-refill-retries"))
                  .description("Maximum retries for refill operations."))
               .defaultValue(3))
            .min(1)
            .max(10)
            .sliderMax(10)
            .build()
      );
   private static final int PLACE_DELAY = 2;
   private static final int BREAK_DELAY = 2;
   private static final int ACTION_DELAY = 2;
   private static final int RANDOM_DELAY_RANGE = 2;
   private static final double PAUSE_CHANCE = 2.0;
   private static final int MAX_PAUSE_TICKS = 2;
   private static final double ROTATION_NOISE = 1.2;
   private static final double WRONG_LOOK_CHANCE = 12.0;
   private static final boolean ROTATE_ENABLED = true;
   private static final boolean USE_BONE_MEAL = true;
   private static final int REFILL_TRIGGER_AMOUNT = 10;
   private static final int RANGE = 3;
   private static final int MAX_GROWTH_WAIT_TIME = 600;
   private static final int ORDER_DELAY = 500;
   private static final int ORDER_VARIANCE = 300;
   private boolean isSimulatingUse = false;
   private int simulationTickDelay = 0;
   private int tickCounter = 0;
   private int actionDelay = 0;
   private int dropTickCounter = 0;
   private List<BlockPos> farmPositions = new ArrayList<>();
   private int currentFarmIndex = 0;
   private AutoTreeFarmer.FarmState currentState = AutoTreeFarmer.FarmState.ANALYZING_CURRENT_STATE;
   private BlockPos currentWorkingPos = null;
   private boolean shouldBeJumping = false;
   private int rotationStabilizeTicks = 0;
   private BlockPos currentBreakingPos = null;
   private boolean isBreaking = false;
   private AutoTreeFarmer.RefillState refillState = AutoTreeFarmer.RefillState.NONE;
   private long refillStageStart = 0L;
   private Item currentRefillItem = null;
   private int stacksCollected = 0;
   private int refillRetryCount = 0;
   private boolean pauseWhileEating = false;
   private final Random random = new Random();
   private int currentPauseTicks = 0;
   private boolean isPaused = false;
   private List<BlockPos> logBlocks = new ArrayList<>();
   private int consecutiveActions = 0;
   private long lastActionTime = 0L;
   private boolean hasAnalyzedCurrentState = false;
   private int totalLogsInCurrentTree = 0;
   private int logsHarvestedInCurrentTree = 0;
   private float targetYaw = 0.0F;
   private float targetPitch = 0.0F;
   private boolean needsRotation = false;
   private int currentBoneMealIndex = 0;
   private BlockPos[] currentSaplingPositions = null;
   private boolean playerTooFar = false;
   private int cycleCount = 0;
   private int growthWaitTicks = 0;
   private boolean hasSaplingsAtCurrentFarm = false;
   private boolean refillQueued = false;
   private Item queuedRefillItem = null;
   private AutoTreeFarmer.FarmState preRefillState = AutoTreeFarmer.FarmState.ANALYZING_CURRENT_STATE;
   private int preRefillFarmIndex = 0;
   private List<BlockPos> preRefillLogBlocks = new ArrayList<>();
   private int preRefillTotalLogs = 0;
   private int preRefillLogsHarvested = 0;
   private BlockPos preRefillBreakingPos = null;
   private boolean treeDetectedInFront = false;
   private int treeDetectionCooldown = 0;

   public AutoTreeFarmer() {
      super(ZincAddon.Zinc, "auto-tree-farmer", "Automated tree farming module with anti-detection features.");
   }

   public void onActivate() {
      this.resetAllStates();
      this.currentState = AutoTreeFarmer.FarmState.ANALYZING_CURRENT_STATE;
      this.hasAnalyzedCurrentState = false;
      this.playerTooFar = false;
      this.cycleCount = 0;
      this.growthWaitTicks = 0;
      this.hasSaplingsAtCurrentFarm = false;
      this.refillQueued = false;
      this.queuedRefillItem = null;
      this.treeDetectedInFront = false;
      this.treeDetectionCooldown = 0;
      this.sendInfo("AutoTreeFarmer activated. Analyzing current state...");
   }

   public void onDeactivate() {
      this.stopBreaking();
      this.resetJump();
      this.mc.options.useKey.setPressed(false);
      this.mc.options.attackKey.setPressed(false);
      this.mc.options.jumpKey.setPressed(false);
      this.isSimulatingUse = false;
      this.refillState = AutoTreeFarmer.RefillState.NONE;
      this.pauseWhileEating = false;
      this.playerTooFar = false;
      this.sendInfo("AutoTreeFarmer deactivated!");
   }

   private void resetAllStates() {
      this.farmPositions.clear();
      this.currentFarmIndex = 0;
      this.tickCounter = 0;
      this.actionDelay = 0;
      this.dropTickCounter = 0;
      this.shouldBeJumping = false;
      this.rotationStabilizeTicks = 0;
      this.currentBreakingPos = null;
      this.isBreaking = false;
      this.refillState = AutoTreeFarmer.RefillState.NONE;
      this.refillStageStart = 0L;
      this.currentRefillItem = null;
      this.stacksCollected = 0;
      this.refillRetryCount = 0;
      this.pauseWhileEating = false;
      this.currentPauseTicks = 0;
      this.isPaused = false;
      this.logBlocks.clear();
      this.consecutiveActions = 0;
      this.lastActionTime = System.currentTimeMillis();
      this.hasAnalyzedCurrentState = false;
      this.totalLogsInCurrentTree = 0;
      this.logsHarvestedInCurrentTree = 0;
      this.targetYaw = 0.0F;
      this.targetPitch = 0.0F;
      this.needsRotation = false;
      this.currentBoneMealIndex = 0;
      this.currentSaplingPositions = null;
      this.playerTooFar = false;
      this.growthWaitTicks = 0;
      this.hasSaplingsAtCurrentFarm = false;
      this.refillQueued = false;
      this.queuedRefillItem = null;
      this.preRefillLogBlocks.clear();
      this.preRefillBreakingPos = null;
      this.treeDetectedInFront = false;
      this.treeDetectionCooldown = 0;
      this.isSimulatingUse = false;
      this.simulationTickDelay = 0;
   }

   private void sendInfo(String message) {
      if ((Boolean)this.chatFeedback.get()) {
         this.info(message, new Object[0]);
      }
   }

   private void handleKeySimulation() {
      if (this.isSimulatingUse && this.simulationTickDelay > 0) {
         this.simulationTickDelay--;
         if (this.simulationTickDelay <= 0) {
            this.mc.options.useKey.setPressed(false);
            this.mc.options.attackKey.setPressed(false);
            this.isSimulatingUse = false;
         }
      }
   }

   @EventHandler
   private void onTick(Pre event) {
      this.handleKeySimulation();
      if (this.mc.currentScreen != null && this.refillState == AutoTreeFarmer.RefillState.NONE) {
         if (this.isSimulatingUse) {
            this.mc.options.useKey.setPressed(false);
            this.mc.options.attackKey.setPressed(false);
            this.isSimulatingUse = false;
         }
      } else {
         if (!this.farmPositions.isEmpty() && this.refillState == AutoTreeFarmer.RefillState.NONE) {
            BlockPos playerPos = this.mc.player.getBlockPos();
            boolean anyFarmInRange = false;

            for (BlockPos farmPos : this.farmPositions) {
               double distance = Math.sqrt(playerPos.getSquaredDistance(farmPos));
               if (distance <= 5.0) {
                  anyFarmInRange = true;
                  break;
               }
            }

            if (!anyFarmInRange) {
               if (!this.playerTooFar) {
                  this.sendInfo("You moved too far from farm locations. Pausing...");
                  this.playerTooFar = true;
               }

               return;
            }

            if (this.playerTooFar) {
               this.sendInfo("Back in range of farms. Resuming...");
               this.playerTooFar = false;
            }
         }

         if (this.mc.player.isUsingItem()) {
            if (!this.pauseWhileEating) {
               this.pauseWhileEating = true;
               this.sendInfo("Pausing while you eat.");
            }
         } else {
            if (this.pauseWhileEating) {
               this.pauseWhileEating = false;
               this.sendInfo("Resuming after eating.");
            }

            if (this.isPaused) {
               this.currentPauseTicks--;
               if (this.currentPauseTicks > 0) {
                  return;
               }

               this.isPaused = false;
            }

            if (this.isBreaking && this.currentBreakingPos != null) {
               if (this.mc.world.getBlockState(this.currentBreakingPos).isAir()) {
                  if (!this.logBlocks.isEmpty() && this.logBlocks.get(0).equals(this.currentBreakingPos)) {
                     this.logBlocks.remove(0);
                     this.logsHarvestedInCurrentTree++;
                     if (!this.logBlocks.isEmpty()) {
                        BlockPos nextLog = this.logBlocks.get(0);
                        this.lookAtBlock(nextLog, false);
                        this.breakBlock(nextLog);
                     } else {
                        this.stopBreaking();
                     }
                  } else {
                     this.stopBreaking();
                  }
               } else {
                  this.mc.options.attackKey.setPressed(true);
                  this.isSimulatingUse = true;
                  this.simulationTickDelay = 2;
               }
            }

            this.tickCounter++;
            this.dropTickCounter++;
            this.handleAutoFeatures();
            if ((Boolean)this.enableOrderRefill.get() && this.refillState == AutoTreeFarmer.RefillState.NONE) {
               this.checkAndQueueRefill();
            }

            if (this.refillQueued && this.refillState == AutoTreeFarmer.RefillState.NONE) {
               this.savePreRefillState();
               this.startRefill(this.queuedRefillItem);
               this.refillQueued = false;
               this.queuedRefillItem = null;
            }

            if (this.refillState != AutoTreeFarmer.RefillState.NONE) {
               this.handleRefill();
            } else {
               this.autoRefillHotbar(Items.field_8324, 5);
               this.autoRefillHotbar(this.getCurrentSapling(), 4);
               if (this.currentState != AutoTreeFarmer.FarmState.PLACING_SAPLINGS && this.shouldBeJumping) {
                  this.resetJump();
               }

               int currentDelay = this.getRandomizedDelay(2);
               if (this.tickCounter >= currentDelay) {
                  if (this.shouldTakeRandomPause()) {
                     this.startRandomPause();
                     return;
                  }

                  this.tickCounter = 0;
                  if (this.actionDelay > 0) {
                     this.actionDelay--;
                     return;
                  }

                  this.executeFarmingState();
               }

               if (this.needsRotation) {
                  this.applySmoothRotation();
               }
            }
         }
      }
   }

   private void savePreRefillState() {
      this.preRefillState = this.currentState;
      this.preRefillFarmIndex = this.currentFarmIndex;
      this.preRefillLogBlocks.clear();
      this.preRefillLogBlocks.addAll(this.logBlocks);
      this.preRefillTotalLogs = this.totalLogsInCurrentTree;
      this.preRefillLogsHarvested = this.logsHarvestedInCurrentTree;
      this.preRefillBreakingPos = this.currentBreakingPos;
      this.sendInfo("Saved state: " + this.currentState + " with " + this.logBlocks.size() + " logs");
   }

   private void restorePreRefillState() {
      if (this.preRefillState == null) {
         this.currentState = AutoTreeFarmer.FarmState.ANALYZING_CURRENT_STATE;
      } else {
         this.currentState = this.preRefillState;
         this.currentFarmIndex = this.preRefillFarmIndex;
         this.logBlocks.clear();
         this.logBlocks.addAll(this.preRefillLogBlocks);
         this.totalLogsInCurrentTree = this.preRefillTotalLogs;
         this.logsHarvestedInCurrentTree = this.preRefillLogsHarvested;
         if (this.preRefillBreakingPos != null && !this.logBlocks.isEmpty()) {
            this.currentBreakingPos = this.preRefillBreakingPos;
            if (!this.mc.world.getBlockState(this.currentBreakingPos).isAir()
               && this.isCurrentLog(this.mc.world.getBlockState(this.currentBreakingPos).getBlock())) {
               this.isBreaking = true;
               this.mc.options.attackKey.setPressed(true);
               this.isSimulatingUse = true;
               this.simulationTickDelay = 2;
               this.lookAtBlock(this.currentBreakingPos, false);
            } else if (!this.logBlocks.isEmpty()) {
               this.logBlocks.remove(0);
               this.logsHarvestedInCurrentTree++;
               if (!this.logBlocks.isEmpty()) {
                  BlockPos nextLog = this.logBlocks.get(0);
                  this.lookAtBlock(nextLog, false);
                  this.breakBlock(nextLog);
               }
            }
         } else if (!this.logBlocks.isEmpty() && this.currentState == AutoTreeFarmer.FarmState.HARVESTING) {
            BlockPos firstLog = this.logBlocks.get(0);
            this.lookAtBlock(firstLog, false);
            this.breakBlock(firstLog);
         }

         this.preRefillLogBlocks.clear();
         this.preRefillBreakingPos = null;
         if (this.currentState == AutoTreeFarmer.FarmState.HARVESTING && this.logBlocks.isEmpty()) {
            this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
         }

         this.sendInfo("Restored state: " + this.currentState + " with " + this.logBlocks.size() + " logs");
      }
   }

   private void applySmoothRotation() {
      float yawDiff = MathHelper.wrapDegrees(this.targetYaw - this.mc.player.getYaw());
      float pitchDiff = this.targetPitch - this.mc.player.getPitch();
      float step = 8.0F;
      this.mc.player.setYaw(this.mc.player.getYaw() + yawDiff / step);
      this.mc.player.setPitch(MathHelper.clamp(this.mc.player.getPitch() + pitchDiff / step, -90.0F, 90.0F));
      if (Math.abs(yawDiff) < 1.0F && Math.abs(pitchDiff) < 1.0F) {
         this.needsRotation = false;
      }
   }

   private boolean shouldTakeRandomPause() {
      return this.random.nextDouble() * 100.0 < 2.0 && !this.isPaused && this.consecutiveActions > 3;
   }

   private void startRandomPause() {
      this.isPaused = true;
      this.currentPauseTicks = this.random.nextInt(2) + 5;
      this.consecutiveActions = 0;
   }

   private int getRandomizedDelay(int baseDelay) {
      return baseDelay + this.random.nextInt(5) - 2;
   }

   private void executeFarmingState() {
      if (this.farmPositions.isEmpty()
         && this.currentState != AutoTreeFarmer.FarmState.ANALYZING_CURRENT_STATE
         && this.currentState != AutoTreeFarmer.FarmState.FINDING_POSITIONS) {
         this.sendInfo("No farm positions found. Resetting state.");
         this.currentState = AutoTreeFarmer.FarmState.ANALYZING_CURRENT_STATE;
         this.hasAnalyzedCurrentState = false;
      } else {
         switch (this.currentState) {
            case ANALYZING_CURRENT_STATE:
               if (!this.hasAnalyzedCurrentState) {
                  this.analyzeCurrentState();
                  this.hasAnalyzedCurrentState = true;
               }
               break;
            case FINDING_POSITIONS:
               this.findFarmPositions();
               if (!this.farmPositions.isEmpty()) {
                  this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
                  this.sendInfo("Found " + this.farmPositions.size() + " farm positions.");
               }
               break;
            case PLACING_SAPLINGS:
               if (this.placeSaplings()) {
                  this.actionDelay = this.getRandomizedDelay(2);
                  this.currentState = AutoTreeFarmer.FarmState.APPLYING_BONEMEAL;
                  this.currentBoneMealIndex = 0;
                  this.currentSaplingPositions = this.get2x2Positions(this.farmPositions.get(this.currentFarmIndex));
                  this.rotationStabilizeTicks = 0;
                  this.consecutiveActions++;
               }
               break;
            case APPLYING_BONEMEAL:
               if (this.applyBoneMeal()) {
                  this.actionDelay = this.getRandomizedDelay(2);
                  this.currentState = AutoTreeFarmer.FarmState.WAITING_FOR_GROWTH;
                  this.growthWaitTicks = 0;
                  this.hasSaplingsAtCurrentFarm = true;
                  this.consecutiveActions++;
               }
               break;
            case WAITING_FOR_GROWTH:
               this.growthWaitTicks++;
               if (this.checkTreeGrown()) {
                  this.growthWaitTicks = 0;
                  this.hasSaplingsAtCurrentFarm = false;
                  this.scanAndPrepareHarvest();
                  if (this.logBlocks.isEmpty()) {
                     this.sendInfo("Tree detected but no logs found. Moving to next farm.");
                     this.moveToNextFarm();
                     this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
                  } else {
                     this.currentState = AutoTreeFarmer.FarmState.HARVESTING;
                     FindItemResult axe = InvUtils.find(itemStack -> itemStack.getItem() instanceof AxeItem);
                     if (axe.found()) {
                        InvUtils.swap(axe.slot(), false);
                     }

                     if (!this.logBlocks.isEmpty()) {
                        BlockPos firstLog = this.logBlocks.get(0);
                        this.lookAtBlock(firstLog, false);
                        this.breakBlock(firstLog);
                     }
                  }
               } else if (this.growthWaitTicks >= 600) {
                  this.sendInfo("Tree growth timeout reached. Moving to next farm.");
                  this.growthWaitTicks = 0;
                  this.hasSaplingsAtCurrentFarm = false;
                  this.moveToNextFarm();
                  this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
               } else if (this.hasSaplingsAtCurrentFarm && !this.saplingsStillPresent()) {
                  this.sendInfo("Saplings missing. Replanting...");
                  this.growthWaitTicks = 0;
                  this.hasSaplingsAtCurrentFarm = false;
                  this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
               }
               break;
            case HARVESTING:
               if (this.harvestTree()) {
                  this.actionDelay = this.getRandomizedDelay(2);
                  this.moveToNextFarm();
                  this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
                  this.consecutiveActions++;
               } else if (this.isBreaking && this.currentBreakingPos != null) {
                  Block block = this.mc.world.getBlockState(this.currentBreakingPos).getBlock();
                  if (!block.equals(Blocks.field_10124) && this.isCurrentLog(block)) {
                     this.mc.options.attackKey.setPressed(true);
                     this.isSimulatingUse = true;
                     this.simulationTickDelay = 2;
                  }
               }
         }
      }
   }

   private boolean saplingsStillPresent() {
      if (this.currentFarmIndex >= this.farmPositions.size()) {
         return false;
      } else {
         BlockPos farmPos = this.farmPositions.get(this.currentFarmIndex);
         BlockPos[] saplingPositions = this.get2x2Positions(farmPos);
         int saplingCount = 0;

         for (BlockPos pos : saplingPositions) {
            Block block = this.mc.world.getBlockState(pos).getBlock();
            if (block.equals(this.getCurrentSapling())) {
               saplingCount++;
            }
         }

         return saplingCount > 0;
      }
   }

   private void analyzeCurrentState() {
      this.sendInfo("Analyzing current farm state...");
      this.findFarmPositions();
      if (this.farmPositions.isEmpty()) {
         this.sendInfo("No valid farm positions found. Searching for new locations...");
         this.currentState = AutoTreeFarmer.FarmState.FINDING_POSITIONS;
      } else {
         boolean foundExistingSaplings = false;
         boolean foundGrownTree = false;
         int bestFarmIndex = 0;

         for (int i = 0; i < this.farmPositions.size(); i++) {
            BlockPos farmPos = this.farmPositions.get(i);
            AutoTreeFarmer.FarmAnalysis analysis = this.analyzeFarmPosition(farmPos);
            switch (analysis) {
               case EMPTY_READY_FOR_PLANTING:
                  if (!foundExistingSaplings && !foundGrownTree) {
                     bestFarmIndex = i;
                     this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
                  }
                  break;
               case HAS_SAPLINGS:
                  if (!foundGrownTree) {
                     bestFarmIndex = i;
                     foundExistingSaplings = true;
                     this.currentState = AutoTreeFarmer.FarmState.APPLYING_BONEMEAL;
                     this.currentSaplingPositions = this.get2x2Positions(farmPos);
                     this.currentBoneMealIndex = 0;
                  }
                  break;
               case HAS_GROWN_TREE:
                  bestFarmIndex = i;
                  foundGrownTree = true;
                  this.scanAndPrepareHarvest(i);
                  if (this.logBlocks.isEmpty()) {
                     this.sendInfo("Tree detected but no logs found at farm " + (i + 1) + ". Skipping.");
                  } else {
                     this.currentState = AutoTreeFarmer.FarmState.HARVESTING;
                  }
            }
         }

         this.currentFarmIndex = bestFarmIndex;
         this.sendInfo(
            "Resuming from: "
               + this.currentState.toString().toLowerCase().replace("_", " ")
               + " at farm "
               + (this.currentFarmIndex + 1)
               + "/"
               + this.farmPositions.size()
         );
      }
   }

   private AutoTreeFarmer.FarmAnalysis analyzeFarmPosition(BlockPos farmPos) {
      BlockPos[] saplingPositions = this.get2x2Positions(farmPos);
      boolean hasAnyLogs = false;
      boolean hasAnySaplings = false;
      int emptySpots = 0;

      for (BlockPos pos : saplingPositions) {
         Block currentBlock = this.mc.world.getBlockState(pos).getBlock();
         if (this.isCurrentLog(currentBlock)) {
            hasAnyLogs = true;
         } else if (currentBlock.equals(this.getCurrentSapling())) {
            hasAnySaplings = true;
         } else if (currentBlock.equals(Blocks.field_10124)) {
            emptySpots++;
         }
      }

      if (hasAnyLogs) {
         return AutoTreeFarmer.FarmAnalysis.HAS_GROWN_TREE;
      } else if (hasAnySaplings) {
         return AutoTreeFarmer.FarmAnalysis.HAS_SAPLINGS;
      } else {
         return emptySpots == 4 ? AutoTreeFarmer.FarmAnalysis.EMPTY_READY_FOR_PLANTING : AutoTreeFarmer.FarmAnalysis.INVALID_OR_BLOCKED;
      }
   }

   private void scanAndPrepareHarvest() {
      this.scanAndPrepareHarvest(this.currentFarmIndex);
   }

   private void scanAndPrepareHarvest(int farmIndex) {
      this.logBlocks.clear();
      this.totalLogsInCurrentTree = 0;
      this.logsHarvestedInCurrentTree = 0;
      if (farmIndex < this.farmPositions.size()) {
         BlockPos farmPos = this.farmPositions.get(farmIndex);
         BlockPos[] saplingPositions = this.get2x2Positions(farmPos);

         for (BlockPos basePos : saplingPositions) {
            boolean hasLogNearby = false;

            for (int y = 1; y <= 25; y++) {
               BlockPos checkPos = basePos.up(y);
               Block block = this.mc.world.getBlockState(checkPos).getBlock();
               if (this.isCurrentLog(block)) {
                  hasLogNearby = true;
                  break;
               }
            }

            if (hasLogNearby) {
               for (int yx = 1; yx <= 25; yx++) {
                  BlockPos logPos = basePos.up(yx);
                  Block block = this.mc.world.getBlockState(logPos).getBlock();
                  if (this.isCurrentLog(block)) {
                     this.logBlocks.add(logPos);
                     this.totalLogsInCurrentTree++;
                  } else if (!block.equals(Blocks.field_10124) && !this.isCurrentLeaves(block)) {
                     break;
                  }
               }
            }
         }

         this.logBlocks.sort((pos1, pos2) -> Integer.compare(pos1.getY(), pos2.getY()));
         if (this.totalLogsInCurrentTree > 0) {
            this.sendInfo("Found tree with " + this.totalLogsInCurrentTree + " logs to harvest.");
         }
      }
   }

   private boolean harvestTree() {
      if (this.currentFarmIndex >= this.farmPositions.size()) {
         this.sendInfo("All farms processed.");
         return true;
      } else if (!this.logBlocks.isEmpty()) {
         FindItemResult axe = InvUtils.find(itemStack -> itemStack.getItem() instanceof AxeItem);
         if (!axe.found()) {
            ChatUtils.warning("No axe found in inventory!", new Object[0]);
            this.stopBreaking();
            return true;
         } else {
            BlockPos targetLog = this.logBlocks.get(0);
            if (this.mc.world.getBlockState(targetLog).isAir()) {
               this.stopBreaking();
               this.logBlocks.remove(0);
               this.logsHarvestedInCurrentTree++;
               return false;
            } else {
               Vec3d playerPos = this.mc.player.getEyePos();
               Vec3d blockCenter = Vec3d.ofCenter(targetLog);
               double distance = playerPos.distanceTo(blockCenter);
               if (distance > 5.5) {
                  ChatUtils.warning("Log too far away, skipping: " + targetLog, new Object[0]);
                  this.stopBreaking();
                  this.logBlocks.remove(0);
                  this.logsHarvestedInCurrentTree++;
                  return false;
               } else {
                  this.currentWorkingPos = targetLog;
                  this.lookAtBlock(targetLog, false);
                  if (!this.isBreaking) {
                     if (this.actionDelay <= 0) {
                        InvUtils.swap(axe.slot(), false);
                        this.breakBlock(targetLog);
                        this.actionDelay = this.getRandomizedDelay(2);
                        this.recordAction();
                     }
                  } else if (this.isBreaking && this.currentBreakingPos != null && !this.currentBreakingPos.equals(targetLog)) {
                     this.stopBreaking();
                  }

                  return false;
               }
            }
         }
      } else {
         this.sendInfo("Tree harvesting complete. Logs harvested: " + this.logsHarvestedInCurrentTree + "/" + this.totalLogsInCurrentTree);
         this.stopBreaking();
         BlockPos farmPos = this.farmPositions.get(this.currentFarmIndex);
         BlockPos[] saplingPositions = this.get2x2Positions(farmPos);
         boolean anyLogsRemaining = false;

         for (BlockPos pos : saplingPositions) {
            for (int y = 1; y <= 10; y++) {
               Block checkPos = this.mc.world.getBlockState(pos.up(y)).getBlock();
               if (this.isCurrentLog(checkPos)) {
                  anyLogsRemaining = true;
                  break;
               }
            }

            if (anyLogsRemaining) {
               break;
            }
         }

         if (anyLogsRemaining) {
            this.scanAndPrepareHarvest();
            return false;
         } else {
            return true;
         }
      }
   }

   private void breakBlock(BlockPos pos) {
      if (this.mc.interactionManager != null) {
         this.lookAtBlock(pos, false);
         this.mc.options.attackKey.setPressed(true);
         this.isSimulatingUse = true;
         this.simulationTickDelay = 2;
      }

      this.isBreaking = true;
      this.currentBreakingPos = pos;
   }

   private void stopBreaking() {
      if (this.isBreaking) {
         this.mc.options.attackKey.setPressed(false);
         this.isBreaking = false;
         this.currentBreakingPos = null;
         this.isSimulatingUse = false;
      }
   }

   private void handleAutoFeatures() {
      if ((Boolean)this.autoDrop.get() && this.dropTickCounter >= this.getRandomizedDelay(25)) {
         this.dropTickCounter = 0;
         this.handleAutoDrop();
      }
   }

   private void handleAutoDrop() {
      for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
         ItemStack stack = this.mc.player.getInventory().getStack(i);
         if (!stack.isEmpty() && this.shouldDropItem(stack.getItem())) {
            InvUtils.drop().slot(i);
            break;
         }
      }
   }

   private boolean shouldDropItem(Item item) {
      return item == this.getCurrentLogItem()
         || item == Items.field_8600
         || this.saplingType.get() == AutoTreeFarmer.SaplingType.SPRUCE && item == Items.SPRUCE_LOG
         || this.saplingType.get() == AutoTreeFarmer.SaplingType.JUNGLE && item == Items.JUNGLE_LOG;
   }

   private void checkAndQueueRefill() {
      if (this.needsRefill(Items.field_8324)) {
         this.queuedRefillItem = Items.field_8324;
         this.refillQueued = true;
         this.sendInfo("Bone meal low (" + this.countItemInInventory(Items.field_8324) + "). Queuing refill...");
      } else if (this.needsRefill(this.getCurrentSapling())) {
         this.queuedRefillItem = this.getCurrentSapling();
         this.refillQueued = true;
         this.sendInfo("Saplings low (" + this.countItemInInventory(this.getCurrentSapling()) + "). Queuing refill...");
      }
   }

   private boolean needsRefill(Item item) {
      return this.countItemInInventory(item) < 10;
   }

   private int countItemInInventory(Item item) {
      int count = 0;

      for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
         ItemStack stack = this.mc.player.getInventory().getStack(i);
         if (!stack.isEmpty() && stack.getItem() == item) {
            count += stack.getCount();
         }
      }

      return count;
   }

   private void startRefill(Item item) {
      if (this.refillRetryCount >= (Integer)this.maxRefillRetries.get()) {
         this.sendInfo("Max refill retries reached for " + item.getName().getString());
         this.refillRetryCount = 0;
      } else {
         this.currentRefillItem = item;
         this.refillState = AutoTreeFarmer.RefillState.OPEN_ORDERS;
         this.refillStageStart = System.currentTimeMillis();
         this.stacksCollected = 0;
         this.sendInfo("Starting refill for " + item.getName().getString() + " (Current: " + this.countItemInInventory(item) + ")");
      }
   }

   private void handleRefill() {
      long now = System.currentTimeMillis();
      long timeInState = now - this.refillStageStart;
      int randomizedOrderDelay = this.getRandomizedOrderDelay();
      switch (this.refillState) {
         case NONE:
         default:
            break;
         case OPEN_ORDERS:
            if (timeInState < 200L) {
               return;
            }

            ChatUtils.sendPlayerMsg("/order");
            this.refillState = AutoTreeFarmer.RefillState.WAIT_ORDERS_GUI;
            this.refillStageStart = now;
            break;
         case WAIT_ORDERS_GUI:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (this.mc.currentScreen instanceof GenericContainerScreen) {
               this.refillState = AutoTreeFarmer.RefillState.FIND_CHEST;
               this.refillStageStart = now;
            } else if (timeInState > 8000L) {
               this.retryRefill("Failed to open orders GUI");
            }
            break;
         case FIND_CHEST:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
               this.retryRefill("Orders GUI closed unexpectedly");
               return;
            }

            ScreenHandler var20 = screen.getScreenHandler();
            boolean var23 = false;

            for (int var26 = 0; var26 < var20.slots.size(); var26++) {
               Slot slot = (Slot)var20.slots.get(var26);
               if (slot.hasStack() && slot.getStack().getItem() == Items.CHEST) {
                  this.mc.interactionManager.clickSlot(var20.syncId, var26, 0, SlotActionType.PICKUP, this.mc.player);
                  this.refillState = AutoTreeFarmer.RefillState.WAIT_ITEM_GUI;
                  this.refillStageStart = now;
                  var23 = true;
                  break;
               }
            }

            if (!var23 && timeInState > 4000L) {
               this.retryRefill("No chest found in orders GUI");
            }
            break;
         case WAIT_ITEM_GUI:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (this.mc.currentScreen instanceof GenericContainerScreen) {
               this.refillState = AutoTreeFarmer.RefillState.CLICK_TARGET_ITEM;
               this.refillStageStart = now;
            } else if (timeInState > 8000L) {
               this.retryRefill("Failed to open item selection GUI");
            }
            break;
         case CLICK_TARGET_ITEM:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
               this.retryRefill("Item selection GUI closed unexpectedly");
               return;
            }

            ScreenHandler var18 = screen.getScreenHandler();
            boolean var22 = false;

            for (int var25 = 0; var25 < var18.slots.size(); var25++) {
               Slot slot = (Slot)var18.slots.get(var25);
               if (slot.hasStack() && slot.getStack().getItem() == this.currentRefillItem) {
                  this.mc.interactionManager.clickSlot(var18.syncId, var25, 0, SlotActionType.PICKUP, this.mc.player);
                  this.refillState = AutoTreeFarmer.RefillState.WAIT_CHEST_GUI;
                  this.refillStageStart = now;
                  var22 = true;
                  break;
               }
            }

            if (!var22 && timeInState > 6000L) {
               this.retryRefill("Target item " + this.currentRefillItem.getName().getString() + " not found in GUI");
            }
            break;
         case WAIT_CHEST_GUI:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (this.mc.currentScreen instanceof GenericContainerScreen) {
               this.refillState = AutoTreeFarmer.RefillState.CLICK_CHEST_CONFIRM;
               this.refillStageStart = now;
            } else if (timeInState > 8000L) {
               this.retryRefill("Failed to open chest confirmation GUI");
            }
            break;
         case CLICK_CHEST_CONFIRM:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
               this.retryRefill("Chest confirmation GUI closed unexpectedly");
               return;
            }

            ScreenHandler var16 = screen.getScreenHandler();
            boolean var21 = false;

            for (int var24 = 0; var24 < Math.min(var16.slots.size(), 54); var24++) {
               Slot slot = (Slot)var16.slots.get(var24);
               if (slot.hasStack() && slot.getStack().getItem() == Items.CHEST) {
                  this.mc.interactionManager.clickSlot(var16.syncId, var24, 0, SlotActionType.PICKUP, this.mc.player);
                  this.refillState = AutoTreeFarmer.RefillState.WAIT_COLLECT_GUI;
                  this.refillStageStart = now;
                  var21 = true;
                  break;
               }
            }

            if (!var21) {
               this.retryRefill("No chest found in confirmation GUI");
            }
            break;
         case WAIT_COLLECT_GUI:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (this.mc.currentScreen instanceof GenericContainerScreen) {
               this.refillState = AutoTreeFarmer.RefillState.COLLECT_ITEMS;
               this.refillStageStart = now;
            } else if (timeInState > 8000L) {
               this.retryRefill("Failed to open collection GUI");
            }
            break;
         case COLLECT_ITEMS:
            if (timeInState < randomizedOrderDelay) {
               return;
            }

            if (!(this.mc.currentScreen instanceof GenericContainerScreen screen)) {
               this.retryRefill("Collection GUI closed unexpectedly");
               return;
            }

            ScreenHandler var14 = screen.getScreenHandler();
            boolean collectedThisTick = false;

            for (int i = 0; i < var14.slots.size(); i++) {
               Slot slot = (Slot)var14.slots.get(i);
               if (slot.hasStack() && slot.getStack().getItem() == this.currentRefillItem && this.stacksCollected < (Integer)this.refillAmount.get()) {
                  this.mc.interactionManager.clickSlot(var14.syncId, i, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.stacksCollected++;
                  collectedThisTick = true;
                  this.refillStageStart = now;
                  break;
               }
            }

            if (!collectedThisTick) {
               if (this.stacksCollected > 0) {
                  this.finishRefill(true);
               } else {
                  this.retryRefill("No items found to collect in collection GUI");
               }
            } else if (this.stacksCollected >= (Integer)this.refillAmount.get()) {
               this.finishRefill(true);
            }
      }
   }

   private int getRandomizedOrderDelay() {
      int base = 500;
      int variance = 300;
      return base + this.random.nextInt(variance * 2 + 1) - variance;
   }

   private void retryRefill(String reason) {
      this.refillRetryCount++;
      if (this.refillRetryCount < (Integer)this.maxRefillRetries.get()) {
         this.sendInfo("Refill failed (" + reason + "), retrying...");
         if (this.mc.currentScreen != null) {
            this.mc.currentScreen.close();
         }

         this.refillState = AutoTreeFarmer.RefillState.OPEN_ORDERS;
         this.refillStageStart = System.currentTimeMillis() + 2000L + this.random.nextInt(1000);
      } else {
         this.sendInfo("Refill failed after max retries: " + reason);
         this.finishRefill(false);
      }
   }

   private void finishRefill(boolean success) {
      if (this.mc.currentScreen != null) {
         this.mc.currentScreen.close();
      }

      if (success) {
         this.sendInfo(
            "Refill completed! Collected "
               + this.stacksCollected
               + " stacks of "
               + (this.currentRefillItem != null ? this.currentRefillItem.getName().getString() : "items")
         );
         this.refillRetryCount = 0;
      } else {
         this.sendInfo("Refill failed.");
      }

      this.refillState = AutoTreeFarmer.RefillState.NONE;
      this.currentRefillItem = null;
      this.stacksCollected = 0;
      this.actionDelay = 10;
      this.restorePreRefillState();
   }

   private void autoRefillHotbar(Item targetItem, int minAmount) {
      try {
         int selectedSlot = VersionUtil.getSelectedSlot(this.mc.player);
         ItemStack stack = this.mc.player.getInventory().getStack(selectedSlot);
         if (stack == null || stack.isEmpty() || stack.getItem() != targetItem || stack.getCount() <= minAmount) {
            FindItemResult hotbarItem = InvUtils.findInHotbar(new Item[]{targetItem});
            if (!hotbarItem.found()) {
               FindItemResult invItem = InvUtils.find(new Item[]{targetItem});
               if (invItem.found()) {
                  InvUtils.move().from(invItem.slot()).to(selectedSlot);
               }
            }
         }
      } catch (Exception var7) {
      }
   }

   private Item getCurrentSapling() {
      return switch ((AutoTreeFarmer.SaplingType)this.saplingType.get()) {
         case SPRUCE -> Items.SPRUCE_SAPLING;
         case JUNGLE -> Items.JUNGLE_SAPLING;
      };
   }

   private Block getCurrentLog() {
      return switch ((AutoTreeFarmer.SaplingType)this.saplingType.get()) {
         case SPRUCE -> Blocks.field_10037;
         case JUNGLE -> Blocks.field_10306;
      };
   }

   private Item getCurrentLogItem() {
      return switch ((AutoTreeFarmer.SaplingType)this.saplingType.get()) {
         case SPRUCE -> Items.SPRUCE_LOG;
         case JUNGLE -> Items.JUNGLE_LOG;
      };
   }

   private Block getCurrentLeaves() {
      return switch ((AutoTreeFarmer.SaplingType)this.saplingType.get()) {
         case SPRUCE -> Blocks.field_9988;
         case JUNGLE -> Blocks.field_10335;
      };
   }

   private void lookAtBlock(BlockPos pos, boolean precise) {
      Vec3d basePos = Vec3d.ofCenter(pos);
      double offsetX = 0.0;
      double offsetY = 0.0;
      double offsetZ = 0.0;
      if (!precise) {
         if (this.random.nextDouble() * 100.0 < 12.0) {
            pos = pos.method_10069(this.random.nextInt(3) - 1, this.random.nextBoolean() ? -1 : 0, this.random.nextInt(3) - 1);
            basePos = Vec3d.ofCenter(pos);
         }

         double noise = 1.2;
         offsetX = (this.random.nextDouble() - 0.5) * noise;
         offsetY = (this.random.nextDouble() - 0.5) * noise * 0.5;
         offsetZ = (this.random.nextDouble() - 0.5) * noise;
      }

      Vec3d targetPos = basePos.add(offsetX, offsetY, offsetZ);
      Vec3d playerPos = this.mc.player.getEyePos();
      Vec3d direction = targetPos.subtract(playerPos).normalize();
      double yaw = Math.toDegrees(Math.atan2(-direction.x, direction.z));
      double pitch = Math.toDegrees(-Math.asin(direction.y));
      this.targetYaw = (float)yaw;
      this.targetPitch = (float)pitch;
      this.needsRotation = true;
   }

   private void resetJump() {
      if (this.shouldBeJumping) {
         this.mc.options.jumpKey.setPressed(false);
         this.shouldBeJumping = false;
      }
   }

   private void findFarmPositions() {
      this.farmPositions.clear();
      BlockPos playerPos = this.mc.player.getBlockPos();

      for (int x = -3; x <= 3; x++) {
         for (int z = -3; z <= 3; z++) {
            BlockPos pos = playerPos.method_10069(x, 0, z);
            if (this.isValidFarmPosition(pos)) {
               this.farmPositions.add(pos);
            }
         }
      }

      Collections.shuffle(this.farmPositions, this.random);
   }

   private boolean isValidFarmPosition(BlockPos pos) {
      BlockPos[] saplingPositions = this.get2x2Positions(pos);

      for (BlockPos saplingPos : saplingPositions) {
         BlockPos groundPos = saplingPos.method_10074();
         Block groundBlock = this.mc.world.getBlockState(groundPos).getBlock();
         if (!this.isValidGroundBlock(groundBlock)) {
            return false;
         }

         Block currentBlock = this.mc.world.getBlockState(saplingPos).getBlock();
         if (!currentBlock.equals(Blocks.field_10124) && !currentBlock.equals(this.getCurrentSapling()) && !this.isCurrentLog(currentBlock)) {
            return false;
         }

         for (int i = 1; i <= 8; i++) {
            Block aboveBlock = this.mc.world.getBlockState(saplingPos.up(i)).getBlock();
            if (!aboveBlock.equals(Blocks.field_10124) && !this.isCurrentLog(aboveBlock) && !this.isCurrentLeaves(aboveBlock)) {
               return false;
            }
         }
      }

      return true;
   }

   private BlockPos[] get2x2Positions(BlockPos basePos) {
      return new BlockPos[]{basePos, basePos.method_10069(1, 0, 0), basePos.method_10069(0, 0, 1), basePos.method_10069(1, 0, 1)};
   }

   private boolean placeSaplings() {
      if (this.currentFarmIndex >= this.farmPositions.size()) {
         return true;
      } else {
         BlockPos farmPos = this.farmPositions.get(this.currentFarmIndex);
         BlockPos[] saplingPositions = this.get2x2Positions(farmPos);
         FindItemResult saplings = InvUtils.find(new Item[]{this.getCurrentSapling()});
         if (!saplings.found()) {
            if (!this.refillQueued && this.refillState == AutoTreeFarmer.RefillState.NONE) {
               this.queuedRefillItem = this.getCurrentSapling();
               this.refillQueued = true;
               this.sendInfo("No saplings found. Queuing refill...");
            }

            return false;
         } else {
            List<BlockPos> posList = new ArrayList<>(List.of(saplingPositions));
            Collections.shuffle(posList, this.random);
            BlockPos[] positions = posList.toArray(new BlockPos[0]);
            boolean needToJump = false;

            for (BlockPos pos : positions) {
               if (this.mc.world.getBlockState(pos).getBlock().equals(Blocks.field_10124)) {
                  Vec3d playerPos = this.mc.player.getEntityPos();
                  Vec3d blockPos = new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                  double distance = playerPos.distanceTo(blockPos);
                  if (distance > 4.5) {
                     needToJump = true;
                     break;
                  }
               }
            }

            if (needToJump && !this.shouldBeJumping) {
               this.mc.options.jumpKey.setPressed(true);
               this.shouldBeJumping = true;
               this.sendInfo("Jumping to reach back saplings...");
            } else if (!needToJump && this.shouldBeJumping && this.random.nextInt(10) == 0) {
               this.resetJump();
            } else if (!needToJump && !this.shouldBeJumping && this.random.nextInt(3) == 0) {
               this.mc.options.jumpKey.setPressed(true);
               this.shouldBeJumping = true;
            }

            for (BlockPos posx : positions) {
               if (this.mc.world.getBlockState(posx).getBlock().equals(Blocks.field_10124)) {
                  this.currentWorkingPos = posx;
                  Vec3d playerPos = this.mc.player.getEntityPos();
                  Vec3d blockPos = new Vec3d(posx.getX() + 0.5, posx.getY(), posx.getZ() + 0.5);
                  double distance = playerPos.distanceTo(blockPos);
                  double reachRange = this.shouldBeJumping ? 5.5 : 4.5;
                  if (!(distance > reachRange)) {
                     this.lookAtBlock(posx, false);
                     if (this.actionDelay <= 0) {
                        InvUtils.swap(saplings.slot(), false);
                        this.mc.options.useKey.setPressed(true);
                        this.simulationTickDelay = 2;
                        this.isSimulatingUse = true;
                        this.actionDelay = this.getRandomizedDelay(2);
                        this.recordAction();
                     }

                     return false;
                  }
               }
            }

            this.resetJump();
            return true;
         }
      }
   }

   private boolean applyBoneMeal() {
      if (this.currentFarmIndex >= this.farmPositions.size()) {
         return true;
      } else {
         BlockPos farmPos = this.farmPositions.get(this.currentFarmIndex);
         if (this.currentSaplingPositions == null) {
            this.currentSaplingPositions = this.get2x2Positions(farmPos);
         }

         if (this.currentSaplingPositions != null && this.currentSaplingPositions.length != 0) {
            FindItemResult boneMeal = InvUtils.find(new Item[]{Items.field_8324});
            if (!boneMeal.found()) {
               if (!this.refillQueued && this.refillState == AutoTreeFarmer.RefillState.NONE) {
                  this.queuedRefillItem = Items.field_8324;
                  this.refillQueued = true;
                  this.sendInfo("No bone meal found. Queuing refill...");
               }

               return true;
            } else if (this.checkTreeGrown()) {
               this.currentBoneMealIndex = 0;
               this.currentSaplingPositions = null;
               return true;
            } else if (this.currentBoneMealIndex < this.currentSaplingPositions.length) {
               BlockPos pos = this.currentSaplingPositions[this.currentBoneMealIndex];
               if (pos == null) {
                  this.currentBoneMealIndex++;
                  return false;
               } else {
                  Block block = this.mc.world.getBlockState(pos).getBlock();
                  if (block != Blocks.field_10217 && block != Blocks.field_10276) {
                     this.currentBoneMealIndex++;
                     return false;
                  } else {
                     this.currentWorkingPos = pos;
                     Vec3d playerPos = this.mc.player.getEntityPos();
                     Vec3d blockPos = new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                     double distance = playerPos.distanceTo(blockPos);
                     if (distance > 4.5) {
                        this.currentBoneMealIndex++;
                        return false;
                     } else {
                        this.lookAtBlock(pos, true);
                        InvUtils.swap(boneMeal.slot(), false);
                        this.mc.options.useKey.setPressed(true);
                        this.simulationTickDelay = 2;
                        this.isSimulatingUse = true;
                        this.currentBoneMealIndex++;
                        this.actionDelay = 0;
                        this.recordAction();
                        if (this.checkTreeGrown()) {
                           this.currentBoneMealIndex = 0;
                           this.currentSaplingPositions = null;
                           return true;
                        } else {
                           return false;
                        }
                     }
                  }
               }
            } else {
               this.currentBoneMealIndex = 0;
               if (this.checkTreeGrown()) {
                  this.currentSaplingPositions = null;
                  return true;
               } else {
                  return false;
               }
            }
         } else {
            this.sendInfo("Error: No sapling positions found. Resetting state.");
            this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
            this.currentBoneMealIndex = 0;
            return false;
         }
      }
   }

   private boolean checkTreeGrown() {
      if (this.currentFarmIndex >= this.farmPositions.size()) {
         return true;
      } else {
         BlockPos farmPos = this.farmPositions.get(this.currentFarmIndex);
         BlockPos[] saplingPositions = this.get2x2Positions(farmPos);

         for (BlockPos pos : saplingPositions) {
            Block block = this.mc.world.getBlockState(pos).getBlock();
            if (this.isCurrentLog(block)) {
               if (this.currentState != AutoTreeFarmer.FarmState.HARVESTING) {
                  this.sendInfo("Tree grown detected! Starting harvest...");
                  this.scanAndPrepareHarvest();
                  this.currentState = AutoTreeFarmer.FarmState.HARVESTING;
                  FindItemResult axe = InvUtils.find(itemStack -> itemStack.getItem() instanceof AxeItem);
                  if (axe.found()) {
                     InvUtils.swap(axe.slot(), false);
                  }

                  if (!this.logBlocks.isEmpty()) {
                     BlockPos firstLog = this.logBlocks.get(0);
                     if (!this.isBreaking) {
                        this.lookAtBlock(firstLog, false);
                        this.breakBlock(firstLog);
                     }
                  }
               }

               return true;
            }

            for (int y = 1; y <= 10; y++) {
               Block checkBlock = this.mc.world.getBlockState(pos.up(y)).getBlock();
               if (this.isCurrentLog(checkBlock)) {
                  if (this.currentState != AutoTreeFarmer.FarmState.HARVESTING) {
                     this.sendInfo("Tree grown detected above! Starting harvest...");
                     this.scanAndPrepareHarvest();
                     this.currentState = AutoTreeFarmer.FarmState.HARVESTING;
                     FindItemResult axex = InvUtils.find(itemStack -> itemStack.getItem() instanceof AxeItem);
                     if (axex.found()) {
                        InvUtils.swap(axex.slot(), false);
                     }

                     if (!this.logBlocks.isEmpty()) {
                        BlockPos firstLog = this.logBlocks.get(0);
                        if (!this.isBreaking) {
                           this.lookAtBlock(firstLog, false);
                           this.breakBlock(firstLog);
                        }
                     }
                  }

                  return true;
               }

               if (!checkBlock.equals(Blocks.field_10124) && !this.isCurrentLeaves(checkBlock)) {
                  break;
               }
            }
         }

         this.checkForTreeInFront();
         return false;
      }
   }

   private void checkForTreeInFront() {
      if (this.treeDetectionCooldown > 0) {
         this.treeDetectionCooldown--;
      } else {
         Vec3d playerPos = this.mc.player.getEyePos();
         Vec3d lookDir = this.mc.player.getRotationVec(1.0F);

         for (int i = 1; i <= 5; i++) {
            Vec3d checkPos = playerPos.add(lookDir.x * i, lookDir.y * i, lookDir.z * i);
            BlockPos blockPos = new BlockPos((int)checkPos.x, (int)checkPos.y, (int)checkPos.z);
            if (i > 1) {
               Vec3d prevPos = playerPos.add(lookDir.x * (i - 1), lookDir.y * (i - 1), lookDir.z * (i - 1));
               BlockPos prevBlockPos = new BlockPos((int)prevPos.x, (int)prevPos.y, (int)prevPos.z);
               if (prevBlockPos.equals(blockPos)) {
                  continue;
               }
            }

            Block block = this.mc.world.getBlockState(blockPos).getBlock();
            if (this.isCurrentLog(block)) {
               if (!this.treeDetectedInFront) {
                  this.treeDetectedInFront = true;
                  this.sendInfo("Tree detected in front! Auto-mining...");
                  if (this.currentState != AutoTreeFarmer.FarmState.HARVESTING) {
                     this.logBlocks.clear();
                     this.logBlocks.add(blockPos);
                     this.totalLogsInCurrentTree = 1;
                     this.logsHarvestedInCurrentTree = 0;

                     for (int y = 1; y <= 25; y++) {
                        BlockPos abovePos = blockPos.up(y);
                        Block aboveBlock = this.mc.world.getBlockState(abovePos).getBlock();
                        if (this.isCurrentLog(aboveBlock)) {
                           this.logBlocks.add(abovePos);
                           this.totalLogsInCurrentTree++;
                        } else if (!aboveBlock.equals(Blocks.field_10124) && !this.isCurrentLeaves(aboveBlock)) {
                           break;
                        }
                     }

                     this.logBlocks.sort((pos1, pos2) -> Integer.compare(pos1.getY(), pos2.getY()));
                     this.currentState = AutoTreeFarmer.FarmState.HARVESTING;
                     FindItemResult axe = InvUtils.find(itemStack -> itemStack.getItem() instanceof AxeItem);
                     if (axe.found()) {
                        InvUtils.swap(axe.slot(), false);
                     }

                     if (!this.logBlocks.isEmpty()) {
                        BlockPos firstLog = this.logBlocks.get(0);
                        if (!this.isBreaking) {
                           this.lookAtBlock(firstLog, false);
                           this.breakBlock(firstLog);
                        }
                     }
                  }
               }

               this.treeDetectionCooldown = 20;
               return;
            }
         }

         if (this.treeDetectedInFront) {
            this.treeDetectedInFront = false;
         }

         this.treeDetectionCooldown = 10;
      }
   }

   private void recordAction() {
      long now = System.currentTimeMillis();
      if (now - this.lastActionTime < 150L) {
         this.consecutiveActions++;
      } else {
         this.consecutiveActions = 0;
      }

      this.lastActionTime = now;
   }

   private void moveToNextFarm() {
      this.currentFarmIndex++;
      this.rotationStabilizeTicks = 0;
      this.logBlocks.clear();
      this.totalLogsInCurrentTree = 0;
      this.logsHarvestedInCurrentTree = 0;
      this.currentBoneMealIndex = 0;
      this.currentSaplingPositions = null;
      this.growthWaitTicks = 0;
      this.hasSaplingsAtCurrentFarm = false;
      if (this.currentFarmIndex >= this.farmPositions.size()) {
         this.currentFarmIndex = 0;
         this.cycleCount++;
         this.sendInfo("Completed cycle " + this.cycleCount + "! Starting new cycle...");
         this.currentState = AutoTreeFarmer.FarmState.PLACING_SAPLINGS;
         if (this.cycleCount % 5 == 0) {
            this.sendInfo("Rescanning for new farm positions...");
            this.findFarmPositions();
         }
      }
   }

   private boolean isValidGroundBlock(Block block) {
      return block.equals(Blocks.field_10219)
         || block.equals(Blocks.field_10566)
         || block.equals(Blocks.field_10253)
         || block.equals(Blocks.field_10520)
         || block.equals(Blocks.field_10402);
   }

   private boolean isCurrentLog(Block block) {
      return block.equals(this.getCurrentLog());
   }

   private boolean isCurrentLeaves(Block block) {
      return block.equals(this.getCurrentLeaves());
   }

   public String getInfoString() {
      if (this.playerTooFar) {
         return "Too far from farms";
      } else if (this.pauseWhileEating) {
         return "Paused (Eating)";
      } else if (this.isPaused) {
         return "Paused (Human-like)";
      } else if (this.refillState != AutoTreeFarmer.RefillState.NONE) {
         return "Refill: " + this.refillState.toString().toLowerCase().replace("_", " ");
      } else {
         String stateStr = this.currentState.toString().toLowerCase().replace("_", " ");
         if (this.currentState == AutoTreeFarmer.FarmState.HARVESTING && this.totalLogsInCurrentTree > 0) {
            stateStr = stateStr + " (" + this.logsHarvestedInCurrentTree + "/" + this.totalLogsInCurrentTree + " logs)";
         } else if (this.currentState == AutoTreeFarmer.FarmState.APPLYING_BONEMEAL && this.currentSaplingPositions != null) {
            stateStr = stateStr + " (" + (this.currentBoneMealIndex + 1) + "/" + this.currentSaplingPositions.length + " saplings)";
         } else if (this.currentState == AutoTreeFarmer.FarmState.WAITING_FOR_GROWTH) {
            stateStr = stateStr + " (" + this.growthWaitTicks + "/600 ticks)";
         }

         String treeDetected = this.treeDetectedInFront ? " [Tree in front]" : "";
         return stateStr + " [" + (this.currentFarmIndex + 1) + "/" + this.farmPositions.size() + " farms] (Cycle " + this.cycleCount + ")" + treeDetected;
      }
   }

   private static enum FarmAnalysis {
      EMPTY_READY_FOR_PLANTING,
      HAS_SAPLINGS,
      HAS_GROWN_TREE,
      INVALID_OR_BLOCKED;

      private FarmAnalysis() {
      }
   }

   private static enum FarmState {
      ANALYZING_CURRENT_STATE,
      FINDING_POSITIONS,
      PLACING_SAPLINGS,
      APPLYING_BONEMEAL,
      WAITING_FOR_GROWTH,
      HARVESTING;

      private FarmState() {
      }
   }

   private static enum RefillState {
      NONE,
      OPEN_ORDERS,
      WAIT_ORDERS_GUI,
      FIND_CHEST,
      WAIT_ITEM_GUI,
      CLICK_TARGET_ITEM,
      WAIT_CHEST_GUI,
      CLICK_CHEST_CONFIRM,
      WAIT_COLLECT_GUI,
      COLLECT_ITEMS;

      private RefillState() {
      }
   }

   public static enum SaplingType {
      SPRUCE,
      JUNGLE;

      private SaplingType() {
      }
   }
}
