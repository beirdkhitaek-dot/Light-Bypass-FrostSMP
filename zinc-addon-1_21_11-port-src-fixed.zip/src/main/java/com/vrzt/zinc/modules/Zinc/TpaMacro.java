package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class TpaMacro extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<String> playerName = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("target-player")).description("Name of the player to send TPA to.")).defaultValue("Steve")).build());
   private final Setting<TpaMacro.TpaType> tpaType = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("tpa-type"))
                  .description("Command to use."))
               .defaultValue(TpaMacro.TpaType.TPA))
            .build()
      );
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("delay"))
                  .description("Ticks between command sends."))
               .defaultValue(40))
            .min(1)
            .sliderMax(200)
            .build()
      );
   private int tickCounter = 0;
   private boolean waitingForConfirm = false;
   private long guiWaitStart = 0L;
   private static final long GUI_TIMEOUT_MS = 5000L;

   public TpaMacro() {
      super(ZincAddon.Zinc, "TpaMacro", "Spams /tpa or /tpahere and clicks the confirmation.");
   }

   public void onActivate() {
      this.tickCounter = 0;
      this.waitingForConfirm = false;
      this.guiWaitStart = 0L;
      this.info("Starting TPA to " + (String)this.playerName.get(), new Object[0]);
   }

   public void onDeactivate() {
      this.waitingForConfirm = false;
      this.guiWaitStart = 0L;
      this.info("TPA Macro deactivated.", new Object[0]);
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.interactionManager != null) {
         PlayerEntity target = this.mc
            .world
            .getPlayers()
            .stream()
            .filter(p -> Objects.equals(p.getGameProfile().name(), this.playerName.get()))
            .findFirst()
            .orElse(null);
         if (target != null && this.mc.player.distanceTo(target) < 5.0F) {
            this.info(" Player " + (String)this.playerName.get() + " is nearby. Macro complete.", new Object[0]);
            this.toggle();
         } else if (this.waitingForConfirm && this.mc.currentScreen instanceof HandledScreen) {
            this.clickConfirmButtonIfPresent();
         } else {
            if (this.waitingForConfirm && this.guiWaitStart > 0L && System.currentTimeMillis() - this.guiWaitStart > 5000L) {
               ChatUtils.warning("GUI timeout. Retrying...", new Object[0]);
               this.waitingForConfirm = false;
               this.guiWaitStart = 0L;
            }

            if (!this.waitingForConfirm) {
               this.tickCounter++;
               if (this.tickCounter >= (Integer)this.delay.get()) {
                  String command = (this.tpaType.get() == TpaMacro.TpaType.TPA ? "/tpa " : "/tpahere ") + (String)this.playerName.get();
                  ChatUtils.sendPlayerMsg(command);
                  ChatUtils.info("\ud83d\udce8 Sent: " + command, new Object[0]);
                  this.waitingForConfirm = true;
                  this.guiWaitStart = System.currentTimeMillis();
                  this.tickCounter = 0;
               }
            }
         }
      }
   }

   private void clickConfirmButtonIfPresent() {
      if (this.mc.currentScreen instanceof HandledScreen<?> screen) {
         ScreenHandler var6 = screen.getScreenHandler();

         for (int i = 0; i < var6.slots.size(); i++) {
            ItemStack stack = var6.getSlot(i).getStack();
            String key = stack.getItem().getTranslationKey().toLowerCase();
            if (key.contains("stained_glass_pane") && key.contains("lime")) {
               this.mc.interactionManager.clickSlot(var6.syncId, i, 0, SlotActionType.PICKUP, this.mc.player);
               ChatUtils.info("\ud83d\udfe2 Confirm button clicked (slot " + i + ").", new Object[0]);
               this.mc.player.closeHandledScreen();
               this.waitingForConfirm = false;
               this.guiWaitStart = 0L;
               return;
            }
         }

         ChatUtils.warning("No button's found in GUI.", new Object[0]);
      }
   }

   public static enum TpaType {
      TPA,
      TPAHERE;

      private TpaType() {
      }
   }
}
