package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;

public class FastExp extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> active = this.sgGeneral.add(((Builder)((Builder)new Builder().name("active")).defaultValue(true)).build());
   private final Setting<Double> useDelay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
               .name("use-delay-ms"))
            .defaultValue(100.0)
            .min(1.0)
            .sliderMax(500.0)
            .build()
      );
   private long lastUseTime;
   private boolean switchedToXP = false;

   public FastExp() {
      super(ZincAddon.pvp, "fast-xp", "Simulated right-click XP thrower.");
   }

   @EventHandler
   private void onTick(Pre event) {
      if ((Boolean)this.active.get() && this.mc.player != null && this.mc.world != null) {
         boolean holdingXP = this.mc.player.getMainHandStack().isOf(Items.field_8287);
         if (holdingXP && !this.switchedToXP) {
            this.switchedToXP = true;
            this.lastUseTime = System.currentTimeMillis();
         } else if (!holdingXP && this.switchedToXP) {
            this.switchedToXP = false;
         }

         if (this.switchedToXP && this.mc.options.useKey.isPressed()) {
            if (System.currentTimeMillis() - this.lastUseTime >= this.getRandomDelay()) {
               this.mc.interactionManager.interactItem(this.mc.player, Hand.field_5808);
               this.mc.player.swingHand(Hand.field_5808);
               this.lastUseTime = System.currentTimeMillis();
            }
         }
      }
   }

   private long getRandomDelay() {
      double base = (Double)this.useDelay.get();
      return (long)(base + ThreadLocalRandom.current().nextDouble(-base * 0.2, base * 0.2));
   }
}
