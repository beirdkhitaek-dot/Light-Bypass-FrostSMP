package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.KeybindSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.client.option.KeyBinding;

public class HorizontalWindCatcher extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Keybind> activateKey = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("activate-key")).defaultValue(Keybind.fromKey(72))).build());
   private final Setting<Double> pearlPitch = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
               .name("pearl-pitch"))
            .defaultValue(-25.0)
            .min(-90.0)
            .max(90.0)
            .build()
      );
   private final Setting<Double> windPitch = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder().name("wind-pitch"))
            .defaultValue(-7.5)
            .min(-90.0)
            .max(90.0)
            .build()
      );
   private int prevSlot = -1;
   private int timer = 0;
   private boolean active = false;
   private boolean prevPressed = false;
   private HorizontalWindCatcher.Stage stage = HorizontalWindCatcher.Stage.IDLE;
   private KeyBinding activeHotbarKey = null;

   public HorizontalWindCatcher() {
      super(ZincAddon.pvp, "horizontal-wind-catcher", "Hardcoded Keybind: Pearl + Wind Charge with custom pitches.");
   }

   public void onActivate() {
      this.reset();
      this.prevPressed = false;
   }

   public void onDeactivate() {
      this.releaseKeys();
      if (this.active) {
         this.reset();
      }
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null) {
         boolean isPressed = ((Keybind)this.activateKey.get()).isPressed();
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (risingEdge && this.mc.currentScreen == null && !this.active) {
            this.startMacro();
         }

         if (this.active) {
            switch (this.stage) {
               case THROW_PEARL:
                  int slot = this.findItem(Items.field_8634);
                  if (slot != -1) {
                     this.hardwareFullSwap(slot);
                     this.mc.player.setPitch(((Double)this.pearlPitch.get()).floatValue());
                     this.mc.options.useKey.setPressed(true);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.stage = HorizontalWindCatcher.Stage.DELAY;
                     this.timer = 0;
                  } else {
                     this.reset();
                  }
                  break;
               case DELAY:
                  if (this.timer == 0) {
                     this.mc.options.useKey.setPressed(false);
                  }

                  if (this.timer >= 1) {
                     int windSlot = this.findItem(Items.field_49098);
                     if (windSlot != -1) {
                        this.hardwareFullSwap(windSlot);
                        this.mc.player.setPitch(((Double)this.windPitch.get()).floatValue());
                        this.stage = HorizontalWindCatcher.Stage.THROW_WIND;
                     } else {
                        this.reset();
                     }
                  }

                  this.timer++;
                  break;
               case THROW_WIND:
                  this.mc.options.useKey.setPressed(true);
                  ((IMinecraftClient)this.mc).zinc$doItemUse();
                  this.stage = HorizontalWindCatcher.Stage.CLEANUP;
                  this.timer = 0;
                  break;
               case CLEANUP:
                  if (this.timer >= 1) {
                     this.releaseKeys();
                     if (this.prevSlot != -1) {
                        this.hardwareFullSwap(this.prevSlot);
                     }

                     this.reset();
                  }

                  this.timer++;
            }
         }
      }
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }

      if (this.mc.options != null) {
         this.mc.options.useKey.setPressed(false);
      }
   }

   private int findItem(Item item) {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(item)) {
            return i;
         }
      }

      return -1;
   }

   private void startMacro() {
      this.active = true;
      this.prevSlot = this.mc.player.getInventory().getSelectedSlot();
      this.stage = HorizontalWindCatcher.Stage.THROW_PEARL;
      this.timer = 0;
   }

   private void reset() {
      this.active = false;
      this.stage = HorizontalWindCatcher.Stage.IDLE;
      this.releaseKeys();
   }

   private static enum Stage {
      IDLE,
      THROW_PEARL,
      DELAY,
      THROW_WIND,
      CLEANUP;

      private Stage() {
      }
   }
}
