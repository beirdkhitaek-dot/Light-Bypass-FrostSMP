package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class SpawnerDropper extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Integer> delay = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("delay")).description("Delay between clicks in ticks.")).defaultValue(5))
            .min(1)
            .max(20)
            .sliderMax(20)
            .build()
      );
   private final Setting<Integer> pagesToProcess = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("pages-to-process")).description("The total number of spawner pages to process before stopping."))
               .defaultValue(1))
            .min(1)
            .max(10)
            .build()
      );
   private final Setting<Boolean> boneOnly = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("bone-only"))
                  .description("Only drop bones. Stops when arrows are detected in slots 0-44."))
               .defaultValue(false))
            .build()
      );
   private int tickCounter = 0;
   private boolean hasClickedSlots = false;
   private int warningCooldown = 0;
   private int currentStep = 0;
   private int checkDelayCounter = 0;
   private int currentPage = 1;
   private static final int CHECK_DELAY = 3;
   private static final int NEXT_PAGE_SLOT = 53;
   private static final int DROP_ITEM_SLOT = 53;
   private static final int SPANWER_OUTPUT_SLOT = 50;

   public SpawnerDropper() {
      super(ZincAddon.Zinc, "SpawnerDropper", "Drops all items from spawners continuously, with page support.");
   }

   private boolean hasArrowsInInventory(HandledScreen<?> screen) {
      for (int i = 9; i <= 44; i++) {
         if (screen.getScreenHandler().getSlot(i).getStack().getItem() == Items.field_8107) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.interactionManager != null) {
         if (this.warningCooldown > 0) {
            this.warningCooldown--;
         }

         if (this.mc.currentScreen instanceof HandledScreen screen) {
            if (this.currentStep == 3) {
               if (screen.getScreenHandler().slots.size() > 53) {
                  this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, 53, 0, SlotActionType.PICKUP, this.mc.player);
                  this.currentPage++;
                  this.info("Advanced to Page " + this.currentPage + " of " + this.pagesToProcess.get(), new Object[0]);
                  this.currentStep = 0;
                  this.tickCounter = 0;
                  this.checkDelayCounter = 0;
               } else {
                  this.info("Could not advance page (Next Page button not found). Stopping.", new Object[0]);
                  this.toggle();
               }
            } else if (this.currentStep == 2) {
               this.checkDelayCounter++;
               if (this.checkDelayCounter >= 3) {
                  this.checkDelayCounter = 0;
                  if (screen.getScreenHandler().getSlot(50).getStack().isEmpty()) {
                     if (this.currentPage >= (Integer)this.pagesToProcess.get()) {
                        this.info("Finished dropping all items through page " + this.pagesToProcess.get() + ".", new Object[0]);
                        this.toggle();
                     } else {
                        this.currentStep = 3;
                     }
                  } else if ((Boolean)this.boneOnly.get() && this.hasArrowsInInventory(screen)) {
                     this.info("Found arrows in inventory. Stopping.", new Object[0]);
                     this.toggle();
                  } else {
                     this.currentStep = 0;
                  }
               }
            } else {
               this.tickCounter++;
               if (this.tickCounter >= (Integer)this.delay.get()) {
                  this.tickCounter = 0;
                  this.hasClickedSlots = true;
                  switch (this.currentStep) {
                     case 0:
                        if (screen.getScreenHandler().getSlot(50).getStack().isEmpty()) {
                           this.currentStep = 2;
                           this.checkDelayCounter = 0;
                           return;
                        }

                        this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, 50, 0, SlotActionType.PICKUP, this.mc.player);
                        this.currentStep = 1;
                        break;
                     case 1:
                        this.mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, 53, 0, SlotActionType.PICKUP, this.mc.player);
                        this.currentStep = 2;
                        this.checkDelayCounter = 0;
                  }
               }
            }
         } else {
            if (this.isActive() && !this.hasClickedSlots && this.warningCooldown == 0) {
               this.warning("You need to be on the spawner screen to use this module.", new Object[0]);
               this.warningCooldown = 20;
            }
         }
      }
   }

   public void onActivate() {
      this.tickCounter = 0;
      this.hasClickedSlots = false;
      this.warningCooldown = 0;
      this.currentStep = 0;
      this.checkDelayCounter = 0;
      this.currentPage = 1;
      this.info("SpawnerDropper activated. Processing up to " + this.pagesToProcess.get() + " pages.", new Object[0]);
   }

   public void onDeactivate() {
      this.currentStep = 0;
      this.checkDelayCounter = 0;
      this.currentPage = 1;
   }

   public String getInfoString() {
      if (!this.isActive()) {
         return null;
      } else {
         return "Page: " + this.currentPage + "/" + this.pagesToProcess.get() + " | Action: " + switch (this.currentStep) {
            case 0 -> "Pickup";
            case 1 -> "Drop";
            case 2 -> "Check";
            case 3 -> "Advance Page";
            default -> "Waiting";
         };
      }
   }
}
