package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.Properties;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.math.Direction.Axis;

public class RotatedDeepslateESP extends Module {
   private final SettingGroup sgGeneral = this.settings.createGroup("General");
   private final SettingGroup sgFiltering = this.settings.createGroup("Block Types");
   private final SettingGroup sgRange = this.settings.createGroup("Range");
   private final Setting<SettingColor> deepslateColor = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("esp-color")).description("The color of the ESP box and tracers."))
            .defaultValue(new SettingColor(255, 0, 255, 100))
            .build()
      );
   private final Setting<ShapeMode> deepslateShapeMode = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("How the shapes are rendered."))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> ignoreExposed = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("ignore-exposed"))
                  .description("Only show blocks that are completely buried (not touching air/water)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> tracers = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("tracers"))
                  .description("Draw lines from your crosshair to the blocks."))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> includeRegular = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("regular-deepslate"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> includeBricks = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("deepslate-bricks"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> includeTiles = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("deepslate-tiles"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> minY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("min-y"))
               .defaultValue(-64))
            .sliderRange(-64, 320)
            .build()
      );
   private final Setting<Integer> maxY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("max-y"))
               .defaultValue(128))
            .sliderRange(-64, 320)
            .build()
      );
   private final Set<BlockPos> rotatedPositions = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;
   private final Color boxColor = new Color();
   private final Color lineColor = new Color();

   public RotatedDeepslateESP() {
      super(ZincAddon.esp, "RotatedDeepslateESP", "Highlights deepslate blocks that have been rotated by players (axis is not Y).");
   }

   public void onActivate() {
      this.rotatedPositions.clear();
      this.threadPool = Executors.newFixedThreadPool(Math.max(1, Runtime.getRuntime().availableProcessors() / 2));

      for (Chunk chunk : Utils.chunks()) {
         if (chunk instanceof WorldChunk worldChunk) {
            this.threadPool.submit(() -> this.scanChunk(worldChunk));
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
      }

      this.rotatedPositions.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (this.isRotated(event.newState, event.pos, this.mc.world)) {
         this.rotatedPositions.add(event.pos.toImmutable());
      } else {
         this.rotatedPositions.remove(event.pos);
      }
   }

   private void scanChunk(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();
      int startX = cpos.getStartX();
      int startZ = cpos.getStartZ();

      for (int x = 0; x < 16; x++) {
         for (int z = 0; z < 16; z++) {
            for (int y = (Integer)this.minY.get(); y <= this.maxY.get(); y++) {
               BlockPos pos = new BlockPos(startX + x, y, startZ + z);
               BlockState state = chunk.getBlockState(pos);
               if (this.isRotated(state, pos, this.mc.world)) {
                  this.rotatedPositions.add(pos.toImmutable());
               }
            }
         }
      }
   }

   private boolean isRotated(BlockState state, BlockPos pos, World world) {
      if (state != null && !state.isAir() && pos.getY() >= (Integer)this.minY.get() && pos.getY() <= (Integer)this.maxY.get()) {
         boolean validBlock = (Boolean)this.includeRegular.get() && state.isOf(Blocks.field_28888)
            || (Boolean)this.includeBricks.get() && state.isOf(Blocks.field_28900)
            || (Boolean)this.includeTiles.get() && state.isOf(Blocks.field_28896);
         if (!validBlock) {
            return false;
         } else if (!state.contains(Properties.AXIS)) {
            return false;
         } else if (state.get(Properties.AXIS) == Axis.field_11052) {
            return false;
         } else {
            if ((Boolean)this.ignoreExposed.get() && world != null) {
               for (Direction dir : Direction.values()) {
                  BlockPos neighbor = pos.method_10093(dir);
                  if (world.isAir(neighbor) || !world.getFluidState(neighbor).isEmpty()) {
                     return false;
                  }
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null) {
         this.boxColor.set((Color)this.deepslateColor.get());
         this.lineColor.set((Color)this.deepslateColor.get());
         this.lineColor.a = 255;
         int renderDistance = (Integer)this.mc.options.getViewDistance().getValue() * 16;
         double renderDistanceSq = renderDistance * renderDistance;

         for (BlockPos pos : this.rotatedPositions) {
            double distSq = this.mc.player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (!(distSq > renderDistanceSq)) {
               event.renderer.box(pos, this.boxColor, this.lineColor, (ShapeMode)this.deepslateShapeMode.get(), 0);
               if ((Boolean)this.tracers.get()) {
                  event.renderer
                     .line(
                        RenderUtils.center.x,
                        RenderUtils.center.y,
                        RenderUtils.center.z,
                        pos.getX() + 0.5,
                        pos.getY() + 0.5,
                        pos.getZ() + 0.5,
                        this.lineColor
                     );
               }
            }
         }
      }
   }
}
