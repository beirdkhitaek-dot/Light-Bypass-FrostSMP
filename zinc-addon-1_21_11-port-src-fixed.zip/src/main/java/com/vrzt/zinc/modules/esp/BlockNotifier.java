package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BlockListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import com.vrzt.zinc.utils.zinc.ZincToast;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.text.Text;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class BlockNotifier extends Module {
   private final SettingGroup sg_general = this.settings.getDefaultGroup();
   private final SettingGroup sg_notifications = this.settings.createGroup("Notifications");
   private final SettingGroup sg_webhook = this.settings.createGroup("Webhook");
   private final SettingGroup sg_render = this.settings.createGroup("Render");
   private final Setting<List<Block>> blocks_to_find = this.sg_general
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("blocks-to-find")).description("Blocks to notify when found.")).defaultValue(Collections.emptyList()))
            .build()
      );
   private final Setting<Boolean> showSpawnerType = this.sg_general
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("show-spawner-type"))
                  .description("Shows entity type (e.g. Zombie Spawner)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> min_y = this.sg_general
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("min-y"))
               .defaultValue(-64))
            .min(-64)
            .max(320)
            .build()
      );
   private final Setting<Integer> max_y = this.sg_general
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("max-y"))
               .defaultValue(320))
            .min(-64)
            .max(320)
            .build()
      );
   private final Setting<BlockNotifier.Mode> notification_mode = this.sg_notifications
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                  .name("notification-mode"))
               .defaultValue(BlockNotifier.Mode.Both))
            .build()
      );
   private final Setting<Boolean> disconnect_on_find = this.sg_notifications
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("disconnect-on-find"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> webhook_enabled = this.sg_webhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("webhook-enabled"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhook_url = this.sg_webhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("webhook-url"))
                  .defaultValue(""))
               .visible(this.webhook_enabled::get))
            .build()
      );
   private final Setting<Boolean> self_ping = this.sg_webhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("self-ping"))
                  .defaultValue(false))
               .visible(this.webhook_enabled::get))
            .build()
      );
   private final Setting<String> discord_id = this.sg_webhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("discord-id"))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.webhook_enabled.get() && (Boolean)this.self_ping.get()))
            .build()
      );
   private final Setting<Boolean> show_esp = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("show-esp"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> esp_color = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("esp-color"))
               .defaultValue(new SettingColor(255, 165, 0, 100))
               .visible(this.show_esp::get))
            .build()
      );
   private final Setting<ShapeMode> shape_mode = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .defaultValue(ShapeMode.Both))
               .visible(this.show_esp::get))
            .build()
      );
   private final Setting<Boolean> tracers = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("tracers"))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> tracer_color = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("tracer-color"))
               .defaultValue(new SettingColor(255, 165, 0, 200))
               .visible(this.tracers::get))
            .build()
      );
   private final Setting<Boolean> only_render_new = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("only-render-new"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Double> render_distance = this.sg_render
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
               .name("render-distance"))
            .defaultValue(0.0)
            .min(0.0)
            .max(500.0)
            .build()
      );
   private final Set<ChunkPos> processed_chunks = Collections.synchronizedSet(new HashSet<>());
   private final Set<BlockPos> found_block_positions = Collections.synchronizedSet(new HashSet<>());
   private final Set<BlockPos> new_found_blocks = Collections.synchronizedSet(new HashSet<>());
   private final HttpClient http_client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public BlockNotifier() {
      super(ZincAddon.esp, "Block Notifier", "Notifies when specific blocks are detected with visual ESP and Discord logging.");
   }

   public void onActivate() {
      this.processed_chunks.clear();
      this.found_block_positions.clear();
      this.new_found_blocks.clear();
   }

   @EventHandler
   private void on_chunk_data(ChunkDataEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         ChunkPos chunk_pos = event.chunk().getPos();
         if (!this.processed_chunks.contains(chunk_pos)) {
            MeteorExecutor.execute(
               () -> {
                  Map<Block, String> found_blocks_map = new HashMap<>();
                  boolean has_target_blocks = false;
                  int startY = Math.max((Integer)this.min_y.get(), this.mc.world.getBottomY());
                  int endY = Math.min((Integer)this.max_y.get(), this.mc.world.getTopYInclusive());

                  for (int x = 0; x < 16; x++) {
                     for (int z = 0; z < 16; z++) {
                        for (int y = startY; y <= endY; y++) {
                           BlockPos pos = new BlockPos(chunk_pos.getStartX() + x, y, chunk_pos.getStartZ() + z);
                           if (this.mc.world == null) {
                              return;
                           }

                           Block block = this.mc.world.getBlockState(pos).getBlock();
                           if (((List)this.blocks_to_find.get()).contains(block)) {
                              String blockName = block.getName().getString();
                              if ((Boolean)this.showSpawnerType.get()
                                 && block == Blocks.field_10260
                                 && this.mc.world.getBlockEntity(pos) instanceof MobSpawnerBlockEntity spawner) {
                                 blockName = spawner.getLogic().getRenderedEntity(this.mc.world, pos).getType().getName().getString() + " Spawner";
                              }

                              found_blocks_map.put(block, blockName);
                              this.found_block_positions.add(pos);
                              this.new_found_blocks.add(pos);
                              has_target_blocks = true;
                           }
                        }
                     }
                  }

                  if (has_target_blocks) {
                     this.processed_chunks.add(chunk_pos);
                     this.mc.execute(() -> this.handle_blocks_found(chunk_pos, found_blocks_map));
                  }
               }
            );
         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && ((Boolean)this.show_esp.get() || (Boolean)this.tracers.get())) {
         Color color = new Color((Color)this.esp_color.get());
         Color tracerColorValue = new Color((Color)this.tracer_color.get());
         double maxDistance = (Double)this.render_distance.get();
         double s = 0.15;
         synchronized (this.found_block_positions) {
            for (BlockPos pos : this.found_block_positions) {
               if (!(Boolean)this.only_render_new.get() || this.new_found_blocks.contains(pos)) {
                  if (maxDistance > 0.0) {
                     double distance = Math.sqrt(this.mc.player.getBlockPos().getSquaredDistance(pos));
                     if (distance > maxDistance) {
                        continue;
                     }
                  }

                  if ((Boolean)this.show_esp.get()) {
                     event.renderer
                        .box(
                           pos.getX() + s,
                           pos.getY() + s,
                           pos.getZ() + s,
                           pos.getX() + 1 - s,
                           pos.getY() + 1 - s,
                           pos.getZ() + 1 - s,
                           color,
                           color,
                           (ShapeMode)this.shape_mode.get(),
                           0
                        );
                  }

                  if ((Boolean)this.tracers.get()) {
                     event.renderer
                        .line(
                           RenderUtils.center.x,
                           RenderUtils.center.y,
                           RenderUtils.center.z,
                           pos.getX() + 0.5,
                           pos.getY() + 0.5,
                           pos.getZ() + 0.5,
                           tracerColorValue
                        );
                  }
               }
            }
         }

         this.new_found_blocks.clear();
      }
   }

   private void handle_blocks_found(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      String message = this.build_notification_message(chunk_pos, found_blocks);
      switch ((BlockNotifier.Mode)this.notification_mode.get()) {
         case Chat:
            this.info(message, new Object[0]);
            break;
         case Toast:
            this.show_toast_notification(chunk_pos, found_blocks);
            break;
         case Both:
            this.info(message, new Object[0]);
            this.show_toast_notification(chunk_pos, found_blocks);
      }

      this.send_webhook_notification(chunk_pos, found_blocks);
      if ((Boolean)this.disconnect_on_find.get()) {
         this.handle_disconnection(found_blocks);
      }
   }

   private String build_notification_message(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      return "Target blocks found: "
         + String.join(", ", found_blocks.values())
         + " at "
         + (chunk_pos.x * 16 + 8)
         + ", "
         + (chunk_pos.z * 16 + 8);
   }

   private void show_toast_notification(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      Entry<Block, String> firstEntry = found_blocks.entrySet().iterator().next();
      ItemStack iconStack = new ItemStack(firstEntry.getKey().asItem());
      if (iconStack.isEmpty()) {
         iconStack = new ItemStack(Items.BARRIER);
      }

      this.mc
         .getToastManager()
         .add(new BlockNotifier.BlockNotifierToast(iconStack, Text.literal("Block Found"), Text.literal(firstEntry.getValue())));
   }

   private void send_webhook_notification(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      if ((Boolean)this.webhook_enabled.get() && !((String)this.webhook_url.get()).trim().isEmpty()) {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String server_info = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Singleplayer";
                  String ping_content = this.self_ping.get() && !((String)this.discord_id.get()).trim().isEmpty()
                     ? String.format("<@%s>", ((String)this.discord_id.get()).trim())
                     : "";
                  StringBuilder items_breakdown = new StringBuilder();

                  for (String name : found_blocks.values()) {
                     items_breakdown.append(String.format("• %s\\n", name));
                  }

                  String json_payload = String.format(
                     "{\"content\":\"%s\",\"username\":\"Block Notifier\",\"embeds\":[{\"title\":\"Block Notifier Alert\",\"description\":\"Detected at **%d, %d**\",\"color\":3447003,\"fields\":[{\"name\":\"Total Types\",\"value\":\"%d\",\"inline\":false},{\"name\":\"Breakdown\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Zinc Addon\"}}]}",
                     ping_content,
                     chunk_pos.x * 16 + 8,
                     chunk_pos.z * 16 + 8,
                     found_blocks.size(),
                     items_breakdown,
                     server_info,
                     System.currentTimeMillis() / 1000L
                  );
                  HttpRequest request = HttpRequest.newBuilder()
                     .uri(URI.create(((String)this.webhook_url.get()).trim()))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(json_payload))
                     .build();
                  this.http_client.send(request, BodyHandlers.discarding());
               } catch (Exception var8) {
               }
            }
         );
      }
   }

   private void handle_disconnection(Map<Block, String> found_blocks) {
      if (this.mc.getNetworkHandler() != null && this.mc.getNetworkHandler().getConnection() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("Target found " + found_blocks.values().iterator().next()));
         this.toggle();
      }
   }

   private static class BlockNotifierToast extends ZincToast {
      private final ItemStack icon;
      private final Text title;
      private final Text description;

      public BlockNotifierToast(ItemStack icon, Text title, Text description) {
         super(icon.getItem(), title.getString(), description.getString());
         this.icon = icon;
         this.title = title;
         this.description = description;
      }

      public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
         context.fill(0, 0, 160, 32, -1442840576);
         int grey = -8355712;
         context.fill(0, 0, 160, 1, grey);
         context.fill(0, 31, 160, 32, grey);
         context.fill(0, 1, 1, 31, grey);
         context.fill(159, 1, 160, 31, grey);
         if (this.icon != null && !this.icon.isEmpty()) {
            context.drawItem(this.icon, 8, 8);
         }

         if (this.title != null) {
            context.drawText(textRenderer, this.title, 32, 7, 16777215, false);
         }

         if (this.description != null) {
            context.drawText(textRenderer, this.description, 32, 18, -5592406, false);
         }
      }
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      private Mode() {
      }
   }
}
