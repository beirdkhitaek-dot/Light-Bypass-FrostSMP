package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.ShearsItem;
import net.minecraft.item.TridentItem;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.block.BannerBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.block.WallBannerBlock;
import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.RegistryKey;
import net.minecraft.item.MaceItem;

public class CollectibleESP extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgColors = this.settings.createGroup("Colors");
   private final List<Item> defaultPlayerItems = new ArrayList<>(
      List.of(
         Items.field_8805,
         Items.field_8058,
         Items.field_8348,
         Items.field_8285,
         Items.field_22027,
         Items.field_22028,
         Items.field_22029,
         Items.field_22030,
         Items.field_8833,
         Items.field_49814,
         Items.field_8547,
         Items.field_8802,
         Items.field_8556,
         Items.field_8377,
         Items.field_8250,
         Items.field_8527,
         Items.field_22022,
         Items.field_22025,
         Items.field_22024,
         Items.field_22023,
         Items.field_22026,
         Items.field_8367,
         Items.field_8301,
         Items.ENDER_CHEST,
         Items.field_8288,
         Items.field_8287,
         Items.SHULKER_BOX,
         Items.RED_SHULKER_BOX,
         Items.ORANGE_SHULKER_BOX,
         Items.YELLOW_SHULKER_BOX,
         Items.LIME_SHULKER_BOX,
         Items.GREEN_SHULKER_BOX,
         Items.CYAN_SHULKER_BOX,
         Items.LIGHT_BLUE_SHULKER_BOX,
         Items.BLUE_SHULKER_BOX,
         Items.PURPLE_SHULKER_BOX,
         Items.MAGENTA_SHULKER_BOX,
         Items.PINK_SHULKER_BOX,
         Items.WHITE_SHULKER_BOX,
         Items.LIGHT_GRAY_SHULKER_BOX,
         Items.GRAY_SHULKER_BOX,
         Items.BROWN_SHULKER_BOX,
         Items.BLACK_SHULKER_BOX
      )
   );
   private final Setting<Boolean> highlightBanners = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("Find Banners")).description("highlights banners.")).defaultValue(true)).build());
   private final Setting<Boolean> highlightMaps = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("Find Maps")).description("highlights item frames that contain maps.")).defaultValue(true)).build());
   private final Setting<Boolean> highlightItems = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("Find Items in Frames")).description("highlights item frames that contain items."))
               .defaultValue(true))
            .build()
      );
   private final Setting<List<Item>> items = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)new meteordevelopment.meteorclient.settings.ItemListSetting.Builder()
                        .name("item-checker"))
                     .description("Items to check for."))
                  .defaultValue(this.defaultPlayerItems))
               .visible(() -> (Boolean)this.highlightItems.get()))
            .build()
      );
   public final Setting<Boolean> enchants = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("enforce-item-enchants"))
                     .description("Requires that armor and tools must be enchanted for module to detect."))
                  .defaultValue(true))
               .visible(() -> (Boolean)this.highlightItems.get()))
            .build()
      );
   public final Setting<Boolean> certainenchants = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("find-certain-item-enchants"))
                     .description("Requires that armor and tools must be enchanted with these enchants."))
                  .defaultValue(false))
               .visible(() -> (Boolean)this.enchants.get()))
            .build()
      );
   private final Setting<Set<RegistryKey<Enchantment>>> toolenchants = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)new meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder()
                     .name("Mining Tool Enchants"))
                  .description("List of enchantments required."))
               .visible(() -> (Boolean)this.enchants.get() && (Boolean)this.certainenchants.get()))
            .defaultValue(new RegistryKey[]{Enchantments.field_9131, Enchantments.field_9119, Enchantments.field_9101})
            .build()
      );
   private final Setting<Set<RegistryKey<Enchantment>>> swordenchants = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)new meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder()
                     .name("Sword Enchants"))
                  .description("List of enchantments required."))
               .visible(() -> (Boolean)this.enchants.get() && (Boolean)this.certainenchants.get()))
            .defaultValue(new RegistryKey[]{Enchantments.field_9119, Enchantments.field_9101})
            .build()
      );
   private final Setting<Set<RegistryKey<Enchantment>>> armorenchants = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)new meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder()
                     .name("Armor Enchants"))
                  .description("List of enchantments required."))
               .visible(() -> (Boolean)this.enchants.get() && (Boolean)this.certainenchants.get()))
            .defaultValue(new RegistryKey[]{Enchantments.field_9119, Enchantments.field_9101})
            .build()
      );
   private final Setting<Set<RegistryKey<Enchantment>>> maceenchants = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)new meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder()
                     .name("Mace Enchants"))
                  .description("List of enchantments required."))
               .visible(() -> (Boolean)this.enchants.get() && (Boolean)this.certainenchants.get()))
            .defaultValue(new RegistryKey[]{Enchantments.field_9119, Enchantments.field_9101})
            .build()
      );
   private final Setting<Set<RegistryKey<Enchantment>>> tridentenchants = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)((meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder)new meteordevelopment.meteorclient.settings.EnchantmentListSetting.Builder()
                     .name("Trident Enchants"))
                  .description("List of enchantments required."))
               .visible(() -> (Boolean)this.enchants.get() && (Boolean)this.certainenchants.get()))
            .defaultValue(new RegistryKey[]{Enchantments.field_9119, Enchantments.field_9101})
            .build()
      );
   private final Setting<SettingColor> mapColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("map-color"))
               .description("fill color for item frames containing maps."))
            .defaultValue(new SettingColor(255, 255, 0, 50, true))
            .build()
      );
   private final Setting<SettingColor> mapOutlineColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("map-outline-color"))
               .description("outline color for item frames containing maps."))
            .defaultValue(new SettingColor(255, 255, 0, 255, true))
            .build()
      );
   private final Setting<SettingColor> itemColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("item-color"))
               .description("fill color for item frames containing items."))
            .defaultValue(new SettingColor(255, 255, 0, 50))
            .build()
      );
   private final Setting<SettingColor> itemOutlineColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("item-outline-color"))
               .description("outline color for item frames containing items."))
            .defaultValue(new SettingColor(255, 255, 0, 255))
            .build()
      );
   private final Setting<SettingColor> bannerColor = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("banner-fill"))
               .description("fill color for banners."))
            .defaultValue(new SettingColor(255, 0, 0, 50))
            .build()
      );
   private final Setting<SettingColor> bannerOutline = this.sgColors
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("banner-outline"))
               .description("outline color for banners."))
            .defaultValue(new SettingColor(255, 0, 0, 255))
            .build()
      );

   public CollectibleESP() {
      super(ZincAddon.esp, "CollectibleESP", "Highlights collectible items in item frames and banners!");
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.world != null && this.mc.player != null) {
         if ((Boolean)this.highlightMaps.get() || (Boolean)this.highlightItems.get()) {
            for (Entity frame : this.mc.world.getEntities()) {
               if (frame instanceof ItemFrameEntity itemframe) {
                  boolean renderedFrame = false;
                  if ((Boolean)this.highlightMaps.get() && itemframe.getHeldItemStack().getItem().getTranslationKey().equals("item.minecraft.filled_map")) {
                     float pitch = itemframe.getPitch();
                     Box box;
                     if (pitch != 90.0F && pitch != -90.0F) {
                        if (itemframe.getHorizontalFacing() != Direction.field_11034 && itemframe.getHorizontalFacing() != Direction.field_11039) {
                           box = itemframe.getBoundingBox().expand(0.12, 0.12, 0.01);
                        } else {
                           box = itemframe.getBoundingBox().expand(0.01, 0.12, 0.12);
                        }
                     } else {
                        box = itemframe.getBoundingBox().expand(0.12, 0.01, 0.12);
                     }

                     Color fill = new Color((Color)this.mapColor.get());
                     Color outline = new Color((Color)this.mapOutlineColor.get());
                     event.renderer.box(box, fill, outline, ShapeMode.Both, 0);
                     renderedFrame = true;
                  }

                  if (!renderedFrame && (Boolean)this.highlightItems.get() && !this.shouldSkip(itemframe.getHeldItemStack())) {
                     float pitch = itemframe.getPitch();
                     Box box;
                     if (pitch != 90.0F && pitch != -90.0F) {
                        if (itemframe.getHorizontalFacing() != Direction.field_11034 && itemframe.getHorizontalFacing() != Direction.field_11039) {
                           box = itemframe.getBoundingBox().expand(0.12, 0.12, 0.01);
                        } else {
                           box = itemframe.getBoundingBox().expand(0.01, 0.12, 0.12);
                        }
                     } else {
                        box = itemframe.getBoundingBox().expand(0.12, 0.01, 0.12);
                     }

                     Color fill = new Color((Color)this.itemColor.get());
                     Color outline = new Color((Color)this.itemOutlineColor.get());
                     event.renderer.box(box, fill, outline, ShapeMode.Both, 0);
                  }
               }
            }
         }

         if ((Boolean)this.highlightBanners.get()) {
            int renderDistance = (Integer)this.mc.options.getViewDistance().getValue();
            int playerChunkX = this.mc.player.getChunkPos().x;
            int playerChunkZ = this.mc.player.getChunkPos().z;

            for (int chunkX = playerChunkX - renderDistance; chunkX <= playerChunkX + renderDistance; chunkX++) {
               for (int chunkZ = playerChunkZ - renderDistance; chunkZ <= playerChunkZ + renderDistance; chunkZ++) {
                  WorldChunk chunk = this.mc.world.method_8497(chunkX, chunkZ);
                  if (chunk != null) {
                     for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (be instanceof BannerBlockEntity banner) {
                           BlockPos pos = banner.getPos();
                           BlockState state = this.mc.world.getBlockState(pos);
                           Color fill = new Color((Color)this.bannerColor.get());
                           Color outline = new Color((Color)this.bannerOutline.get());
                           if (state.contains(WallBannerBlock.FACING)) {
                              Direction facing = (Direction)state.get(WallBannerBlock.FACING);
                              double centerX = pos.getX() + 0.5;
                              double centerZ = pos.getZ() + 0.5;
                              double offset = 0.1;
                              double depth = 0.03;
                              double width = 0.45;
                              double y1 = pos.getY() - 0.95;
                              double y2 = pos.getY() + 0.85;
                              Box box;
                              switch (facing) {
                                 case field_11043:
                                    box = new Box(
                                       centerX - width, y1, pos.getZ() + 1 - offset - depth, centerX + width, y2, pos.getZ() + 1 - offset
                                    );
                                    break;
                                 case field_11035:
                                    box = new Box(
                                       centerX - width, y1, pos.getZ() + offset, centerX + width, y2, pos.getZ() + offset + depth
                                    );
                                    break;
                                 case field_11039:
                                    box = new Box(
                                       pos.getX() + 1 - offset - depth, y1, centerZ - width, pos.getX() + 1 - offset, y2, centerZ + width
                                    );
                                    break;
                                 case field_11034:
                                    box = new Box(
                                       pos.getX() + offset, y1, centerZ - width, pos.getX() + offset + depth, y2, centerZ + width
                                    );
                                    break;
                                 default:
                                    continue;
                              }

                              event.renderer.box(box, fill, outline, ShapeMode.Both, 0);
                           } else if (state.contains(BannerBlock.ROTATION)) {
                              int rotation = (Integer)state.get(BannerBlock.ROTATION);
                              double centerX = pos.getX() + 0.5;
                              double centerZ = pos.getZ() + 0.5;
                              double y1 = pos.getY();
                              double y2 = pos.getY() + 1.85;
                              double angle = Math.toRadians(rotation % 16 * 22.5);
                              double width = 0.45;
                              double depth = -0.05;
                              double outlineOffset = 0.02;
                              double dxx = depth * Math.sin(angle);
                              double dzz = depth * Math.cos(angle);
                              double x1 = centerX - width * Math.cos(angle) + dxx;
                              double z1 = centerZ - width * Math.sin(angle) - dzz;
                              double x2 = centerX + width * Math.cos(angle) + dxx;
                              double z2 = centerZ + width * Math.sin(angle) - dzz;
                              event.renderer.quad(x1, y1, z1, x1, y2, z1, x2, y2, z2, x2, y1, z2, fill);
                              double ox = outlineOffset * Math.sin(angle);
                              double oz = outlineOffset * Math.cos(angle);
                              double ox1 = x1 - ox;
                              double oz1 = z1 + oz;
                              double ox2 = x2 - ox;
                              double oz2 = z2 + oz;
                              double ox3 = x2 + ox;
                              double oz3 = z2 - oz;
                              double ox4 = x1 + ox;
                              double oz4 = z1 - oz;
                              event.renderer.quad(ox1, y2, oz1, ox2, y2, oz2, ox3, y2, oz3, ox4, y2, oz4, outline);
                              event.renderer.quad(ox4, y1, oz4, ox3, y1, oz3, ox2, y1, oz2, ox1, y1, oz1, outline);
                              event.renderer.quad(ox1, y1, oz1, ox1, y2, oz1, ox4, y2, oz4, ox4, y1, oz4, outline);
                              event.renderer.quad(ox2, y1, oz2, ox3, y1, oz3, ox3, y2, oz3, ox2, y2, oz2, outline);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static boolean isTool(ItemStack itemStack) {
      return itemStack.isIn(ItemTags.field_42612)
         || itemStack.isIn(ItemTags.field_42613)
         || itemStack.isIn(ItemTags.field_42614)
         || itemStack.isIn(ItemTags.field_42615)
         || itemStack.getItem() instanceof ShearsItem
         || itemStack.getItem() instanceof FlintAndSteelItem;
   }

   public static boolean isArmor(ItemStack itemStack) {
      return itemStack.isIn(ItemTags.field_48297)
         || itemStack.isIn(ItemTags.field_48296)
         || itemStack.isIn(ItemTags.field_48295)
         || itemStack.isIn(ItemTags.field_48294);
   }

   public boolean shouldSkip(ItemStack stack) {
      boolean skip = false;
      if ((Boolean)this.enchants.get()) {
         if (!(Boolean)this.certainenchants.get()
            && (
               isTool(stack)
                  || isArmor(stack)
                  || stack.isIn(ItemTags.field_42611)
                  || stack.getItem() instanceof FishingRodItem
                  || stack.getItem() instanceof FlintAndSteelItem
                  || stack.getItem() instanceof MaceItem
                  || stack.getItem() instanceof ShearsItem
                  || stack.getItem() instanceof ShieldItem
                  || stack.getItem() instanceof TridentItem
            )
            && stack.isEnchantable()
            && stack.getEnchantments().isEmpty()) {
            skip = true;
         } else if ((Boolean)this.certainenchants.get()) {
            if (isTool(stack)) {
               skip = this.compareEnchants(stack, this.toolenchants);
            } else if (stack.isIn(ItemTags.field_42611)) {
               skip = this.compareEnchants(stack, this.swordenchants);
            } else if (isArmor(stack)) {
               skip = this.compareEnchants(stack, this.armorenchants);
            } else if (stack.getItem() instanceof MaceItem) {
               skip = this.compareEnchants(stack, this.maceenchants);
            } else if (stack.getItem() instanceof TridentItem) {
               skip = this.compareEnchants(stack, this.tridentenchants);
            }
         }
      }

      if (!((List)this.items.get()).contains(stack.getItem())) {
         skip = true;
      }

      return skip;
   }

   private boolean compareEnchants(ItemStack stack, Setting<Set<RegistryKey<Enchantment>>> enchantsetting) {
      boolean skip = false;
      Set<RegistryKey<Enchantment>> itemenchants = new HashSet<>();
      stack.getEnchantments().getEnchantments().forEach(enchantment -> itemenchants.add((RegistryKey)enchantment.getKey().get()));

      for (RegistryKey<Enchantment> enchantKey : (Set<RegistryKey<Enchantment>>)enchantsetting.get()) {
         if (!itemenchants.contains(enchantKey)) {
            skip = true;
            break;
         }
      }

      return skip;
   }
}
