package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.Item.TooltipContext;

public class AutoBlazeRodOrder extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<String> minPrice = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("min-price")).description("Minimum price to deliver blaze rods for.")).defaultValue("350")).build());
   private final Setting<Integer> actionDelay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("action-delay"))
                  .description("Ticks between major actions."))
               .defaultValue(1))
            .min(1)
            .sliderMax(10)
            .build()
      );
   private AutoBlazeRodOrder.Stage stage = AutoBlazeRodOrder.Stage.IDLE;
   private int delayCounter = 0;
   private int lastActionTicks = 0;
   private final int MAX_STAGNANT_TICKS = 80;

   public AutoBlazeRodOrder() {
      super(ZincAddon.Zinc, "auto-blazerod-order", "Automatically flips Blaze Rods from shop to orders.");
   }

   public void onActivate() {
      this.stage = AutoBlazeRodOrder.Stage.OPEN_SHOP;
      this.resetTimer(0);
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.lastActionTicks++;
         if (this.lastActionTicks >= 80) {
            if (this.mc.currentScreen != null) {
               this.mc.player.closeHandledScreen();
            }

            this.stage = AutoBlazeRodOrder.Stage.OPEN_SHOP;
            this.resetTimer(10);
         } else if (this.delayCounter > 0) {
            this.delayCounter--;
         } else {
            switch (this.stage) {
               case OPEN_SHOP:
                  this.mc.getNetworkHandler().sendChatCommand("shop");
                  this.stage = AutoBlazeRodOrder.Stage.SHOP_CATEGORY;
                  this.resetTimer(10);
                  break;
               case SHOP_CATEGORY:
                  if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                     ScreenHandler handlerx = screen.getScreenHandler();

                     for (Slot slotxxxxx : handlerx.slots) {
                        if (this.isShopCategory(slotxxxxx.getStack())) {
                           this.mc.interactionManager.clickSlot(handlerx.syncId, slotxxxxx.id, 0, SlotActionType.PICKUP, this.mc.player);
                           this.stage = AutoBlazeRodOrder.Stage.SHOP_ITEM;
                           this.resetTimer((Integer)this.actionDelay.get());
                           return;
                        }
                     }
                  }
                  break;
               case SHOP_ITEM:
                  if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                     ScreenHandler handlerx = screen.getScreenHandler();

                     for (Slot slotxxxx : handlerx.slots) {
                        if (slotxxxx.inventory != this.mc.player.getInventory() && this.isBlazeRod(slotxxxx.getStack())) {
                           this.mc.interactionManager.clickSlot(handlerx.syncId, slotxxxx.id, 0, SlotActionType.PICKUP, this.mc.player);
                           this.stage = AutoBlazeRodOrder.Stage.BUYING;
                           this.resetTimer((Integer)this.actionDelay.get());
                           return;
                        }
                     }
                  }
                  break;
               case BUYING:
                  if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                     ScreenHandler handler = screen.getScreenHandler();
                     if (this.isInventoryFull()) {
                        this.mc.player.closeHandledScreen();
                        this.stage = AutoBlazeRodOrder.Stage.OPEN_ORDERS;
                        this.resetTimer(10);
                        return;
                     }

                     int fallbackSlot = -1;

                     for (Slot slot : handler.slots) {
                        ItemStack stack = slot.getStack();
                        if (this.isConfirmButton(stack)) {
                           if (stack.getCount() == 64) {
                              this.mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                              this.checkBuyStatus();
                              return;
                           }

                           if (stack.getCount() == 1) {
                              fallbackSlot = slot.id;
                           }
                        }
                     }

                     if (fallbackSlot != -1) {
                        this.mc.interactionManager.clickSlot(handler.syncId, fallbackSlot, 0, SlotActionType.PICKUP, this.mc.player);
                        this.checkBuyStatus();
                     }
                  }
                  break;
               case OPEN_ORDERS:
                  this.mc.getNetworkHandler().sendChatCommand("orders blaze rod");
                  this.stage = AutoBlazeRodOrder.Stage.SELECT_ORDERS;
                  this.resetTimer(10);
                  break;
               case SELECT_ORDERS:
                  if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                     ScreenHandler handlerx = screen.getScreenHandler();

                     for (Slot slotxxx : handlerx.slots) {
                        if (slotxxx.inventory != this.mc.player.getInventory() && this.isBlazeRod(slotxxx.getStack())) {
                           double price = this.getOrderPrice(slotxxx.getStack());
                           if (price >= this.parsePrice((String)this.minPrice.get())) {
                              this.mc.interactionManager.clickSlot(handlerx.syncId, slotxxx.id, 0, SlotActionType.PICKUP, this.mc.player);
                              this.stage = AutoBlazeRodOrder.Stage.FILLING;
                              this.resetTimer((Integer)this.actionDelay.get());
                              return;
                           }
                        }
                     }
                  }
                  break;
               case FILLING:
                  if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                     ScreenHandler handlerx = screen.getScreenHandler();
                     boolean foundAny = false;

                     for (int i = 0; i < 36; i++) {
                        ItemStack invStack = this.mc.player.getInventory().getStack(i);
                        if (this.isBlazeRod(invStack)) {
                           for (Slot slotx : handlerx.slots) {
                              if (slotx.inventory == this.mc.player.getInventory() && slotx.getIndex() == i) {
                                 this.mc.interactionManager.clickSlot(handlerx.syncId, slotx.id, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                                 foundAny = true;
                                 this.lastActionTicks = 0;
                                 break;
                              }
                           }

                           if (foundAny) {
                              break;
                           }
                        }
                     }

                     if (!foundAny) {
                        this.mc.player.closeHandledScreen();
                        this.stage = AutoBlazeRodOrder.Stage.ESC_PAUSE;
                        this.resetTimer(5);
                     } else {
                        this.delayCounter = 1;
                     }
                  }
                  break;
               case ESC_PAUSE:
                  this.stage = AutoBlazeRodOrder.Stage.CONFIRM;
                  this.resetTimer(2);
                  break;
               case CONFIRM:
                  if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                     ScreenHandler handlerx = screen.getScreenHandler();

                     for (Slot slotxx : handlerx.slots) {
                        if (this.isConfirmButton(slotxx.getStack())) {
                           this.mc.interactionManager.clickSlot(handlerx.syncId, slotxx.id, 0, SlotActionType.PICKUP, this.mc.player);
                           this.stage = AutoBlazeRodOrder.Stage.DONE;
                           this.resetTimer((Integer)this.actionDelay.get());
                           return;
                        }
                     }
                  }
                  break;
               case DONE:
                  if (this.mc.currentScreen != null) {
                     this.mc.player.closeHandledScreen();
                  }

                  this.stage = AutoBlazeRodOrder.Stage.OPEN_SHOP;
                  this.resetTimer(10);
            }
         }
      }
   }

   private void checkBuyStatus() {
      if (this.isInventoryFull()) {
         this.mc.player.closeHandledScreen();
         this.stage = AutoBlazeRodOrder.Stage.OPEN_ORDERS;
         this.resetTimer(10);
      } else {
         this.resetTimer(1);
      }

      this.lastActionTicks = 0;
   }

   private void resetTimer(int ticks) {
      this.delayCounter = ticks;
      this.lastActionTicks = 0;
   }

   private boolean isInventoryFull() {
      for (int i = 0; i < 36; i++) {
         if (this.mc.player.getInventory().getStack(i).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private boolean isShopCategory(ItemStack stack) {
      String name = stack.getName().getString().toLowerCase();
      return stack.getItem() == Items.NETHERRACK || name.contains("nether");
   }

   private boolean isBlazeRod(ItemStack stack) {
      return !stack.isEmpty() && stack.getItem() == Items.field_8894;
   }

   private boolean isConfirmButton(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         String name = stack.getName().getString().toLowerCase();
         return name.contains("confirm")
            || name.contains("buy")
            || name.contains("deliver")
            || stack.getItem() == Items.LIME_STAINED_GLASS_PANE
            || stack.getItem() == Items.GREEN_STAINED_GLASS_PANE;
      }
   }

   private double getOrderPrice(ItemStack stack) {
      List<Text> tooltip = stack.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC);
      Pattern p = Pattern.compile("\\$([\\d,]+(?:\\.[\\d]+)?)([kmb])?", 2);

      for (Text line : tooltip) {
         Matcher m = p.matcher(line.getString().replace(",", ""));
         if (m.find()) {
            double val = Double.parseDouble(m.group(1));
            String suffix = m.group(2) != null ? m.group(2).toLowerCase() : "";

            return val * switch (suffix) {
               case "k" -> 1000;
               case "m" -> 1000000;
               case "b" -> 1000000000;
               default -> 1;
            };
         }
      }

      return -1.0;
   }

   private double parsePrice(String s) {
      try {
         s = s.toLowerCase().replace(",", "");
         double mul = 1.0;
         if (s.endsWith("k")) {
            mul = 1000.0;
            s = s.substring(0, s.length() - 1);
         } else if (s.endsWith("m")) {
            mul = 1000000.0;
            s = s.substring(0, s.length() - 1);
         } else if (s.endsWith("b")) {
            mul = 1.0E9;
            s = s.substring(0, s.length() - 1);
         }

         return Double.parseDouble(s) * mul;
      } catch (Exception var4) {
         return -1.0;
      }
   }

   private static enum Stage {
      IDLE,
      OPEN_SHOP,
      SHOP_CATEGORY,
      SHOP_ITEM,
      BUYING,
      OPEN_ORDERS,
      SELECT_ORDERS,
      FILLING,
      ESC_PAUSE,
      CONFIRM,
      DONE;

      private Stage() {
      }
   }
}
