package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.KeybindSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.client.option.KeyBinding;

public class WindPearlMacro extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Keybind> activateKey = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("activate-key")).defaultValue(Keybind.fromKey(71))).build());
   private final Setting<Boolean> autoRotate = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("auto-rotate"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> windDelay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("wind-delay"))
               .defaultValue(1))
            .min(1)
            .max(10)
            .build()
      );
   private int prevSlot = -1;
   private int timer = 0;
   private boolean active = false;
   private boolean prevPressed = false;
   private WindPearlMacro.Stage stage = WindPearlMacro.Stage.WAITING;
   private KeyBinding activeHotbarKey = null;

   public WindPearlMacro() {
      super(ZincAddon.pvp, "wind-pearl-macro", "Hardcoded Keybind: Scroll Sim + Pearl + Wind Charge.");
   }

   public void onActivate() {
      this.resetMacro();
      this.prevPressed = false;
   }

   public void onDeactivate() {
      this.releaseKeys();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null) {
         boolean isPressed = ((Keybind)this.activateKey.get()).isPressed();
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (risingEdge && this.mc.currentScreen == null) {
            this.startMacro();
         }

         if (this.active) {
            switch (this.stage) {
               case THROW_PEARL:
                  int slotx = this.findItem(Items.field_8634);
                  if (slotx != -1) {
                     this.hardwareFullSwap(slotx);
                     if ((Boolean)this.autoRotate.get()) {
                        this.mc.player.setPitch(-90.0F);
                     }

                     this.mc.options.useKey.setPressed(true);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.stage = WindPearlMacro.Stage.DELAY;
                     this.timer = 0;
                  } else {
                     this.resetMacro();
                  }
                  break;
               case DELAY:
                  if (this.timer == 1) {
                     this.mc.options.useKey.setPressed(false);
                  }

                  if (this.timer >= (Integer)this.windDelay.get() + 1) {
                     this.stage = WindPearlMacro.Stage.THROW_WIND;
                  }

                  this.timer++;
                  break;
               case THROW_WIND:
                  int slot = this.findItem(Items.field_49098);
                  if (slot != -1) {
                     this.hardwareFullSwap(slot);
                     if ((Boolean)this.autoRotate.get()) {
                        this.mc.player.setPitch(-90.0F);
                     }

                     this.mc.options.useKey.setPressed(true);
                     ((IMinecraftClient)this.mc).zinc$doItemUse();
                     this.stage = WindPearlMacro.Stage.CLEANUP;
                     this.timer = 0;
                  } else {
                     this.resetMacro();
                  }
                  break;
               case CLEANUP:
                  if (this.timer >= 1) {
                     this.releaseKeys();
                     if (this.prevSlot != -1) {
                        this.hardwareFullSwap(this.prevSlot);
                     }

                     this.resetMacro();
                  }

                  this.timer++;
            }
         }
      }
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }

      if (this.mc.options != null) {
         this.mc.options.useKey.setPressed(false);
      }
   }

   private int findItem(Item item) {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(item)) {
            return i;
         }
      }

      return -1;
   }

   private void startMacro() {
      if (!this.active) {
         this.active = true;
         this.prevSlot = this.mc.player.getInventory().getSelectedSlot();
         this.stage = WindPearlMacro.Stage.THROW_PEARL;
         this.timer = 0;
      }
   }

   private void resetMacro() {
      this.active = false;
      this.stage = WindPearlMacro.Stage.WAITING;
      this.releaseKeys();
   }

   private static enum Stage {
      WAITING,
      THROW_PEARL,
      DELAY,
      THROW_WIND,
      CLEANUP;

      private Stage() {
      }
   }
}
