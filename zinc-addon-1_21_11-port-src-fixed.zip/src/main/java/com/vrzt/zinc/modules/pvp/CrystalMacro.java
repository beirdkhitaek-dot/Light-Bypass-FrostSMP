package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.hit.HitResult;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;

public class CrystalMacro extends Module {
   private final SettingGroup sgPause = this.settings.createGroup("Pause & Switch");
   private final Setting<Boolean> stopOnKill = this.sgPause.add(((Builder)((Builder)new Builder().name("stop-on-kill")).defaultValue(true)).build());
   private final Setting<Integer> pauseTime = this.sgPause
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("pause-time-ms"))
               .defaultValue(500))
            .min(0)
            .sliderMax(2000)
            .build()
      );
   private long resumeTime;
   private boolean isPaused;
   private int attackDelay;
   private boolean isSimulatingAttack = false;

   public CrystalMacro() {
      super(ZincAddon.pvp, "CrystalMacro", "Uses doAttack/doItemUse invokers for undetectable simulation.");
   }

   public void onActivate() {
      this.isPaused = false;
      this.attackDelay = 0;
   }

   public void onDeactivate() {
      this.releaseKeys();
   }

   @EventHandler
   private void onTick(Pre event) {
      this.releaseKeys();
      if (this.mc.player != null && this.mc.world != null && this.mc.currentScreen == null) {
         if (this.isPaused) {
            if (System.currentTimeMillis() >= this.resumeTime) {
               this.isPaused = false;
            }
         } else if (this.mc.options.useKey.isPressed()) {
            HitResult target = this.mc.crosshairTarget;
            if (target != null) {
               if (target instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystalEntity) {
                  if (this.attackDelay <= 0) {
                     this.simulateLeftClick();
                     this.attackDelay = ThreadLocalRandom.current().nextInt(1, 3);
                  } else {
                     this.attackDelay--;
                  }
               } else if (target instanceof BlockHitResult bhr && this.isResistant(bhr.getBlockPos()) && this.getCrystalHand() != null) {
                  ((IMinecraftClient)this.mc).zinc$doItemUse();
               }
            }
         }
      }
   }

   private void simulateLeftClick() {
      this.mc.options.attackKey.setPressed(true);
      this.isSimulatingAttack = true;
      ((IMinecraftClient)this.mc).zinc$doAttack();
   }

   private void releaseKeys() {
      if (this.isSimulatingAttack) {
         this.mc.options.attackKey.setPressed(false);
         this.isSimulatingAttack = false;
      }
   }

   @EventHandler
   private void onPacketReceive(Receive event) {
      if ((Boolean)this.stopOnKill.get()
         && event.packet instanceof EntityStatusS2CPacket packet
         && packet.getStatus() == 3
         && packet.getEntity(this.mc.world) instanceof PlayerEntity p
         && p != this.mc.player
         && p.distanceTo(this.mc.player) < 6.0F) {
         this.isPaused = true;
         this.resumeTime = System.currentTimeMillis() + ((Integer)this.pauseTime.get()).intValue() + ThreadLocalRandom.current().nextInt(0, 200);
      }
   }

   private Hand getCrystalHand() {
      if (this.mc.player.getMainHandStack().isOf(Items.field_8301)) {
         return Hand.field_5808;
      } else {
         return this.mc.player.getOffHandStack().isOf(Items.field_8301) ? Hand.field_5810 : null;
      }
   }

   private boolean isResistant(BlockPos pos) {
      return this.mc.world.getBlockState(pos).isOf(Blocks.field_10540)
         || this.mc.world.getBlockState(pos).isOf(Blocks.field_9987);
   }
}
