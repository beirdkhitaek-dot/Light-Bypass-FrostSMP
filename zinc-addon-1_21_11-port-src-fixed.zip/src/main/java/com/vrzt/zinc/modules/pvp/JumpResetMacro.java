package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public class JumpResetMacro extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgFilter = this.settings.createGroup("Filter");
   private final Setting<Integer> jumpDuration = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("jump-duration")).defaultValue(100)).min(10).sliderMax(500).build());
   private final Setting<Integer> jumpDelay = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("jump-delay")).defaultValue(300)).min(50).sliderMax(1000).build());
   private final Setting<Boolean> requireOnGround = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("require-on-ground"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("chat-feedback"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> onlyOnPlayers = this.sgFilter
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("only-on-players"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> onlyMeleeHits = this.sgFilter
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("only-melee-hits"))
                  .defaultValue(false))
               .visible(this.onlyOnPlayers::get))
            .build()
      );
   private final Setting<JumpResetMacro.WeaponType> weaponType = this.sgFilter
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("weapon-type"))
                  .defaultValue(JumpResetMacro.WeaponType.ANY_MELEE))
               .visible(() -> (Boolean)this.onlyOnPlayers.get() && (Boolean)this.onlyMeleeHits.get()))
            .build()
      );
   private boolean jumping = false;
   private long jumpStartTime = 0L;
   private long lastJumpTime = 0L;
   private int lastHurtTime = 0;
   private PlayerEntity lastAttacker = null;

   public JumpResetMacro() {
      super(ZincAddon.pvp, "jump-reset-macro", "Legit jump reset using GLFW key simulation.");
   }

   public void onActivate() {
      this.jumping = false;
      this.lastHurtTime = this.mc.player != null ? this.mc.player.hurtTime : 0;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         long currentTime = System.currentTimeMillis();
         if (this.mc.player.hurtTime > 0 && this.mc.player.hurtTime != this.lastHurtTime) {
            DamageSource source = this.mc.player.getRecentDamageSource();
            PlayerEntity attacker = source != null && source.getAttacker() instanceof PlayerEntity ? (PlayerEntity)source.getAttacker() : null;
            boolean validAttacker = !(Boolean)this.onlyOnPlayers.get()
               || attacker != null && (!(Boolean)this.onlyMeleeHits.get() || this.isValidWeapon(attacker.getMainHandStack()));
            boolean groundValid = !(Boolean)this.requireOnGround.get() || this.mc.player.isOnGround();
            boolean delayValid = currentTime - this.lastJumpTime >= ((Integer)this.jumpDelay.get()).intValue();
            if (validAttacker && groundValid && delayValid) {
               this.simulateJumpKey(true);
               this.jumping = true;
               this.jumpStartTime = currentTime;
               this.lastJumpTime = currentTime;
               this.lastAttacker = attacker;
               if ((Boolean)this.chatFeedback.get()) {
                  this.info("Jump reset triggered" + (attacker != null ? " by " + attacker.getName().getString() : ""), new Object[0]);
               }
            }
         }

         this.lastHurtTime = this.mc.player.hurtTime;
         if (this.jumping && currentTime - this.jumpStartTime >= ((Integer)this.jumpDuration.get()).intValue()) {
            this.simulateJumpKey(false);
            this.jumping = false;
         }
      }
   }

   private void simulateJumpKey(boolean press) {
      if (this.mc.getWindow() != null && this.mc.keyboard != null) {
         int key = 32;
         int action = press ? 1 : 0;
         ((com.vrzt.zinc.mixins.IKeyboardAccessor)this.mc.keyboard).invokeOnKey(this.mc.getWindow().getHandle(), action, new net.minecraft.client.input.KeyInput(key, 0, 0));
      }
   }

   private boolean isValidWeapon(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         String path = Registries.ITEM.getId(stack.getItem()).getPath().toLowerCase();

         return switch ((JumpResetMacro.WeaponType)this.weaponType.get()) {
            case ANY_MELEE -> path.contains("sword") || path.contains("axe") || path.contains("mace");
            case SWORDS_ONLY -> path.contains("sword");
            case AXES_ONLY -> path.contains("axe");
            case SWORDS_AND_AXES -> path.contains("sword") || path.contains("axe");
            case ALL_TOOLS -> path.contains("sword")
               || path.contains("axe")
               || path.contains("pickaxe")
               || path.contains("shovel")
               || path.contains("hoe")
               || path.contains("mace");
         };
      }
   }

   private static enum WeaponType {
      ANY_MELEE("Any Melee"),
      SWORDS_ONLY("Swords Only"),
      AXES_ONLY("Axes Only"),
      SWORDS_AND_AXES("Swords & Axes"),
      ALL_TOOLS("All Tools");

      private final String title;

      private WeaponType(String title) {
         this.title = title;
      }

      @Override
      public String toString() {
         return this.title;
      }
   }
}
