package com.vrzt.zinc.modules.Render;

import com.vrzt.zinc.ZincAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class CreeperOrbit extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgFriends = this.settings.createGroup("Friends");
   private final Setting<Integer> creeperCount = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("creeper-count")).description("Number of creeper ghosts orbiting each player.")).defaultValue(3))
            .min(1)
            .sliderMax(10)
            .build()
      );
   private final Setting<Double> orbitSpeed = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("speed"))
               .description("Speed of the orbiting creepers."))
            .defaultValue(2.0)
            .min(0.1)
            .sliderMax(10.0)
            .build()
      );
   private final Setting<Double> radius = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("radius"))
               .description("Orbit radius around players."))
            .defaultValue(1.5)
            .min(0.5)
            .sliderMax(4.0)
            .build()
      );
   private final Setting<SettingColor> color = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("color"))
               .description("Color of the creeper ghosts."))
            .defaultValue(new SettingColor(0, 255, 100, 150))
            .build()
      );
   private final Setting<Double> bobbingHeight = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("bobbing-height"))
               .description("How much the creepers bob up and down."))
            .defaultValue(0.3)
            .min(0.0)
            .sliderMax(1.0)
            .build()
      );
   private final Setting<Double> size = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("size"))
               .description("Size of the creeper ghosts."))
            .defaultValue(0.12)
            .min(0.05)
            .sliderMax(0.3)
            .build()
      );
   private final Setting<Boolean> friendColorEnabled = this.sgFriends
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("use-friend-color"))
                  .description("Use a different color for friends."))
               .defaultValue(true))
            .build()
      );
   private final Setting<SettingColor> friendColor = this.sgFriends
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("friend-color"))
                  .description("Color for friends' creeper ghosts."))
               .defaultValue(new SettingColor(0, 150, 255, 150))
               .visible(this.friendColorEnabled::get))
            .build()
      );

   public CreeperOrbit() {
      super(ZincAddon.Render, "creeper-orbit", "Miniature creeper ghosts orbiting around players.");
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.world != null) {
         for (PlayerEntity player : this.mc.world.getPlayers()) {
            if (player != this.mc.player) {
               Color creeperColor = (Color)this.color.get();
               if ((Boolean)this.friendColorEnabled.get() && Friends.get().isFriend(player)) {
                  creeperColor = (Color)this.friendColor.get();
               }

               double tickDelta = event.tickDelta;
               double posX = MathHelper.lerp(tickDelta, player.lastRenderX, player.getX());
               double posY = MathHelper.lerp(tickDelta, player.lastRenderY, player.getY());
               double posZ = MathHelper.lerp(tickDelta, player.lastRenderZ, player.getZ());
               double time = System.currentTimeMillis() / 1000.0 * (Double)this.orbitSpeed.get();

               for (int i = 0; i < this.creeperCount.get(); i++) {
                  double angle = time + (Math.PI * 2) / ((Integer)this.creeperCount.get()).intValue() * i;
                  double x = posX + Math.cos(angle) * (Double)this.radius.get();
                  double z = posZ + Math.sin(angle) * (Double)this.radius.get();
                  double y = posY + player.getHeight() / 2.0F + Math.sin(angle) * (Double)this.bobbingHeight.get();
                  this.renderCreeperGhost(event, x, y, z, angle, creeperColor);
               }
            }
         }
      }
   }

   private void renderCreeperGhost(Render3DEvent event, double x, double y, double z, double angle, Color c) {
      Color black = new Color(0, 0, 0, 255);
      double headSize = (Double)this.size.get();
      event.renderer.box(x - headSize, y, z - headSize, x + headSize, y + headSize * 2.0, z + headSize, c, c, ShapeMode.Both, 0);
      double bodyWidth = headSize * 0.67;
      double bodyHeight = headSize * 1.5;
      event.renderer.box(x - bodyWidth, y - bodyHeight, z - bodyWidth, x + bodyWidth, y, z + bodyWidth, c, c, ShapeMode.Both, 0);
      double lookX = Math.cos(angle + Math.PI);
      double lookZ = Math.sin(angle + Math.PI);
      this.renderFacePixel(event, x, y, z, lookX, lookZ, 0.05, 0.16, 0.02, black);
      this.renderFacePixel(event, x, y, z, lookX, lookZ, -0.05, 0.16, 0.02, black);
      this.renderFacePixel(event, x, y, z, lookX, lookZ, 0.0, 0.08, 0.03, black);
      this.renderFacePixel(event, x, y, z, lookX, lookZ, 0.03, 0.06, 0.02, black);
      this.renderFacePixel(event, x, y, z, lookX, lookZ, -0.03, 0.06, 0.02, black);
   }

   private void renderFacePixel(
      Render3DEvent event, double x, double y, double z, double lx, double lz, double lateralOffset, double vertOffset, double pixelSize, Color color
   ) {
      double px = x + lx * 0.125 + -lz * lateralOffset;
      double pz = z + lz * 0.125 + lx * lateralOffset;
      double py = y + vertOffset;
      event.renderer.box(px - pixelSize, py - pixelSize, pz - pixelSize, px + pixelSize, py + pixelSize, pz + pixelSize, color, color, ShapeMode.Both, 0);
   }
}
