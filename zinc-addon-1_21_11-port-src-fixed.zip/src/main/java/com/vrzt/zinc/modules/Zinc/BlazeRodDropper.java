package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.Locale;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

public class BlazeRodDropper extends Module {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private BlazeRodDropper.Stage stage = BlazeRodDropper.Stage.NONE;
   private long stageStart = 0L;
   private int bulkBuyCount = 0;
   private static final int MAX_BULK_BUY = 5;
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<Boolean> notifications = this.sgGeneral
      .add(((Builder)((Builder)((Builder)new Builder().name("notifications")).description("Show detailed notifications.")).defaultValue(true)).build());

   public BlazeRodDropper() {
      super(ZincAddon.Zinc, "BlazeRodDropper", "Automatically buys blaze rods and drops them instantly");
   }

   public void onActivate() {
      this.stage = BlazeRodDropper.Stage.SHOP;
      this.stageStart = System.currentTimeMillis();
      this.bulkBuyCount = 0;
      if ((Boolean)this.notifications.get()) {
         this.info("BlazeRodDropper activated! Zero delay mode.");
      }
   }

   public void onDeactivate() {
      this.stage = BlazeRodDropper.Stage.NONE;
   }

   @EventHandler
   private void onTick(Post event) {
      if (this.mc.player != null && this.mc.world != null) {
         long now = System.currentTimeMillis();
         switch (this.stage) {
            case NONE:
            default:
               break;
            case SHOP:
               ChatUtils.sendPlayerMsg("/shop");
               this.stage = BlazeRodDropper.Stage.SHOP_END;
               this.stageStart = now;
               break;
            case SHOP_END:
               if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                  ScreenHandler handler = screen.getScreenHandler();

                  for (Slot slot : handler.slots) {
                     ItemStack stack = slot.getStack();
                     if (!stack.isEmpty() && this.isNetherrack(stack)) {
                        this.mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.PICKUP, this.mc.player);
                        this.stage = BlazeRodDropper.Stage.SHOP_SHULKER;
                        this.stageStart = now;
                        this.bulkBuyCount = 0;
                        return;
                     }
                  }

                  if (now - this.stageStart > 3000L) {
                     this.mc.player.closeHandledScreen();
                     this.stage = BlazeRodDropper.Stage.SHOP;
                     this.stageStart = now;
                  }
               }
               break;
            case SHOP_SHULKER:
               if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                  ScreenHandler handler = screen.getScreenHandler();
                  boolean foundBlazeRod = false;

                  for (Slot slotx : handler.slots) {
                     ItemStack stack = slotx.getStack();
                     if (!stack.isEmpty() && this.isBlazeRod(stack)) {
                        for (int i = 0; i < 5; i++) {
                           this.mc.interactionManager.clickSlot(handler.syncId, slotx.id, 0, SlotActionType.PICKUP, this.mc.player);
                        }

                        foundBlazeRod = true;
                        this.bulkBuyCount++;
                        break;
                     }
                  }

                  if (foundBlazeRod) {
                     this.stage = BlazeRodDropper.Stage.SHOP_CONFIRM;
                     this.stageStart = now;
                     return;
                  }

                  if (now - this.stageStart > 1500L) {
                     this.mc.player.closeHandledScreen();
                     this.stage = BlazeRodDropper.Stage.SHOP;
                     this.stageStart = now;
                  }
               }
               break;
            case SHOP_CONFIRM:
               if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
                  ScreenHandler handler = screen.getScreenHandler();
                  boolean foundGreen = false;

                  for (Slot slotxx : handler.slots) {
                     ItemStack stack = slotxx.getStack();
                     if (!stack.isEmpty() && this.isGreenGlass(stack)) {
                        for (int i = 0; i < 64; i++) {
                           this.mc.interactionManager.clickSlot(handler.syncId, slotxx.id, 0, SlotActionType.PICKUP, this.mc.player);
                        }

                        foundGreen = true;
                        break;
                     }
                  }

                  if (foundGreen) {
                     this.stage = BlazeRodDropper.Stage.SHOP_CHECK_FULL;
                     this.stageStart = now;
                     return;
                  }

                  if (now - this.stageStart > 800L) {
                     this.stage = BlazeRodDropper.Stage.SHOP_SHULKER;
                     this.stageStart = now;
                  }
               }
               break;
            case SHOP_CHECK_FULL:
               if (now - this.stageStart > 200L) {
                  if (!this.isInventoryFull() && this.bulkBuyCount < 5) {
                     this.stage = BlazeRodDropper.Stage.SHOP_SHULKER;
                     this.stageStart = now;
                  } else {
                     this.mc.player.closeHandledScreen();
                     this.stage = BlazeRodDropper.Stage.SHOP_EXIT;
                     this.stageStart = now;
                  }
               }
               break;
            case SHOP_EXIT:
               if (this.mc.currentScreen == null) {
                  this.mc.setScreen(new InventoryScreen(this.mc.player));
                  this.stage = BlazeRodDropper.Stage.DROP_ITEMS;
                  this.stageStart = now;
               }

               if (now - this.stageStart > 5000L) {
                  this.mc.player.closeHandledScreen();
                  this.stage = BlazeRodDropper.Stage.SHOP;
                  this.stageStart = now;
               }
               break;
            case DROP_ITEMS:
               if (!(this.mc.currentScreen instanceof InventoryScreen)) {
                  this.mc.setScreen(new InventoryScreen(this.mc.player));
               }

               ScreenHandler handler = this.mc.player.playerScreenHandler;
               boolean foundAnyToDrop = false;

               for (int i = 9; i <= 44; i++) {
                  ItemStack stack = handler.getSlot(i).getStack();
                  if (this.isBlazeRod(stack)) {
                     this.mc.interactionManager.clickSlot(handler.syncId, i, 1, SlotActionType.THROW, this.mc.player);
                     foundAnyToDrop = true;
                     break;
                  }
               }

               if (!foundAnyToDrop) {
                  if ((Boolean)this.notifications.get()) {
                     this.info("Inventory empty. Restarting loop immediately...");
                  }

                  this.mc.player.closeHandledScreen();
                  this.stage = BlazeRodDropper.Stage.SHOP;
                  this.stageStart = now;
               }
         }
      }
   }

   private boolean isNetherrack(ItemStack stack) {
      return stack.getItem() == Items.NETHERRACK || stack.getName().getString().toLowerCase(Locale.ROOT).contains("netherrack");
   }

   private boolean isBlazeRod(ItemStack stack) {
      return !stack.isEmpty() && stack.getItem() == Items.field_8894;
   }

   private boolean isGreenGlass(ItemStack stack) {
      return stack.getItem() == Items.LIME_STAINED_GLASS_PANE || stack.getItem() == Items.GREEN_STAINED_GLASS_PANE;
   }

   private boolean isInventoryFull() {
      for (int i = 9; i <= 44; i++) {
         if (this.mc.player.playerScreenHandler.getSlot(i).getStack().isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public void info(String message, Object... args) {
      if ((Boolean)this.notifications.get()) {
         ChatUtils.info(String.format(message, args), new Object[0]);
      }
   }

   private static enum Stage {
      NONE,
      SHOP,
      SHOP_END,
      SHOP_SHULKER,
      SHOP_CONFIRM,
      SHOP_CHECK_FULL,
      SHOP_EXIT,
      DROP_ITEMS;

      private Stage() {
      }
   }
}
