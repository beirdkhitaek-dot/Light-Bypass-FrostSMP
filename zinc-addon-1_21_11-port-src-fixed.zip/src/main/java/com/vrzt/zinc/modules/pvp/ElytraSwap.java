package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.client.option.KeyBinding;

public class ElytraSwap extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<ElytraSwap.Mode> activationMode = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("activation-mode")).defaultValue(ElytraSwap.Mode.Keybind)).build());
   private final Setting<Keybind> customKey = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()
                     .name("custom-key"))
                  .defaultValue(Keybind.fromKey(73)))
               .visible(() -> this.activationMode.get() == ElytraSwap.Mode.Keybind))
            .build()
      );
   private final Setting<Boolean> chatFeedback = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("chat-feedback"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> restoreSlot = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("restore-slot"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> equipDelay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                  .name("equip-delay"))
               .defaultValue(1))
            .min(0)
            .max(10)
            .build()
      );
   private int tickCounter = 0;
   private int previousSlot = -1;
   private int targetSlot = -1;
   private boolean prevPressed = false;
   private KeyBinding activeHotbarKey = null;
   private ElytraSwap.State state = ElytraSwap.State.IDLE;

   public ElytraSwap() {
      super(ZincAddon.pvp, "elytra-swap", "Hardware Scroll Elytra: Uses scroll sim and Zinc invoker.");
   }

   public void onActivate() {
      this.state = ElytraSwap.State.IDLE;
      this.prevPressed = false;
      this.tickCounter = 0;
   }

   public void onDeactivate() {
      this.releaseKeys();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.options != null) {
         boolean isPressed = this.isActivated();
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (this.state == ElytraSwap.State.IDLE) {
            if (risingEdge && this.mc.currentScreen == null) {
               this.previousSlot = this.mc.player.getInventory().getSelectedSlot();
               this.state = ElytraSwap.State.FINDING_SLOT;
            }
         } else {
            switch (this.state) {
               case FINDING_SLOT:
                  this.targetSlot = this.findTargetSlot();
                  if (this.targetSlot == -1) {
                     if ((Boolean)this.chatFeedback.get()) {
                        this.error("No elytra or chestplate found!", new Object[0]);
                     }

                     this.state = ElytraSwap.State.IDLE;
                     return;
                  }

                  this.state = ElytraSwap.State.SWAPPING;
                  break;
               case SWAPPING:
                  this.hardwareFullSwap(this.targetSlot);
                  this.tickCounter = 0;
                  this.state = ElytraSwap.State.WAITING;
                  break;
               case WAITING:
                  this.tickCounter++;
                  if (this.tickCounter >= (Integer)this.equipDelay.get()) {
                     this.tickCounter = 0;
                     this.state = ElytraSwap.State.RIGHT_CLICKING;
                  }
                  break;
               case RIGHT_CLICKING:
                  this.mc.options.useKey.setPressed(true);
                  ((IMinecraftClient)this.mc).zinc$doItemUse();
                  this.state = ElytraSwap.State.RESTORING;
                  break;
               case RESTORING:
                  this.mc.options.useKey.setPressed(false);
                  if ((Boolean)this.restoreSlot.get() && this.previousSlot != -1) {
                     this.hardwareFullSwap(this.previousSlot);
                  }

                  this.state = ElytraSwap.State.COMPLETE;
                  break;
               case COMPLETE:
                  if ((Boolean)this.chatFeedback.get()) {
                     this.info("Equipped.", new Object[0]);
                  }

                  this.releaseKeys();
                  this.state = ElytraSwap.State.IDLE;
            }
         }
      }
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         if (this.activeHotbarKey != null) {
            this.activeHotbarKey.setPressed(false);
         }

         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void releaseKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }

      if (this.mc.options != null) {
         this.mc.options.useKey.setPressed(false);
      }
   }

   private boolean isActivated() {
      return switch ((ElytraSwap.Mode)this.activationMode.get()) {
         case Keybind -> ((Keybind)this.customKey.get()).isPressed();
         case RightClick -> this.mc.options.useKey.isPressed();
         case LeftClick -> this.mc.options.attackKey.isPressed();
      };
   }

   private int findTargetSlot() {
      for (int i = 0; i < 9; i++) {
         ItemStack stack = this.mc.player.getInventory().getStack(i);
         if (!stack.isEmpty() && (stack.isOf(Items.field_8833) || this.isChestplate(stack))) {
            return i;
         }
      }

      return -1;
   }

   private boolean isChestplate(ItemStack stack) {
      return stack.getItem().toString().contains("chestplate");
   }

   public static enum Mode {
      Keybind,
      RightClick,
      LeftClick;

      private Mode() {
      }
   }

   private static enum State {
      IDLE,
      FINDING_SLOT,
      SWAPPING,
      WAITING,
      RIGHT_CLICKING,
      RESTORING,
      COMPLETE;

      private State() {
      }
   }
}
