package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ItemSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.text.Text;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item.TooltipContext;

public class AHSniper extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgEnchants = this.settings.createGroup("Enchantments");
   private final SettingGroup sgWebhook = this.settings.createGroup("Discord Webhook");
   private final SettingGroup sgAutoSell = this.settings.createGroup("Auto Sell");
   private final Setting<Item> snipingItem = this.sgGeneral
      .add(((Builder)((Builder)new Builder().name("sniping-item")).defaultValue(Items.field_22024)).build());
   private final Setting<String> targetItemName = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                  .name("item-name"))
               .defaultValue("drill"))
            .build()
      );
   private final Setting<String> maxPrice = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                  .name("max-price"))
               .defaultValue("13m"))
            .build()
      );
   private final Setting<Boolean> filterLowTime = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("filter-low-time"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Double> minTimeHours = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("min-time-hours"))
               .defaultValue(24.0)
               .min(1.0)
               .sliderMax(72.0)
               .max(72.0)
               .visible(this.filterLowTime::get))
            .build()
      );
   private final Setting<Boolean> topLeftOnly = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("top-left-only"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> requireEnchants = this.sgEnchants
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("require-enchants"))
               .defaultValue(false))
            .build()
      );
   private final Setting<Boolean> allowFortuneIII = this.sgEnchants
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("allow-fortune-3"))
                  .defaultValue(true))
               .visible(this.requireEnchants::get))
            .build()
      );
   private final Setting<Boolean> allowSilkTouch = this.sgEnchants
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("allow-silk-touch"))
                  .defaultValue(true))
               .visible(this.requireEnchants::get))
            .build()
      );
   private final Setting<Boolean> autoSell = this.sgAutoSell
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("auto-sell"))
               .defaultValue(true))
            .build()
      );
   private final Setting<String> sellPrice = this.sgAutoSell
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("sell-price"))
                  .defaultValue("14m"))
               .visible(this.autoSell::get))
            .build()
      );
   private final Setting<Boolean> webhookEnabled = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                  .name("webhook-enabled"))
               .defaultValue(false))
            .build()
      );
   private final Setting<String> webhookUrl = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                     .name("webhook-url"))
                  .defaultValue(""))
               .visible(this.webhookEnabled::get))
            .build()
      );
   private final Setting<Boolean> selfPing = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("self-ping"))
                     .description("Ping yourself in the webhook message."))
                  .defaultValue(false))
               .visible(this.webhookEnabled::get))
            .build()
      );
   private final Setting<String> discordId = this.sgWebhook
      .add(
         ((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)new meteordevelopment.meteorclient.settings.StringSetting.Builder()
                        .name("discord-id"))
                     .description("Your Discord user ID for pinging."))
                  .defaultValue(""))
               .visible(() -> (Boolean)this.webhookEnabled.get() && (Boolean)this.selfPing.get()))
            .build()
      );
   private final int SELL_DELAY_TICKS = 2;
   private boolean isProcessing = false;
   private boolean hasClickedBuy = false;
   private boolean hasClickedConfirm = false;
   private int delayCounter = 2;
   private int navigationDelayCounter = 1;
   private boolean purchaseAttempted = false;
   private boolean sellingPhase = false;
   private int sellingDelayCounter = 1;
   private double attemptedPrice = 1.0;
   private int previousItemCount = 2;
   private int inventoryCheckTicks = 2;
   private int lastActionTicks = 2;
   private final int MAX_STAGNANT_TICKS = 2200;
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   public AHSniper() {
      super(ZincAddon.Zinc, "AH-Sniper", "Advanced sniper with Shulker/Curse Blacklist and Auto-Sell.");
   }

   public void onActivate() {
      if (this.mc.player == null) {
         this.toggle();
      } else {
         AutoReconnect autoReconnect = (AutoReconnect)Modules.get().get(AutoReconnect.class);
         if (autoReconnect != null && !autoReconnect.isActive()) {
            autoReconnect.toggle();
         }

         this.resetState();
         this.previousItemCount = this.countItemInInventory();
      }
   }

   public void onDeactivate() {
      this.resetState();
   }

   private void resetState() {
      this.isProcessing = this.hasClickedBuy = this.hasClickedConfirm = this.purchaseAttempted = this.sellingPhase = false;
      this.delayCounter = this.navigationDelayCounter = this.inventoryCheckTicks = this.sellingDelayCounter = this.lastActionTicks = 0;
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.lastActionTicks++;
         if (this.lastActionTicks >= 2200) {
            if (this.mc.currentScreen != null) {
               this.mc.currentScreen.close();
            }

            this.resetState();
            this.openAH();
         } else if (this.delayCounter > 0) {
            this.delayCounter--;
         } else if (this.navigationDelayCounter > 0) {
            this.navigationDelayCounter--;
         } else if (this.sellingDelayCounter > 0) {
            this.sellingDelayCounter--;
            if (this.sellingDelayCounter == 0) {
               this.performAutoSell();
            }
         } else if (this.purchaseAttempted) {
            this.inventoryCheckTicks++;
            int current = this.countItemInInventory();
            if (this.inventoryCheckTicks >= 10) {
               if (current > this.previousItemCount) {
                  this.lastActionTicks = 0;
                  if ((Boolean)this.autoSell.get()) {
                     this.sellingPhase = true;
                     this.purchaseAttempted = false;
                     if (this.mc.currentScreen != null) {
                        this.mc.currentScreen.close();
                     }

                     this.sellingDelayCounter = 2;
                  } else {
                     this.purchaseAttempted = false;
                  }

                  this.sendWebhook(current - this.previousItemCount);
                  this.previousItemCount = current;
                  this.hasClickedBuy = this.hasClickedConfirm = false;
               } else if (this.inventoryCheckTicks >= 50) {
                  this.purchaseAttempted = false;
                  this.hasClickedBuy = this.hasClickedConfirm = false;
               }
            }
         } else if (!this.sellingPhase) {
            ScreenHandler sh = this.mc.player.currentScreenHandler;
            if (this.isConfirmationGUI(sh)) {
               this.handleConfirmationGUI((GenericContainerScreenHandler)sh);
            } else {
               if (sh instanceof GenericContainerScreenHandler ch) {
                  if (ch.getRows() == 6) {
                     if ((Boolean)this.topLeftOnly.get()) {
                        this.processMainPageTopLeftOnly(ch);
                     } else {
                        this.processMainPage(ch);
                     }
                  } else if (ch.getRows() == 3) {
                     this.processSingleView(ch);
                  }
               } else {
                  this.openAH();
               }
            }
         }
      }
   }

   private boolean isValidItem(ItemStack s, double price) {
      if (s.isEmpty()) {
         return false;
      } else if (s.isIn(ItemTags.field_54293)) {
         return false;
      } else {
         double max = this.parsePrice((String)this.maxPrice.get());
         if (price != -1.0 && !(price > max)) {
            if ((Boolean)this.filterLowTime.get()) {
               double timeLeft = this.parseSelfDestructTime(s);
               if (timeLeft == -1.0 || timeLeft < (Double)this.minTimeHours.get()) {
                  return false;
               }
            }

            ItemEnchantmentsComponent enchants = (ItemEnchantmentsComponent)s.get(DataComponentTypes.field_49633);
            boolean hasFortune3 = false;
            boolean hasSilkTouch = false;
            if (enchants != null) {
               for (RegistryEntry<Enchantment> entry : enchants.getEnchantments()) {
                  String id = entry.getKey().isPresent() ? ((RegistryKey)entry.getKey().get()).getValue().toString() : "";
                  if (id.contains("vanishing_curse") || id.contains("binding_curse")) {
                     return false;
                  }

                  String name = ((Enchantment)entry.comp_349()).comp_2686().getString().toLowerCase();
                  int level = enchants.getLevel(entry);
                  if (name.contains("fortune") && level >= 3) {
                     hasFortune3 = true;
                  }

                  if (name.contains("silk touch")) {
                     hasSilkTouch = true;
                  }
               }
            }

            return !(Boolean)this.requireEnchants.get()
               || (Boolean)this.allowFortuneIII.get() && hasFortune3
               || (Boolean)this.allowSilkTouch.get() && hasSilkTouch;
         } else {
            return false;
         }
      }
   }

   private void handleConfirmationGUI(GenericContainerScreenHandler handler) {
      if (!this.hasClickedConfirm) {
         if (this.clickConfirm(handler)) {
            this.lastActionTicks = 0;
            this.hasClickedConfirm = true;
            this.purchaseAttempted = true;
            this.inventoryCheckTicks = 0;
            this.previousItemCount = this.countItemInInventory();
         }
      }
   }

   private boolean clickConfirm(GenericContainerScreenHandler h) {
      for (int i = 0; i < h.slots.size(); i++) {
         ItemStack stack = h.getSlot(i).getStack();
         if (this.isConfirmButton(stack)) {
            this.mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.PICKUP, this.mc.player);
            return true;
         }
      }

      return false;
   }

   private void performAutoSell() {
      double price = this.parsePrice((String)this.sellPrice.get());
      if (price <= 0.0) {
         this.sellingPhase = false;
      } else {
         this.mc.getNetworkHandler().sendChatCommand(String.format("ah sell %s", (int)price));
         this.sellingPhase = false;
         this.navigationDelayCounter = 5;
         this.lastActionTicks = 0;
      }
   }

   private boolean isConfirmationGUI(ScreenHandler screenHandler) {
      if (!(screenHandler instanceof GenericContainerScreenHandler)) {
         return false;
      } else if (this.mc.currentScreen instanceof GenericContainerScreen screen) {
         String title = screen.getTitle().getString().toLowerCase();
         if (!title.contains("confirm") && !title.contains("sure") && !title.contains("buy") && !title.contains("purchase")) {
            GenericContainerScreenHandler h = (GenericContainerScreenHandler)screenHandler;

            for (int i = 0; i < Math.min(h.slots.size(), 54); i++) {
               if (this.isConfirmButton(h.getSlot(i).getStack())) {
                  return true;
               }
            }

            return false;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean isConfirmButton(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         String name = stack.getName().getString().toLowerCase();
         Item item = stack.getItem();
         return !name.contains("confirm") && !name.contains("buy") && !name.contains("yes") && !name.contains("accept")
            ? item == Items.LIME_STAINED_GLASS_PANE
               || item == Items.GREEN_STAINED_GLASS_PANE
               || item == Items.LIME_WOOL
               || item == Items.GREEN_WOOL
               || item == Items.field_8131
               || item == Items.field_8408
               || item == Items.EMERALD_BLOCK
               || item == Items.field_8687
            : true;
      }
   }

   private void processMainPageTopLeftOnly(GenericContainerScreenHandler h) {
      ItemStack btn = h.getSlot(47).getStack();
      if (!btn.isEmpty() && btn.getName().getString().contains("Recently Listed")) {
         this.mc.interactionManager.clickSlot(h.syncId, 47, 0, SlotActionType.PICKUP, this.mc.player);
         this.navigationDelayCounter = 1;
      } else {
         ItemStack topLeft = h.getSlot(0).getStack();
         double price = this.getPrice(topLeft);
         if (!topLeft.isEmpty() && topLeft.isOf((Item)this.snipingItem.get()) && this.isValidItem(topLeft, price)) {
            this.mc.interactionManager.clickSlot(h.syncId, 0, 0, SlotActionType.PICKUP, this.mc.player);
            this.trackPurchase(price);
            this.hasClickedBuy = true;
         } else {
            this.mc.interactionManager.clickSlot(h.syncId, 49, 0, SlotActionType.PICKUP, this.mc.player);
            this.navigationDelayCounter = 1;
         }
      }
   }

   private void processMainPage(GenericContainerScreenHandler h) {
      ItemStack btn = h.getSlot(47).getStack();
      if (!btn.isEmpty() && btn.getName().getString().contains("Recently Listed")) {
         this.mc.interactionManager.clickSlot(h.syncId, 47, 0, SlotActionType.PICKUP, this.mc.player);
         this.navigationDelayCounter = 1;
      } else {
         for (int i = 0; i < 44; i++) {
            ItemStack s = h.getSlot(i).getStack();
            if (s.isOf((Item)this.snipingItem.get())) {
               double price = this.getPrice(s);
               if (price != -1.0 && this.isValidItem(s, price)) {
                  if (this.isProcessing) {
                     if (this.hasClickedBuy) {
                        return;
                     }

                     this.mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.PICKUP, this.mc.player);
                     this.trackPurchase(price);
                     this.hasClickedBuy = true;
                     this.isProcessing = false;
                     return;
                  }

                  this.isProcessing = true;
                  return;
               }
            }
         }

         this.mc.interactionManager.clickSlot(h.syncId, 49, 0, SlotActionType.PICKUP, this.mc.player);
         this.navigationDelayCounter = 1;
      }
   }

   private void processSingleView(GenericContainerScreenHandler h) {
      ItemStack s = h.getSlot(13).getStack();
      if (s.isOf((Item)this.snipingItem.get())) {
         double price = this.getPrice(s);
         if (price != -1.0 && this.isValidItem(s, price) && !this.hasClickedBuy) {
            this.mc.interactionManager.clickSlot(h.syncId, 15, 0, SlotActionType.PICKUP, this.mc.player);
            this.trackPurchase(price);
            this.hasClickedBuy = true;
         }
      }
   }

   private void openAH() {
      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().sendChatCommand("ah " + (String)this.targetItemName.get());
         this.navigationDelayCounter = 10;
         this.lastActionTicks = 0;
      }
   }

   private void trackPurchase(double price) {
      this.attemptedPrice = price;
      this.inventoryCheckTicks = 0;
   }

   private double getPrice(ItemStack s) {
      if (s.isEmpty()) {
         return -1.0;
      } else {
         List<Text> lines = s.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC);
         if (lines != null && !lines.isEmpty()) {
            Pattern p = Pattern.compile("\\$([\\d,]+(?:\\.[\\d]+)?)([kmb]?)", 2);

            for (Text line : lines) {
               String str = line.getString().replace(",", "").toLowerCase();
               if (str.contains("trillion") || str.contains(" t")) {
                  return 9.99999999999999E14;
               }

               Matcher m = p.matcher(str);
               if (m.find()) {
                  double val = Double.parseDouble(m.group(1));
                  String var10 = m.group(2);

                  return val * switch (var10) {
                     case "k" -> 1000;
                     case "m" -> 1000000;
                     case "b" -> 1000000000;
                     default -> 1;
                  };
               }
            }

            return -1.0;
         } else {
            return -1.0;
         }
      }
   }

   private double parsePrice(String priceStr) {
      if (priceStr != null && !priceStr.isEmpty()) {
         String s = priceStr.trim().toLowerCase().replace(",", "");
         double mul = 1.0;
         if (s.endsWith("b")) {
            mul = 1.0E9;
            s = s.substring(0, s.length() - 1);
         } else if (s.endsWith("m")) {
            mul = 1000000.0;
            s = s.substring(0, s.length() - 1);
         } else if (s.endsWith("k")) {
            mul = 1000.0;
            s = s.substring(0, s.length() - 1);
         }

         try {
            return Double.parseDouble(s) * mul;
         } catch (Exception var6) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   private String formatPrice(double p) {
      if (p >= 1.0E9) {
         return String.format("%.1fB", p / 1.0E9);
      } else if (p >= 1000000.0) {
         return String.format("%.1fM", p / 1000000.0);
      } else {
         return p >= 1000.0 ? String.format("%.1fK", p / 1000.0) : String.format("%.0f", p);
      }
   }

   private double parseTimeString(String timeStr) {
      if (timeStr != null && !timeStr.trim().isEmpty()) {
         double totalHours = 0.0;
         timeStr = timeStr.toLowerCase();
         boolean foundComponent = false;
         Matcher days = Pattern.compile("(\\d+)\\s*d").matcher(timeStr);
         if (days.find()) {
            totalHours += Double.parseDouble(days.group(1)) * 24.0;
            foundComponent = true;
         }

         Matcher hrs = Pattern.compile("(\\d+)\\s*h").matcher(timeStr);
         if (hrs.find()) {
            totalHours += Double.parseDouble(hrs.group(1));
            foundComponent = true;
         }

         return foundComponent ? totalHours : -1.0;
      } else {
         return -1.0;
      }
   }

   private double parseSelfDestructTime(ItemStack stack) {
      List<Text> tooltip = stack.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC);
      String full = tooltip.stream().<String>map(Text::getString).reduce("", (a, b) -> a + "\n" + b).toLowerCase();
      Pattern p = Pattern.compile("self\\s*destruct[:\\s]*([\\d\\s+d+h+m+s]+)");
      Matcher m = p.matcher(full);
      return m.find() ? this.parseTimeString(m.group(1).trim()) : -1.0;
   }

   private int countItemInInventory() {
      if (this.mc.player == null) {
         return 0;
      } else {
         int count = 0;

         for (int i = 0; i < this.mc.player.getInventory().size(); i++) {
            ItemStack s = this.mc.player.getInventory().getStack(i);
            if (s.isOf((Item)this.snipingItem.get())) {
               count += s.getCount();
            }
         }

         return count;
      }
   }

   private void sendWebhook(int qty) {
      if ((Boolean)this.webhookEnabled.get() && !((String)this.webhookUrl.get()).isEmpty()) {
         CompletableFuture.runAsync(
            () -> {
               try {
                  String ping_content = this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()
                     ? String.format("<@%s> ", ((String)this.discordId.get()).trim())
                     : "";
                  String json = String.format(
                     "{\"content\":\"%s**%s** sniped %dx **%s** for **%s**! No curses detected. Shulkers ignored.\"}",
                     ping_content,
                     this.mc.player.getName().getString(),
                     qty,
                     ((Item)this.snipingItem.get()).getName().getString(),
                     this.formatPrice(this.attemptedPrice)
                  );
                  HttpRequest req = HttpRequest.newBuilder()
                     .uri(URI.create((String)this.webhookUrl.get()))
                     .header("Content-Type", "application/json")
                     .POST(BodyPublishers.ofString(json))
                     .build();
                  this.httpClient.send(req, BodyHandlers.discarding());
               } catch (Exception var5) {
               }
            }
         );
      }
   }
}
