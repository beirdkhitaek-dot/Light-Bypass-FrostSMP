package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincAddon;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.fluid.Fluids;

public class CobblestoneESP extends Module {
   private final SettingGroup sgGeneral = this.settings.createGroup("General");
   private final SettingGroup sgVisual = this.settings.createGroup("Visual");
   private final SettingGroup sgFiltering = this.settings.createGroup("Filtering");
   private final SettingGroup sgRange = this.settings.createGroup("Range");
   private final SettingGroup sgThreading = this.settings.createGroup("Threading");
   private final SettingGroup sgPerformance = this.settings.createGroup("Performance");
   private final Setting<Boolean> showCobblestone = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("show-cobblestone")).description("Enable highlighting of cobblestone blocks")).defaultValue(true))
            .build()
      );
   private final Setting<Integer> mossyAvoidRadius = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("mossy-avoid-radius"))
                  .description("Radius to avoid around mossy cobblestone (blocks)"))
               .defaultValue(12))
            .min(1)
            .max(32)
            .sliderRange(1, 32)
            .build()
      );
   private final Setting<Integer> lavaAvoidRadius = this.sgFiltering
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("lava-avoid-radius"))
                  .description("Radius to avoid around lava (blocks)"))
               .defaultValue(12))
            .min(1)
            .max(32)
            .sliderRange(1, 32)
            .build()
      );
   private final Setting<SettingColor> cobblestoneColor = this.sgVisual
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("cobblestone-color"))
               .description("Color for normal cobblestone"))
            .defaultValue(new SettingColor(128, 128, 128, 80))
            .build()
      );
   private final Setting<ShapeMode> shapeMode = this.sgVisual
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("shape-mode"))
                  .description("How the shapes are rendered"))
               .defaultValue(ShapeMode.Both))
            .build()
      );
   private final Setting<Boolean> tracers = this.sgVisual
      .add(((Builder)((Builder)((Builder)new Builder().name("tracers")).description("Draw tracers to cobblestone blocks")).defaultValue(false)).build());
   private final Setting<SettingColor> tracerColor = this.sgVisual
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("tracer-color"))
                  .description("Tracer color"))
               .defaultValue(new SettingColor(128, 128, 128, 200))
               .visible(this.tracers::get))
            .build()
      );
   private final Setting<Integer> minY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("min-y"))
                  .description("Minimum Y level to scan"))
               .defaultValue(-64))
            .min(-64)
            .max(320)
            .sliderRange(-64, 320)
            .build()
      );
   private final Setting<Integer> maxY = this.sgRange
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("max-y"))
                  .description("Maximum Y level to scan"))
               .defaultValue(128))
            .min(-64)
            .max(320)
            .sliderRange(-64, 320)
            .build()
      );
   private final Setting<Integer> chunkCleanupDistance = this.sgPerformance
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                     .name("chunk-cleanup-distance"))
                  .description("Remove blocks farther than this many chunks from player (0 = disabled)"))
               .defaultValue(3))
            .min(0)
            .max(8)
            .sliderRange(0, 8)
            .build()
      );
   private final Setting<Double> cleanupInterval = this.sgPerformance
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("cleanup-interval"))
               .description("How often to clean up far chunks (seconds)"))
            .defaultValue(5.0)
            .min(1.0)
            .max(30.0)
            .sliderRange(1.0, 30.0)
            .build()
      );
   private final Setting<Boolean> useThreading = this.sgThreading
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("enable-threading")).description("Use multi-threading for chunk scanning (better performance)"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Integer> threadPoolSize = this.sgThreading
      .add(
         ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("thread-pool-size"))
                     .description("Number of threads to use for scanning"))
                  .defaultValue(2))
               .min(1)
               .max(8)
               .sliderRange(1, 8)
               .visible(this.useThreading::get))
            .build()
      );
   private final Setting<Boolean> cobblestoneChat = this.sgThreading
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("chat-feedback")).description("Show chat notifications for non-ignored cobblestone"))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> limitChatSpam = this.sgThreading
      .add(
         ((Builder)((Builder)((Builder)((Builder)new Builder().name("limit-chat-spam")).description("Reduce chat spam when using threading"))
                  .defaultValue(true))
               .visible(() -> (Boolean)this.useThreading.get() && (Boolean)this.cobblestoneChat.get()))
            .build()
      );
   private final Set<BlockPos> cobblestonePositions = ConcurrentHashMap.newKeySet();
   private ExecutorService threadPool;
   private long lastCleanupTime = 0L;

   public CobblestoneESP() {
      super(ZincAddon.esp, "CobblestoneESP", "ESP for cobblestone that ignores blocks near mossy cobblestone or lava.");
   }

   public void onActivate() {
      if (this.mc.world != null) {
         if ((Boolean)this.useThreading.get()) {
            this.threadPool = Executors.newFixedThreadPool((Integer)this.threadPoolSize.get());
         }

         this.cobblestonePositions.clear();
         this.lastCleanupTime = System.currentTimeMillis();
         if ((Boolean)this.useThreading.get()) {
            for (Chunk chunk : Utils.chunks()) {
               if (chunk instanceof WorldChunk worldChunk) {
                  this.threadPool.submit(() -> this.scanChunk(worldChunk));
               }
            }

            if ((Boolean)this.cobblestoneChat.get()) {
               this.info("§7[§8Cobblestone ESP§7] §8Started scanning chunks in background...", new Object[0]);
            }
         } else {
            int foundCount = 0;

            for (Chunk chunkx : Utils.chunks()) {
               if (chunkx instanceof WorldChunk worldChunk) {
                  foundCount += this.scanChunk(worldChunk);
               }
            }

            if ((Boolean)this.cobblestoneChat.get()) {
               this.info("§7[§8Cobblestone ESP§7] §8Initial scan complete! Found " + foundCount + " valid cobblestone blocks.", new Object[0]);
            }
         }
      }
   }

   public void onDeactivate() {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         try {
            this.threadPool.shutdown();
            if (!this.threadPool.awaitTermination(2L, TimeUnit.SECONDS)) {
               this.threadPool.shutdownNow();
            }
         } catch (InterruptedException var2) {
            this.threadPool.shutdownNow();
         }

         this.threadPool = null;
      }

      if ((Boolean)this.cobblestoneChat.get()) {
         this.info("§7[§8Cobblestone ESP§7] §8Disabled. Cleared " + this.cobblestonePositions.size() + " block positions.", new Object[0]);
      }

      this.cobblestonePositions.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if ((Boolean)this.useThreading.get() && this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      } else {
         this.scanChunk(event.chunk());
      }
   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      BlockPos pos = event.pos;
      BlockState state = event.newState;
      Runnable updateTask = () -> {
         boolean wasPresent = this.cobblestonePositions.remove(pos);
         if (state.isOf(Blocks.field_9989)) {
            this.filterNearbyBlocks(pos, (Integer)this.mossyAvoidRadius.get());
         } else if (state.getFluidState().getFluid() == Fluids.LAVA) {
            this.filterNearbyBlocks(pos, (Integer)this.lavaAvoidRadius.get());
         } else {
            if (state.isOf(Blocks.field_10445)) {
               int y = pos.getY();
               if (y >= (Integer)this.minY.get() && y <= (Integer)this.maxY.get()) {
                  if (!this.shouldFilterCobblestone(pos)) {
                     if ((Integer)this.chunkCleanupDistance.get() <= 0 || this.mc.player == null) {
                        this.cobblestonePositions.add(pos);
                        if ((Boolean)this.cobblestoneChat.get() && !wasPresent && (!(Boolean)this.useThreading.get() || !(Boolean)this.limitChatSpam.get())) {
                           this.info(
                              "§7[§8Cobblestone ESP§7] §aValid cobblestone at " + pos.toShortString() + " (Total: " + this.cobblestonePositions.size() + ")",
                              new Object[0]
                           );
                        }
                     } else if (this.isWithinChunkDistance(pos, (Integer)this.chunkCleanupDistance.get())) {
                        this.cobblestonePositions.add(pos);
                        if ((Boolean)this.cobblestoneChat.get() && !wasPresent && (!(Boolean)this.useThreading.get() || !(Boolean)this.limitChatSpam.get())) {
                           this.info(
                              "§7[§8Cobblestone ESP§7] §aValid cobblestone at " + pos.toShortString() + " (Total: " + this.cobblestonePositions.size() + ")",
                              new Object[0]
                           );
                        }
                     }
                  } else if ((Boolean)this.cobblestoneChat.get() && wasPresent && (!(Boolean)this.useThreading.get() || !(Boolean)this.limitChatSpam.get())) {
                     this.info("§7[§8Cobblestone ESP§7] §cCobblestone at " + pos.toShortString() + " is now ignored (near mossy/lava)", new Object[0]);
                  }
               }
            }
         }
      };
      if ((Boolean)this.useThreading.get() && this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(updateTask);
      } else {
         updateTask.run();
      }
   }

   private int scanChunk(WorldChunk chunk) {
      if (this.mc.player == null) {
         return 0;
      } else {
         ChunkPos cpos = chunk.getPos();
         if ((Integer)this.chunkCleanupDistance.get() > 0) {
            ChunkPos playerChunk = new ChunkPos(this.mc.player.getBlockPos());
            if (!this.isWithinChunkDistance(cpos, playerChunk, (Integer)this.chunkCleanupDistance.get())) {
               return 0;
            }
         }

         int xStart = cpos.getStartX();
         int zStart = cpos.getStartZ();
         int yMin = Math.max(chunk.getBottomY(), (Integer)this.minY.get());
         int yMax = Math.min(chunk.getBottomY() + chunk.getHeight(), (Integer)this.maxY.get());
         Set<BlockPos> chunkCobblestone = new HashSet<>();
         Set<BlockPos> chunkMossyCobblestone = new HashSet<>();

         for (int x = xStart; x < xStart + 16; x++) {
            for (int z = zStart; z < zStart + 16; z++) {
               for (int y = yMin; y < yMax; y++) {
                  BlockPos pos = new BlockPos(x, y, z);
                  BlockState state = chunk.getBlockState(pos);
                  if (state.isOf(Blocks.field_10445)) {
                     chunkCobblestone.add(pos);
                  } else if (state.isOf(Blocks.field_9989)) {
                     chunkMossyCobblestone.add(pos);
                  }
               }
            }
         }

         int addedCount = 0;
         int ignoredCount = 0;

         for (BlockPos pos : chunkCobblestone) {
            if (!this.shouldFilterCobblestone(pos)) {
               if (((Integer)this.chunkCleanupDistance.get() <= 0 || this.isWithinChunkDistance(pos, (Integer)this.chunkCleanupDistance.get()))
                  && this.cobblestonePositions.add(pos)) {
                  addedCount++;
               }
            } else {
               ignoredCount++;
            }
         }

         int removedCount = 0;
         Set<BlockPos> toRemove = new HashSet<>();

         for (BlockPos posx : this.cobblestonePositions) {
            ChunkPos blockChunk = new ChunkPos(posx);
            if (blockChunk.equals(cpos) && !chunkCobblestone.contains(posx)) {
               toRemove.add(posx);
               removedCount++;
            }
         }

         this.cobblestonePositions.removeAll(toRemove);
         if ((Boolean)this.cobblestoneChat.get() && (addedCount > 0 || removedCount > 0 || ignoredCount > 0)) {
            if ((Boolean)this.useThreading.get() && (Boolean)this.limitChatSpam.get()) {
               if (addedCount > 0 || removedCount > 0 || ignoredCount > 0) {
                  String message = "§7[§8Cobblestone ESP§7] §8Chunk " + cpos.x + "," + cpos.z + "§7: ";
                  if (addedCount > 0) {
                     message = message + "§a+" + addedCount + " valid ";
                  }

                  if (removedCount > 0) {
                     message = message + "§c-" + removedCount + " ";
                  }

                  if (ignoredCount > 0) {
                     message = message + "§7(" + ignoredCount + " ignored) ";
                  }

                  message = message + "§7blocks";
                  this.info(message, new Object[0]);
               }
            } else if (!(Boolean)this.useThreading.get()) {
               for (BlockPos posxx : chunkCobblestone) {
                  if (!this.shouldFilterCobblestone(posxx) && !this.cobblestonePositions.contains(posxx)) {
                     this.info("§7[§8Cobblestone ESP§7] §aValid cobblestone at " + posxx.toShortString(), new Object[0]);
                  }
               }
            }
         }

         return addedCount;
      }
   }

   private boolean shouldFilterCobblestone(BlockPos pos) {
      for (int dx = -(Integer)this.mossyAvoidRadius.get(); dx <= this.mossyAvoidRadius.get(); dx++) {
         for (int dy = -(Integer)this.mossyAvoidRadius.get(); dy <= this.mossyAvoidRadius.get(); dy++) {
            for (int dz = -(Integer)this.mossyAvoidRadius.get(); dz <= this.mossyAvoidRadius.get(); dz++) {
               if (dx != 0 || dy != 0 || dz != 0) {
                  BlockPos checkPos = pos.method_10069(dx, dy, dz);
                  BlockState checkState = this.mc.world.getBlockState(checkPos);
                  if (checkState.isOf(Blocks.field_9989)) {
                     return true;
                  }
               }
            }
         }
      }

      for (int dx = -(Integer)this.lavaAvoidRadius.get(); dx <= this.lavaAvoidRadius.get(); dx++) {
         for (int dy = -(Integer)this.lavaAvoidRadius.get(); dy <= this.lavaAvoidRadius.get(); dy++) {
            for (int dzx = -(Integer)this.lavaAvoidRadius.get(); dzx <= this.lavaAvoidRadius.get(); dzx++) {
               if (dx != 0 || dy != 0 || dzx != 0) {
                  BlockPos checkPos = pos.method_10069(dx, dy, dzx);
                  BlockState checkState = this.mc.world.getBlockState(checkPos);
                  if (checkState.getFluidState().getFluid() == Fluids.LAVA) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean isWithinRadius(BlockPos pos1, BlockPos pos2, int radius) {
      int dx = Math.abs(pos1.getX() - pos2.getX());
      int dy = Math.abs(pos1.getY() - pos2.getY());
      int dz = Math.abs(pos1.getZ() - pos2.getZ());
      double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
      return distance <= radius;
   }

   private int filterNearbyBlocks(BlockPos center, int radius) {
      Set<BlockPos> toRemove = new HashSet<>();

      for (BlockPos cobblestonePos : this.cobblestonePositions) {
         if (this.isWithinRadius(cobblestonePos, center, radius)) {
            toRemove.add(cobblestonePos);
         }
      }

      for (BlockPos pos : toRemove) {
         this.cobblestonePositions.remove(pos);
      }

      return toRemove.size();
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && (Boolean)this.showCobblestone.get()) {
         if ((Integer)this.chunkCleanupDistance.get() > 0) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lastCleanupTime > (Double)this.cleanupInterval.get() * 1000.0) {
               this.cleanupFarChunks();
               this.lastCleanupTime = currentTime;
            }
         }

         Vec3d playerPos = this.mc.player.getLerpedPos(event.tickDelta);
         Color cobblestoneRenderColor = new Color((Color)this.cobblestoneColor.get());
         Color tracerRenderColor = new Color((Color)this.tracerColor.get());
         int renderDistance = (Integer)this.mc.options.getViewDistance().getValue() * 16;

         for (BlockPos pos : this.cobblestonePositions) {
            if (this.isWithinRenderDistance(playerPos, pos, renderDistance)
               && ((Integer)this.chunkCleanupDistance.get() <= 0 || this.isWithinChunkDistance(pos, (Integer)this.chunkCleanupDistance.get()))) {
               event.renderer.box(pos, cobblestoneRenderColor, cobblestoneRenderColor, (ShapeMode)this.shapeMode.get(), 0);
               if ((Boolean)this.tracers.get()) {
                  this.renderTracer(event, playerPos, pos, tracerRenderColor);
               }
            }
         }
      }
   }

   private void cleanupFarChunks() {
      if (this.mc.player != null && (Integer)this.chunkCleanupDistance.get() > 0) {
         int cleanupDistance = (Integer)this.chunkCleanupDistance.get();
         BlockPos playerPos = this.mc.player.getBlockPos();
         ChunkPos playerChunk = new ChunkPos(playerPos);
         int sizeBefore = this.cobblestonePositions.size();
         Set<BlockPos> positionsToCheck = new HashSet<>(this.cobblestonePositions);
         int removedCount = 0;

         for (BlockPos pos : positionsToCheck) {
            if (!this.isWithinChunkDistance(pos, playerChunk, cleanupDistance) && this.cobblestonePositions.remove(pos)) {
               removedCount++;
            }
         }

         if ((Boolean)this.cobblestoneChat.get() && removedCount > 0) {
            String message = "§7[§8Cobblestone ESP§7] §cCleaned up " + removedCount + " §7blocks beyond " + cleanupDistance + " chunks.";
            message = message + " Remaining: §a" + this.cobblestonePositions.size() + " §7blocks.";
            this.info(message, new Object[0]);
         }
      }
   }

   private boolean isWithinChunkDistance(BlockPos blockPos, int maxChunks) {
      return this.mc.player == null ? true : this.isWithinChunkDistance(blockPos, new ChunkPos(this.mc.player.getBlockPos()), maxChunks);
   }

   private boolean isWithinChunkDistance(BlockPos blockPos, ChunkPos playerChunk, int maxChunks) {
      ChunkPos blockChunk = new ChunkPos(blockPos);
      int chunkDistanceX = Math.abs(blockChunk.x - playerChunk.x);
      int chunkDistanceZ = Math.abs(blockChunk.z - playerChunk.z);
      return chunkDistanceX <= maxChunks && chunkDistanceZ <= maxChunks;
   }

   private boolean isWithinChunkDistance(ChunkPos chunkPos, ChunkPos playerChunk, int maxChunks) {
      int chunkDistanceX = Math.abs(chunkPos.x - playerChunk.x);
      int chunkDistanceZ = Math.abs(chunkPos.z - playerChunk.z);
      return chunkDistanceX <= maxChunks && chunkDistanceZ <= maxChunks;
   }

   private void renderTracer(Render3DEvent event, Vec3d playerPos, BlockPos blockPos, Color tracerColor) {
      Vec3d blockCenter = Vec3d.ofCenter(blockPos);
      Vec3d startPos;
      if (this.mc.options.getPerspective().isFirstPerson()) {
         Vec3d lookDirection = this.mc.player.getRotationVector();
         startPos = new Vec3d(
            playerPos.x + lookDirection.x * 0.5,
            playerPos.y + this.mc.player.getEyeHeight(this.mc.player.getPose()) + lookDirection.y * 0.5,
            playerPos.z + lookDirection.z * 0.5
         );
      } else {
         startPos = new Vec3d(
            playerPos.x, playerPos.y + this.mc.player.getEyeHeight(this.mc.player.getPose()), playerPos.z
         );
      }

      event.renderer
         .line(
            startPos.x, startPos.y, startPos.z, blockCenter.x, blockCenter.y, blockCenter.z, tracerColor
         );
   }

   private boolean isWithinRenderDistance(Vec3d playerPos, BlockPos blockPos, int renderDistance) {
      double dx = playerPos.x - blockPos.getX() - 0.5;
      double dz = playerPos.z - blockPos.getZ() - 0.5;
      double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
      return horizontalDistance <= renderDistance;
   }
}
