package com.vrzt.zinc.modules.Zinc;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.client.MinecraftClient;

public class NoBlockInteract extends Module {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private final Set<Block> blockedBlocks = Set.of(
      Blocks.field_10034,
      Blocks.field_10443,
      Blocks.field_10380,
      Blocks.field_9980,
      Blocks.field_10485,
      Blocks.field_10535,
      Blocks.field_16330,
      Blocks.field_16328,
      Blocks.field_16329,
      Blocks.field_10181,
      Blocks.field_16333,
      Blocks.field_16334,
      Blocks.field_10603,
      Blocks.field_10199,
      Blocks.field_10407,
      Blocks.field_10063,
      Blocks.field_10203,
      Blocks.field_10600,
      Blocks.field_10275,
      Blocks.field_10051,
      Blocks.field_10140,
      Blocks.field_10320,
      Blocks.field_10532,
      Blocks.field_10268,
      Blocks.field_10605,
      Blocks.field_10373,
      Blocks.field_10055,
      Blocks.field_10068,
      Blocks.field_10371
   );

   public NoBlockInteract() {
      super(ZincAddon.Zinc, "no-block-interact", "Lets you pearl through containers by blocking GUI interactions but still throwing pearls.");
   }

   @EventHandler
   private void onSendPacket(Send event) {
      if (this.mc.player != null && this.mc.world != null) {
         if (event.packet instanceof PlayerInteractBlockC2SPacket packet) {
            BlockPos pos = packet.getBlockHitResult().getBlockPos();
            Block block = this.mc.world.getBlockState(pos).getBlock();
            if (!this.blockedBlocks.contains(block)) {
               return;
            }

            if (this.mc.player.getMainHandStack().getItem() == Items.field_8634) {
               event.cancel();
               this.mc.interactionManager.interactItem(this.mc.player, Hand.field_5808);
               this.mc.player.swingHand(Hand.field_5808);
            } else if (this.mc.player.getOffHandStack().getItem() == Items.field_8634) {
               event.cancel();
               this.mc.interactionManager.interactItem(this.mc.player, Hand.field_5810);
               this.mc.player.swingHand(Hand.field_5810);
            } else {
               event.cancel();
               this.mc.player.swingHand(Hand.field_5808);
            }
         }
      }
   }
}
