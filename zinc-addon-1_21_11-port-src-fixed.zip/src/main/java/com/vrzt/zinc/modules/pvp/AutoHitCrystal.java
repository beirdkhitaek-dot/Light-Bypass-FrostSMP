package com.vrzt.zinc.modules.pvp;

import com.vrzt.zinc.ZincAddon;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import com.vrzt.zinc.mixins.IMouseAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;

public class AutoHitCrystal extends Module {
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgItems = this.settings.createGroup("Activation Items");
   private final Setting<Boolean> checkSword = this.sgItems.add(((Builder)((Builder)new Builder().name("check-sword")).defaultValue(true)).build());
   private final Setting<Boolean> checkTotem = this.sgItems.add(((Builder)((Builder)new Builder().name("check-totem")).defaultValue(true)).build());
   private int tickStage = 0;
   private boolean prevPressed = false;
   private KeyBinding activeHotbarKey = null;
   private int originalSlot = -1;

   public AutoHitCrystal() {
      super(ZincAddon.pvp, "auto-hit-crystal", "Hardcoded Right-Click Swap: Obby -> Crystals -> Return.");
   }

   public void onDeactivate() {
      this.resetLogic();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (this.mc.player != null && this.mc.world != null && this.mc.currentScreen == null) {
         boolean isLookingAtBlock = this.mc.crosshairTarget != null && this.mc.crosshairTarget.getType() == Type.field_1332;
         boolean isPressed = this.mc.options.useKey.isPressed() && isLookingAtBlock;
         boolean risingEdge = isPressed && !this.prevPressed;
         this.prevPressed = isPressed;
         if (!isPressed) {
            if (this.tickStage != 0) {
               this.resetLogic();
            }
         } else {
            switch (this.tickStage) {
               case 0:
                  if (!risingEdge) {
                     return;
                  }

                  if (this.mc.crosshairTarget instanceof BlockHitResult bhr) {
                     Block block = this.mc.world.getBlockState(bhr.getBlockPos()).getBlock();
                     if (block == Blocks.field_10540 || block == Blocks.field_9987) {
                        return;
                     }
                  }

                  if (!this.isAllowedItem(this.mc.player.getMainHandStack())) {
                     return;
                  }

                  int obbySlot = this.findSlot(Items.OBSIDIAN);
                  if (obbySlot != -1) {
                     this.originalSlot = this.mc.player.getInventory().getSelectedSlot();
                     this.hardwareFullSwap(obbySlot);
                     this.tickStage = 1;
                  }
                  break;
               case 1:
                  this.tickStage = 2;
                  break;
               case 2:
                  int crystalSlot = this.findSlot(Items.field_8301);
                  if (crystalSlot != -1) {
                     this.hardwareFullSwap(crystalSlot);
                     this.tickStage = 3;
                  } else {
                     this.resetLogic();
                  }
                  break;
               case 3:
                  this.tickStage = 4;
                  break;
               case 4:
                  if (this.originalSlot != -1) {
                     this.hardwareFullSwap(this.originalSlot);
                  }

                  this.resetLogic();
            }
         }
      }
   }

   private void hardwareFullSwap(int slot) {
      if (this.mc.player != null && slot >= 0 && slot <= 8) {
         this.releaseHotbarKeys();
         this.activeHotbarKey = this.mc.options.hotbarKeys[slot];
         this.activeHotbarKey.setPressed(true);
         IMouseAccessor mouse = (IMouseAccessor)((IMinecraftClientAccessor)this.mc).getMouse();
         long window = this.mc.getWindow().getHandle();

         for (int safety = 0; this.mc.player.getInventory().getSelectedSlot() != slot && safety < 10; safety++) {
            int current = this.mc.player.getInventory().getSelectedSlot();
            int diff = slot - current;
            double scrollDir = diff > 0 ? -1.0 : 1.0;
            if (Math.abs(diff) > 4) {
               scrollDir *= -1.0;
            }

            mouse.invokeOnMouseScroll(window, 0.0, scrollDir);
         }

         this.mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void resetLogic() {
      this.tickStage = 0;
      this.originalSlot = -1;
      this.releaseHotbarKeys();
   }

   private void releaseHotbarKeys() {
      if (this.activeHotbarKey != null) {
         this.activeHotbarKey.setPressed(false);
         this.activeHotbarKey = null;
      }
   }

   private boolean isAllowedItem(ItemStack stack) {
      String name = stack.getItem().toString().toLowerCase();
      return this.checkSword.get() && name.contains("sword") ? true : (Boolean)this.checkTotem.get() && stack.isOf(Items.field_8288);
   }

   private int findSlot(Item item) {
      for (int i = 0; i < 9; i++) {
         if (this.mc.player.getInventory().getStack(i).isOf(item)) {
            return i;
         }
      }

      return -1;
   }
}
