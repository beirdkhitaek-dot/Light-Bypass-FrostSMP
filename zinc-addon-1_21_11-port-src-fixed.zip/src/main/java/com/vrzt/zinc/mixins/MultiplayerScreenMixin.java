package com.vrzt.zinc.mixins;

import com.vrzt.zinc.utils.zinc.SessionUtils;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MultiplayerScreen.class})
public class MultiplayerScreenMixin extends Screen {
   @Unique
   private TextFieldWidget tokenField;
   @Unique
   private Text statusText = Text.empty();

   protected MultiplayerScreenMixin(Text title) {
      super(title);
   }

   @Inject(
      method = {"init()V"},
      at = {@At("TAIL")}
   )
   private void addZincLoginComponents(CallbackInfo ci) {
      int fieldWidth = this.textRenderer.getWidth("Paste Token...") + 20;
      int buttonWidth = 45;
      int height = 20;
      int padding = 5;
      int spacing = 2;
      int fieldY = this.height - height - padding;
      int buttonX = padding + fieldWidth + spacing;
      this.tokenField = new TextFieldWidget(this.textRenderer, padding, fieldY, fieldWidth, height, Text.literal("Token"));
      this.tokenField.setMaxLength(2048);
      this.tokenField.setPlaceholder(Text.literal("Paste Token..."));
      this.addSelectableChild(this.tokenField);
      this.addDrawableChild(ButtonWidget.builder(Text.literal("Login"), button -> {
         String token = this.tokenField.getText().trim();
         if (!token.isEmpty()) {
            this.statusText = Text.literal("§eChecking...");
            SessionUtils.setSession(token, success -> {
               this.statusText = success ? Text.literal("§aApproved!") : Text.literal("§cInvalid!");
               this.tokenField.setText("");
            });
         }
      }).dimensions(buttonX, fieldY, buttonWidth, height).build());
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;IIF)V"},
      at = {@At("TAIL")}
   )
   private void renderZincUI(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (this.tokenField != null) {
         this.tokenField.render(context, mouseX, mouseY, delta);
         if (!this.statusText.getString().isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, this.statusText, 5, this.height - 37, 16777215);
         }
      }
   }
}
