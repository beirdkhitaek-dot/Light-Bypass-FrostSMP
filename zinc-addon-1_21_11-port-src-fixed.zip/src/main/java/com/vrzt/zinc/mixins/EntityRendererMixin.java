package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.pvp.NameProtectV2;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntityRenderer.class})
public abstract class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
   public EntityRendererMixin() {
   }

   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V"},
      at = {@At("TAIL")}
   )
   private void onUpdateRenderState(T entity, S state, float tickDelta, CallbackInfo ci) {
      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      MinecraftClient mc = MinecraftClient.getInstance();
      if (module != null && module.isActive() && entity instanceof PlayerEntity player && state instanceof PlayerEntityRenderState playerState) {
         boolean isNPC = mc.getNetworkHandler().getPlayerListEntry(player.getUuid()) == null;
         if (isNPC) {
            playerState.displayName = null;
            return;
         }

         if (module.shouldProtect(player)) {
            playerState.displayName = player == mc.player ? null : module.getRenderText(player);
         }
      }
   }
}
