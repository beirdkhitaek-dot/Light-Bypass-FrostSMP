package com.vrzt.zinc.mixins;

import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({Mouse.class})
public interface IMouseAccessor {
   @Invoker("onMouseScroll")
   void invokeOnMouseScroll(long var1, double var3, double var5);

}
