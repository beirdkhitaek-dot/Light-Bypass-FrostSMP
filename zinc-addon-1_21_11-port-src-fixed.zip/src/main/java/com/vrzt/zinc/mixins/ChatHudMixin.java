package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.pvp.NameProtectV2;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.text.Text;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({ChatHud.class})
public class ChatHudMixin {
   public ChatHudMixin() {
   }

   @ModifyVariable(
      method = {"addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private Text onAddMessage(Text text) {
      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (module != null && module.isActive() && (Boolean)module.protectChat.get()) {
         try {
            String original = text.getString();
            String replaced = module.replaceNameInText(original);
            if (!original.equals(replaced)) {
               return Text.literal(replaced);
            }
         } catch (Exception var5) {
         }
      }

      return text;
   }
}
