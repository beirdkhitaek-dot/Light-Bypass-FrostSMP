package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.pvp.NameProtectV2;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.bar.ExperienceBar;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceBar.class)
public class ExperienceBarMixin {
   @Inject(method = "renderBar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
   private void zinc$hideExp(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (module != null && module.isActive() && (Boolean)module.hideExp.get()) {
         ci.cancel();
      }
   }
}
