package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.Render.ZincFreecam;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.entity.Entity;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Camera.class})
public abstract class CameraMixin {
   public CameraMixin() {
   }

   @Shadow
   protected abstract void setPos(double var1, double var3, double var5);

   @Shadow
   protected abstract void setRotation(float var1, float var2);

   @Inject(
      method = {"update(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;ZZF)V"},
      at = {@At("TAIL")}
   )
   private void onUpdate(net.minecraft.world.World area, Entity focusedEntity, boolean thirdPerson, boolean frontView, float tickDelta, CallbackInfo ci) {
      ZincFreecam freecam = (ZincFreecam)Modules.get().get(ZincFreecam.class);
      if (freecam != null && freecam.isActive()) {
         this.setPos(freecam.getX(tickDelta), freecam.getY(tickDelta), freecam.getZ(tickDelta));
         this.setRotation(freecam.getYaw(tickDelta), freecam.getPitch(tickDelta));
      }
   }

   @Inject(
      method = {"isThirdPerson()Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsThirdPerson(CallbackInfoReturnable<Boolean> cir) {
      if (Modules.get().isActive(ZincFreecam.class)) {
         cir.setReturnValue(true);
      }
   }

   @Inject(
      method = {"getFocusedEntity()Lnet/minecraft/entity/Entity;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetFocusedEntity(CallbackInfoReturnable<Entity> cir) {
   }
}
