package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.Render.ZincFreecam;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.entity.Entity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderManager.class})
public class EntityRenderDispatcherMixin {
   public EntityRenderDispatcherMixin() {
   }

   @Inject(
      method = {"shouldRender(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/Frustum;DDD)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onShouldRender(Entity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
      ZincFreecam freecam = (ZincFreecam)Modules.get().get(ZincFreecam.class);
      if (freecam != null && freecam.isActive() && entity == MinecraftClient.getInstance().player) {
         cir.setReturnValue(true);
      }
   }
}
