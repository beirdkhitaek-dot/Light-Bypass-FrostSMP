package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.pvp.NameProtectV2;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractClientPlayerEntity.class})
public abstract class AbstractClientPlayerEntityMixin {
   public AbstractClientPlayerEntityMixin() {
   }

   @Inject(
      method = {"getSkin()Lnet/minecraft/entity/player/SkinTextures;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetSkinTextures(CallbackInfoReturnable<SkinTextures> info) {
      NameProtectV2 module = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (module != null && module.isActive()) {
         PlayerEntity player = (PlayerEntity)(Object)this;
         if (module.shouldHideSkin(player)) {
            info.setReturnValue(DefaultSkinHelper.getSkinTextures(player.getUuid()));
         }
      }
   }
}
