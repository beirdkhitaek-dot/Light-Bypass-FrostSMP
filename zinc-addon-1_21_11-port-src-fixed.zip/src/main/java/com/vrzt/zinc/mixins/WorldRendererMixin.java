package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.Render.ZincFreecam;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({WorldRenderer.class})
public class WorldRendererMixin {
   public WorldRendererMixin() {
   }

   @Inject(
      method = {"isRenderingReady(Lnet/minecraft/util/math/BlockPos;)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsRenderingReady(CallbackInfoReturnable<Boolean> cir) {
      if (Modules.get().isActive(ZincFreecam.class)) {
         cir.setReturnValue(true);
      }
   }
}
