package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.Render.ZincFreecam;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public abstract class MouseMixin {
   @Shadow
   private double cursorDeltaX;
   @Shadow
   private double cursorDeltaY;

   public MouseMixin() {
   }

   @Inject(
      method = {"updateMouse(D)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onUpdateMouse(CallbackInfo ci) {
      ZincFreecam freecam = (ZincFreecam)Modules.get().get(ZincFreecam.class);
      if (freecam != null && freecam.isActive()) {
         freecam.changeLookDirection(this.cursorDeltaX, this.cursorDeltaY);
         this.cursorDeltaX = 0.0;
         this.cursorDeltaY = 0.0;
         ci.cancel();
      }
   }
}
