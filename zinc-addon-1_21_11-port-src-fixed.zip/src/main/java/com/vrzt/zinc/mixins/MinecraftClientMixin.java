package com.vrzt.zinc.mixins;

import com.mojang.authlib.minecraft.UserApiService;
import com.vrzt.zinc.core.ZincUserApiWrapper;
import com.vrzt.zinc.mixininterface.IMinecraftClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MinecraftClient.class})
public abstract class MinecraftClientMixin implements IMinecraftClient {
   @Shadow
   private UserApiService userApiService;
   @Shadow
   private Session session;

   public MinecraftClientMixin() {
   }

   @Shadow
   protected abstract boolean doAttack();

   @Shadow
   protected abstract void doItemUse();

   @Inject(
      method = {"createUserApiService(Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;Lnet/minecraft/client/RunArgs;)Lcom/mojang/authlib/minecraft/UserApiService;"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void onClearRestrictions(CallbackInfoReturnable<UserApiService> cir) {
      cir.setReturnValue(new ZincUserApiWrapper((UserApiService)cir.getReturnValue()));
   }

   @Override
   public boolean zinc$doAttack() {
      return this.doAttack();
   }

   @Override
   public void zinc$doItemUse() {
      this.doItemUse();
   }

   @Override
   public void setSession(Session session) {
      this.session = session;
   }
}
