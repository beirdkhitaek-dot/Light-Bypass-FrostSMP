package com.vrzt.zinc.mixins;

import com.vrzt.zinc.modules.pvp.NameProtectV2;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.text.Text;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListHud.class})
public class PlayerListHudMixin {
   public PlayerListHudMixin() {
   }

   @Inject(
      method = {"getPlayerName(Lnet/minecraft/client/network/PlayerListEntry;)Lnet/minecraft/text/Text;"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void onGetPlayerName(PlayerListEntry entry, CallbackInfoReturnable<Text> info) {
      NameProtectV2 nameProtect = (NameProtectV2)Modules.get().get(NameProtectV2.class);
      if (nameProtect != null && nameProtect.isActive()) {
         Text protectedName = nameProtect.getTabNameFromEntry(entry);
         if (protectedName != null) {
            info.setReturnValue(protectedName);
         }
      }
   }
}
