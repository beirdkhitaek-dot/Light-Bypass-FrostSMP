package com.vrzt.zinc.mixins;

import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.login.LoginHelloC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({ClientConnection.class})
public class MixinClientConnection {
   public MixinClientConnection() {
   }

   @ModifyVariable(
      method = {"send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private Packet<?> onSendPacket(Packet<?> packet) {
      return (Packet<?>)(packet instanceof LoginHelloC2SPacket loginPacket ? new LoginHelloC2SPacket(loginPacket.comp_765(), loginPacket.comp_907()) : packet);
   }
}
