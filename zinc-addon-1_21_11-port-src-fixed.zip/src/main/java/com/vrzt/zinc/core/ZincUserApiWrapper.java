package com.vrzt.zinc.core;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSet.Builder;
import com.mojang.authlib.minecraft.TelemetrySession;
import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.minecraft.UserApiService.UserFlag;
import com.mojang.authlib.minecraft.UserApiService.UserProperties;
import com.mojang.authlib.minecraft.report.AbuseReportLimits;
import com.mojang.authlib.yggdrasil.request.AbuseReportRequest;
import com.mojang.authlib.yggdrasil.response.KeyPairResponse;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executor;

public class ZincUserApiWrapper implements UserApiService {
   private final UserApiService service;
   private static final UserProperties FORCED_PROPERTIES;

   public ZincUserApiWrapper(UserApiService service) {
      this.service = service;
   }

   public UserProperties fetchProperties() {
      return FORCED_PROPERTIES;
   }

   public boolean isBlockedPlayer(UUID playerID) {
      return this.service.isBlockedPlayer(playerID);
   }

   public void refreshBlockList() {
      this.service.refreshBlockList();
   }

   public TelemetrySession newTelemetrySession(Executor executor) {
      return TelemetrySession.DISABLED;
   }

   public KeyPairResponse getKeyPair() {
      return this.service.getKeyPair();
   }

   public void reportAbuse(AbuseReportRequest request) {
      this.service.reportAbuse(request);
   }

   public boolean canSendReports() {
      return this.service.canSendReports();
   }

   public AbuseReportLimits getAbuseReportLimits() {
      return this.service.getAbuseReportLimits();
   }

   static {
      Builder<UserFlag> flags = ImmutableSet.builder();
      flags.add(UserFlag.CHAT_ALLOWED);
      flags.add(UserFlag.SERVERS_ALLOWED);
      flags.add(UserFlag.REALMS_ALLOWED);
      FORCED_PROPERTIES = new UserProperties(flags.build(), Map.of());
   }
}
