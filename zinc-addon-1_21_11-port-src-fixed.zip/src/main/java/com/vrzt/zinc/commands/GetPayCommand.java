package com.vrzt.zinc.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.util.Formatting;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;

public class GetPayCommand extends Command {
   public static long lockUntil = 0L;

   public GetPayCommand() {
      super("getpay", "1:1 Fake Receive with 1-tick Action Bar priority.", new String[0]);
   }

   public void build(LiteralArgumentBuilder<CommandSource> builder) {
      builder.then(
         argument("player", StringArgumentType.word())
            .then(
               argument("amount", StringArgumentType.word())
                  .executes(
                     context -> {
                        String player = StringArgumentType.getString(context, "player");
                        String amount = StringArgumentType.getString(context, "amount").toUpperCase();
                        Text playerText = Text.literal(player)
                           .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(43775)));
                        Text fakeMessage = Text.literal("")
                           .append(playerText)
                           .append(Text.literal(" paid you ").formatted(Formatting.field_1080))
                           .append(Text.literal("$" + amount).formatted(Formatting.field_1060))
                           .append(Text.literal(".").formatted(Formatting.field_1080));
                        if (mc.player != null) {
                           lockUntil = System.currentTimeMillis() + 350L;
                           mc.player.sendMessage(fakeMessage, false);
                           mc.player.sendMessage(fakeMessage, true);
                        }

                        return 1;
                     }
                  )
            )
      );
   }
}
