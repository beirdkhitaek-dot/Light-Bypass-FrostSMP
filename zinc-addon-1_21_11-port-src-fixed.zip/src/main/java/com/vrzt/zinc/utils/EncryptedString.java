package com.vrzt.zinc.utils;

import java.nio.CharBuffer;
import java.security.SecureRandom;
import java.util.Arrays;
import org.jetbrains.annotations.NotNull;

public class EncryptedString implements AutoCloseable, CharSequence {
   private final char[] encryptionKey;
   private final char[] encryptedValue;
   private final int length;
   private static final SecureRandom secureRandom = new SecureRandom();
   private boolean isClosed = false;

   public EncryptedString(String input) {
      if (input == null) {
         throw new IllegalArgumentException("Input string cannot be null");
      } else {
         this.length = input.length();
         this.encryptionKey = generateRandomKey(Math.min(this.length, 128));
         this.encryptedValue = new char[this.length];
         input.getChars(0, this.length, this.encryptedValue, 0);
         applyXorCipher(this.encryptedValue, this.encryptionKey, 0, this.length);
      }
   }

   public EncryptedString(char[] encryptedData, char[] key) {
      if (encryptedData == null || key == null) {
         throw new IllegalArgumentException("Neither encrypted value nor key can be null");
      } else if (key.length == 0) {
         throw new IllegalArgumentException("Encryption key cannot be empty");
      } else {
         this.length = encryptedData.length;
         this.encryptedValue = Arrays.copyOf(encryptedData, encryptedData.length);
         this.encryptionKey = Arrays.copyOf(key, key.length);
      }
   }

   public static EncryptedString of(String text) {
      return new EncryptedString(text);
   }

   public static EncryptedString of(String encryptedText, String key) {
      if (encryptedText != null && key != null) {
         return new EncryptedString(encryptedText.toCharArray(), key.toCharArray());
      } else {
         throw new IllegalArgumentException("Neither encrypted data nor key can be null");
      }
   }

   private static char[] generateRandomKey(int length) {
      char[] key = new char[length];

      for (int i = 0; i < length; i++) {
         key[i] = (char)secureRandom.nextInt(65536);
      }

      return key;
   }

   private static void applyXorCipher(char[] target, char[] key, int offset, int count) {
      for (int i = 0; i < count; i++) {
         int targetIndex = offset + i;
         target[targetIndex] ^= key[i % key.length];
      }
   }

   @Override
   public int length() {
      this.ensureNotClosed();
      return this.length;
   }

   @Override
   public char charAt(int index) {
      this.ensureNotClosed();
      if (index >= 0 && index < this.length) {
         return (char)(this.encryptedValue[index] ^ this.encryptionKey[index % this.encryptionKey.length]);
      } else {
         throw new IndexOutOfBoundsException("Index: " + index + ", Length: " + this.length);
      }
   }

   @NotNull
   @Override
   public CharSequence subSequence(int start, int end) {
      this.ensureNotClosed();
      if (start >= 0 && end <= this.length && start <= end) {
         int subLength = end - start;
         char[] subValue = new char[subLength];
         System.arraycopy(this.encryptedValue, start, subValue, 0, subLength);
         char[] subKey = new char[subLength];

         for (int i = 0; i < subLength; i++) {
            subKey[i] = this.encryptionKey[(start + i) % this.encryptionKey.length];
         }

         applyXorCipher(subValue, this.encryptionKey, 0, subLength);
         applyXorCipher(subValue, subKey, 0, subLength);
         return new EncryptedString(subValue, subKey);
      } else {
         throw new IndexOutOfBoundsException("Invalid range: " + start + " to " + end);
      }
   }

   @NotNull
   @Override
   public String toString() {
      this.ensureNotClosed();
      char[] decryptedBuffer = new char[this.length];

      for (int i = 0; i < this.length; i++) {
         decryptedBuffer[i] = this.charAt(i);
      }

      String result = new String(decryptedBuffer);
      Arrays.fill(decryptedBuffer, '\u0000');
      return result;
   }

   @NotNull
   public String decryptToString() {
      return this.toString();
   }

   public CharBuffer asCharBuffer() {
      this.ensureNotClosed();
      CharBuffer buffer = CharBuffer.allocate(this.length);

      for (int i = 0; i < this.length; i++) {
         buffer.put(i, this.charAt(i));
      }

      buffer.flip();
      return buffer.asReadOnlyBuffer();
   }

   @Override
   public void close() {
      if (!this.isClosed) {
         Arrays.fill(this.encryptedValue, '\u0000');
         Arrays.fill(this.encryptionKey, '\u0000');
         this.isClosed = true;
      }
   }

   private void ensureNotClosed() {
      if (this.isClosed) {
         throw new IllegalStateException("This EncryptedString has been closed and cannot be used");
      }
   }

   @Override
   public boolean equals(Object other) {
      this.ensureNotClosed();
      if (this == other) {
         return true;
      } else if (!(other instanceof CharSequence otherSeq)) {
         return false;
      } else if (this.length != otherSeq.length()) {
         return false;
      } else {
         for (int i = 0; i < this.length; i++) {
            if (this.charAt(i) != otherSeq.charAt(i)) {
               return false;
            }
         }

         return true;
      }
   }

   @Override
   public int hashCode() {
      this.ensureNotClosed();
      int hash = 0;

      for (int i = 0; i < this.length; i++) {
         hash = 31 * hash + this.charAt(i);
      }

      return hash;
   }
}
