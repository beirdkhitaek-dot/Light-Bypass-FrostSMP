package com.vrzt.zinc.utils;

import java.util.Objects;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.block.RespawnAnchorBlock;

public final class BlockUtil {
   public BlockUtil() {
   }

   public static Stream<WorldChunk> getLoadedChunks() {
      int radius = Math.max(2, MeteorClient.mc.options.getClampedViewDistance()) + 3;
      int diameter = radius * 2 + 1;
      ChunkPos center = MeteorClient.mc.player.getChunkPos();
      ChunkPos min = new ChunkPos(center.x - radius, center.z - radius);
      ChunkPos max = new ChunkPos(center.x + radius, center.z - radius);
      return Stream.<ChunkPos>iterate(min, pos -> {
            int x = pos.x;
            int z = pos.z;
            if (++x > max.x) {
               x = min.x;
               z++;
            }

            if (z > max.z) {
               throw new IllegalStateException("Stream limit didn't work.");
            } else {
               return new ChunkPos(x, z);
            }
         })
         .limit((long)diameter * diameter)
         .filter(c -> MeteorClient.mc.world.isChunkLoaded(c.x, c.z))
         .map(c -> MeteorClient.mc.world.method_8497(c.x, c.z))
         .filter(Objects::nonNull);
   }

   public static boolean isBlockAtPosition(BlockPos blockPos, Block block) {
      return MeteorClient.mc.world.getBlockState(blockPos).getBlock() == block;
   }

   public static boolean isRespawnAnchorCharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.field_23152)
         && (Integer)MeteorClient.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) != 0;
   }

   public static boolean isRespawnAnchorUncharged(BlockPos blockPos) {
      return isBlockAtPosition(blockPos, Blocks.field_23152)
         && (Integer)MeteorClient.mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) == 0;
   }

   public static void interactWithBlock(BlockHitResult blockHitResult, boolean shouldSwingHand) {
      ActionResult result = MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, Hand.field_5808, blockHitResult);
      if (result.isAccepted() && shouldSwingHand) {
         MeteorClient.mc.player.swingHand(Hand.field_5808);
      }
   }

   public static void place(BlockPos pos, BlockHitResult hitResult, int slot, boolean swingHand) {
      MeteorClient.mc.player.getInventory().setSelectedSlot(slot);
      ActionResult result = MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, Hand.field_5808, hitResult);
      if (result.isAccepted() && swingHand) {
         MeteorClient.mc.player.swingHand(Hand.field_5808);
      }
   }
}
