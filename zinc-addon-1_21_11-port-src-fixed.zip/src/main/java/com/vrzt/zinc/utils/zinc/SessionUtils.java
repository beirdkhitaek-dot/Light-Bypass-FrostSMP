package com.vrzt.zinc.utils.zinc;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.minecraft.UserApiService;
import com.vrzt.zinc.mixins.IMinecraftClientAccessor;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import net.minecraft.client.session.ProfileKeysImpl;
import net.minecraft.client.session.ProfileKeys;

public class SessionUtils {
   public SessionUtils() {
   }

   public static void setSession(String token, Consumer<Boolean> callback) {
      MinecraftClient mc = MinecraftClient.getInstance();
      new Thread(
            () -> {
               try {
                  URL url = new URL("https://api.minecraftservices.com/minecraft/profile");
                  HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                  conn.setRequestMethod("GET");
                  conn.setRequestProperty("Authorization", "Bearer " + token);
                  if (conn.getResponseCode() == 200) {
                     InputStreamReader reader = new InputStreamReader(conn.getInputStream());
                     JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                     String name = json.get("name").getAsString();
                     String id = json.get("id").getAsString();
                     UUID uuid = UUID.fromString(
                        id.replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{12})", "$1-$2-$3-$4-$5")
                     );
                     Session newSession = new Session(name, uuid, token, Optional.empty(), Optional.empty());
                     mc.execute(() -> {
                        ((IMinecraftClientAccessor)mc).setSession(newSession);
                        UserApiService service = UserApiService.OFFLINE;
                        ProfileKeys newKeys = new ProfileKeysImpl(service, uuid, mc.runDirectory.toPath());
                        ((IMinecraftClientAccessor)mc).setProfileKeys(newKeys);
                        newKeys.fetchKeyPair().thenRun(() -> {
                           System.out.println("[Zinc] Successfully switched to: " + name);
                           callback.accept(true);
                        }).exceptionally(ex -> {
                           callback.accept(true);
                           return null;
                        });
                     });
                  } else {
                     mc.execute(() -> callback.accept(false));
                  }
               } catch (Exception var11) {
                  mc.execute(() -> callback.accept(false));
               }
            }
         )
         .start();
   }
}
