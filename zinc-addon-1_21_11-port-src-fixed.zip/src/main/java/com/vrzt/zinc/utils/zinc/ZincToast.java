package com.vrzt.zinc.utils.zinc;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/**
 * Minimal toast replacement for ZincToast (whose constructor now requires a Builder).
 * Subclasses may override draw() for custom rendering.
 */
public class ZincToast implements Toast {
   private static final long DISPLAY_MS = 5000L;
   private final ItemStack iconStack;
   private final Text titleText;
   private final Text bodyText;
   private Toast.Visibility visibility = Toast.Visibility.SHOW;

   public ZincToast(Item icon, String title, String text) {
      this.iconStack = icon == null ? ItemStack.EMPTY : new ItemStack(icon);
      this.titleText = title == null ? null : Text.literal(title);
      this.bodyText = text == null ? null : Text.literal(text);
   }

   public Toast.Visibility getVisibility() {
      return this.visibility;
   }

   public void update(ToastManager manager, long time) {
      this.visibility = time >= DISPLAY_MS ? Toast.Visibility.HIDE : Toast.Visibility.SHOW;
   }

   public void draw(DrawContext context, TextRenderer textRenderer, long currentTime) {
      context.fill(0, 0, 160, 32, -1442840576);
      if (!this.iconStack.isEmpty()) {
         context.drawItem(this.iconStack, 8, 8);
      }

      if (this.titleText != null) {
         context.drawText(textRenderer, this.titleText, 32, 7, 16777215, false);
      }

      if (this.bodyText != null) {
         context.drawText(textRenderer, this.bodyText, 32, 18, 16777215, false);
      }
   }
}
