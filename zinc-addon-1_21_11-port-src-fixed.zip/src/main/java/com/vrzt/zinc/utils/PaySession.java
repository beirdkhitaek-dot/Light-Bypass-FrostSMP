package com.vrzt.zinc.utils;

public class PaySession {
   private static long lockUntil = 0L;

   public PaySession() {
   }

   public static void lock(long ms) {
      lockUntil = System.currentTimeMillis() + ms;
   }

   public static boolean isLocked() {
      return System.currentTimeMillis() < lockUntil;
   }
}
