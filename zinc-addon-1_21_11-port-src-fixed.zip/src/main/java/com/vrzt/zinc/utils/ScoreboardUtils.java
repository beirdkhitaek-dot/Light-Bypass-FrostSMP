package com.vrzt.zinc.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.text.Text;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;

public class ScoreboardUtils {
   public ScoreboardUtils() {
   }

   public static String getRawScoreboard() {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null && mc.world != null && mc.world.getScoreboard() != null) {
            Scoreboard scoreboard = mc.world.getScoreboard();
            ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.field_45157);
            if (objective == null) {
               return "";
            } else {
               StringBuilder result = new StringBuilder();

               for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
                  if (entry != null) {
                     String name = entry.comp_2127();
                     if (name != null) {
                        Team team = scoreboard.getScoreHolderTeam(name);
                        if (team != null) {
                           Text prefix = team.getPrefix();
                           Text suffix = team.getSuffix();
                           if (prefix != null && suffix != null) {
                              result.append(prefix.getString()).append(name).append(suffix.getString()).append("\n");
                           } else {
                              result.append(name).append("\n");
                           }
                        } else {
                           result.append(name).append("\n");
                        }
                     }
                  }
               }

               return result.toString();
            }
         } else {
            return "";
         }
      } catch (Exception var11) {
         return "";
      }
   }

   public static String getPing() {
      String scoreboard = getRawScoreboard();
      Pattern pattern = Pattern.compile("\\((\\d+)ms\\)");
      Matcher matcher = pattern.matcher(scoreboard);
      if (matcher.find()) {
         return matcher.group(1);
      } else {
         MinecraftClient mc = MinecraftClient.getInstance();
         return mc.player != null && mc.player.networkHandler != null && mc.player.networkHandler.getPlayerListEntry(mc.player.getUuid()) != null
            ? String.valueOf(mc.player.networkHandler.getPlayerListEntry(mc.player.getUuid()).getLatency())
            : "0";
      }
   }

   public static String getMoney() {
      String scoreboard = getRawScoreboard();
      if (scoreboard.isEmpty()) {
         return "0";
      } else {
         Pattern pattern = Pattern.compile("(?:\\$|Money|Balance)\\s*:?\\s*\\$?\\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.\\d+)?[KMB]?)", 2);
         Matcher matcher = pattern.matcher(scoreboard);
         return matcher.find() ? matcher.group(1).replace(",", "") : "0";
      }
   }

   public static String getShards() {
      String scoreboard = getRawScoreboard();
      if (scoreboard.isEmpty()) {
         return "0";
      } else {
         Pattern pattern = Pattern.compile("(?:Shards|Stars?|★)\\s*:?\\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]+)?[KMB]?)", 2);
         Matcher matcher = pattern.matcher(scoreboard);
         return matcher.find() ? matcher.group(1).replace(",", "") : "0";
      }
   }

   public static String getKills() {
      String scoreboard = getRawScoreboard();
      if (scoreboard.isEmpty()) {
         return "0";
      } else {
         Pattern pattern = Pattern.compile("(?:Kills|Kill)\\s*:?\\s*(\\d+)", 2);
         Matcher matcher = pattern.matcher(scoreboard);
         if (matcher.find()) {
            return matcher.group(1);
         } else {
            Pattern kdPattern = Pattern.compile("(?:K/D|Kill/Death)\\s*:?\\s*(\\d+)/\\d+", 2);
            Matcher kdMatcher = kdPattern.matcher(scoreboard);
            return kdMatcher.find() ? kdMatcher.group(1) : "0";
         }
      }
   }

   public static String getDeaths() {
      String scoreboard = getRawScoreboard();
      if (scoreboard.isEmpty()) {
         return "0";
      } else {
         Pattern pattern = Pattern.compile("(?:Deaths|Death)\\s*:?\\s*(\\d+)", 2);
         Matcher matcher = pattern.matcher(scoreboard);
         if (matcher.find()) {
            return matcher.group(1);
         } else {
            Pattern kdPattern = Pattern.compile("(?:K/D|Kill/Death)\\s*:?\\s*\\d+/(\\d+)", 2);
            Matcher kdMatcher = kdPattern.matcher(scoreboard);
            return kdMatcher.find() ? kdMatcher.group(1) : "0";
         }
      }
   }

   public static String getKeyallTimer() {
      String scoreboard = getRawScoreboard();
      Pattern pattern = Pattern.compile("Keyall\\s+([0-9]+[msh]\\s*)+", 2);
      Matcher matcher = pattern.matcher(scoreboard);
      if (matcher.find()) {
         String fullMatch = matcher.group(0);
         return fullMatch.replaceFirst("(?i)Keyall\\s+", "").trim();
      } else {
         return "0m 0s";
      }
   }

   public static String getPlaytime() {
      String scoreboard = getRawScoreboard();
      scoreboard = scoreboard.replaceAll("§.", "");
      Pattern pattern = Pattern.compile("(?:Playtime|Played|Time)\\s*:?\\s*([0-9]+[dhm]\\s*)+", 2);
      Matcher matcher = pattern.matcher(scoreboard);
      if (matcher.find()) {
         String fullMatch = matcher.group(0);
         Pattern timePattern = Pattern.compile("([0-9]+[dhm]\\s*)+");
         Matcher timeMatcher = timePattern.matcher(fullMatch);
         if (timeMatcher.find()) {
            return timeMatcher.group().trim();
         }
      }

      return "0d 0h";
   }

   public static String getTeam() {
      String scoreboard = getRawScoreboard();
      scoreboard = scoreboard.replaceAll("§.", "");
      Pattern pattern = Pattern.compile("(?:Team|Clan|Guild|Faction)\\s*:?\\s*([A-Za-z0-9_]{2,20})", 2);
      Matcher matcher = pattern.matcher(scoreboard);
      return matcher.find() ? matcher.group(1) : "";
   }

   public static String getRegion(boolean replace) {
      if (replace) {
         return "Zinc";
      } else {
         String raw = getRawScoreboard();
         String noColors = raw.replaceAll("§.", "");
         String clean = noColors.replaceAll("[^a-zA-Z\\s]", " ");
         Pattern pattern = Pattern.compile("(EU\\s*West|EU\\s*Central|US\\s*East|NA\\s*East|NA\\s*West|Global|Oceania|AU|OC|Europe|Asia)", 2);
         Matcher matcher = pattern.matcher(clean);
         return matcher.find() ? matcher.group(1).trim() : "EU Central";
      }
   }
}
